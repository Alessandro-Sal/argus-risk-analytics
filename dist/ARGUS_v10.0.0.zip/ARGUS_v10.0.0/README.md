# ARGUS - Risk Analytics & Wealth Intelligence Platform

![ARGUS Banner](docs/argus_banner.jpg)

[![CI Pipeline](https://github.com/Alessandro-Sal/argus-risk-analytics/actions/workflows/ci.yml/badge.svg)](https://github.com/Alessandro-Sal/argus-risk-analytics/actions/workflows/ci.yml)
[![GitHub Pages](https://github.com/Alessandro-Sal/argus-risk-analytics/actions/workflows/deploy-pages.yml/badge.svg)](https://alessandro-sal.github.io/argus-risk-analytics/)
[![Latest Release](https://img.shields.io/github/v/release/Alessandro-Sal/argus-risk-analytics?color=blue&label=version)](https://github.com/Alessandro-Sal/argus-risk-analytics/releases/latest)
[![Python Version](https://img.shields.io/badge/python-3.11%20%7C%203.12-green.svg)](https://www.python.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-purple.svg)](LICENSE.md)
[![Test Suite](https://img.shields.io/badge/PyTest-888%2F888%20PASSED%20(100%25)-brightgreen)](tests/)
[![Documentation: MkDocs](https://img.shields.io/badge/docs-Material%20for%20MkDocs-blue.svg)](https://alessandro-sal.github.io/argus-risk-analytics/)
[![REST API: FastAPI](https://img.shields.io/badge/REST%20API-FastAPI%20%7C%20OpenAPI-009688.svg)](http://localhost:8000/docs)
[![Code Style: Ruff](https://img.shields.io/badge/code%20style-ruff-000000.svg)](https://github.com/astral-sh/ruff)
[![Docker Ready](https://img.shields.io/badge/docker-ready-blue.svg)](docker-compose.yml)

---

## 🚀 Institutional Multi-User Cloud Architecture, Supabase PostgreSQL Persistence, Zero-Leakage Data Isolation, BYOD Vault & Fiscal Intelligence Suite (v10.0.0)

ARGUS v10.0.0 segna il passaggio epocale a una piattaforma **Cloud-Native Multi-Tenant** con persistenza ibrida PostgreSQL/SQLite, isolamento crittografico dei portafogli per ciascun utente e suite fiscale italiana completa:
- **Motore di Persistenza Ibrido Cloud PostgreSQL ⇄ SQLite (`core/cloud_db.py`)**: Layer universale `ArgusConnectionProxy` compatibile simultaneamente con **Supabase PostgreSQL 16 (AWS EU-West-1 Ireland)** tramite SQLAlchemy `QueuePool` (`pool_pre_ping=True`, SSL obbligatorio) e con **SQLite locale (`data/argus_local.db`)** per uso desktop offline. Traduzione trasparente del dialetto SQL (`AUTOINCREMENT` $\leftrightarrow$ `SERIAL`, `INSERT OR IGNORE` $\leftrightarrow$ `ON CONFLICT DO NOTHING`, placeholder parametrizzati).
- **Pre-Splash Institutional Cloud Auth Gate & PBKDF2-SHA256 User Vault (`core/cloud_auth.py`, `components/splash.py`, `core/sidebar.py`)**: Portale di accesso istituzionale full-screen (`render_cloud_auth_gate`) posizionato prima dello splash screen con 3 modalità operative: **🔑 Accedi al tuo Vault** (autenticazione `PBKDF2-HMAC-SHA256` a 120.000 iterazioni con salt crittografico a 16 byte), **📝 Crea Nuovo Account** (provisioning istantaneo di un profilo patrimoniale isolato su cloud) e **🧪 Esplora in Modalità Demo (1-Click)** (accesso sandbox immediato con i 3 archetipi didattici sintetici). Include **Account Identity Badge** (`👑 Owner`, `🔐 Cloud Member`, `🧪 Demo Sandbox`) e pulsante **🚪 Logout / Cambia Account** a 1-click nella Control Room e nella Sidebar.
- **Isolamento Multi-Tenant Zero-Leakage & BYOD Database Override (`core/wealth/wealth_db.py`, `core/db_exporter.py`, `src/0_Control_Room.py`)**: Segregazione rigorosa dei dati su oltre 30 tabelle SQL patrimoniali e di rischio (`_resolve_isolated_portfolio_filter`), prenotazione esclusiva del `profile_id = 1` (`Personale`) per l'account `owner`, targatura nominativa dei portafogli Risk (`owner_username`) e supporto **BYOD (Bring Your Own Database)** per consentire agli utenti avanzati di connettere una propria istanza PostgreSQL personale (Supabase/Neon) in sessione.
- **Suite Fiscale Italiana & Pianificazione Patrimoniale Avanzata (`core/tax_engine.py`, `core/wealth/tax_wealth_engine.py`, `src/pages/6_🧾_Ottimizzazione_Fiscale.py`, `src/pages/18_🏛️_Pianificazione_Fiscale.py`)**: Doppio motore di calcolo plusvalenze (**Costo Medio Ponderato ex Art. 67-68 TUIR** vs simulatore LIFO), regole Crypto-attività 2026 (aliquota 33% diretta vs 26% tramite ETN/ETC), generatore **Quadro RW / IVAFE (0,2% vs 0,4%) / IVIE (1,06%)**, matrice di compensazione **Redditi di Capitale vs Redditi Diversi** con scadenziario quadriennale dello *Zainetto Fiscale* ($T+4$) e simulatore interattivo di Stress Test Normativo.
- **Audit di Sicurezza & Packaging Certificato (`scripts/package_release.py`, `SECURITY.md`)**: Scanner preventivo automatizzato che garantisce l'assenza totale di database personali, backup compressi, cache o credenziali nel repository Git e nell'archivio di rilascio `dist/ARGUS_v10.0.0.zip`.

---

## 🚀 Quant Risk Audit, Exact Euler Homogeneity, Multi-Asset Calendar Harmonization & Dynamic Wealth-Risk Liquidity Bridge (v9.19.0)

ARGUS v9.19.0 consolida l'integrità quantitativa, la quadratura algebrica e l'accuratezza multi-asset dell'intero ecosistema istituzionale:
- **Quadratura Deterministica dei Pesi & Decomposizione di Eulero Esatta (`core/risk_engine.py`, `core/multi_portfolio.py`)**: Pesi calcolati rigorosamente sui controvalori monetari fisici correnti ($w_i = V_i / \sum V_k$) con $\sum w_i = 1.00000000$, eliminando troncamenti su allocazioni frazionarie micro ($w_i < 0.01$). Chiusura esatta $\sum \text{Component VaR}_i = \text{Total Portfolio VaR}$ con test di convergenza $\epsilon_{\text{Euler}} < 10^{-2}\text{ EUR}$, shrinkage Ledoit-Wolf e regolarizzazione spettrale semi-definita positiva (PSD).
- **Sincronizzazione Multi-Asset Calendario Ibrido 252gg vs 365gg (`core/multi_portfolio.py`)**: Compounding geometrico continuo dei rendimenti weekend crypto ($W_t = \prod (1 + R_\tau)$) riproiettati sul calendario lavorativo $B$-days ($R_{\text{Mon}} = \prod_{d \in \{\text{Sab, Dom, Lun}\}} (1 + R_d) - 1$), preservando il rendimento cumulato e la volatilità reale senza giorni spuri a varianza zero.
- **Ponte Dinamico Wealth ⇄ Risk: Liquidity-at-Risk & Buffer Anti-Forced Selling (`core/wealth/wealth_engine.py`, `src/pages/12_🏛️_Wealth_Control_Room.py`)**: Moltiplicatore dinamico della riserva di sicurezza $\mathcal{M}_{\text{risk-buffer}} = 1.0 + 1.5 \cdot \text{CVaR}_{0.95}^{\text{ann}} \cdot w_{\text{equity}}^{\text{NW}}$ per proteggere il patrimonio da vendite forzate a prezzi di saldo (*Forced Selling at Market Trough*) durante i crolli di borsa.
- **Armonizzazione Factsheet & Export Allineati (`core/html_exporter.py`, `core/report_exporter.py`)**: Scalatura uniforme del VaR a 20 giorni su base $\sqrt{20}$ e della volatilità annualizzata su 252 giorni, con perfetta coerenza tra KPI a video e report PDF/HTML/CSV.

---

## 🚀 Institutional Desk Architecture, Methodological Info Boxes, ISDA SIMM™ v2.6, Rough Vol SVI, CDS Tranches, ALM/LDI & Bilateral XVA (v9.18.0)

ARGUS v9.18.0 consolida l'ecosistema istituzionale a **42 pilastri quantitativi e regolamentari** con un'architettura a tab rigorosamente separata, collegamento dinamico al portafoglio attivo (*Master Wealth*) e **Riquadri Informativi Metodologici (`render_institutional_info_box`)** a 3 colonne (*1. Fondamento Matematico & Modello*, *2. Come Leggere i KPI & i Grafici*, *3. Implicazioni Regolamentari & Operative*) su ogni motore:
- **ISDA SIMM™ v2.6 & Uncleared Margin Rules (UMR) (`core/isda_simm_engine.py`, `src/pages/7_🌪️_Stress_Testing.py`)**: Calcolo di *DeltaMargin*, *VegaMargin* e *CurvatureMargin* sulle 6 classi di rischio ISDA con soglie di concentrazione $CR_k$, matrice cross-risk-class $\psi_{r,s}$, verifica soglia UMR €50M e risparmio MVA tramite Central Clearing CCP (MPOR 5d vs 10d).
- **Bilateral XVA & Counterparty Credit Risk Engine (`core/xva_engine.py`, `src/pages/7_🌪️_Stress_Testing.py`)**: Calcolo CVA, DVA, FVA, MVA e KVA, simulazione Monte Carlo profili di esposizione ($EE$, PFE 95%, PFE 99%, $ENE$, $EEPE$) e accordi di compensazione CSA bilaterali.
- **CreditMetrics™ S&P 8-State Migration, Vasicek IRB & Fed CCAR / EBA 9Q Capital (`core/credit_portfolio_engine.py`, `core/ccar_stress_engine.py`, `src/pages/7_🌪️_Stress_Testing.py`)**: Matrice di transizione S&P a 8 stati, modello asintotico a singolo fattore di Vasicek (Basilea III Art. 153 CRR) e proiezione trimestrale 9Q del CET1 Ratio con trigger MDA/AT1 CoCo.
- **Rough Volatility (rBergomi $H \approx 0.10$) & Gatheral SVI Arbitrage-Free Surface (`core/rough_vol_svi_engine.py`, `src/pages/4_🔬_Modelli_Quantitativi.py`)**: Parametrizzazione SVI con verifica assenza di arbitraggio Butterfly di Durrleman ($g(k) \ge 0$) e modello frazionario Rough Bergomi per lo skew ATM a breve termine $\mathcal{O}(T^{H-1/2})$.
- **Single-Name CDS Bootstrapping & Synthetic Credit Index Tranches (`core/cds_tranche_engine.py`, `src/pages/4_🔬_Modelli_Quantitativi.py`)**: Bootstrapping curve di sopravvivenza $Q(0,t)$ e hazard rate $\lambda(t)$, CS01/JTD e prezzatura 1-Factor Gaussian Copula / Base Correlation delle tranche iTraxx Europe / CDX IG (`0-3%`..`12-22%`).
- **Multi-Curve OIS Bootstrapping, Hull-White Bermudan Swaptions, Heston FFT & Bayesian Black-Litterman (`core/multicurve_engine.py`, `core/hull_white_engine.py`, `core/heston_fft_engine.py`, `core/black_litterman_engine.py`, `src/pages/4_🔬_Modelli_Quantitativi.py`)**: Separazione discounting €STR / forwarding Euribor 6M, albero trinomiale Hull-White 1F, Fast Fourier Transform di Carr-Madan e ottimizzazione bayesiana con confidenza di Idzorek.
- **ALM / LDI Redington Immunization, Cash-Flow Matching LP, Schwartz 2F Commodities, Almgren-Chriss & VPIN/Hawkes (`core/alm_ldi_engine.py`, `core/commodity_engine.py`, `core/optimal_liquidation_engine.py`, `core/market_making_vpin_engine.py`, `src/pages/13_🏛️_Patrimonio_e_NetWorth.py`)**: Immunizzazione attuariale delle passività con programmazione lineare HiGHS, curva forward commodity 2-Factor, traiettoria di liquidazione ottima con tossicità VPIN/Hawkes, Phoenix Autocallable Worst-Of e PRIIPs KID (SRI 1-7) / SFDR 14 PAI.
- **Endpoint REST Headless v9.18.0 (`api/main.py`)**: `/api/v1/margin/isda-simm`, `/api/v1/wealth/alm-ldi`, `/api/v1/pricing/rough-vol-svi`, `/api/v1/credit/cds-tranches`, `/api/v1/execution/market-making-vpin`, `/api/v1/reporting/executive-board-pack`, `/api/v1/risk/xva`, `/api/v1/pricing/heston`, `/api/v1/optimize/black-litterman`, `/api/v1/risk/basel-liquidity`, `/api/v1/pricing/structured-products`, `/api/v1/regulatory/priips-sfdr`.

---

## 🚀 FRTB Basel IV, SABR Vol Surface (3D), NGFS Climate Stress, Multi-Venue SOR & Private Markets (v9.13.0)

ARGUS v9.13.0 espande la piattaforma con 6 motori quantitativi di livello Tier-1 per banche d'investimento, desk derivati, banche centrali, broker MiFID II e family office:
- **FRTB Basel IV Standardized Approach (`core/frtb_engine.py`, `src/pages/7_🌪️_Stress_Testing.py`)**: Implementazione BCBS 365 con Sensitivities-Based Method (SBM) Delta, Vega e Curvature su GIRR, CSR, Equity, FX e Commodity, aggregazione multi-scenario (Medium, High, Low), Default Risk Charge (DRC) Jump-to-Default e Residual Risk Add-on (RRAO).
- **SABR Stochastic Volatility & Dupire Local Volatility Surface 3D (`core/sabr_local_vol_engine.py`, `src/pages/4_🔬_Modelli_Quantitativi.py`)**: Calibrazione analitica Hagan et al. (2002) $(\alpha, \rho, \nu)$, inversione PDE di Dupire (1994) $\sigma_{\text{loc}}(K, T)$ e Volatility Cube 3D con visualizzazione Mesh interattiva in Plotly WebGL.
- **NGFS Phase IV Climate Transition & Physical Risk Stress Engine (`core/climate_stress_engine.py`, `src/pages/7_🌪️_Stress_Testing.py`)**: Stress test climatico su scenari NGFS (Orderly Net Zero 2050, Disorderly Delayed Transition, Hot House World), contabilità Scope 1-2-3, intensità WACI ($\text{tCO}_2\text{e}/\text{M€}$), impatto carbon tax su EBITDA/spread e danni fisici su immobili con Climate VaR aggregato.
- **Multi-Venue Smart Order Router & MiFID II RTS 28 Best Execution (`core/smart_order_router.py`)**: Algoritmo SOR su 5 liquidity pools (Primary Lit, Alt MTF, Systematic Internalizer, Dark Pool, Crossing Network), scoring multi-criterio concorrente e report annuale di disclosure conforme a MiFID II RTS 28 (top 5 venue, ordini passivi/aggressivi, price improvement).
- **Private Markets & Illiquid Asset Valuation Engine (`core/wealth/private_markets_engine.py`, `src/pages/13_🏛️_Patrimonio_e_NetWorth.py`)**: Pacing dei flussi di cassa a 10 anni secondo Takahashi-Alexander (2001) per Private Equity e VC (Capital Calls, Distribuzioni, NAV, J-Curve, Net IRR, TVPI/DPI/RVPI), Kaplan-Schoar PME, Direct Alpha e de-smoothing econometrico di Geltner-Fisher (1991/1994).
- **Interactive Macro War Room & Correlation Breakdown Stress Engine (`core/macro_war_room.py`, `src/pages/7_🌪️_Stress_Testing.py`)**: Simulatore macro a leve multiple (Tassi, Slope Twist, Inflazione, Petrolio, FX USD, Azionario, Spread OAS) con crollo sistemico delle correlazioni verso equicorrelazione di panico $\mathbf{R}_{\text{panic}} \to 0.85$, aumento di volatilità, perdita di diversificazione e proiezione drenaggio liquidità / margin call.
- **Nuovi Endpoint REST Headless v9.13.0 (`api/main.py`)**: `/api/v1/risk/frtb-sbm`, `/api/v1/pricing/sabr-vol`, `/api/v1/stress/climate-ngfs`, `/api/v1/execution/smart-route`, `/api/v1/wealth/private-markets`, `/api/v1/stress/macro-war-room`.

---

## 🚀 Barra Risk Model, Solvency II SCR, DCC-GARCH & Vine Copula, Mock FIX 4.4 Engine & Family Office Succession (v9.12.0)

ARGUS v9.12.0 introduce 6 moduli istituzionali tier-1 per l'investment management, le assicurazioni, il trading algoritmico e il family office:
- **Barra Structural Multi-Asset Risk Model (`core/barra_risk_model.py`)**: Decomposizione della covarianza strutturale $\boldsymbol{\Sigma} = \mathbf{X}\boldsymbol{\Sigma}_F\mathbf{X}^T + \boldsymbol{\Delta}_\epsilon$, stima factor loadings per 6 fattori di stile (Size, Value, Momentum, Quality, Low Volatility, Liquidity), 11 settori GICS e macro fattori, calcolo Euler MCTR/PCTR e Tracking Error attivo.
- **Solvency II Standard Formula & SCR Engine (`core/solvency2_engine.py`)**: Calcolo del Requisito Patrimoniale di Solvibilità (SCR) conforme al Regolamento Delegato (UE) 2015/35 EIOPA: sub-moduli Market Risk (Interest Rate up/down, Equity Type 1/2, Property 25%, Spread CQS 0-6, Concentration, Currency), aggregazione con matrice $\boldsymbol{\Omega}_{\text{mkt}}$, Basic SCR (BSCR), Rischio Operativo $\text{SCR}_{\text{op}}$, Loss-Absorbing Capacity (LAC), Solvency Ratio ed export QRT S.25.01 / S.26.01.
- **DCC-GARCH Dynamic Correlation & Vine Copula Tail Risk (`core/dcc_garch_engine.py`)**: Filtraggio GARCH(1,1) univariate, correlazione dinamica tempo-variante $R_t$ (Engle 2002), copule a vite (Clayton per crash contagion, Gumbel per rally, Student-t) e previsione dinamica VaR / CVaR a $T+1$ e $T+5$.
- **Mock FIX 4.4 Protocol Engine & L2 DOM Simulator (`core/fix_engine.py`)**: Parser/serializer tag-value FIX 4.4 standard con validazione CheckSum a 3 cifre, book Depth-of-Market a 10 livelli, matching engine con book walking e Post-Trade Transaction Cost Analysis (TCA) completa (Arrival Price, Execution VWAP, Implementation Shortfall in EUR e bps).
- **Family Office Generational Succession Optimizer (`core/wealth/succession_optimizer.py`)**: Confronto stocastico a 30 anni su 5 veicoli: Holding Familiare (PEX 95% Art. 87 TUIR, Patto di Famiglia Art. 768-bis c.c. ed esenzione Art. 3 c. 4-ter D.Lgs. 346/1990) vs Trust Fiduciario (AdE Circolare 34/E/2022) vs Polizze Vita Ramo I/III (Art. 12 D.Lgs. 346/1990) vs Regime Ordinario, con calcolo del Tax Alpha generazionale (€ e %).
- **Event-Driven Risk Watchdog & Notification Hub (`core/watchdog/risk_watchdog.py`)**: Monitoraggio dei limiti RAF (VaR 99%, Solvency Ratio, Max Drawdown, concentrazione) e webhook dispatcher verso Telegram, Discord, Slack e SMTP Email con modalità mock e audit trail.
- **Nuovi Endpoint REST Headless v9.12.0 (`api/main.py`)**: `/api/v1/risk/barra`, `/api/v1/risk/solvency2-scr`, `/api/v1/risk/dcc-garch`, `/api/v1/execution/fix/order`, `/api/v1/wealth/succession-optimization`, `/api/v1/watchdog/check`, `/api/v1/watchdog/alerts`.

---

## 🚀 Walk-Forward Rolling OOS Engine, HMM Adaptive Allocation, Total Wealth Reverse Stress & MIP Rebalancing (v9.11.0)

ARGUS v9.11.0 introduce il simulatore Walk-Forward multi-strategia Out-of-Sample con attrito reale, l'overlay tattico adattivo con Hidden Markov Models (HMM), il Reverse Stress Testing sul patrimonio consolidato (Solvency II), il ribilanciatore discreto a numeri interi con programmazione lineare mista (SciPy HiGHS MILP), la coda asincrona di job con WebSocket gateway e il Dossier Regolamentare PDF a 4 pagine:

* **📦 Python Package Headless & CLI Console Scripts (`argus-risk`)**:
  ```bash
  # Motore analitico puro (zero dipendenze web)
  pip install argus-risk
  
  # Con microservizio REST API (FastAPI + Uvicorn)
  pip install "argus-risk[api]"
  
  # Suite completa con dashboard Streamlit e visual analytics
  pip install "argus-risk[all]"

  # Esecuzione immediata via CLI console scripts
  argus-api      # Avvia il server REST FastAPI su http://127.0.0.1:8000
  argus-ui       # Avvia la Control Room Streamlit su http://127.0.0.1:8501
  ```

* **⚡ Microservizio REST API ad Alte Prestazioni (`api/main.py`)**:
  Server asincrono ASGI (`uvicorn api.main:app --port 8000`) con coda asincrona `BackgroundTasks`, WebSocket streaming (`/api/v1/stream/ticks`) e contratti Pydantic v2:
  - `GET /health`: Health-check dedicato, diagnostica del motore v9.11.0 e disponibilità DuckDB C++.
  - `POST /api/v1/jobs/submit`: Accodamento asincrono non bloccante di task quantitativi pesanti (Walk-Forward, MIP, Stress).
  - `GET /api/v1/jobs/{job_id}`: Polling di stato e recupero dei risultati elaborati dal background worker.
  - `GET /api/v1/jobs`: Registro storico e diagnostico dei task in esecuzione/completati.
  - `WS /api/v1/stream/ticks`: Streaming WebSocket di tick di mercato ad alta frequenza con bid/ask spread.
  - `POST /api/v1/backtest/walk-forward`: Simulazione rolling out-of-sample (Equal Weight, HRP, ERC, Max Sharpe).
  - `POST /api/v1/optimize/regime-adaptive`: Allocazione condizionata a regimi HMM con haircut asimmetrici.
  - `POST /api/v1/risk/total-wealth-reverse-stress`: Reverse stress testing su 5 macro-fattori patrimoniali.
  - `POST /api/v1/rebalance/mip`: Ottimizzazione discreta a quote intere con limite di cardinalità e CGT budget.
  - `GET /api/v1/reports/stress-dossier`: Download del Dossier Regolamentare PDF a 4 pagine (EBA / Solvency II).
  - `POST /api/v1/risk/metrics`: Calcolo istantaneo di VaR/CVaR Cornish-Fisher, Sharpe, Sortino e drawdown.
  - `POST /api/v1/optimize/hrp`: Ottimizzazione di portafoglio con algoritmo Hierarchical Risk Parity.
  - `POST /api/v1/optimize/erc`: Spinu (2013) Strictly Convex Potential Risk Budgeting & Equal Risk Contribution.
  - `POST /api/v1/risk/reverse-stress`: Regulatory Reverse Stress Testing (EBA / BCE minimum Mahalanobis distance).
  - `POST /api/v1/risk/fama-french`: Regressione multivariata e attribuzione a 3/4/5 fattori + Momentum.
  - `POST /api/v1/fixed-income/analytics`: Metriche Bloomberg YAS (YTM, Duration, Convexity, DV01/PVBP).
  - `POST /api/v1/risk/liquidity`: Basel III Days-to-Liquidate (DTL), Amihud illiquidity ratio e L-VaR.
  - `POST /api/v1/tax/harvesting`: Italian TUIR tax-loss harvesting screening e calcolo potenziale risparmio.
  - `GET /api/v1/reports/factsheet`: Streaming del PDF Factsheet istituzionale a 2 pagine certificato.
  - `GET /api/v1/wealth/networth`: Consolidamento istantaneo Net Worth, liquidità, solvency ratio e health score.
  - `POST /api/v1/rebalance`: Ribilanciamento con supporto strategie `autonomous`, `tax_aware` e `mip_cardinality`.
  - `POST /api/v1/ledger/timetravel`: Ricostruzione contabile bitemporale Point-in-Time con sigillo Merkle Tree.

* **🏛️ Application Service Layer Headless (`core/services/`)**:
  Architettura a servizi applicativi agnostici dall'interfaccia utente: `RiskService` (VaR, CVaR, HRP, Monte Carlo stocastico), `TaxService` (TUIR Art. 67, Crypto, Cross-Border) e `WealthService` (Net Worth, Solvency, Stress Testing, Glide Path), condivisi identicamente da FastAPI e da tutte le 21 viste Streamlit.


* **📚 Portale di Documentazione Interattivo (Material for MkDocs)**:
  Portale istituzionale ad alta leggibilità ospitato su GitHub Pages con supporto KaTeX/MathJax per formule matematiche, code-copy, navigazione a schede e whitepaper tecnico:
  👉 **[Consulta la Documentazione Live](https://alessandro-sal.github.io/argus-risk-analytics/)**

* **🎯 Quickstart in 5 Righe (Ottimizzazione HRP da CSV)**:
  ```python
  import pandas as pd
  from core.hrp_optimizer import compute_hrp_portfolio
  
  df_returns = pd.read_csv("returns.csv", index_col="Date", parse_dates=True)
  result = compute_hrp_portfolio(df_returns, linkage_method="single")
  print(result["df_weights"])
  ```

---

## 📌 Panoramica del Progetto

**ARGUS** — il cui nome si ispira al mito dell'osservatore dai cento occhi che vede tutto e non dorme mai — è una piattaforma integrata di **Business Intelligence, Financial Valuation, Forensic Accounting, AI Narrative Intelligence, Data Engineering e Quantitative Risk Management** potenziata con standard **Bloomberg Terminal Parity**. Progettata con un'interfaccia ad alta densità informativa di livello istituzionale, la soluzione offre un ecosistema avanzato per la diagnosi contabile, la profilazione del rischio e la protezione strategica di portafogli d'investimento multi-asset (*Equity, ETF, Fixed Income, Crypto e Cash*).

* **🏛️ Real Fama-French Econometrics, Portfolio Fixed Income ALM, Liquidity Risk & Tax Harvesting v9.9 (`core/risk_engine.py`, `core/fixed_income.py`, `core/tax_engine.py`, `core/wealth/tbs_monte_carlo.py`, `src/pages/7_🌪️_Stress_Testing.py`, `src/pages/18_📑_Fiscalita_e_Quadro_RW.py`)**:
  1. *Fattori Reali Kenneth French Fama-French 3/4/5 & Carhart Econometrics*: Sostituzione delle approssimazioni gaussiane con le serie storiche ufficiali del Dartmouth College Data Library (Mkt-RF, SMB, HML, RMW, CMA, WML). Regressione OLS multivariata con calcolo di t-stat, p-value, $R^2$ aggiustato, quota di rischio sistemico vs idiosincratico e significatività di Alpha di Jensen.
  2. *Portfolio Fixed Income & ALM Treasury Analytics (DV01 & KRD)*: Aggregazione dinamica di obbligazioni individuali ed ETF obbligazionari (SHY, IEI, IEF, TLT, AGG, BND, BTP, HYG). Calcolo di Macaulay Duration, Modified Duration effettiva, Convessità ponderata, Dollar Duration / DV01 (€/bps) e Key Rate Durations a 4 nodi critici (2Y, 5Y, 10Y, 30Y).
  3. *Scenari di Curva Non Paralleli (Curve Twist & Steepening/Flattening)*: Simulazione istantanea di shock sulla struttura a termine con scenari Bear Steepener (+100 bps lungo, +25 bps breve), Bull Steepener (-25 bps lungo, -100 bps breve), Bear Flattener (+100 bps breve, +25 bps lungo) e Bull Flattener (-25 bps breve, -100 bps lungo).
  4. *Endogenous Liquidity Risk & Orizzonte Days to Liquidate (DTL)*: Calcolo dell'Average Daily Volume (ADV 30d/90d), orizzonte Days to Liquidate con cap di partecipazione al 10% e 20%, Amihud Illiquidity Ratio, classificazione in 4 Tier di liquidità (<1d, 1-3d, 3-7d, >7d) e stima del Liquidity-Adjusted VaR (L-VaR endogeno).
  5. *Proactive Tax-Loss Harvesting & Minusvalenze Proxy Switches*: Monitoraggio real-time delle perdite latenti con stima del Tax Alpha generabile (26% azioni/ETF, 12.5% titoli di stato), raccomandazione automatica di ETF proxy correlati ($\rho \ge 0.98$, es. SWDA $\leftrightarrow$ LCWD, VWCE $\leftrightarrow$ FWRA, CSSPX $\leftrightarrow$ VUAA) e alert di urgenza per minusvalenze in scadenza nel quarto anno solare.
  6. *Decumulo Patrimoniale Stocastico a Ciclo di Vita (TBS-MC Decumulation)*: Simulazione Monte Carlo a 5.000 cammini con flussi di cassa reali attesi, calcolo della Probabilità di Rovina, Età di Massima Fragilità patrimoniale e corridoio di spesa annua sostenibile al 95% di confidenza.
* **🏛️ Institutional Risk Engine, Basel IV Traffic Light, EVT Tail Risk & Total Wealth Stress Testing v9.8 (`core/risk_engine.py`, `core/yield_curve.py`, `core/macro_stress_engine.py`, `core/wealth/personal_balance_sheet.py`, `src/pages/3_🔴_Analisi_Rischio.py`, `src/pages/4_🔬_Modelli_Quantitativi.py`, `src/pages/13_🏛️_Patrimonio_e_NetWorth.py`, `src/pages/16_🛡️_Previdenza_e_Pension_Planning.py`)**:
  1. *Extreme Value Theory (EVT POT-GPD) & Tail Risk 99.9%*: Modellazione avanzata delle perdite estreme e dei cigni neri tramite approccio Peaks-Over-Threshold (POT) e distribuzione di Pareto Generalizzata (GPD) conforme ai requisiti di Basilea IV per la stima accurata di VaR e CVaR (Expected Shortfall) al 99.0% e 99.9%.
  2. *Backtesting Regolamentare Basilea IV (Traffic Light Framework)*: Backtest su finestra mobile standard di 250 giorni di negoziazione con classificazione automatica in Zona Verde ($x \le 4$, moltiplicatore $3.00$), Gialla ($5 \le x \le 9$, moltiplicatori $3.40 - 3.85$) o Rossa ($x \ge 10$, moltiplicatore $4.00$), corredato dal test di copertura incondizionata di Kupiec (POF), dal test di indipendenza di Christoffersen (clustering delle violazioni) e dal test di copertura condizionale congiunto.
  3. *Ottimizzatori Avanzati: Maximum Diversification (MDP) & Min-CVaR (Rockafellar-Uryasev LP)*: Ottimizzazione del Diversification Ratio (DR) di Choueifaty & Coignard per estrarre la massima riduzione della volatilità senza stime di rendimento atteso, unita all'ottimizzazione convessa esatta Min-CVaR (Rockafellar & Uryasev 2000) formulata come Programma Lineare e risolta in sub-5ms tramite solutore C++ HiGHS.
  4. *Risoluzione Point-in-Time dei Tassi Risk-Free & Regime ZIRP (2020–2026)*: Term structure storica dei tassi privi di rischio (€STR/BCE Deposit per EUR, T-Bill 3M per USD, SONIA per GBP, SARON per CHF) con supporto fedele ai tassi negativi (-0.50% BCE) ed eliminazione totale dei bias retroattivi di Sharpe e Sortino.
  5. *Dinamica Point-in-Time delle Quote $Q_{i,t}$, True TWR (Modified Dietz) & MWR (IRR)*: Ricostruzione giornaliera delle quote possedute, calcolo del Time-Weighted Return quotidiano depurato dai flussi di cassa esogeni (PAC e prelievi) e risoluzione esatta del Money-Weighted Return (IRR) via algoritmo di Brent (`scipy.optimize.brentq`).
  6. *Scomposizione del Rischio di Cambio (FX Risk) & Forward Hedging Carry Simulator*: Decomposizione esatta della varianza $\sigma^2_{tot} \approx \sigma^2_{local} + \sigma^2_{fx} + 2\text{Cov}$, quantificazione dell'esposizione valutaria aperta e stima del Carry Drag annuo da Covered Interest Rate Parity.
  7. *Stress Testing Macroeconomico Consolidato sul Patrimonio Netto (Total Wealth)*: Simulazione congiunta degli shock regolamentari (EBA Regulatory Adverse 2026, Fed CCAR Severe, Stagflazione & Shock Tassi, Crisi Geopolitica Globale) su tutte le macro-classi dell'attivo (Liquidità, Portafogli, Immobili, Fondi Pensione, Caveau & Orologi) con quantificazione del drawdown patrimoniale e dell'amplificazione dell'indebitamento (Debt-to-Assets).
  8. *Bilancio Comparativo Pluriennale (2021–2026) & Dossier PDF a 4 Pagine*: Sub-tab 5 e 6 in Pagina 13, esportazione CSV della serie storica completa, Dossier PDF a 4 pagine certificato con Pagina 4 dedicata al trend pluriennale e CSS Progress Bars evolutive, e cronistoria previdenziale (2023–2026) con scudo fiscale art. 51 TUIR dinamico in Pagina 16.
* **⚡ Institutional UI/UX Ergonomics, Command Palette (Ctrl+K), Action Drawers & @st.fragment Reactivity v9.7 (`components/command_palette.py`, `components/action_drawers.py`, `core/chart_framework.py`, `core/ui_utils.py`, `desktop_launcher.py`)**:
  1. *Universal Bloomberg-Style Command Palette (`Ctrl+K` / `Cmd+K`)*: Switcher ad altissima velocità accessibile globalmente da tutte le 22 pagine della piattaforma. Permette la ricerca fuzzy istantanea tra moduli analitici, asset/ISIN del portafoglio attivo e macro-scenari di stress (Lehman 2008, COVID-19, Rates Shock 2022, Spread BTP 2011, Dot-Com). Architettura a tripla intercettazione DOM con supporto completo sia per browser web moderni che per l'applicazione desktop nativa Windows standalone (`.exe` via PyInstaller e Microsoft Edge WebView2).
  2. *Ultra-Reactive UI with `@st.fragment`*: Eliminazione dei re-render globali e dei flash di caricamento. Isolamento computazionale granulare per il simulatore interattivo di shock multi-asset (`src/pages/7_🌪️_Stress_Testing.py`) e per il motore parametrico Cornish-Fisher / decomposizione del rischio di Eulero (`src/pages/3_🔴_Analisi_Rischio.py`), con feedback istantaneo in millisecondi su variazioni di slider e confidenza.
  3. *Institutional Modal Action Drawers (`@st.dialog`)*: Esperienza utente fluida senza perdita di contesto o navigazione forzata. Include il *Pre-Trade Order Blotter* (pre-flight check conformi a MiFID II e staging ordini FIX), il *TUIR Tax Lot Inspector* (audit analitico lotto per lotto conforme al TUIR Art. 44 Redditi di Capitale vs Art. 67 Redditi Diversi e PMC fiscale) e la *Decomposizione Rischio Euler* (analisi granulare di Marginal VaR e contributo percentuale al rischio di portafoglio).
  4. *Obsidian Dark Institutional Theme & Monospace Tabular Ergonomics*: Palette a contrasto elevato per terminali finanziari (`ObsidianTheme`), tabelle monospaziate contabili ad alta densità (`argus-dense-table`) e integrazione di `st.data_editor` con badge cromatici di conformità fiscale in `src/pages/5_📋_Posizioni_e_Dettagli.py`.
* **🏛️ Enterprise Quant Hardening, Arrow Binary Engine & Unified Rebalancing Architecture v9.6 (`core/rebalancing/`, `core/services/rebalancing_service.py`, `core/session_manager.py`, `api/main.py`, `core/cache_shield.py`, `core/risk_engine.py`)**:
  1. *Unified Multi-Strategy Rebalancing Layer & Strategy Protocols*: Architettura polimorfica a contratti unificati (`protocol.py`, `engine.py`) che orchestra le 4 strategie di ribilanciamento (*Autonomous AI*, *Tax-Aware Friction Matrix*, *Prescriptive Conic SLSQP*, *Heuristic Target Allocation*) con piena conformità TUIR Art. 44 (asimmetria ETF/OICR Redditi di Capitale) vs Art. 67 (azioni/ETC Redditi Diversi capienti nello zainetto fiscale).
  2. *Application Services Facade & Headless REST API (`POST /api/v1/rebalance`)*: Facciata di servizio applicativo `RebalancingService` e router FastAPI ad alte prestazioni conforme a schemi Pydantic v2 per l'esecuzione headless da terminali quantitativi, automazioni esterne e sistemi OMS/EMS.
  3. *Type-Safe Session State Governance (`ArgusSessionManager`)*: Gestore centralizzato e tipizzato per `st.session_state` con costanti univoche, default atomici, controlli di validazione (ISO 4217, profili MiFID II) e fallback trasparente per ambienti di test e microservizi.
  4. *High-Performance L2 Apache Arrow Feather Binary Caching (`CacheShield`)*: Serializzazione binaria LZ4/ZSTD ad altissima velocità per l'archivio SQLite della cache di mercato con abbattimento del 90% della latenza di I/O e compatibilità retroattiva per payload legacy.
  5. *Vettorizzazione 2D Merton Jump-Diffusion & Euler VaR Ledoit-Wolf Shrinkage*: Vettorizzazione 2D NumPy per la simulazione Monte Carlo con salti poissoniani ed eliminazione di 2.500.000 iterazioni pure Python; regolarizzazione spettrale PSD e shrinkage di Ledoit-Wolf per la decomposizione del rischio di Eulero e solutore vincolato Quadratic Programming SLSQP per Black-Litterman ($w_i \ge 0, \sum w_i = 1$).
  6. *Streamlit UI Fragment Isolation (`@st.fragment`)*: Isolamento granulare della toolbar di esportazione universale (`render_export_toolbar`), azzerando i re-run completi di pagina al download di file CSV/Excel su tutte le 50+ tabelle della piattaforma.
  7. *Desktop Packaging PyInstaller (`--build-exe`)*: Generazione automatica di eseguibili standalone Windows compilati a partire da `argus_desktop.spec`.
* **🏛️ Next-Level Enterprise Transformation v8.1 & Universal Financial Intelligence (`core/universal_ledger.py`, `core/wealth/human_capital_engine.py`, `core/prescriptive_rebalancer.py`, `core/msci_barra_risk_engine.py`, `core/wealth/tbs_monte_carlo.py`, `core/ai_analyst.py`)**: Trasformazione architetturale strategica di classe Tier-1 (standard BlackRock Aladdin, Bloomberg AIM, MSCI Barra):
  1. *Universal One-Ledger Core & Vectorized DuckDB/PyArrow Engine*: Modello a partita doppia unificato per asset liquidi ed illiquidi, calcolo contabile FIFO WACP/PMC con window functions analitiche C++ in DuckDB, estrazione zero-copy PyArrow e persistenza Apache Parquet.
  2. *Human Capital Valuation & Total Balance Sheet VaR (TBS-VaR)*: Integrazione attuariale del Capitale Umano come asset sintetico Quasi-Equity/Quasi-Bond (sconto Nelson-Siegel, premio rischio settore/disoccupazione), matrice di covarianza cross-asset allargata (Mercati + Real Estate + Capitale Umano), stima di TBS-VaR 95% e TBS-CVaR 95%, stress test su mutui a tasso variabile (+200 bps), Emergency Runway in mesi e raccomandazioni di sottopeso settoriale contro il rischio di correlazione stipendio-portafoglio.
  3. *Prescriptive Conic Rebalancer & FIX 4.4 Protocol Blotter*: Ottimizzatore convesso/SLSQP multi-obiettivo (Tracking Error vs Turnover vs Tax Drag vs Almgren-Chriss Slippage/Market Impact) con assorbimento progressivo delle minusvalenze (TUIR 26% / 12.5%) e generazione di flussi ordini conformi allo standard internazionale FIX Protocol 4.4 (Tag 35=D, Tag 54, Tag 38, Tag 44, Tag 59).
  4. *Tri-Agent AI Quantitative Governance Council*: Comitato collegiale autonomo composto da 3 agenti con mandati specialistici ortogonali (*QuantRiskAuditor*, *TaxEfficiencySpecialist*, *MacroExecutionStrategist*), protocollo formale di consenso, scoring di governance e verbale esecutivo di delibera conforme MiFID II / CONSOB.
  5. *Asset-Level Factor Risk Decomposition Engine (MSCI Barra GEM3/USE4)*: Scomposizione formale della covarianza $\Sigma = X F X^T + \Delta$ tra Rischio Sistemico Fattoriale e Rischio Idiosincratico Specifico, Marginal Contribution to Total Risk (MCTR), Percent Contribution to Total Risk (PCTR per titolo e per fattore di stile/settore GICS) secondo il teorema di Eulero, e mappa radar degli active factor tilts.
  6. *Total Balance Sheet Lifetime Monte Carlo Simulation Engine (TBS-MC)*: Simulazione stocastica su 5.000 cammini a ciclo di vita (fino a 90 anni) per la stima della probabilità di rovina patrimoniale $P(\text{Liquidity} \le 0)$, identificazione dell'Età di Massima Fragilità, calcolo del corridoio di spesa annua sostenibile e fan chart dei percentili del Patrimonio Netto Olistico ($P_{10}, P_{25}, P_{50}, P_{75}, P_{90}$).
* **🏛️ Enterprise Masterplan v7.0 & Cross-Asset Macro Bridge (`core/wealth/unified_stress_bridge.py`, `core/wealth/tax_aware_location.py`, `core/autonomous_rebalancer.py`)**: Convergenza unificata tra rischio di mercato mobiliare e patrimonio totale (immobili, liquidità, fondi pensione, debito/mutui) con il **Cross-Asset Macro Bridge**, **Tax-Aware Asset Location Optimizer** (arbitraggio fiscale tra conti tassabili e previdenza integrativa), **Autonomous Rebalancer con WACP/PMC reale e recupero minusvalenze** dallo zainetto fiscale, calibrazione zero-coupon **Nelson-Siegel & Key Rate Durations (KRD)** a 5 nodi istituzionali (1Y, 2Y, 5Y, 10Y, 30Y) e stima del **Liquidity-Adjusted Value at Risk (L-VaR Bangia 1999)** con costo stocastico di bid-ask spread.
* **🎓 Institutional 5-Block Educational Modals & Crisp Vector SVG Icons (`core/ui_utils.py`)**: Standardizzazione istituzionale delle schede esplicative di tutte le metriche visualizzate in piattaforma, conformi allo schema a 5 blocchi (📌 *Cos'è & Definizione*, 📐 *Formula Matematica*, 🎯 *Come interpretarlo & Benchmark*, ⚙️ *Implementazione nel Codice*, ⚠️ *Limiti & Falsi Segnali*) affiancate da icone informative vettoriali SVG pure-code nitide a qualsiasi risoluzione.
* **🏛️ Obsidian Sovereign UI/UX Institutional Design System (`core/ui_utils.py`)**: Rinnovamento visivo ad alta densità "Fintech Institutional Grade" con gerarchia a 3 livelli (Header & Context Pill $\to$ Horizontal Control Bar $\to$ Modular Content Grid), palette antracite/ardesia a contrasto certificato WCAG AAA, cifre contabili a spaziatura monospaziata tabulare (`JetBrains Mono` con `tnum`), micro-grafici SVG pure-code ultra-leggeri a zero latenza (`generate_svg_sparkline`), status badge con animazione pulsante (`render_status_badge`), KPI card multilivello (`render_kpi_metric`, `render_kpi_card`), container in vetro acrilico (`render_glassmorphic_card`) e data table con barre di avanzamento orizzontali dinamiche `ProgressColumn` (`render_data_table`).
* **📥 Universal Financial Data Export Framework & Multi-Format Engine (`core/ui_export_utils.py`, `core/ui_utils.py`)**: Standardizzazione istituzionale dell'esportazione dati su tutte le tabelle della piattaforma (oltre 50 dataset nei 22 moduli operativi). Include download immediato in formato **CSV conforme agli standard europei/italiani** (codifica UTF-8 con Byte Order Mark `utf-8-sig` che preserva simboli di valuta `€` e caratteri accentati in Microsoft Excel) e **Excel professionale (.xlsx via openpyxl)** arricchito con palette *Dark Obsidian* (`#161B22`), accento ambra ARGUS (`#FF9900`), griglie contabili esplicite (`showGridLines = True`), auto-fit dinamico delle colonne, blocco pannelli (`freeze_panes = "A2"`) e formattazione numerica automatica (valute, percentuali, date e interi). Integrato con micro-popover a zero footprint verticale (`render_export_toolbar`), wrapper per card unificate (`render_table_with_export`) e caching binario `@st.cache_data` ad alte prestazioni.
* **📊 Quantitative Data Visualization Framework & Plotly Factory (`core/ui_utils.py`)**: Architettura centralizzata di data visualization basata sui template ufficiali registrati `argus_dark` e `argus_light` con griglie a basso contrasto, layout factory `apply_custom_chart_layout` (formattazione automatica assi valuta/percentuale, hovermode unificato, spikelines temporali coordinate) e toolbar essenziale ad alta risoluzione (PNG $2\times$ via `get_plotly_config`). Include una Pattern Library per i 4 grafici quantitativi fondamentali (*Monte Carlo Fan Chart* con coni percentili 5-25-50-75-95, *Matrice di Correlazione Cross-Asset* fissa -1.0/+1.0, *Cash Flow Waterfall Chart* con saldo netto cumulato e *NAV Cumulato & Underwater Drawdown Plot* sincronizzato su doppio asse temporale con rilevamento del Max Drawdown).
* **🌪️ Unified Macro Stress Engine & Liquidity Squeeze Protocol (`core/wealth/wealth_stress_engine.py`)**: Motore congiunto di simulazione macroeconomica multi-asset che connette il portafoglio titoli del modulo Risk al bilancio patrimoniale del modulo Wealth. Modella la trasmissione dello shock tassi sui mutui a tasso variabile tramite ammortamento non-lineare alla francese ($\Delta PMT$), identifica analiticamente il **Point of Forced Liquidation ($t^*$)** sul fondo di emergenza, quantifica la perdita irreversibile da liquidazione forzata di asset depressi sui minimi di mercato e ricalcola il **Dynamic Safe Withdrawal Rate (FIRE SWR)** secondo le regole prudenziali di Guyton-Klinger contro il *Sequence of Returns Risk*, con timeline Plotly interattiva.
* **🧱 State Management Reattivo & Multi-Workspace Isolation (`core/workspace_context.py`)**: Architettura a sottocontesti tipizzati (`RiskSubContext`, `WealthSubContext`, `UIViewState`) con persistenza e isolamento deterministico della sessione (`data/cache/sessions/session_{id}.pkl`), metodo `flush_risk_domain()` per la bonifica automatica e chirurgica delle chiavi di widget orfane in Streamlit, e consolidamento in-memory in tempo reale del Net Worth tra modulo Risk e modulo Wealth senza necessità di snapshot preventivi su database.
* **🛡️ AI Analyst & MiFID II Regulatory Compliance Guardrails (`core/sec_rag_engine.py`, `core/voice_advisor_engine.py`)**: Standard di governance finanziaria con disclaimer vincolanti Art. 21 TUF e divieto di consulenza/raccomandazioni operative non autorizzate, validatore semantico di aderenza numerica contro allucinazioni LLM, chunking normativo a finestra scorrevole e query expansion lessicale bilingue sui bilanci SEC Form 10-K, affiancati da executive voice briefing a 2 voci (CIO & CRO).
* **📊 Institutional Financial Reporting Design System (`core/reporting_design_system.py`, `core/modular_factsheet_builder.py`, `core/pdf_generator.py`, `core/excel_generator.py`)**: Suite grafica unificata basata sulla palette istituzionale *Obsidian Sovereign*, canvas ReportLab A4 a due passaggi (`InstitutionalNumberedCanvas`) con numerazione continua "Pagina X di Y", grafici a ciambella vettoriali in-memory senza dipendenze esterne o memory leak, ed esportazioni Excel interattive con tabelle native `ListObject` e formule dinamiche live (`XIRR`, somme condizionali).
* **🛡️ Cybersecurity, Data Vault & Anti-Formula Injection (`core/security_engine.py`)**: Difesa in profondità (*Defense-in-Depth*) contro attacchi **CWE-1236 (Formula Injection)** con sanitizzazione di ogni cella esportata in CSV e XLSX multi-foglio (neutralizzazione prefissi `=`, `+`, `-`, `@`, `\t`, `\r`), de-identificazione e mascheramento dinamico PII (IBAN, Codice Fiscale e conti correnti conformi a GDPR Art. 5/32), cifratura dei dati sensibili a riposo **ArgusDataVault** (algoritmo Fernet AES-128/256 CBC con autenticazione HMAC-SHA256 e derivazione chiave PBKDF2 a 100.000 iterazioni) e sanitizzazione preventiva delle credenziali nei prompt inoltrati ai modelli LLM esterni.
* **🔄 Zero-Downtime Hot Backup & Disaster Recovery Atomico (`core/backup_engine.py`)**: Motore di continuità operativa e resilienza basato sulle API C native `sqlite3_backup_init` per snapshot consistenti a caldo del database patrimoniale senza interruzione dei servizi, checkpointing preventivo del Write-Ahead Logging (`PRAGMA wal_checkpoint(TRUNCATE)`), doppio audit di integrità (`PRAGMA integrity_check` & `PRAGMA foreign_key_check`), compressione trasparente gzip con rotazione e retention temporale, e procedura di ripristino atomico point-in-time protetta da copia di rollback automatico `.emergency_pre_restore`. Integrato come hook di pre-flight in `desktop_launcher.py`.
* **🗄️ Database Reliability Engineering & Embedded Schema Migration Engine (`core/database_migration_manager.py`)**: Framework evolutivo embedded per database client-side (SQLite & DuckDB) a zero dipendenze esterne pesanti. Implementa Dual-Layer Schema Versioning ($O(1)$ con `PRAGMA user_version` + audit ledger crittografico `schema_migrations` con hash SHA-256 anti-manomissione), pre-flight shadow backup atomico prima di modifiche DDL, fail-safe disaster recovery con rollback automatico immediato e ripristino dallo snapshot su eccezione, schema drift inspector continuo contro i modelli Python (`core/models.py`, `core/wealth/wealth_models.py`), rilevamento orfani referenziali (`PRAGMA foreign_key_check`) e indici compositi analitici per l'accelerazione vettorizzata di query OLAP e attach nativo in DuckDB C++.
* **🩺 Lead SRE Observability, Structured JSON Logging & Self-Service Support Bundle Engine (`core/diagnostics.py`, `src/0_Control_Room.py`)**: Framework istituzionale di telemetria, logging sicuro e supporto diagnostico client-side. Implementa formattazione JSONL atomica (`StructuredJsonFormatter`), separazione fisica a canali isolati con rotazione controllata (`logs/argus_system.jsonl` per ops/latenze/errori e `logs/argus_audit.jsonl` per audit trail contabile di business con `log_audit_event`), filtro di mascheramento dati sensibili `FinancialAndPIISanitizingFilter` a conformità GDPR Art. 32 / PCI-DSS (oscuramento irreversibile di IBAN, Codici Fiscali, numeri di carte PAN, importi monetari e token/credenziali), decoratore `@measure_latency`, visualizzatore live dei log con filtri per severità e generatore 1-click di **Support Bundle ZIP** (`generate_support_bundle`) con diagnostica hardware (CPU, RAM via `psutil`, disco), stato integrità database SQLite, versioni pacchetti e log recenti sanificati.
* **🚦 Enterprise Data Quality Gate & Middleware Ingestion (`core/data_quality_gate.py`)**: Middleware di validazione e riconciliazione contabile pre-ingestion basato su schemi dichiarativi **Pydantic v2** (`CanonicalTradeRecord`, `QualityGateReport`), regole semantiche avanzate (blocco posizioni corte accidentali, rilevamento trade in giorni festivi/weekend, validazione cross-currency FX), riconciliazione automatica ISIN/Ticker e deduplicazione deterministica a chiave naturale SHA-256 (`tx_hash`) per garantire l'idempotenza assoluta nei ricaricamenti multipli di estratti conto.
* **🎲 Quantitative Simulation Engine & Educational Archetypes Generator (`scripts/generate_realistic_portfolio.py`)**: Motore di simulazione vettorizzato per la generazione di dataset finanziari sintetici ad alto realismo. Modella storie pluriennali con PAC mensili, dividendi periodici, split azionari, spese ricorrenti, mutui ad ammortamento francese ($\Delta PMT$), asset illiquidi con perizie e haircut di mercato, e vincolo ferreo di solvibilità di cassa ($C_t \ge 0$). Include 3 archetipi educativi preconfigurati (*Young Accumulator*, *FIRE / Decumulation*, *HNWI / Family Office*) con iniezione atomica 1-click in sessione e su database SQLite (`data/argus_local.db`).
* **🌍 Internationalization (i18n), Localization (L10n) & Multi-Currency FX Engine (`core/i18n/`, `core/sidebar.py`)**: Framework istituzionale di internazionalizzazione, traduzione gerarchica $O(1)$ (`translator.py`) con supporto ad interpolazione dinamica e session state Streamlit (`st.session_state["locale"]`), formattatori regionali ad alta densità (`formatters.py`) per convenzioni europee, anglosassoni e svizzere con notazione contabile Wall Street a parentesi `(1.234,56 €)` / `($1,234.56)`, formati compatti e Pandas Styler helpers, connettore tassi ufficiali BCE con forward-fill TARGET2, matrice di cross-rate ad arbitraggio triangolare (`fx_engine.py`) e scomposizione analitica esatta del rischio valutario (FX Risk) su rendimento, varianza ($2\,\text{Cov}$), *Natural Hedge* e riconciliazione monetaria esatta del PnL ($\Delta \equiv 0$).
* **⚡ Bloomberg Terminal Command Gateway & Mnemonic Parser**: Barra di comando istituzionale globale con sintassi a codici rapidi (`<TICKER> <MNEMONIC> <GO>`, es. `AAPL DES`, `MSFT FA`, `NVDA VOLS`, `PORT RISK`, `YCRV`, `BTP YAS`, `US10Y FI`, `CDS`, `STREAM`, `ATTR`, `TAX`, `EQS`, `BQUANT`, `LAUNCHPAD`, `XL`, `LIVE`, `TERM`, `CLI`), autocompletamento fuzzy, visual command feedback in tempo reale, sincronizzazione bidirezionale perfetta con la Navigation Rail e navigazione rapida senza mouse.
* **🖥️ ARGUS Live Terminal & Interactive CLI Execution Desk (`LIVE` / `TERM`)**: Console operativa interattiva in-app con prompt comandi Bloomberg (`ARGUS:LIVE>`), motore streaming Level-2 Depth Book con calcolo del Microprice di Stoikov (2018) e Order Flow Imbalance (OFI), simulatore Order Management System (OMS) Blotter con order slicing algoritmico TWAP/VWAP e telemetria di sistema in tempo reale (`TOP` Monitor CPU, RAM RSS, Ring Buffer, DB).
* **🤖 Smart Order Routing & Algoritmi di Esecuzione TWAP / VWAP**: Motore istituzionale di order slicing intraday (09:00 - 17:30) per grandi blocchi ed ordini di ribilanciamento con profilazione della curva di liquidità a "U", **TWAP** uniforme con jitter stocastico anti-frontrunning, **VWAP** ponderato sui volumi con tetto di partecipazione (POV Cap al 15%), stima dello slippage atteso e calcolo del risparmio netto rispetto all'ordine a mercato immediato.
* **🧬 Asset Allocation con Reinforcement Learning (RL Policy Sandbox)**: Agente neurale Policy Gradient (REINFORCE con baseline mobile) formulato come Processo Decisionale di Markov (MDP) continuo nello spazio degli stati $\mathbb{R}^{3N}$ (rendimenti, volatilità di regime, momentum), addestrato a massimizzare il **Sortino Ratio** penalizzando i drawdown e l'attrito di turnover, con simulazione storica ad episodi e curve di equity comparate con benchmark 1/N.
* **🌐 Frontiera Efficiente Tri-Dimensionale & Iperspazio Quantitativo 3D**: Estensione volumetrica della frontiera di Markowitz con proiezione nello spazio 3D ($X = \text{Volatilità}$, $Y = \text{Rendimento}$, $Z = \text{Concentrazione HHI / CVaR 0.95 / Sortino}$), alimentata da un algoritmo di campionamento **Multi-Alpha Dirichlet ($\alpha \in [0.05, 5.0]$) con Sparse Masking** per mappare con continuità l'intero volume geometrico dal baricentro ($1/N$) ai vertici di massima concentrazione ($HHI = 1.0$).
* **🏛️ Suite Fiscale Avanzata a 4 Pilastri & Regime Dichiarativo (TUIR, Quadro RT/RW/RM & Withholding)**:
  1. *Asimmetria Fiscale ETF & Rebalancer Compliance (TUIR Artt. 44, 67, 68)*: Separazione analitica e vincolante tra *Redditi di Capitale* (plusvalenze ETF tassate al 26% non compensabili) e *Redditi Diversi* (azioni, bond, ETC, certificates compensabili con minusvalenze pregresse nello zainetto quadriennale), integrata in tutti i ribilanciatori sia euristici che convessi (`core/tax_aware_rebalancer.py`, `core/prescriptive_rebalancer.py`).
  2. *Prospetto Precompilato Modello Redditi PF (Quadri RT, RW e RM)*:
     - **Quadro RT (Sezione II & Sezione II-B Cripto-Attività)**: Compilazione ministeriale righi RT21-RT26, gestione franchigia assoluta 2.000€ su cripto-attività ex L. 197/2022 con tassazione integrale al 26% oltre soglia e codice tributo 1100.
     - **Quadro RW (Monitoraggio Fiscale & IVAFE)**: Valutazione della giacenza media annua ponderata ($\bar{G} > 5.000€ \implies 34,20€$) e picco massimo annuale ($> 15.000€ \implies$ solo monitoraggio fiscale senza IVAFE) su conti correnti esteri (Revolut, Degiro, IBKR), codice 21 per cripto-attività (decentralizzato 000) e aliquota maggiorata allo **0,40% per territori Black List** ex L. 213/2023.
     - **Quadro RM (Sezione V - Rigo RM12)**: Imposizione al 26% sul *Netto Frontiera* per dividendi esteri e proventi distribuiti da ETF esteri percepiti su broker esteri senza intermediario residente (codice tributo 1242 / F24).
  3. *Analizzatore Withholding Tax & Doppia Imposizione*: Tracciamento ritenute alla fonte estere (W-8BEN 15% USA, 26,375% Germania, 35% Svizzera), calcolo dell'aliquota effettiva reale (37,10% USA) e quantificazione del Tax Drag rispetto ad ETF UCITS ad accumulazione.
  4. *Tax-Loss Harvesting & Step-Up Fiscale Anti-Elusivo (Art. 10-bis L. 212/2000)*: Ottimizzazione del risparmio d'imposta tramite matrice di Proxy Asset correlati per garantire piena sostanza economica (no Wash Sale abusive) e Step-Up a imposta 0€ per affrancare il PMC e consumare le minusvalenze al 4° anno solare.
* **🐍 ARGUS BQuant Python Sandbox In-App (`BQUANT` / `PY`)**: Console Python interattiva in-app per eseguire script analitici direttamente in-memory sui DataFrame di sessione (`df_positions`, `df_returns`, `df_prices`, `results`), interrogazioni SQL ad alta velocità con motore DuckDB in-process, cattura automatica di stdout/stderr, tabelle `df_out` e figure Plotly interattive con 5 snippet quantitativi istituzionali preimpostati.
* **🎛️ ARGUS Launchpad & Institutional Role Workspaces (`LAUNCHPAD` / `WS`)**: Orchestratore di dashboard per 5 profili operativi istituzionali (*Trading Desk & Execution*, *Risk Officer & Compliance*, *Portfolio Manager & CIO*, *Quantitative Analyst & Data Scientist*, *Corporate Treasurer & Fixed Income*) con 1-Click Fast Teleportation verso i moduli primari, Live Role KPI Cockpit e persistenza del layout su database SQLite locale.
* **📊 Excel Live Connector & Bloomberg RTD Builder (`XL` / `EXCEL`)**: Costruttore visuale di formule Excel Bloomberg Parity (`=ARGUS_BDP`, `=ARGUS_BDH`, `=ARGUS_RISK`), generatore di moduli VBA Desktop (`.bas`), Microsoft Office Scripts TypeScript (`.ts`) per Excel 365/Web ed esportatore di cartelle di lavoro multi-foglio `.xlsx` (*Executive_Summary*, *Positions_Portfolio*, *Fixed_Income_YAS*, *Execution_Schedule*).
* **🔍 Formula Engine EQS & Screener Universale (`EQS`)**: Motore di valutazione AST logico-booleana per interrogazioni composte personalizzate dall'utente (es. `Piotroski >= 7 AND Altman > 2.9 AND ROIC > WACC * 1.5 AND Beta < 1.0`), download parallelo multi-thread ultra-rapido (8 workers) e Smart Sizing Optimizer pre-trade.
* **🌊 Modello di Market Impact Almgren-Chriss & Execution Schedule**: Modellazione analitica dell'impatto permanente e temporaneo di liquidazione di ordini istituzionali in base all'Average Daily Volume (ADV), traiettoria ottima iperbolica $\sinh(\kappa(T-t))/\sinh(\kappa T)$, Half-Life di smobilizzo, piano di slicing a 10 scaglioni ed Execution VaR al 95%.
* **📊 Backtesting di Strategie Multi-Fattoriali a 5 Quintili**: Analisi di performance e rischio su panieri quantitativi ordinati (Q1..Q5), calcolo dello spread Long-Short ($Q1 - Q5$), Information Ratio e test di monotonicità di rango di Spearman ($r_s$) sui fattori Quality, Low-Beta, Momentum e Profitability.
* **📈 Fixed Income Istituzionale & Z-Spread (`YAS` / `FI`)**: Risolutore numerico per **Yield to Maturity (YTM)**, **Current Yield**, **Macaulay Duration**, **Modified Duration**, **Convexity esatta**, **DV01 / PVBP**, espansione di Taylor di 2° ordine ($\frac{\Delta P}{P} \approx -D_{\text{mod}} \Delta y + \frac{1}{2} C (\Delta y)^2$) e calibrazione dello **Z-Spread (Zero-Volatility Spread)** rispetto alla curva spot sovereign Nelson-Siegel-Svensson.
* **🛡️ Credit Default Swap (CDS) & Curva di Default Implicita**: Stima dell'Hazard Rate (intensità di default $\lambda = \frac{S_{\text{CDS}}}{1 - R}$) e term structure continua della probabilità cumulativa di default $PD(t) = 1 - e^{-\lambda \cdot t}$ su scadenze 6M, 1Y, 2Y, 3Y, 5Y, 7Y, 10Y, 15Y, 30Y.
* **⚡ Real-Time In-Memory Ring Buffer & Order Flow Engine (`STREAM`)**: Struttura dati circolare thread-safe con complessità temporale $O(1)$ per ingestione tick-by-tick ad alta frequenza, calcolo istantaneo di **VWAP intraday**, **Order Flow Imbalance (OFI)**, volatilità rolling e Level-2 Order Book Microprice (Stoikov 2018).
* **📉 Decomposizione Istituzionale del Rischio (Marginal VaR, Component VaR & LVaR)**: Decomposizione del Value at Risk con proprietà di Eulero ($\sum \text{CVaR}_i = \text{VaR}_p$), calcolo del Marginal VaR $(\partial \text{VaR}/\partial w_i)$, quantificazione del contributo percentuale di ogni posizione al rischio e stima del **Liquidity-Adjusted VaR (LVaR Bangia 1999)** con penalizzazione per orizzonti di smobilizzo e bid-ask spread.
* **📊 Attribuzione di Performance Multi-Periodo Carino (Zero-Residual) & Karnosky-Singer**: Algoritmo di raccordo logaritmico multi-periodale (Carino 1999) con garanzia matematica di **residuo zero** su orizzonti multi-anno ($\sum \text{Effetti} = R_p - R_b$) e scomposizione valutaria Karnosky-Singer per isolare l'impatto del mercato locale, dell'asset selection e del rischio di cambio.
* **🏛️ Modello Nelson-Siegel-Svensson (NSS a 6 Parametri) & Key Rate Durations (KRD)**: Modellazione continua della struttura a termine dei tassi sovrani con doppia gobba $(\beta_0, \beta_1, \beta_2, \beta_3, \tau_1, \tau_2)$, calcolo della sensitività triangolare dei flussi obbligazionari sui nodi chiave (6M, 1Y, 2Y, 5Y, 10Y, 30Y) e stima esatta della Duration Effettiva.
* **Motore Analitico Embedded DuckDB & Archiviazione Apache Parquet**: Database colonnare in-process vettorizzato (C++ SIMD) per eseguire aggregazioni OLAP complesse a latenza sub-millisecondo ($\mu s$/ms), **Cubi Multi-Dimensionali** (`Asset Class` $\times$ `Settore` $\times$ `Valuta`), window functions con `QUALIFY` e `DENSE_RANK()`, **Console SQL Interattiva** per query analitiche arbitrarie su tabelle in-memory ed esportazione con **compressione colonnare dell'85% in Apache Parquet**.
* **Local RAG & SEC Filing Vector Store con Reciprocal Rank Fusion (RRF)**: Motore di Retrieval-Augmented Generation e Vector Store semantico locale potenziato con **Reciprocal Rank Fusion (RRF)** tra matching lessicale BM25 e similarità vettoriale densa Cosine TF-IDF per interrogare con massima accuratezza le sezioni normative dei bilanci SEC (**Item 1**: *Business Overview & Moat*, **Item 1A**: *Risk Factors & Macro Threats*, **Item 7**: *MD&A & Operating Margins*, **Item 8**: *Debt Schedule & Financial Notes*), con evidenziazione delle fonti e citazioni testuali certificate.
* **Kenneth French Factor Library Live (Fama-French 5-Factor & Carhart Momentum)**: Connessione, ingestione e caching delle serie storiche ufficiali di Dartmouth College (*Mkt-RF, Size SMB, Value HML, Profitability RMW, Investment CMA, Momentum MOM/WML*), regressione multivariata OLS con stima di $\alpha$ annualizzato, statistica $t$, $p$-value al 95%, **Factor Return Attribution** per quantificare il contributo di ciascun driver al rendimento complessivo ed evoluzione dinamica delle esposizioni con **Rolling OLS a 60 giorni**, pienamente integrata con il motore generale di rischio.
* **Modulo Fiscale Cripto-Attività con Tassi FX Storici Dinamici (Legge 197/2022 & Circolare AdE 30/E/2023)**: Motore di calcolo fiscale dedicato alle valute virtuali e token con conversione dinamica sui cambi storici ufficiali, prospetto **Quadro RT (Sezione II-B)**, gestione automatica della franchigia annuale di 2.000€ su plusvalenze nette (Art. 67 c. 1 lett. c-sexies TUIR), imposta sostitutiva del 26%, **Zainetto Fiscale Cripto Separato** a 4 anni (non compensabile con azioni/obbligazioni), compilazione pre-dichiarativa del **Quadro RW (Codice 21)** e calcolo dell'**Imposta sul Valore delle Cripto-Attività / IVAFE (0,20% annuo)**.
* **Superficie di Volatilità Implicita 3D, Skew Calibration & Covered Call a Lotti Interi**: Risolutore numerico Newton-Raphson con fallback a Brent per l'inversione di Black-Scholes ($BS(S, K, T, r, \sigma_{\text{IV}}) = P_{\text{mkt}}$), calibrazione parametrica di Volatility Skew e Smile in funzione del log-moneyness $m = \ln(K / S)$ ($\sigma_{\text{IV}}(m) = a + b \cdot m + c \cdot m^2$), modellazione della superficie 3D $(K \times T \to \text{IV})$, dimensionamento realistico del costo di Delta-Hedging con opzioni Put e strategie Covered Call a **lotti eseguibili interi (100x)**.
* **Volatilità Condizionale GARCH(1,1) & Filtered Historical Simulation (FHS)**: Modellazione econometrica avanzata dei cluster di volatilità (Bollerslev 1986) con stima MLE dei parametri $\omega, \alpha, \beta$, persistenza, varianza di lungo periodo $V_L$ e Half-Life di riassorbimento degli shock. Calcolo di VaR e CVaR a code spesse tramite Filtered Historical Simulation (Hull-White 1998, Barone-Adesi 1999) con de-volatilizzazione dei residui empirici e proiezione della struttura a termine della volatilità a 30 giorni conforme agli standard Basel III / FRTB.
* **Multi-Broker Ingestion Hub & Auto-Detector a 8 Piattaforme**: Importazione automatica, riconoscimento istantaneo del formato senza configurazione manuale e normalizzazione da tutti i principali intermediari italiani ed internazionali (**Directa SIM**, **Fineco Bank**, **Interactive Brokers / IBKR**, **Trade Republic**, **Scalable Capital / Baader Bank**, **DeGiro**, **eToro**, **Revolut Trading**), con risolutore ISIN a 3 livelli (in-memory cache, `config.json` persistente e Yahoo Finance live lookup) e pulizia trasparente di formati numerici con virgola/punto e date internazionali.
* **Corporate Actions & Stock Split Engine**: Rilevazione automatica e manuale di frazionamenti azionari (*Forward Split*, es. NVDA 10:1, AAPL 4:1), raggruppamenti (*Reverse Split*) e dividendi in azioni con rettifica retroattiva dei lotti fiscali e contabili della coda FIFO, garantendo la rigorosa invarianza del valore fiscale totale ($Q \times P = \text{Cost Basis}$) secondo il TUIR Art. 67 e gli standard IFRS/US GAAP.
* **Modello Parametrico Nelson-Siegel & Curva Tassi Privi di Rischio Dinamica Multi-Valuta**: Modellazione term structure zero-coupon con stima parametrica continua di Nelson-Siegel a 4 parametri $(\beta_0, \beta_1, \beta_2, \tau)$, calcolo dei fattori di sconto continui $DF(t) = e^{-y(t) \cdot t}$ e calibrazione real-time del tasso risk-free ($R_f$) in base alla valuta base di portafoglio (**EUR** con BCE €STR via `XEON.DE`, **USD** con US 3M Treasury Bill via `^IRX`, **GBP** con BoE SONIA via `CSH2.L`, **CHF** con SNB SARON), con supporto ad override manuale e propagazione istantanea su Sharpe Ratio, Sortino Ratio, Jensen's Alpha, Treynor Ratio, Black-Scholes Delta-Hedging, Cost of Capital WACC e Kelly Position Sizing.
* **Infrastruttura Data Warehouse Duale & Total Wealth Hub**: Storicizzazione relazionale duale su MySQL 8.0 e SQLite locale (`data/argus_local.db`), gestione multi-valuta (EUR, USD, GBP, CHF) e **Total Wealth Hub Multi-Portafoglio** per salvare, confrontare e consolidare profili distinti (*Crescita, Dividendi, Previdenza, Crypto*) in un unico Master Portfolio unificato con fusione ponderata delle serie storiche dei rendimenti, stima esatta della durata solare (standard GIPS / CFA Institute) e decomposizione del rischio di componente.
* **Dual Google Sheets Pipeline (Stocks + Crypto)**: Connessione crittografata tramite Google Service Account con estrazione parallela e separazione nativa a livello di database dei fogli `History B/S Stocks` e `History B/S Crypto`, normalizzazione automatica dei tassi di cambio multi-valuta (EUR/USD/GBP) e mappatura dei ticker crypto (`BTC-EUR`, `ETH-EUR`, `SOL-EUR`, ecc.).
* **Database & Memory Storage Cockpit**: Monitoraggio in tempo reale dell'occupazione fisica dei database SQLite/MySQL, della memoria RAM (RSS) del processo, grafico Donut della ripartizione dello storage per tabella e file, e pulsanti di manutenzione 1-click (*VACUUM compattazione disco, pulizia cache scaduta TTL 24h, rigenerazione indici B-Tree e test PRAGMA integrity*).
* **Posizioni Chiuse & Graveyard Analytics**: Tracciamento contabile FIFO integrale delle operazioni chiuse con **Curva Cumulativa di PnL Realizzato (€)**, **High-Water Mark (Picco)**, telemetria di trade drawdown, **Trading Calendar & Heatmap Mensile** (matrice Mese $\times$ Anno) e scomposizione per settore GICS e asset class.
* **Fisco Italiano & Tax-Loss Harvesting Wizard (TUIR Art. 67)**: Modulo per la massimizzazione dell'efficienza fiscale con **Strategia Step-Up a 0€ imposte** (vendita e riacquisto immediato di titoli in utile su *Redditi Diversi* per azzerare le minusvalenze pregresse dello Zainetto Fiscale in scadenza quadriennale) e **Strategia Tax-Loss Harvesting** su posizioni in perdita latente.
* **Motore Quantitativo & Portfolio Engineering di Frontiera**: Risoluzione analitica della Frontiera Efficiente di Markowitz affiancata da stimatori *Ledoit-Wolf Shrinkage*, **Equal Risk Contribution (ERC / Parità di Rischio Pura)**, **Dipendenza di Coda Asimmetrica con Tail Copulas (Clayton & Gumbel)** per rilevare il rischio di crash congiunto non lineare, **Simulatore Interattivo Trade-Level Kelly Criterion & Half-Kelly Position Sizing** (pre-popolato con Win Rate e Payoff Ratio reali del Graveyard), **Live Rebalancing Sandbox** interattivo, allocazione mediante Machine Learning con **Hierarchical Risk Parity (HRP - Marcos López de Prado)**, copertura analitica con **Black-Scholes (1973)** con calcolo dei 5 Greci e Delta-Hedging con opzioni Put, generazione di rendimento passivo con *Covered Call Yield Enhancer*, modelli econometrici a 3 fattori di Fama-French (con regressione OLS multivariata), Carhart a 4 fattori, modello macro-fattoriale *MSCI Barra a 5 fattori ortogonalizzati*, simulazioni stocastiche *Merton Jump-Diffusion*, classificazione di regime macro con **Market Regime Switching (3-State Markov Model)**, rilevatore di anomalie di mercato via *Machine Learning Isolation Forest* e proiezioni stocastiche *Monte Carlo* (con decomposizione di Cholesky e distribuzioni *Student-t* a code grasse).
* **AI & LLM Narrative Intelligence (ARGUS AI Analyst & Copilot)**: Motore di sintesi narrativa automatica a due livelli (**LLM Online** con Google Gemini / OpenAI e **NLG Deterministico Offline 100%**) per generare Executive Memorandum istituzionali e rispondere in tempo reale a domande complesse sul portafoglio via chat interattiva.
* **Financial Statement & Forensic Accounting**: Suite completa per la valutazione della solvibilità e del valore intrinseco aziendale mediante modelli *Altman Z-Score*, decomposizione *DuPont a 5 fattori*, *Piotroski F-Score (9pt)*, **Contabilità Forense Beneish M-Score (1999)** a 8 indici econometrici per il rilevamento di frodi contabili e manipolazione degli utili, **Sloan Accrual Ratio (1996)** per la qualità dei flussi di cassa, stima del *WACC (CAPM)*, *DCF stocastico a due stadi* e classificatore *Random Forest Distress Risk*.
* **🎯 Goal-Based Investing & Multi-Life-Goal Engine (Merton Jump-Diffusion SPI %)**: Modulo di pianificazione per traguardi di vita (*FIRE, anticipo prima casa, università figli, rendita previdenziale*) con simulazione stocastica su 5.000 cammini a salti di Poisson, calcolo del **Success Probability Index (SPI %)**, coni di confidenza a ventaglio ($P5, P25, P50, P75, P95$), stima dello shortfall e risolutore dell'apporto mensile PAC raccomandato per raggiungere SPI $\ge$ 85%.
* **📉 Target-Date Dynamic Glide Path & TCO / Fee Drag Lookthrough**: Algoritmo sigmoideo di de-risking progressivo (*Equity $\to$ Fixed Income $\to$ Cash/Alts*) combinato con l'analizzatore di **Total Cost of Ownership (TCO)** per misurare l'erosione da costi di gestione (TER medio ponderato) su orizzonti di 5, 10, 20 e 30 anni rispetto a benchmark indicizzati a basso costo (0.15%).
* **📑 Client-Ready Advisory Pitchbook (PDF Multipagina Istituzionale)**: Generatore esecutivo di dossier PDF A4 a 6 pagine per Family Office e Private Banking con impaginazione pixel-perfect (Edge/Chrome headless e ReportLab in-memory), Stato Patrimoniale 360°, Health Score Radar a 5 pilastri, Goal-Based tracking, TCO MiFID II ex-post e Action Plan.
* **⚖️ Tax-Smart Rebalancing Watchdog & Drift Monitor**: Monitoraggio in tempo reale dello scostamento dell'asset allocation patrimoniale rispetto ai pesi target, rilevamento automatico del Cash Drag (con quantificazione del costo opportunità annuo) e generazione degli ordini di riallineamento a minimo impatto fiscale (TUIR Art. 67).
* **🏡 Real Estate Net Equity & Dynamic LTV Integration**: Collegamento dinamico tra gli immobili registrati e i debiti residui dei mutui per il calcolo in tempo reale del Net Home Equity, del Loan-to-Value (LTV %) medio ponderato e della rata di ammortamento stimata.
* **🌪️ Macro Factor Stress Testing Normativo & Reverse Stress (`STRESS MACRO` / `RSTRESS`)**: Scenari macroeconomici congiunti (EBA Regulatory Adverse 2026, Fed CCAR Severe, Stagflazione, Geopolitica Risk-Off) e risolutore numerico di Reverse Stress per identificare le soglie minime di crash necessarie a violare la solvibilità.
* **⚖️ Autonomous AI Rebalancer & MiFID II Suitability Gate (`PROP REBAL` / `MIFID CHECK`)**: Generatore automatico di distinte ordini (Trade Blotter) per riallineare il portafoglio ai pesi target con vincoli di turnover, stima dell'imposta capital gain (TUIR) e verifica di adeguatezza MiFID II e limiti di concentrazione (UCITS 5/10/40).
* **🌿 European SFDR Sustainability Desk & Carbon Footprint (`ESG` / `CARBON`)**: Diagnosi di sostenibilità conforme al Regolamento UE 2019/2088 (SFDR Art. 6/8/9), intensità carbonica ponderata ($t\text{CO}_2e/\text{M€}$) e screening controversie internazionali.
* **📈 Multi-Leg Options Strategy Workbench & Payoff Desk (`OPTS BUILD` / `PAYOFF`)**: Costruttore interattivo di strategie su derivati multi-gamba (Iron Condor, Protective Collar, Bull/Bear Spreads, Straddle) con analisi delle Greche aggregate (Delta, Gamma, Theta, Vega) e profilo di PnL a scadenza e anticipato.
* **📄 Universal White-Label Client Quarterly PDF Report Generator (`REPORT QTR`)**: Motore di reporting esecutivo multipagina ad alta risoluzione (PDF) per Family Office & HNWI con bilancio consolidato, attribuzione di performance Brinson, stress testing ed ESG scorecard.
* **🏛️ Private Debt, Direct Lending & Credit Waterfall Desk (`PDEBT` / `COVENANT`)**: Modello multi-tranche per investimenti in credito illiquido (Senior Secured, Unitranche, Mezzanine), monitoraggio contrattuale dei covenants (Debt/EBITDA, ICR, DSCR) e capitalizzazione interessi PIK (*Payment-in-Kind*).
* **🤖 Algorithmic Trade Execution & Implementation Shortfall (`ALGO EXEC` / `IMPACT`)**: Scomposizione analitica dei costi di transazione istituzionali (Perold 1988) tra Delay, Market Impact, Commissioni e Costo Opportunità, con benchmark comparato tra ordini a mercato, TWAP, VWAP e Adaptive IS.
* **🌍 Cross-Border Tax & Global Wealth Structuring Engine (`GLOBAL TAX` / `RESIDENCY`)**: Simulatore tributario comparato per patrimoni internazionali (Italia Ordinaria, Art. 24-bis Neo-Residenti 100k/200k, Svizzera Zugo, Lussemburgo SOPARFI, Dubai Zero-Tax) e ottimizzazione ritenute estere DTT.
* **⚡ Machine Learning Hidden Markov Models (HMM) Regime Detection (`HMM` / `REGIME ML`)**: Rilevamento non supervisionato a 3 stati latenti di mercato (Bull, Range-Bound, Crisis), matrice di transizione dinamica e raccomandazioni tattiche anticicliche.
* **🎙️ AI Voice Executive Briefing & Wealth Audio Podcast (`VOICE BRIEF` / `AUDIO`)**: Generatore automatico di audio briefing esecutivi e copioni broadcast a 2 voci (Chief Investment Officer & Chief Risk Officer) sincronizzati sui dati reali di bilancio.
* **📊 Wealth Temporal Analytics & Net Worth Dynamics (`WEALTH TIME` / `WTIME`)**: Suite temporale completa per il patrimonio con traiettoria storica a 24 mesi per asset class, matrice mensile dei flussi di risparmio (Gen..Dic + Totale Annuo), curva Underwater di drawdown patrimoniale vs High-Water Mark, metriche rolling a 6 mesi (Growth %, Volatilità %, Liquid Share %) e diagnosi di stagionalità dei flussi.
* **📑 Hub di Reportistica & Esportazioni Istituzionali Multi-Formato (9 Formati)**: Centro unificato di export per Family Office e HNWI con White-Label Client Quarterly PDF ReportLab, Advisory Pitchbook a 6 pagine, Tear-Sheet Sintetica (PDF/HTML), Master Excel Dossier (.xlsx a 10 fogli con formule), Parquet Analytical Database, Prospetto Fiscale Quadro RW/RT (.csv), Registro Transazioni (.csv), Snapshot JSON e Copione Audio Podcast (.txt).
* **🎓 Wealth Educational Modals & IFRS/GIPS Dialogs (`@st.dialog`)**: Modali informativi interattivi in alta risoluzione distribuiti su tutti i moduli Wealth per guidare l'utente su metodologia di bilancio, regola 50/30/20, perizie illiquidi, modello di Merton SPI %, ammortamento mutui e successioni.
* **Interfaccia Istituzionale, Navigation Rail Bidirezionale & Spotlight (`Ctrl+K`)**: Sincronizzazione automatica tra Sidebar ed elementi attivi delle pagine, **Spotlight Command Palette** integrata per ricerca globale istantanea su tutti i 22 moduli, oltre 50 sottomoduli, ticker e comandi di sistema, comparatore **Multi-Benchmark Overlay** fino a 4 indici contemporanei con scorecard di Alpha e Sharpe, e architettura *Zero-Recalc* con reattività istantanea.
* **🌐 Institutional Splash Screen & Dual-Portal Gateway (`components/splash.py`)**: Gateway di benvenuto istituzionale con design Obsidian Dark Glass / Bento Grid Monolith, soppressione completa dei controlli sidebar e freccette collassate (`stExpandSidebarButton`) all'avvio, telemetria Bloomberg-style in tempo reale, conteggio certificato dei 22 moduli operativi (12 Risk & Quant + 10 Wealth & Advisory) e apertura automatica ed immediata della sidebar all'ingresso nel modulo prescelto.

---

## 🚀 Caratteristiche Chiave & Moduli Operativi (22 Moduli Istituzionali)

### 🏛️ SEZIONE 1: QUANTITATIVE RISK & PORTFOLIO BI (12 Moduli: 0 – 11)

### 0. 🎛️ Control Room & Total Wealth Hub (`src/0_Control_Room.py`)
* **⚡ Motore Analitico Embedded DuckDB & SQL Sandbox**: Esecuzione in-process vettorizzata SIMD per aggregazioni OLAP sub-millisecondo, preset istituzionali 1-click (Cubi Multi-Dimensionali, Window Functions `QUALIFY`, Storico Volumi/Commissioni, Matrice FX), console SQL interattiva ed esportazione compressa in formato **Apache Parquet**.
* **Multi-Broker Ingestion Hub**: Ingestione universale con auto-rilevamento (**Auto-Detect**) per CSV Standard, DeGiro, Directa SIM, Fineco Bank, Interactive Brokers (IBKR), Trade Republic e Scalable Capital. Include modale con guida export passo-passo per ciascun broker.
* **Total Wealth Hub (Multi-Account)**: Salvataggio di profili di portafoglio distinti per strategia (*Growth*, *Dividendi*, *Previdenza*, *Crypto*), caricamento rapido 1-click (`📂 Carica`), scorecard comparativa affiancata e **Consolidamento automatico in Master Wealth Portfolio** con fusione ponderata delle serie storiche dei rendimenti su oltre 5.000 osservazioni giornaliere, calcolo esatto del CAGR ancorato alla durata temporale solare e ottimizzazione Markowitz Ledoit-Wolf integrata.
* **Dual Pipeline Google Sheets Live**: Ingestione simultanea e separata di `History B/S Stocks` e `History B/S Crypto`, conversione multi-valuta e creazione automatica dei portafogli dedicati con persistenza locale e su MySQL.
* **Database & Memory Storage Cockpit**: Dashboard diagnostica con 4 KPI superiori (*Stato Piattaforma*, *Storage Totale Disco*, *RAM Processo*, *Cache Shield*), grafico Donut Plotly di ripartizione dello storage per tabella e file, e pulsanti di manutenzione 1-click (*VACUUM & Compatta DB*, *Pulisci Cache Scaduta TTL > 24h*, *Rigenera Indici B-Tree*).
* **Selezione Database & Multi-Valuta**: Switch dinamico tra database (`investment_risk_bi` vs `wealth`), modalità Offline in-memory e selezione valuta base (EUR, USD, GBP, CHF).
* **🎲 Archetipi Didattici & Portafogli Realistici 1-Click**: Selettore rapido ad espansione per caricare all'istante portafogli di trading realistici pluriennali (*Young Accumulator*, *FIRE Decumulation*, *HNWI Family Office*) direttamente nel motore di rischio e nella pipeline di analisi della piattaforma.
* **Diagnostica di Sistema & Multi-Tier Caching**: Monitoraggio in tempo reale delle latenze dei 26 motori computazionali e dello scudo anti-rate limit della cache locale SQLite.

### 1. 📈 Dashboard Generale & AI Analyst (`src/pages/1_📈_Dashboard_Generale.py`)
* **🧠 ARGUS AI Analyst (Executive Memorandum)**: Diagnosi narrativa strutturata in 4 sezioni (*Sintesi Esecutiva*, *Profilo di Rischio*, *Regime Macro*, *Raccomandazioni Tattiche*) con architettura dual-engine (Gemini / OpenAI API / NLG Deterministico Offline).
* **💬 ARGUS Quant Copilot**: Chatbot interattivo integrato con chip di scelta rapida per interrogare l'AI su VaR, Sharpe, ribilanciamento e titoli in portafoglio.
* **Executive Cockpit & Badges Istituzionali**: Sintesi quantitativa immediata, Radar Factor a 6 assi, PnL cumulato e conformità regolamentare.
* **Dynamic Multi-Benchmark Overlay & Scorecard**: Confronto simultaneo del portafoglio contro fino a 4 benchmark personalizzati (SPY, QQQ, ACWI, AGG, GLD, BTC) con tabella analitica comparativa (CAGR, Volatilità, Sharpe, Max Drawdown, Alpha).
* **Centro Esportazione Report**: Download in-memory di Factsheet PDF a 2 pagine, Workbook Excel multi-tab, Report HTML Standalone e pacchetto Star Schema ZIP per Power BI.

### 2. 🖥️ Live Terminal & Real-Time Market Desk (`src/pages/2_🖥️_Live_Terminal.py`)
* **🛡️ Desk Compliance HUD & Pre-Trade Risk Checks**: Controllo automatico e vincolante dei limiti di conformità istituzionale prima dell'invio a mercato (`evaluate_pre_trade_risk`), con monitoraggio in tempo reale del **Circuit Breaker** di perdita giornaliera (max -€5.000), del tetto di concentrazione su singolo asset (max 25%), della leva lorda (max 1.50x) e dell'impatto marginale sul VaR ($\Delta\text{VaR}$).
* **⚡ Live Market Streaming Tape & Level-2 Order Book**: Ingestione ad alta frequenza di quotazioni spot real-time multi-asset via `yfinance fast_info`, visualizzazione del Level-2 Depth Book a 5 livelli Bid/Ask, calcolo istantaneo del **Microprice di Stoikov (2018)**, **VWAP** e **Order Flow Imbalance (OFI)**.
* **⚡ Fast Ladder Trading & One-Click DOM Routing**: Pannello di immissione ed esecuzione ordini ultra-rapido (`🟢 BUY`, `🔴 SELL`, `🛑 Chiudi Posizione`) con routing istantaneo verso l'OMS, algoritmi di execution slicing `MKT`, `TWAP (15m)` e `VWAP (30m)`.
* **🧩 Intraday Multi-Currency PnL Attribution**: Scomposizione analitica del PnL Day (€) in **Effetto Prezzo Titolo** $(\text{Qty} \cdot \Delta\text{Spot} \cdot \text{FX}_{t-1})$ ed **Effetto Tasso di Cambio FX** $(\text{Qty} \cdot \text{Spot}_t \cdot \Delta\text{FX})$, con visualizzazione a zero latenza nella tabella del portafoglio e nei KPI superiori.
* **📈 Relative Performance Overlay Chart & Benchmark Matrix (Base 0%)**: Modulo di confronto dinamico intraday normalizzato a base 0.00% tra il Portafoglio ARGUS e i benchmark di riferimento (SPY, QQQ, BTC-USD, EUR/USD), arricchito dalla **Matrice di Performance Relativa & Alpha Intraday** con stima di Beta implicito e stato di Momentum.
* **📰 Live News & Macro Catalyst Feed Hub**: Feed istituzionale di annunci macroeconomici (CPI, decisioni BCE/Fed) ed eventi societari (trimestrali/earnings, lanci prodotto) con sentiment score (`BULLISH 🟢`, `HAWKISH 🦅`, `VOLATILE ⚡`, `NEUTRAL ⚪`) e countdown temporale.
* **⌨️ Console Interattiva Bloomberg CLI (`ARGUS:LIVE>`)**: Prompt a riga di comando ad alta densità con supporto immediato all'invio con tasto **INVIO** (`PORT LIVE`, `PORT RISK`, `WATCHLIST`, `QUOTE <TICKER>`, `VAR 95`, `TOP`, `BUY`, `TWAP`, `EQS`, `SQL`, `NEWS`, `SNAP`, `SHOCK`, `CORR`).
* **📋 Live OMS Execution Blotter**: Simulatore di negoziazione con algoritmi di order slicing TWAP e VWAP, stima dello slippage e calcolo del risparmio eseguito.
* **📊 Telemetria di Sistema (TOP Monitor)**: Monitoraggio in tempo reale di RAM RSS, utilizzo CPU, thread attivi, cache e record DB.

### 3. 🔴 Analisi del Rischio & Rilevamento Anomalie (`src/pages/3_🔴_Analisi_Rischio.py`)
* **📊 Profilo del Rischio & Fama-French**: Rischio sistematico Beta, Tracking Error, Information Ratio, asimmetria (Skewness), curtosi (Kurtosis/Fat Tails) e regressione OLS multivariata sui 3 fattori accademici Kenneth French.
* **🚦 Backtesting Regolamentare Basilea IV (Traffic Light Framework)**: Validazione istituzionale su finestra a 250 giorni per il VaR 99% a 1 giorno con classificazione in Zona Verde ($x \le 4$, moltiplicatore $3.00$), Gialla ($5 \le x \le 9$) o Rossa ($x \ge 10$, moltiplicatore $4.00$), test di Kupiec (POF), test di indipendenza di Christoffersen (clustering delle eccezioni) e test di copertura condizionale congiunto.
* **⚡ Extreme Value Theory (EVT POT-GPD a 99.0% e 99.9%)**: Stima del rischio di coda asimmetrico e dei cigni neri tramite approccio Peaks-Over-Threshold (POT) e distribuzione di Pareto Generalizzata (GPD) conforme ai requisiti di Basilea IV per scenari di stress estremi.
* **💱 Decomposizione del Rischio di Cambio (FX Risk) & Forward Hedging**: Scomposizione analitica della varianza $(\sigma^2_{tot} \approx \sigma^2_{local} + \sigma^2_{fx} + 2\text{Cov})$, quantificazione dell'esposizione valutaria aperta in Euro e simulazione del Forward Carry Drag annuo basato sulla Covered Interest Rate Parity.
* **📉 VaR, CVaR & Decomposizione di Eulero**: Decomposizione di Eulero VaR/CVaR $(\sum \text{CVaR}_i = \text{VaR}_p)$, Marginal VaR $(\partial \text{VaR}/\partial w_i)$, Liquidity-Adjusted VaR (LVaR Bangia 1999) e 4 modelli di VaR (Storico, Parametrico Gaussiano, Cornish-Fisher asimmetrico e Filtered Historical Simulation FHS).
* **🔗 Correlazioni, Liquidità & ATR Chandelier**: Matrice di correlazione interattiva Pearson/Spearman, monitoraggio volumi medi giornalieri (Average Daily Volume ADV) e calcolo dinamico degli Stop-Loss Chandelier ($3 \times ATR_{14}$).
* **🕵️‍♂️ Rilevatore Anomalie ML (Isolation Forest)**: Algoritmo non supervisionato di Machine Learning per l'identificazione precoce di panic selling, rotture improvvise delle correlazioni storiche (*Correlation Breakdown*) e code di rischio non lineari.

### 4. 🔬 Modelli Quantitativi di Frontiera & Live Sandbox (`src/pages/4_🔬_Modelli_Quantitativi.py`)
* **📊 Markowitz & Rebalancing**: Frontiera Efficiente risolta via SciPy SLSQP vincolato con stimatori di covarianza *Ledoit-Wolf Shrinkage*, Parità di Rischio Pura (Equal Risk Contribution ERC), Frontiera 3D ad alta densità con campionamento Multi-Alpha Dirichlet e generatore di ribilanciamento interattivo.
* **💎 Portafoglio a Massima Diversificazione (MDP - Choueifaty & Coignard)**: Ottimizzazione del Diversification Ratio (DR) per massimizzare la diversificazione effettiva estraendo il massimo beneficio dalle correlazioni imperfette senza dipendere da stime di rendimento atteso.
* **🛡️ Min-CVaR Exact Linear Programming (Rockafellar & Uryasev 2000)**: Ottimizzazione convessa del Conditional Value at Risk formulata come Programma Lineare esatto e risolta in sub-5ms tramite solutore C++ HiGHS, con pulsanti di allocazione rapida one-click nel Super-Ribilanciatore.
* **🤖 AI Reinforcement Learning Policy Sandbox**: Ottimizzazione dinamica dei pesi di portafoglio basata su Policy Gradient REINFORCE e MDP continuo nello spazio degli stati $\mathbb{R}^{3N}$, addestrata ad adattarsi ai cambi di regime di mercato massimizzando il Sortino Ratio con controllo del turnover.
* **🧬 Tail Copula & Kelly**: Mappatura della dipendenza di coda asimmetrica inferiore ($\lambda_L$) e superiore ($\lambda_U$) con copule di Clayton e Gumbel per il rischio di crash sistemico, affiancata dal simulatore continuo/discreto Kelly Criterion & Half-Kelly Position Sizing.
* **🎲 Monte Carlo & Merton**: Simulazioni stocastiche previsionali a 10.000 cammini con Decomposizione di Cholesky e distribuzioni Student-t a code grasse, combinate con il modello Merton Jump-Diffusion a shock di salto Poissoniani.
* **🛡️ Hedging & Opzioni**: Prezzatura analitica Black-Scholes (1973), calcolo dei 5 Greci ($\Delta, \Gamma, \Theta, \mathcal{V}, \rho$), dimensionamento del Delta-Hedging con opzioni Put protettive, strategie Covered Call a lotti interi (100x) e calibrazione dello Skew/Smile di volatilità 3D.
* **🎯 Attribuzione & Fattori**: Decomposizione di Brinson-Fachler con algoritmo di raccordo logaritmico multi-periodale a residuo zero (Carino 1999), scomposizione valutaria Karnosky-Singer FX e backtesting fattoriale a 5 quintili con test di monotonicità di rango di Spearman ($r_s$).
* **🏛️ Fixed Income & Z-Spread**: Risolutore numerico per Yield to Maturity (YTM), Current Yield, Macaulay/Modified Duration, Convessità esatta, DV01/PVBP, Z-Spread rispetto alla curva sovrana Nelson-Siegel e term structure della probabilità di default da spread CDS.

### 5. 📋 Posizioni, Contabilità FIFO & Fiscalità TUIR (`src/pages/5_📋_Posizioni_e_Dettagli.py`)
* **📋 Posizioni Attive & Costi FIFO**: Mappa analitica e tabellare dei titoli in portafoglio con calcolo deterministico del Weighted Average Cost Price (WACP), separazione tra PnL realizzato/non realizzato e grafici di concentrazione settoriale GICS.
* **🪦 Posizioni Chiuse & Graveyard Cockpit**: Tracciamento contabile FIFO delle operazioni storiche chiuse, Curva Cumulativa del PnL Realizzato (€) con High-Water Mark di picco, telemetria di trade drawdown e Trading Calendar Heatmap Mese $\times$ Anno.
* **📅 Proiezione Dividendi**: Calendario dinamico mensile degli incassi cedolari per singola società, storico incassi reali e calcolo del Dividend Yield medio di portafoglio.
* **💰 Ottimizzazione Fiscale (TUIR Art. 67)**: Suite fiscale integrata a 4 pilastri con simulatore Riforma Fiscale 2026 (armonizzazione ETF e quantificazione Tax Drag), prospetto precompilato per il Regime Dichiarativo con Quadro RT (tributo 1100) e Quadro RW/IVAFE, analizzatore Withholding Tax (W-8BEN 15% USA, aliquota reale 37,10%) e simulatore pre-trade Tax-Smart Lot Sizing.
* **⚡ Liquidità & Smart Order Router**: Motore istituzionale di order slicing intraday (09:00 - 17:30) per la minimizzazione dello slippage su ordini consistenti e ribilanciamenti con profilazione della curva a "U", algoritmi **TWAP** uniforme (con jitter anti-frontrunning) e **VWAP** ponderato sui volumi (con POV Cap al 15%), affiancato dal modello di liquidazione ottima iperbolica di Almgren-Chriss.

### 6. 🏛️ Analisi dei Bilanci, Valutazione & Contabilità Forense (`src/pages/6_🏛️_Valutazione_Aziendale.py`)
* **Beneish M-Score (1999)**: Modello econometrico a 8 indici (DSRI, GMI, AQI, SGI, DEPI, SGAI, LVGI, TATA) per rilevare manipolazioni contabili (soglia critica $M > -1.78$).
* **Sloan Accrual Ratio (1996)**: Analisi della qualità dell'utile netto rispetto ai flussi di cassa operativi reali per isolare gli utili artificiali.
* **Altman Z-Score Model (1968)**: Previsione del rischio di fallimento a 24 mesi (*Safe Z > 2.99*, *Grey 1.81–2.99*, *Distress Z < 1.81*).
* **Diagnostica Predittiva ML (Random Forest Distress Classifier)**: Classificatore ensemble sui ratio finanziari per stimare la probabilità di default.
* **Scomposizione DuPont (3 e 5 Fattori)** & **Piotroski F-Score (9pt Stanford)**.
* **Valutazione Intrinseca DCF Monte Carlo (2-Stage)** & **WACC CAPM**.
* **Local RAG & SEC Filing Vector Store (Form 10-K / 10-Q Q&A)**: Interrogazione semantica in linguaggio naturale sui bilanci e note integrative con chunking normativo (**Item 1**, **Item 1A**, **Item 7 MD&A**, **Item 8 Debt Notes**), retrieval BM25/Cosine a latenza zero e citazione verificata delle fonti ufficiali.
* **Consultazione Bilanci Ufficiali 10-K** & **Comparativa Multiaziendale** con grafici Radar e multipli di settore.

### 7. 🌪️ Stress Testing & Scenari di Crisi (`src/pages/7_🌪️_Stress_Testing.py`)
* **MSCI Barra Multi-Scenario Matrix**: Stima delle perdite in € e % simulando i 5 grandi shock storici (*Dot-Com 2000*, *Lehman 2008*, *US Downgrade 2011*, *COVID-19*, *Rate Shock 2022*).
* **Beta Shock Waterfall & Macro Scenario Builder**: Simulazione interattiva su shock tassi ($\Delta r$), cambi ($\Delta\text{FX}$), materie prime ($\Delta\text{Commodity}$) ed equity.
* **Superficie 3D di Rischio (Plotly Surface)**: Mappatura tridimensionale interattiva dell'impatto combinato di shock congiunti.

### 8. 📊 Analisi Temporale & Storicizzazione Multi-Snapshot (`src/pages/8_📊_Analisi_Temporale.py`)
* **Time Series Multi-Snapshot**: Evoluzione temporale del controvalore di portafoglio, del capitale investito e delle metriche di rischio tra snapshot storici.
* **Matrice dei Delta ($\Delta$)**: Confronto analitico affiancato tra due punti temporali qualsiasi con calcolo del tasso di risparmio e apporti di liquidità.

### 9. 📈 Analisi Tecnica Quantitativa & Volume Profile (`src/pages/9_📈_Analisi_Tecnica.py`)
* **⚡ Real-Time Streaming Ring Buffer & Order Flow Imbalance (OFI)**: Ingestione tick-by-tick ad alta frequenza, VWAP dinamico, Order Flow Imbalance e Level-2 Microprice (Stoikov 2018).
* **Indicatori Algoritmici**: Medie Mobili (EMA 20, EMA 50, SMA 200 con Golden/Death Cross), MACD, RSI 14, Bande di Bollinger con **Bollinger Squeeze Detection**, ATR 14 e ADX 14.
* **Volume Profile (POC, VAH, VAL)**: Distribuzione orizzontale dei volumi sul grafico con evidenziazione del Point of Control (POC) e della Value Area (70% del volume totale).
* **Candlestick Pattern Recognition**: Rilevamento automatico di pattern (*Bullish/Bearish Engulfing*, *Hammer*, *Shooting Star*, *Doji*).
* **Technical Confluence Score Card (0-100)**: Score ponderato su 5 driver tecnici con verdetto tattico (*Strong Buy* $\rightarrow$ *Strong Sell*) e allineamento trend multi-timeframe (1D vs 1W).

### 10. 🔍 Screener Quantitativo & Pre-Trade Simulator (`src/pages/10_🔍_Screener_Opportunita.py`)
* **⚡ Formula Engine EQS (Custom Query Builder)**: Parsing ed esecuzione vettorizzata di espressioni logiche personalizzate dall'utente con oltre 35 alias finanziari supportati.
* **🚀 Parallel Multi-Thread Download (8 Workers)**: Download concorrente con ThreadPoolExecutor e retry esponenziale anti-429 per processare interi universi di mercato (fino a 100 titoli) in 2–4 secondi, con fallback automatico `fast_info` per ETF e crypto.
* **🔄 Granular Cache Invalidation & Force Live Refresh**: Tracciamento granulare del contenuto degli universi (preconfigurati, custom o portafoglio attivo) con pulsante `🔄 Forza Live` per bypassare istantaneamente la cache SQLite L2 e recuperare dati freschi.
* **Asset Discovery Multi-Fattoriale**: Esplorazione quantitativa di 11 universi globali (*US Mega Caps S&P 100*, *EuroStoxx 50*, *FTSE MIB Leaders*, *AI Supercycle*, *Dividend Champions*, *Healthcare*, *Defense & Aerospace*, *Portafoglio Attivo Live*, *Custom*) su Valutazione, Qualità Contabile, Rischio e Momentum.
* **Normalizzazione Istituzionale Dividend Yield %**: Calcolo normalizzato su $\frac{\text{dividendRate}}{\text{last\_price}}\times 100$, pricing sintetico per stablecoin ed ETF europei.
* **Smart Sizing Optimizer & Pre-Trade Simulator**: Simulazione *What-If* dell'impatto sul portafoglio reale ($\Delta\text{CAGR}$, $\Delta\sigma$, $\Delta\text{Sharpe}$, $\Delta\text{Beta}$, $\Delta\text{Diversification Ratio}$ di Choueifaty), determinazione del peso ottimo $w^*$ del candidato con curva di frontiera Sharpe.
* **Confronto Radar Head-to-Head & Factsheet PDF One-Pager**: Confronto grafico a 6 dimensioni fino a 4 titoli ed esportazione immediata di Factsheet PDF istituzionale ad alta risoluzione.

### 11. 💻 BQuant Python Sandbox, Workspace Launchpad & Excel Live Connector (`src/pages/11_💻_BQuant_e_Launchpad.py`)
* **🐍 Console Python Interattiva In-App (Bloomberg BQuant Style)**: Editor di codice Python integrato con iniezione dinamica in-memory dei DataFrame di sessione (`df_positions`, `df_returns`, `df_prices`, `results`), query SQL vettoriali ad alta velocità con DuckDB in-process, cattura automatica di stdout, tabelle `df_out` con download CSV e grafici Plotly interattivi con 5 snippet quantitativi istituzionali preimpostati.
* **🎛️ ARGUS Launchpad & Role Workspace Customizer**: Configurazione rapida dell'ambiente operativo basata su 5 profili istituzionali predefiniti (*Trading Desk & Execution*, *Risk Officer & Compliance*, *Portfolio Manager & CIO*, *Quantitative Analyst & Data Scientist*, *Corporate Treasurer & Fixed Income*) con 1-Click Fast Teleportation verso i moduli primari, Live Role KPI Cockpit e persistenza delle preferenze su SQLite locale.
* **📊 Excel Live Connector & Bloomberg RTD Formula Generator**: Costruttore visuale di formule Excel compatibili Bloomberg Terminal (`=ARGUS_BDP`, `=ARGUS_BDH`, `=ARGUS_RISK`), generatore di codice VBA Desktop (`.bas`), Microsoft Office Scripts TypeScript (`.ts`) per Excel 365/Web ed esportatore di workbook istituzionali multi-foglio formattati (`Executive_Summary`, `Positions_Portfolio`, `Fixed_Income_YAS`, `Execution_Schedule`).

---

### 💎 SEZIONE 2: WEALTH MANAGEMENT & PERSONAL FINANCE (10 Moduli: 12 – 21)

### 12. 🎛️ Wealth Control Room (`src/pages/12_🎛️_Wealth_Control_Room.py`)
* **🏛️ Master Wealth Hub & Multi-Account Management**: Centro di comando unificato per la gestione di conti correnti, depositi, conti titoli, carte e passività con switch dinamico tra profili patrimoniali.
* **🎲 Archetipi Patrimoniali Didattici 1-Click**: Modulo di iniezione transazionale atomica per popolare il database patrimoniale locale (`argus_local.db` / `argus_wealth.db`) con l'intero ecosistema finanziario (*Young Accumulator*, *FIRE Decumulation*, *HNWI Family Office*) inclusi conti, flussi di cassa, mutui con ammortamento francese, asset illiquidi con perizie periodiche, fondi pensione e snapshot storici.
* **🔄 Live Sync Google Sheets & Transazioni**: Sincronizzazione automatica da fogli Google con categorizzazione semantica, supporto multi-banca e associazione automatica conti.
* **🩺 Diagnostica di Bilancio & Master Excel Workbook**: Health Check del bilancio personale ed esportazione del Master Workbook Excel multi-tab (.xlsx) con bilancio patrimoniale consolidato.

### 13. 🏛️ Patrimonio & Net Worth Consolidato (`src/pages/13_🏛️_Patrimonio_e_NetWorth.py`)
* **📜 Bilancio Personale Istituzionale (Personal Financial Statements)**:
  * **Stato Patrimoniale a Sezioni Contrapposte**: Prospetto contabile conforme agli standard CFP Board e Private Banking, con aggregazione analitica dell'Attivo (Liquidità & Mezzi Equivalenti, Investimenti Finanziari, Previdenza di Lungo Termine, Attività Reali & Beni Personali, Crediti) contrapposto a Passività (Debiti a breve e medio/lungo termine) e Patrimonio Netto con quadratura a pareggio matematico perfetto ($\text{Totale Attivo} = \text{Totale Passivo} + \text{Patrimonio Netto}$, $\Delta = 0,00\text{ €}$).
  * **Conto Economico di Gestione (Income Statement)**: Rendiconto economico per anno solare con distinzione rigorosa tra Redditi Personali (Lavoro, Capitale, Supporto familiare, Rimborsi) e Costi di Gestione/Consumi di vita (Abitazione, Alimentari, Ristorazione, Mobilità, Formazione, Salute, Svago).
  * **Waterfall Chart & Allocazione del Capitale**: Rappresentazione grafica Plotly a cascata dai flussi lordi al Risparmio Netto d'Esercizio, con rendiconto della destinazione del surplus tra investimenti in asset produttivi (PAC Titoli/ETF, Cripto-attività, Fondi Pensione) e accantonamento di cassa liquida.
  * **6 Indici di Bilancio & Radar di Solidità**: Suite di KPI patrimoniali con benchmark istituzionali e semafori di sicurezza: *Indice di Solvibilità* ($\ge$ 70%), *Debt-to-Assets* ($\le$ 30%), *Runway Fondo di Emergenza* ($\ge$ 6 mesi), *Personal Savings Rate* ($\ge$ 20%), *Debt Service-to-Income DSTI* ($\le$ 33%), *Invested Assets Ratio* ($\ge$ 50%) affiancati da Radar Chart e rating sintetico (AAA / AA / A).
  * **Bilancio Comparativo Pluriennale (2021–2026)**: Prospetto comparativo storico con serie a 6 esercizi di Attivo, Passivo, Patrimonio Netto, delta anno su anno (€ e %) e savings rate medio, corredato da grafico evolutivo e pulsante di esportazione CSV immediata.
  * **🌪️ Stress Testing Macroeconomico Consolidato sul Patrimonio Netto (Sub-Tab 6)**: Simulazione congiunta degli shock regolamentari EBA Adverse 2026, Fed CCAR Severe, Stagflazione e Geopolitico su tutto l'attivo consolidato, con stima della perdita di capitale netto, del drawdown e dell'effetto leva finanziaria (*Debt-to-Assets Post-Stress*).
* **🏛️ Consolidamento a 5 Livelli**: Aggregazione in tempo reale di Liquidità, Investimenti Finanziari (collegamento dinamico a portafogli Risk), Asset Fisici/Caveau, Previdenza Integrativa e Passività.
* **🏆 Wealth Health Score (0-100)**: Punteggio sintetico di salute patrimoniale calcolato su 5 pilastri: Riserva di Liquidità, Tasso di Risparmio, Diversificazione, Copertura Previdenziale e Grado di Indebitamento (DTI).
* **🌪️ Global Wealth Stress-Testing 3D, Waterfall & Liquidity Squeeze Timeline**: Simulazione interattiva di shock macro congiunti (Stagflazione 2022, Cigno Nero, Crisi Immobiliare, GFC 2008 Deflattivo, COVID 2020) con scomposizione Plotly Waterfall, stima del *Point of Forced Liquidation ($t^*$)*, calcolo della variazione rata mutuo alla francese, Dynamic FIRE SWR (Guyton-Klinger) e proiezione Monte Carlo della ripresa del Net Worth a 10 anni.
* **🏢 Family Office Multi-Entity & Holding Consolidator**: Consolidamento patrimoniale e societario tra diverse entità giuridiche del nucleo familiare (*Persona Fisica, Holding SRL, Società Semplice, Trust Familiare, Polizze Dedicate*) con elisione automatica delle partite infragruppo (finanziamenti soci ed equity intercompany) e analisi di convenienza fiscale **PEX (Participation Exemption Art. 87 TUIR: 1,2% effettivo vs 26% IRPEF)**.
* **💱 Multi-Currency FX Exposure & Forward Hedging Overlay**: Mappatura dell'esposizione a valute estere (USD, GBP, CHF, JPY), calcolo dei Forward Points e costo annuo di copertura secondo la Covered Interest Parity (CIP) e simulazione di scenari di shock valutario (-15%) a confronto tra strategie Unhedged, 50% e 100% Hedged.
* **🎯 Total Wealth Brinson-Fachler Multi-Asset Attribution**: Scomposizione del rendimento attivo patrimoniale (Alpha) rispetto a un benchmark strategico composito in Effetto Allocazione, Effetto Selezione ed Effetto Interazione su tutto il patrimonio consolidato.
* **📊 Trend Storico & Snapshot Temporali al 31/12**: Storicizzazione dei bilanci patrimoniali e congelamento batch degli snapshot ufficiali di chiusura esercizio (2021–2025).
* **📑 Dossier PDF Istituzionale a 4 Pagine & Client-Ready Advisory Pitchbook**: Generazione esecutiva in formato PDF certificato a 4 pagine (Stato Patrimoniale, Conto Economico, Indici di Solidità e Bilancio Comparativo Pluriennale con CSS Progress Bars) e HTML interattivo per clientela Private Banking e Family Office.

### 14. 💳 Cash Flow, Budgeting 50/30/20 & Spese (`src/pages/14_💳_Cash_Flow_e_Spese.py`)
* **📊 Libro Mastro Entrate & Uscite**: Analisi granulare dei flussi di cassa, scomposizione per categorie di spesa e monitoraggio del tasso di risparmio mensile.
* **⚖️ Regola del 50/30/20 & Zero-Based Budgeting**: Valutazione automatica della ripartizione tra Bisogni Primari (50%), Desideri/Discrezionali (30%) e Risparmio/Investimenti (20%).
* **🔍 Smart Cashflow Reconciliation & Auto-Matching**: Algoritmo di pattern matching semantico tra flussi contabili bancari ed impegni contrattuali ricorrenti (mutui, stipendi, abbonamenti), con calcolo del tasso di riconciliazione e rilevamento istantaneo di doppi addebiti sospetti.
* **🔁 Subscription Sentinel & Cumulative Opportunity Drag**: Rilevamento automatico degli abbonamenti ricorrenti e delle rate a termine (da `Config_FixedExpenses`), con stima del capitale perso se investito al 7% annuo su 5, 10 e 20 anni.
* **🔮 Rolling Cash Flow Forecast & Z-Score Anomalies**: Proiezioni probabilistiche di cassa a 3 e 6 mesi (bande P10/P50/P90) e rilevamento statistico delle uscite straordinarie anomale ($Z \ge 1.8$).

### 15. ⌚ Asset Illiquidi, Caveau & Orologi di Lusso (`src/pages/15_⌚_Asset_Illiquidi_e_Orologi.py`)
* **🪙 Caveau Metalli Preziosi**: Gestione metalli da investimento (Oro 18K/24K, Argento) con rivalutazione automatica al prezzo spot e calcolo plusvalenze.
* **⌚ Collezione Orologi di Lusso**: Inventario orologi da collezione (Rolex, Omega, Patek Philippe, ecc.) con tracciamento referenza, corredo, grado di conservazione e pricing di mercato.
* **💼 Private Equity, Venture Capital & J-Curve Waterfall**: Monitoraggio di quote societarie non quotate, club deal e fondi chiusi con tracking di Capitale Impegnato (Committed), Richiamato (Called) e Unfunded, metriche standard ILPA (**MOIC/TVPI**, **DPI**, **RVPI**, **XIRR**) e modellazione stocastica della J-Curve a 8 anni.
* **💧 Matrice di Liquidabilità**: Mappatura del tempo medio di smobilizzo (Days-to-Cash) e haircut prudenziale in caso di liquidazione rapida.

### 16. 🛡️ Previdenza & Pension Planning (`src/pages/16_🛡️_Previdenza_e_Pension_Planning.py`)
* **📜 Cronistoria Previdenziale & Scudo Fiscale Dinamico (2023–2026)**: Tabella analitica dei versamenti storici con tracking della deducibilità fiscale IRPEF (art. 51 TUIR, tetto 5.164,57 €), risparmio d'imposta reale (aliquota 43%) e plafond residuo con anno d'esercizio dinamico (`datetime.now().year`), affiancata dal grafico evolutivo su doppio asse (versamenti annui vs montante accumulato).
* **🎲 Simulazione Monte Carlo Fondo Pensione**: Proiezione stocastica del montante pensionistico a 10.000 scenari con calcolo rendita mensile attesa post-tassazione agevolata (15% $\rightarrow$ 9%).
* **💼 Rivalutazione TFR (Trattamento di Fine Rapporto)**: Calcolo contabile della rivalutazione annuale di legge (1.5% + 75% FOI) e confronto rendimento TFR in azienda vs Fondo Pensione negoziale/aperto.
* **🏛️ Gap Previdenziale & Tasso di Sostituzione**: Stima della pensione pubblica INPS attesa e quantificazione del gap reddituale rispetto all'ultimo stipendio.

### 17. 🔥 Indipendenza Finanziaria, FIRE & Goal-Based Engine (`src/pages/17_🔥_Indipendenza_Finanziaria_e_FIRE.py`)
* **🧮 Calcolatore FIRE Dinamico**: Determinazione del FIRE Number per 4 archetipi (*Standard FIRE 100%*, *Lean FIRE 70%*, *Fat FIRE 135%*, *Coast FIRE*).
* **🌪️ Ponte Wealth ⇄ Risk Management**:
  * **Fondo Anti-Forced Selling (Liquidity-at-Risk)**: Calibrazione dinamica dei mesi di runway in funzione del 95% CVaR e della volatilità di mercato per azzerare il rischio di vendite forzate in drawdown.
  * **Net Worth-at-Risk (NWaR)**: Stress test macroeconomico consolidato su shock sistemici (*Crisi 2008*, *Stagflazione*, *Crypto Winter*, *Job Loss*).
  * **Dynamic Safe Withdrawal Rate (SWR)**: Tasso di prelievo sicuro con regime switching anticiclico (*3.2% Crisi*, *3.8% Normale*, *4.2% Bull Market*).
* **🎯 Goal-Based Multi-Traguardo & Stocastico Merton Jump-Diffusion (SPI %)**:
  * Gestione e persistenza su DB di $N$ traguardi di vita (*Casa, FIRE, Studi, Auto, Pensione*).
  * Simulazioni Monte Carlo su 5.000 scenari stocastici a salti di Poisson con ventaglio $P5-P95$, stima dello shortfall e calcolo dell'apporto mensile PAC ottimale per raggiungere un **Success Probability Index (SPI $\ge$ 85%)**.
  * **Dynamic Glide Path**: Curva sigmoidea di de-risking temporale (Equity $\to$ Bonds $\to$ Cash $\to$ Oro).
* **🔮 Sequence of Returns Risk (SRR) & Decumulation Crash Test**:
  * Simulatore di decumulo patrimoniale a 30 anni sotto 4 regimi di sequenza rendimenti (*Early Crash -25% Y1-Y3*, *Rendimento Costante +6%*, *Late Crash Y11*, *Early Crash CON Glide Buffer*).
  * Dimensionamento algoritmico del **Glide Cash Buffer** ($SWR \times 2.5\text{ anni}$) per azzerare le liquidazioni forzate in bear market.
* **💸 Total Cost of Ownership (TCO) & Fee Drag Breakdown**:
  * Stima del TER medio ponderato degli strumenti e quantificazione dell'erosione patrimoniale cumulativa da commissioni a 5, 10, 20 e 30 anni vs benchmark ETF low-cost (0.15%).

### 18. 📑 Fiscalità, Quadro RW & Tax-Loss Harvesting (`src/pages/18_📑_Fiscalita_e_Quadro_RW.py`)
* **🏛️ Ripartizione Fiscale Italia vs Estero**: Monitoraggio dell'incidenza tributaria patrimoniale (Imposta di Bollo IT 0,20% vs IVAFE estera).
* **🌾 Motore di Tax-Loss Harvesting**: Identificazione quantitativa delle posizioni in perdita latente da realizzare strategicamente entro il 31 dicembre per compensare lo zainetto fiscale quadriennale.
* **🛡️ Simulatore Deduzione IRPEF Fondo Pensione**: Calcolo del credito IRPEF recuperabile in busta paga (Modello 730) saturando il plafond di € 5.164,57 per gli scaglioni al 23%, 35% e 43%.
* **📑 Monitoraggio Monitoraggio Fiscale Quadro RW & Criptovalute**.

### 19. 🏡 Immobili, Mutui & Buy vs Rent (`src/pages/19_🏡_Immobili_e_Mutui.py`)
* **📐 Piani di Ammortamento Mutuo**: Simulatore mutui a tasso fisso e variabile con calcolo quota capitale, quota interessi, debito residuo e impatto di estinzioni anticipate parziali.
* **🏢 Real Estate ROI & Cap Rate**: Valutazione del rendimento lordo/netto da locazione, Cash-on-Cash Return e incidenza imposte (Cedolare Secca vs IRPEF, IMU).
* **⚖️ Buy vs Rent Analyzer**: Modello comparativo a valore attuale netto (NPV) tra acquisto prima casa con mutuo vs affitto con investimento del capitale risparmiato.

### 20. ⚖️ Pianificazione Successoria, Generational Transfer & Asset Protection (`src/pages/20_⚖️_Pianificazione_Successoria.py`)
* **📜 Asse Ereditario & Riunione Fittizia (Art. 556 c.c.)**: Formalizzazione contabile dell'attivo ereditario $\text{Asse} = \max(0, \text{Relictum} - \text{Debiti}) + \text{Donatum}$ con deducibilità passività e divieto di erosione del donatum sotto zero (Cass. Civ. 12919/2012).
* **🍰 Quote di Riserva e Disponibile (Codice Civile Artt. 536-544 c.c.)**: Ripartizione matematica per tutte le configurazioni familiari: coniuge solo (50% riserva + diritto abitazione art. 540 c.c.), coniuge + 1 figlio (1/3 ciascuno), coniuge + $\ge 2$ figli (25% coniuge, 50% figli), solo figli (50% unico, 66.67% multipli), concorso coniuge (50%) + ascendenti (25%) ex art. 544 c.c., e soli ascendenti (33.33% art. 538 c.c.).
* **🛡️ Diagnostica Azione di Riduzione (Artt. 553-564 c.c.)**: Rilevamento in tempo reale delle lesioni di legittima su disposizioni testamentarie e donazioni pregresse a ritroso.
* **🧾 Motore Fiscale Successioni e Donazioni (D.Lgs. 346/1990 - TUS & D.Lgs. 347/1990)**:
  * Mappatura aliquote e franchigie per grado di parentela: 4% oltre 1.000.000€ (coniuge/linea retta), 6% oltre 100.000€ (fratelli/sorelle), 6% senza franchigia (parenti entro 4° grado), 8% (terzi estranei).
  * Franchigia maggiorata a **1.500.000€** per soggetti con disabilità grave riconosciuta ex L. 104/1992 (art. 2 c. 49-bis D.L. 262/2006).
  * Imposte ipotecarie (2%) e catastali (1%) con calcolo forfettario fisso a **€ 400 totali** (€ 200 + € 200) per agevolazione "Prima Casa" (L. 342/2000).
* **🚀 Generational Transfer Optimizer (Ante vs. Post Pianificazione HNWI)**:
  * Simulatore quantitativo per confrontare lo *Status Quo* (inerzia successoria) contro la *Pianificazione Attiva*.
  * **Leva Polizze Vita Ramo I/III**: Capitale esente da imposta successoria (art. 12 lett. c TUS), impignorabile/insequestrabile (art. 1923 c.c.) e liquidabile agli eredi entro 30 giorni per azzerare il *Succession Liquidity Crunch*.
  * **Leva Patto di Famiglia & Holding Familiare (Società Semplice)**: Esenzione totale al 100% da imposta di successione/donazione per quote di controllo societario ($\ge$ 50%+1) ex art. 3 c. 4-ter TUS con prosecuzione quinquennale e blindatura legale da collazione e riduzione (art. 768-quater c.c.).
  * **Leva Donazione Nuda Proprietà Immobili**: Applicazione della tabella ministeriale attuariale dei coefficienti di usufrutto a vita per età del donante (D.P.R. 131/1986) con abbattimento immediato della base imponibile e consolidamento automatico a costo zero alla morte.
  * **Leva Cointestazione Conti**: Presunzione paritetica 50% ex art. 1298 c.c. con liquidità immediatamente disponibile agli eredi.
  * Cruscotto interattivo KPI con delta imposte risparmiate (€ e %), Liquidity Coverage Ratio (LCR), Score di Protezione Patrimoniale (0-100) ed esportazione dell'**Executive Succession Memorandum** in Markdown.

### 21. 🤖 AI Wealth Copilot & Advisor (`src/pages/21_🤖_AI_Copilot_e_Advisor.py`)
* **🧠 Diagnostica Patrimoniale AI**: Analisi automatica in linguaggio naturale dello stato di salute patrimoniale, cash flow ed esposizione al rischio.
* **📑 Executive Quarterly Review (NLG)**: Generazione automatica di Relazioni Trimestrali Istituzionali in Markdown per Family Office e clienti Private Banking, strutturate in 5 sezioni (*Executive Summary*, *Asset Allocation & Drift*, *Goal Progress*, *Macro & Fiscal Outlook*, *Raccomandazioni Tattiche*).
* **💬 Assistente Finanziario Interattivo**: Chatbot avanzato con accesso in tempo reale al bilancio consolidato, budget e simulazioni FIRE.
* **📄 Generatore Report Istituzionali**: Creazione di Tear Sheet patrimoniali completi e sintesi esecutive stampabili.

---

## 🏛️ Architettura di Runtime del Sistema

```mermaid
flowchart TD
    subgraph Layer1 ["📡 1. DATA SOURCES & INGESTION"]
        CSV[/"📄 File CSV Utente Generico"/]
        DEGIRO[/"📄 Export Broker DeGiro CSV"/]
        GSHEETS[/"🌐 Google Sheets Live Sync (Service Account)"/]
        YF(("🌐 yfinance API (Prezzi & Metadati)"))
    end

    subgraph Layer2 ["⚙️ 2. ETL & VALIDATION PIPELINE"]
        ADAPT{"🔌 core/adapters/broker_hub.py"}
        VAL{"⚙️ core/validator.py"}
        SCH{"🛡️ core/schemas.py"}
        FETCH{"⚙️ core/fetcher.py"}
        CACHE{"⚡ core/cache_shield.py (LRU + SQLite 24h)"}
    end

    subgraph Layer3 ["🗄️ 3. DATA WAREHOUSE & WEALTH REGISTRY"]
        DB_RAW[("Tabelle Grezze ORM\n(portfolios, assets, transactions, market_prices)")]
        DB_SNAP[("Tabelle Snapshot Metriche\n(portfolio_snapshots, snapshot_positions)")]
        MULTI_REG[("🗂️ core/multi_portfolio.py\n(Total Wealth Registry & Merged Snapshots)")]
        DUCK_OLAP[("🦆 core/duckdb_engine.py\n(In-Memory OLAP & Parquet Store)")]
    end

    subgraph Layer4 ["🧠 4. ANALYTICS & QUANTITATIVE ENGINE"]
        RE{"⚙️ core/risk_engine.py (VaR/CVaR, LVaR, Almgren-Chriss)"}
        ADV_Q{"🧬 core/advanced_quant.py (Tail Copulas, Kelly, ERC)"}
        FACTORS{"📊 core/factor_library.py (Dartmouth 5-Factor & Q1-Q5 Backtest)"}
        FI_YAS{"🏛️ core/fixed_income.py (YAS, Z-Spread, CDS Curve)"}
        STREAM_ENG{"⚡ core/streaming_engine.py (Ring Buffer, VWAP, OFI)"}
        AI_ANL{"🧠 core/ai_analyst.py (Dual-Engine LLM/NLG & Copilot)"}
        BQUANT_ENG{"🐍 core/bquant_engine.py (Python Sandbox & DuckDB SQL)"}
        WS_ENG{"🎛️ core/workspace_engine.py (Launchpad Role Profiles)"}
        XL_ENG{"📊 core/excel_connector.py (Bloomberg Formulas & XLSX)"}
        HRP{"🧬 core/hrp_optimizer.py"}
        OPT{"🛡️ core/options_hedging.py & volatility_surface.py"}
        REG{"🌊 core/regime_switching.py & garch_fhs_engine.py"}
        FIN{"🏛️ core/financial_analysis.py & sec_rag_engine.py"}
        FORENSIC{"🕵️‍♂️ core/forensic_accounting.py (Beneish & Sloan)"}
        TA{"📈 core/technical_analysis.py"}
        SCREENER{"🔍 core/screener_engine.py (EQS Formula Engine)"}
        TAX{"💰 core/tax_engine.py & crypto_tax_engine.py"}
        REBAL{"⚖️ core/rebalancer.py"}
        DIV{"📅 core/dividend_engine.py"}
        DIAG{"🩺 core/diagnostics.py"}
        DBEXP{"⚙️ core/db_exporter.py"}
    end

    subgraph Layer5 ["📊 5. PRESENTATION & DESKTOP REPORTING LAYER"]
        APP("💻 Streamlit App / Dual Gateway Control Room (22 Moduli Live)")
        DESK("🖥️ Native Desktop App (desktop_launcher.py + WebView2)")
        SPOTLIGHT{"🔍 Spotlight Command Palette (Ctrl+K)"}
        REPEXP{"📄 core/report_exporter.py (PDF, Excel, HTML)"}
        STARZIP{"🗃️ scripts/export_star_schema.py (Power BI ZIP)"}
        POWERBI[/"📈 Power BI / Looker Studio"/]
    end

    DEGIRO ==> ADAPT
    ADAPT --> VAL
    CSV ==> VAL
    GSHEETS ==> VAL
    VAL --> SCH
    SCH --> FETCH
    YF <==> CACHE <==> FETCH
    FETCH ==> DB_RAW
    DB_RAW ==> DUCK_OLAP
    DB_RAW ==> RE
    DB_RAW ==> FIN
    DB_RAW ==> TA
    RE --> ADV_Q
    RE --> FACTORS
    RE --> FI_YAS
    RE --> AI_ANL
    RE --> DBEXP
    DBEXP ==> DB_SNAP
    DBEXP ==> MULTI_REG
    RE ==> APP
    ADV_Q ==> APP
    FACTORS ==> APP
    FI_YAS ==> APP
    STREAM_ENG ==> APP
    BQUANT_ENG ==> APP
    WS_ENG ==> APP
    XL_ENG ==> APP
    AI_ANL ==> APP
    FIN ==> APP
    TA ==> APP
    SCREENER ==> APP
    SPOTLIGHT ==> APP
    REPEXP --> APP
    STARZIP --> POWERBI
```

---

## 🚀 Quick Start & Modalità di Esecuzione

ARGUS è progettato con un'architettura ibrida a zero-frizione che supporta quattro diverse modalità di esecuzione:

### 🖥️ Opzione 1: Launcher Desktop Nativo 1-Click (Windows)
Per la massima comodità su ambienti Windows 10/11 senza digitare comandi da terminale:
1. **Setup Iniziale (1-Click)**: Fai doppio clic su `setup_desktop.bat` per installare le dipendenze e generare l'icona sul Desktop.
2. **Avvio Applicativo**: Fai doppio clic su `start_dashboard.bat`. Lo script rileva automaticamente l'interprete Python del sistema e avvia la finestra nativa accelerata via hardware (PyWebView2) con fallback trasparente sul browser web predefinito.

---

### 🐍 Opzione 2: Ambiente Virtuale Locale (Linux / macOS / Windows)
Per sviluppatori e quant researcher che utilizzano il terminale standard:

```bash
# 1. Clona il repository
git clone https://github.com/Alessandro-Sal/argus-risk-analytics.git
cd argus-risk-analytics

# 2. Crea e attiva l'ambiente virtuale (Python 3.11 o 3.12 raccomandato)
python -m venv .venv

# Su Linux/macOS:
source .venv/bin/activate
# Su Windows (PowerShell):
.venv\Scripts\Activate.ps1
# Su Windows (CMD):
.venv\Scripts\activate.bat

# 3. Installa le dipendenze con ruote binarie ottimizzate
python -m pip install --upgrade pip
pip install -r requirements.txt

# 4. Avvia la Control Room istituzionale
streamlit run src/0_Control_Room.py
```
La dashboard si aprirà automaticamente all'indirizzo `http://localhost:8501`.

---

### 🐳 Opzione 3: Container Docker & Docker Compose (Isolamento Totale)
Per distribuire l'applicazione in un ambiente containerizzato production-ready con database relazionale MySQL 8.0:

```bash
# Avvia l'infrastruttura completa (Web App + MySQL 8.0 Data Warehouse)
docker compose up --build -d

# Visualizza i log in tempo reale
docker compose logs -f argus-app
```
L'applicazione risponde su `http://localhost:8501` e il database su porta `3306`.

---

### ☁️ Opzione 4: Streamlit Community Cloud (Zero-Ops)
1. Forka o collega il repository al tuo account [Streamlit Community Cloud](https://share.streamlit.io/).
2. Configura il Main file path su: `src/0_Control_Room.py`.
3. Inserisci le eventuali credenziali opzionali (Gemini, OpenAI) nella sezione *App Settings -> Secrets*.
4. Clicca su **Deploy**.

---

## 📂 Struttura del Repository

```text
argus-risk-analytics/
├── .github/                     # Workflows di CI/CD e Release automatizzata
│   └── workflows/
│       ├── ci.yml
│       ├── deploy-pages.yml
│       └── release.yml
├── api/                         # Headless FastAPI Microservice (REST OpenAPI & WebSocket Gateway)
│   ├── __init__.py
│   └── main.py                  # API Hub v9.19.0: 40+ Endpoint Istituzionali (SIMM, XVA, FRTB, Heston, Solvency II)
├── components/                  # Modali Istituzionali @st.dialog, Command Palette (Ctrl+K) & Splash Screen
│   ├── __init__.py
│   ├── action_drawers.py        # Institutional Drawers (Pre-Trade Blotter, TUIR Lot Inspector, Euler Risk)
│   ├── command_palette.py       # Bloomberg-Style Command Palette (Ctrl+K) & Switcher Multi-Modulo
│   └── splash.py                # Bootloader Splash Screen, Animated Vector Logo & Diagnostics
├── config/                      # Configurazione e mapping ISIN-Ticker
│   └── config.json
├── core/                        # Engine quantitativo, calcoli di rischio e moduli istituzionali
│   ├── adapters/                # Adapter per broker esterni (DeGiro, Directa, Fineco, IBKR, ecc.)
│   │   ├── __init__.py
│   │   ├── broker_hub.py        # Hub centralizzato di rilevamento ed esecuzione adapter
│   │   ├── degiro.py            # Adapter DeGiro CSV (formato standard e avanzato con commissioni)
│   │   ├── directa.py           # Adapter Directa SIM CSV
│   │   ├── etoro.py             # Adapter eToro Account Statement XLSX/CSV
│   │   ├── fineco.py            # Adapter Fineco Bank estratto conto titoli e liquidità
│   │   ├── ibkr.py              # Adapter Interactive Brokers (IBKR) Activity Statement CSV/XML
│   │   ├── isin_resolver.py     # Risoluzione deterministica ISIN <-> Ticker via cache e lookup online
│   │   ├── revolut.py           # Adapter Revolut Trading CSV
│   │   ├── scalable.py          # Adapter Scalable Capital Baader Bank PDF/CSV
│   │   └── traderepublic.py     # Adapter Trade Republic PDF/CSV
│   ├── i18n/                    # Framework Internazionalizzazione, L10n & Multi-Currency FX Engine
│   │   ├── __init__.py
│   │   ├── formatters.py        # Regional Number/Date Formatters, Wall Street Accounting & Currencies
│   │   ├── fx_engine.py         # ECB Official Historical Rates, Triangular Arbitrage & FX Risk Decomposition
│   │   ├── translator.py        # O(1) Key-Path Translation Engine con Interpolazione & Fallback
│   │   └── locales/             # Dizionari Linguistici Strutturati
│   │       ├── en.json          # Dizionario istituzionale lingua inglese
│   │       └── it.json          # Dizionario istituzionale lingua italiana
│   ├── wealth/                  # Wealth Management & Personal Finance Subsystem (27 Moduli)
│   │   ├── __init__.py
│   │   ├── asset_protection_engine.py # Asset Protection, Trust, Fondo Patrimoniale, Polizze & Holding (S.s.)
│   │   ├── glidepath_engine.py  # Goal-Based Dynamic Glide Path 3D & Life Events Probabilistic Engine
│   │   ├── human_capital_engine.py # Human Capital Actuarial Valuation, Quasi-Asset & TBS-VaR
│   │   ├── neural_advisor_engine.py # Neural Wealth Advisor & Conversational Action Memo Engine
│   │   ├── personal_balance_sheet.py # Personal Balance Sheet & Net Worth Reconciliation
│   │   ├── private_markets_engine.py # Private Equity, Venture Capital, J-Curve & Illiquid Valuation
│   │   ├── succession_optimizer.py # Generational Transfer Optimizer, Patto di Famiglia & Nuda Proprietà
│   │   ├── tax_aware_location.py # Tax-Aware Asset Location & Frictional Optimization (TUIR Art. 44 vs 67)
│   │   ├── tbs_monte_carlo.py   # Lifetime Total Balance Sheet Monte Carlo Engine (5000 Paths)
│   │   ├── total_wealth_reverse_stress.py # Reverse Stress Testing sul Patrimonio Netto Consolidato (Solvency II)
│   │   ├── unified_stress_bridge.py # Cross-Asset Macro Factor Stress Bridge Engine
│   │   ├── universal_bank_parser.py # Universal Bank Ingestion Hub & Multi-Broker Layout Sniffer
│   │   ├── wealth_db.py         # SQLite / MySQL Star Schema & Snapshot Storicizzati Wealth
│   │   ├── wealth_engine.py     # Net Worth Engine, FIRE SWR, Mutui alla Francese & Dynamic Glide Path
│   │   ├── wealth_exporter.py   # Master Excel Dossier & Multi-Tab Exporter (.xlsx)
│   │   ├── wealth_importer.py   # Ingestion Pipeline & Transaction Deduplication SHA-256
│   │   ├── wealth_modals.py     # Modali Informativi ed Educativi Istituzionali Wealth (@st.dialog)
│   │   ├── wealth_models.py     # Schemi, Enums e Dataclass tipizzate di bilancio personale
│   │   ├── wealth_olap.py       # Motore OLAP Vettorizzato DuckDB In-Memory & Aggregazioni Temporali
│   │   ├── wealth_reporting_hub.py # Centralized Wealth Reporting & Factsheet Hub
│   │   ├── wealth_snapshot.py   # Gestione snapshot patrimoniali temporali e riconciliazione Net Worth
│   │   ├── wealth_stress_engine.py # Unified Macro Stress Engine & French Mortgage Variable Rate Model
│   │   ├── wealth_sync.py       # Sincronizzazione Google Sheets & Config_FixedExpenses
│   │   ├── wealth_temporal_engine.py # Time-Series Wealth Analytics & Historic Reconciliation
│   │   ├── wealth_validator.py  # Validazione template e formati bancari italiani
│   │   └── wealth_watchdog.py   # Smart Financial Watchdog & Proactive Anomaly Alert Engine
│   ├── __init__.py                   # Package init e versione dell'ecosistema (v9.19.0)
│   ├── advanced_quant.py             # Tail Copulas, Kelly Criterion & Equal Risk Contribution (ERC)
│   ├── advisor.py                    # ARGUS Quant Advisor & Health Score Engine
│   ├── ai_analyst.py                 # AI & LLM Narrative Intelligence (Gemini/OpenAI & NLG Offline)
│   ├── alm_ldi_engine.py             # ALM, Redington Immunization, LDI Receiver Swap & Cash-Flow Matching LP
│   ├── archetype_manager.py          # Gestione profili patrimoniali istituzionali e archetipi didattici
│   ├── attribution.py                # Brinson-Fachler, Carino Multi-Period & Karnosky-Singer FX
│   ├── autonomous_rebalancer.py      # Autonomous Rebalancer con WACP/PMC reale & Recupero Minusvalenze
│   ├── backup_engine.py              # Zero-Downtime Hot Backup, WAL Checkpoint, PRAGMA Audit & Rollback
│   ├── barra_risk_model.py           # MSCI Barra GEM3/USE4 Structural Multi-Factor Risk Decomposition
│   ├── basel_liquidity_engine.py     # Basilea III LCR, NSFR & Dynamic Cash Flow Stress Ladder (BCBS 238)
│   ├── bitemporal_engine.py          # Motore di persistenza bitemporale (Valid Time vs Transaction Time) & Audit Hash SHA-256
│   ├── black_litterman_engine.py     # Bayesian Black-Litterman Portfolio Optimization & Idzorek Confidence
│   ├── bquant_engine.py              # ARGUS BQuant In-App Python Sandbox & DuckDB In-Memory SQL
│   ├── cache_shield.py               # Multi-Tier LRU & SQLite Rate-Limit Shield (yfinance)
│   ├── ccar_stress_engine.py         # Supervisory Fed CCAR / EBA 9-Quarter Capital Stress & CET1 Trajectory
│   ├── cds_tranche_engine.py         # ISDA Single-Name CDS Bootstrapping & Tranche Sintetiche iTraxx/CDX
│   ├── chart_framework.py            # ARGUS Institutional Plotly Design System & High-Performance Chart Framework
│   ├── climate_stress_engine.py      # NGFS Phase IV Climate Transition & Physical Risk Stress Engine
│   ├── closed_trades.py              # Graveyard, FIFO Closed Trades Journal & Tax Step-Up Analytics
│   ├── commodity_engine.py           # Gibson-Schwartz 2-Factor Commodity Futures, Convenience Yield & Kirk Spread
│   ├── compliance_gate.py            # MiFID II RTS 28 & SEC 15c3-5 Pre-Trade Risk & Compliance Gateway
│   ├── confirm_dialogs.py            # Modali interattivi di conferma operazioni critiche e transazioni (@st.dialog)
│   ├── corporate_actions.py          # Corporate Actions, Stock Splits & Stock Dividends Engine
│   ├── credit_portfolio_engine.py    # CreditMetrics S&P 8-State Migration & Vasicek Multi-Obligor IRB
│   ├── cross_border_tax_engine.py    # Fisco cross-border, convenzioni contro le doppie imposizioni & W-8BEN
│   ├── crypto_provider.py            # Aggregatore multi-provider crypto (Binance, Kraken, CoinGecko)
│   ├── crypto_tax_engine.py          # Fisco Cripto-Attività, Quadri RT/RW/IVAFE & Zainetto Cripto
│   ├── data_quality_gate.py          # Pydantic v2 Ingestion Gate, Semantic Sanity & SHA-256 Deduplication
│   ├── database_migration_manager.py # DBRE Migration Engine, Dual Versioning, Shadow Backup & Drift Inspector
│   ├── db_exporter.py                # Layer di storicizzazione snapshot su DB (MySQL & SQLite)
│   ├── dcc_garch_engine.py           # Engle Dynamic Conditional Correlation (DCC-GARCH) & Asymmetric GJR
│   ├── diagnostics.py                # System Diagnostics, Storage Cockpit & Lead SRE Observability
│   ├── dividend_engine.py            # Cash Flow Forecast & Dividend Calendar
│   ├── duckdb_engine.py              # Motore Analitico In-Process DuckDB (OLAP) & Parquet Storage
│   ├── esg_engine.py                 # ESG Scoring, Carbon Intensity Scope 1-3 & SFDR Art. 8/9 Classification
│   ├── excel_connector.py            # Bloomberg Formula Generator, VBA Macro, Office Scripts & XLSX Exporter
│   ├── excel_generator.py            # Modello tattico Excel What-If
│   ├── execution_algo.py             # Algoritmi di esecuzione TWAP, VWAP, POV & Square-Root Market Impact
│   ├── execution_algo_engine.py      # Motore di simulazione avanzata esecuzione algoritmica & Almgren-Chriss
│   ├── executive_board_pack_engine.py # 1-Click CRO Executive Board-Pack & Actionable Playbook Synthesizer
│   ├── exporter.py                   # Esportatore CSV denormalizzati
│   ├── factor_library.py             # Kenneth French Factor Library (5-Factor, MOM & Q1-Q5 Backtest)
│   ├── fetcher.py                    # Download dati storici yfinance & conversione valute
│   ├── financial_analysis.py         # Altman Z-Score, DuPont, Piotroski, WACC, DCF Monte Carlo
│   ├── fix_engine.py                 # Protocollo di negoziazione istituzionale FIX 4.4 (Execution & Routing Mock)
│   ├── fixed_income.py               # Fixed Income YTM, Duration, Convexity, DV01, Z-Spread, CDS, Nelson-Siegel KRD
│   ├── forensic_accounting.py        # Beneish M-Score (1999) & Sloan Accrual Ratio (1996)
│   ├── frtb_engine.py                # FRTB Basilea IV Standardized Approach (SBM, DRC & RRAO - BCBS 365)
│   ├── fx_overlay_engine.py          # Dynamic FX Hedging Overlay, Carry Trade & Forward FX Pricing
│   ├── garch_engine.py               # Volatilità condizionale GARCH(1,1), architettura di stima ML & forecasting
│   ├── hedging.py                    # Copertura Beta-Neutral & Tail Risk Protection
│   ├── heston_fft_engine.py          # Heston Stochastic Volatility FFT Option Pricing & Surface Calibration
│   ├── hmm_regime_engine.py          # Hidden Markov Model (HMM) Adaptive Regime Switching & Viterbi Decoding
│   ├── hrp_optimizer.py              # Hierarchical Risk Parity (HRP - Marcos López de Prado)
│   ├── html_exporter.py              # Exporter Report Standalone HTML
│   ├── hull_white_engine.py          # Hull-White 1-Factor Short Rate & Bermudan Swaption Tree Pricing
│   ├── ingestion_utils.py            # Universal Bank Ingestion, Sniffer & Encoding Detection
│   ├── isda_simm_engine.py           # ISDA SIMM v2.6 Initial Margin & BCBS-IOSCO UMR €50M Rule Checker
│   ├── loading_states.py             # UI Lifecycle, Skeleton Loaders, Atomicity & Loading Transitions
│   ├── macro_provider.py             # Connettore dati macroeconomici FRED, BCE & Term Structure
│   ├── macro_stress_engine.py        # Stress testing macroeconomico congiunto (tassi, spread, inflazione, PIL)
│   ├── macro_war_room.py             # Interactive Macro War Room, Geopolitical Stress & Correlation Breakdown
│   ├── market_making_vpin_engine.py  # Avellaneda-Stoikov Market-Making & Hawkes VPIN Toxicity Engine
│   ├── michaud_resampling.py         # Michaud Resampled Efficient Frontier (1998) & Monte Carlo Bootstrap
│   ├── metadata_resolver.py          # Risoluzione metadati e anagrafiche asset
│   ├── mip_rebalancer.py             # Mixed-Integer Programming (MIP/MILP) Cardinality & Lot-Sizing Rebalancer
│   ├── models.py                     # Schema ORM SQLAlchemy (MySQL & SQLite)
│   ├── modular_factsheet_builder.py  # Institutional Factsheet Generator & Section Compositor
│   ├── morning_meeting_engine.py     # Morning Meeting Audio Briefing & Executive Daily Note Engine
│   ├── msci_barra_risk_engine.py     # MSCI Barra Structural Factor Risk & Euler Decomposition (GEM3)
│   ├── multi_portfolio.py            # Total Wealth Multi-Account Registry, Scorecard & Consolidator
│   ├── multicurve_engine.py          # Post-LIBOR Multi-Curve OIS Discounting (€STR/SOFR) & Dual Bootstrapping
│   ├── onboarding_guard.py           # Onboarding Wizard & Guardrail per primo avvio piattaforma
│   ├── optimal_liquidation_engine.py # Optimal Liquidation con Square-Root Impact, POV VWAP & Almgren-Chriss
│   ├── options_hedging.py            # Black-Scholes 1973, 5 Greci, Delta-Hedging & Covered Call
│   ├── options_workbench.py          # Workbench opzioni interattivo, pay-off diagram & strategie complesse
│   ├── pdf_generator.py              # Exporter Factsheet PDF (ReportLab) con Numbered Canvas
│   ├── prescriptive_rebalancer.py    # Prescriptive Conic Rebalancer & FIX 4.4 Protocol Blotter
│   ├── priips_kid_generator.py       # PRIIPs KID Regulatory Engine (SRI 1-7, 4 Scenari di Performance, SFDR)
│   ├── private_debt_engine.py        # Private Debt, Mezzanine Financing, Cash Flow Waterfall & Covenants
│   ├── quarterly_report_generator.py # Generatore di report trimestrali istituzionali white-label
│   ├── rebalancer.py                 # Smart Rebalancer & Generatore Ordini
│   ├── regime_allocation.py          # Asset allocation tattica condizionata al regime di mercato
│   ├── regime_switching.py           # Market Regime Switching (3-State Markov Model)
│   ├── regulatory_reporting_engine.py # Motore unificato per reporting regolamentare (PRIIPs, SFDR, MiFID II)
│   ├── reinforcement_learning.py     # Deep Q-Learning & Actor-Critic Portfolio Rebalancing Agent
│   ├── report_exporter.py            # Manager Centralizzato Esportazione Report
│   ├── reporting_design_system.py    # Obsidian Sovereign Design System & Numbered Canvas
│   ├── resilient_market_engine.py    # Enterprise SRE Circuit Breaker, Jittered Retry & Multi-Provider Engine
│   ├── risk_engine.py                # Motore FIFO, VaR/CVaR Euler, L-VaR Bangia, Almgren-Chriss, Kupiec
│   ├── risk_limits.py                # Early Warning System & Controlli di Rischio UCITS/MiFID
│   ├── rough_vol_svi_engine.py       # Rough Volatility (rBergomi H~0.10) & Gatheral SVI Arbitrage-Free Surface
│   ├── sabr_local_vol_engine.py      # Hagan SABR (2002) & Dupire Local Volatility Surface Calibration
│   ├── schemas.py                    # Data Contracts & Validazione Pydantic v2
│   ├── screener_engine.py            # EQS Formula Engine, Screener Multi-Fattoriale & Pre-Trade Simulator
│   ├── sec_rag_engine.py             # Local RAG & Vector Store Semantico sui Bilanci SEC (10-K/10-Q)
│   ├── security_engine.py            # CWE-1236 Anti-Formula Injection, PII Masking & ArgusDataVault AES
│   ├── session_manager.py            # ArgusSessionManager: Type-Safe Session State Governance & Fallback
│   ├── sidebar.py                    # Navigation Rail v9.19.0, Command Palette (Ctrl+K) & Spotlight Search
│   ├── smart_order_router.py         # MiFID II RTS 28 Smart Order Router & Execution Venues Slicing
│   ├── solvency2_engine.py           # Solvency II Standard Formula SCR & Market Risk Correlation Aggregation
│   ├── stochastic_kernel.py          # Simulatore stocastico Monte Carlo vettorizzato (Browniano, Jump, CIR)
│   ├── streaming_engine.py           # Real-Time Ring Buffer, VWAP, Order Flow Imbalance & Level-2 Book
│   ├── structured_products_engine.py # Derivati esotici, Phoenix Autocallable Worst-Of & Reverse Convertible
│   ├── tax_aware_rebalancer.py       # Ribilanciamento tax-aware con compensazione plusvalenze e minusvalenze pregresse
│   ├── tax_engine.py                 # Ottimizzazione Fiscale TUIR Art. 67 & Tax-Loss Harvesting Wizard
│   ├── technical_analysis.py         # Motore Analisi Tecnica, Volume Profile & Confluenza
│   ├── temporal_engine.py            # Motore di Analisi Temporale, Rolling Risk & Performance Matrix
│   ├── terminal_engine.py            # Live Terminal Desk, Pre-Trade Risk Checks, OMS Blotter & PnL Attribution
│   ├── trade_staging_blotter.py      # Blotter per staging ordini pre-trade con validazione limiti
│   ├── ui_export_utils.py            # Universal Export Toolbar isolata con @st.fragment per tabelle e report
│   ├── ui_lifecycle.py               # Gestione ciclo di vita UI, caching transitorio e teardown sicuro
│   ├── ui_utils.py                   # Helper Grafici Plotly, Modali Informativi Istituzionali & Vector SVG Icons
│   ├── unified_demo_seeder.py        # Seeder universale dataset demo & scenari di prova realistici
│   ├── universal_ledger.py           # Universal One-Ledger Core, Star Schema & Vectorized PyArrow/DuckDB
│   ├── ux_institutional_hub.py       # Institutional Terminal UX/UI Hub, Bloomberg Command Bar & Top Bar
│   ├── ux_quant_canvas.py            # Visual Quant Canvas 3D & 2D Interactive Figures Engine
│   ├── validator.py                  # Pipeline di Bonifica & Normalizzazione Dati
│   ├── voice_advisor_engine.py       # Executive Voice Briefing & Script a 2 Voci (CIO & CRO)
│   ├── volatility_surface.py         # Superficie di Volatilità Implicita 3D, Skew & Smile Calibration
│   ├── walk_forward_engine.py        # Walk-Forward Rolling Out-of-Sample Optimizer con attrito reale
│   ├── workspace_context.py          # Typed Multi-Session Context & Domain Flush Manager
│   ├── workspace_engine.py           # ARGUS Launchpad, 5 Ruoli Istituzionali & Layout Persistence
│   ├── workspace_manager.py          # State Manager, Routing Dinamico & URL State Sync
│   ├── xva_engine.py                 # Bilateral XVA (CVA, DVA, FVA, MVA, KVA) & CSA Netting Exposure Simulation
│   ├── yield_curve.py                # Curva Tassi Privi di Rischio Live Dinamica Multi-Valuta & Nelson-Siegel
├── data/                        # Dataset di input & database SQLite fallback
│   ├── archetypes/              # Profili didattici patrimoniali (Giovane Accumulatore, Famiglia, HNWI)
│   ├── multi_portfolios/        # Repository JSON profili multi-portafoglio registrati
│   ├── Transactions.csv         # Dataset storico reale DeGiro WealthApp (400+ operazioni verificate)
│   ├── portfolio_transactions_realistic.csv # Dataset realistico multi-asset multi-valuta (EUR, USD, GBP, CHF)
│   ├── argus_local.db           # Database SQLite locale Data Warehouse e snapshot storici
│   ├── argus_wealth.db          # Database SQLite locale Wealth Management Ecosystem
│   ├── argus_workspaces.db      # Database SQLite per persistenza profili Launchpad & workspaces
│   ├── bitemporal_ledger.duckdb # Database analitico colonnare DuckDB per One-Ledger bitemporale
│   ├── yfinance_cache.db        # Database SQLite Cache Shield per rate-limiting e caching 24h
│   └── .gitkeep
├── docker/                      # File di containerizzazione Docker
│   └── Dockerfile               # Multi-stage build hardening (non-root unprivileged user argus:argus)
├── docs/                        # Documentazione Tecnica & Specifica Architetturale
│   ├── api/
│   │   └── index.md             # Specifica Tecnica & Catalogo Endpoint Headless REST API (FastAPI)
│   ├── compliance/
│   │   └── whitepaper.md        # Whitepaper di conformità normativa (Basilea IV, MiFID II, TUIR, Solvency II)
│   ├── getting-started/
│   │   ├── installation.md      # Guida all'installazione locale, virtual environment e dipendenze
│   │   └── quickstart.md        # Guida rapida di primo avvio e importazione del primo portafoglio
│   ├── methodology/
│   │   ├── bitemporal.md        # Fondamenti teorici del ledger bitemporale e tracciabilità rettifiche
│   │   ├── execution.md         # Modelli di esecuzione ottima, Almgren-Chriss e market impact radice quadrata
│   │   ├── hrp.md               # Metodologia Hierarchical Risk Parity (HRP) e clustering gerarchico dei pesi
│   │   └── risk_engine.md       # Manuale metodologico del Quantitative Risk Engine e quadratura di Eulero
│   ├── CSV_Format_Specification.md # Specifica tecnica formato CSV & DeGiro
│   ├── DESIGN.md                # Design System Sovereign Obsidian & Specifiche UI/UX
│   ├── EXECUTIVE_REPORT_OUTLINE.md # Struttura standard del dossier esecutivo trimestrale
│   ├── FLOWCHART.md             # Diagramma di Flusso ETL a 5 Livelli
│   ├── POWER_BI_GUIDE.md        # Guida all'integrazione del Data Warehouse Star Schema in Microsoft Power BI
│   ├── PRESENTATION_SLIDES.md   # Presentazione esecutiva e slide deck del progetto
│   ├── PROJECT_HANDOFF.md       # Documento di Consegna & Handoff Tecnico (v9.19.0)
│   ├── architecture-map.html    # Mappa architetturale interattiva a nodi
│   ├── argus-architecture.html  # Diagramma Architetturale HTML Standalone v9.19.0
│   ├── argus-architecture.json  # Specifica Architetturale JSON IR v9.19.0
│   ├── argus_banner.jpg         # Banner grafico istituzionale ARGUS
│   ├── argus_icon.ico           # Asset icona Occhio di Argus
│   ├── index.md                 # Home page documentazione MkDocs
│   └── metriche_rischio.md      # Manuale Matematico ed Econometrico completo (101 Sezioni Istituzionali)
├── exports/                     # Cartella di destinazione report esportati (.xlsx, .pdf, .zip)
│   └── .gitkeep
├── gsheets_sync_subproject/     # Sub-servizio Sincronizzazione ETL Google Sheets
│   ├── run_daily_scheduler.py   # Schedulatore cron giornaliero
│   └── sync_google_sheets.py    # Pipeline ETL Google Sheets con iniezione dati
├── notebooks/                   # Jupyter Notebooks di prototyping quantitativo
│   └── test_pipeline.ipynb
├── scripts/                     # Script di Build, Schema SQL, Reporting e Packaging
│   ├── DB.sql                   # Schema DDL Data Warehouse MySQL 8.0 (Risk & Assets)
│   ├── DB_wealth.sql            # Schema DDL Wealth Management MySQL 8.0
│   ├── build_desktop_app.py     # Automazione compilazione PyInstaller (.exe standalone)
│   ├── create_desktop_shortcut.py # Generatore collegamento Desktop con icona (.lnk)
│   ├── export_star_schema.py    # Generatore pacchetto ZIP Star Schema per Power BI & Looker Studio
│   ├── freeze_historical_snapshots.py # Script per congelamento deterministico snapshot patrimoniali
│   ├── generate_excel_model.py  # Generatore standalone modello Excel dinamico con formule RTD
│   ├── generate_icon.py         # Generatore icona ICO multi-risoluzione
│   ├── generate_realistic_portfolio.py # Quantitative Simulation Engine (3 Archetipi, PAC, Mutui, Solvibilità)
│   └── package_release.py       # Pacchettizzatore Release ZIP con hash crittografici
├── src/                         # Codice sorgente dell'applicazione Streamlit (22 Moduli Operativi)
│   ├── 0_Control_Room.py        # Entry point principale, Total Wealth Hub & Control Room
│   └── pages/                   # Moduli e viste della dashboard (1..21)
│       ├── 1_📈_Dashboard_Generale.py # Executive Cockpit, Asset Allocation & Performance Summary
│       ├── 2_🖥️_Live_Terminal.py     # Institutional Terminal Desk, Pre-Trade Risk Checks & OMS Blotter
│       ├── 3_🔴_Analisi_Rischio.py   # Cornish-Fisher CVaR, Euler VaR, GARCH(1,1), L-VaR & Basilea IV
│       ├── 4_🔬_Modelli_Quantitativi.py # Markowitz, HRP, Copula, Heston FFT, SABR 3D, Hull-White & CDS
│       ├── 5_📋_Posizioni_e_Dettagli.py # Analisi Granulare Posizioni, PnL Storico & Movimenti
│       ├── 6_🏛️_Valutazione_Aziendale.py # Altman Z-Score, Beneish M-Score, DCF & DuPont Analysis
│       ├── 7_🌪️_Stress_Testing.py    # Macro Stress, EBA 2026, CCAR, FRTB SBM, NGFS Climate, ISDA SIMM & XVA
│       ├── 8_📊_Analisi_Temporale.py  # Rolling Risk Metrics, Drawdown Matrix & Regime Switching
│       ├── 9_📈_Analisi_Tecnica.py    # Volume Profile (POC/VAH/VAL), ATR Chandelier & Oscillatori
│       ├── 10_🔍_Screener_Opportunita.py # Multi-Factor Screener, EQS Engine & Fundamental Filters
│       ├── 11_💻_BQuant_e_Launchpad.py # In-App Python Sandbox, DuckDB SQL & Launchpad Workspace
│       ├── 12_🎛️_Wealth_Control_Room.py # Wealth Management Cockpit & Data Quality Overview
│       ├── 13_🏛️_Patrimonio_e_NetWorth.py # Net Worth Consolidato, ALM/LDI Cash-Flow Matching & Reverse Stress
│       ├── 14_💳_Cash_Flow_e_Spese.py # Cash Flow Analysis, Budgeting 50/30/20 & Emergency Runway
│       ├── 15_⌚_Asset_Illiquidi_e_Orologi.py # Passion Assets, Real Estate & Private Equity Valuation
│       ├── 16_🛡️_Previdenza_e_Pension_Planning.py # Human Capital Actuarial Valuation, TBS-VaR & Pension Gap
│       ├── 17_🔥_Indipendenza_Finanziaria_e_FIRE.py # FIRE Simulator, Guyton-Klinger Dynamic SWR & Monte Carlo
│       ├── 18_📑_Fiscalita_e_Quadro_RW.py # Ottimizzazione Fiscale TUIR, Quadro RW/RT/IVAFE & Tax-Loss Harvesting
│       ├── 19_🏡_Immobili_e_Mutui.py  # Mutui alla Francese, Sensibilità Tassi +200 bps & LTV Ratio
│       ├── 20_⚖️_Pianificazione_Successoria.py # Asse Ereditario, Riunione Fittizia ex art. 556 c.c., Trust & Donazioni
│       └── 21_🤖_AI_Copilot_e_Advisor.py # Conversational Wealth Copilot, Action Memo Istituzionale & Voice Briefing
├── tests/                       # Test suite automatizzata PyTest (856 Test su 133 File)
│   ├── test_advanced_institutional_suite.py
│   ├── test_advanced_quant.py
│   ├── test_ai_analyst.py
│   ├── test_ai_governance.py
│   ├── test_all_pages_smoke.py
│   ├── test_api_endpoints.py
│   ├── test_backtest.py
│   ├── test_backup_engine.py
│   ├── test_bitemporal_engine.py
│   ├── test_black_litterman_fama_french.py
│   ├── test_bloomberg_terminal_features.py
│   ├── test_broker_adapters.py
│   ├── test_cache_shield_and_diagnostics.py
│   ├── test_chart_framework.py
│   ├── test_closed_trades.py
│   ├── test_confirmation_dialogs.py
│   ├── test_corporate_actions.py
│   ├── test_crypto_provider.py
│   ├── test_crypto_tax.py
│   ├── test_custom_stress.py
│   ├── test_data_quality_gate.py
│   ├── test_database_profile_isolation.py
│   ├── test_diversification.py
│   ├── test_duckdb_engine.py
│   ├── test_empty_state_and_demo.py
│   ├── test_enhancements.py
│   ├── test_enterprise_masterplan_features.py
│   ├── test_estate_planning_optimizer.py
│   ├── test_excel.py
│   ├── test_execution_algo.py
│   ├── test_factor_library.py
│   ├── test_fase3_screener_almgren_factors.py
│   ├── test_fase4_bquant_launchpad_excel.py
│   ├── test_financial_analysis.py
│   ├── test_fixed_income_and_streaming.py
│   ├── test_forensic_accounting.py
│   ├── test_garch_fhs.py
│   ├── test_hedging_attribution_limits.py
│   ├── test_history_analytics.py
│   ├── test_hrp_optimizer.py
│   ├── test_html_exporter.py
│   ├── test_human_capital_and_tbs_var.py
│   ├── test_i18n_and_fx_engine.py
│   ├── test_institutional_enhancements.py
│   ├── test_institutional_enhancements_pack2.py
│   ├── test_institutional_expansion.py
│   ├── test_institutional_expansion_v63.py
│   ├── test_institutional_frontiers.py
│   ├── test_institutional_metric_modals.py
│   ├── test_institutional_v910.py
│   ├── test_kmeans_elbow.py
│   ├── test_loading_states.py
│   ├── test_macro_provider.py
│   ├── test_merton_and_isolation_forest.py
│   ├── test_metric_knowledge_modals.py
│   ├── test_michaud_and_api_expansion.py
│   ├── test_migration_manager.py
│   ├── test_ml_and_3d_features.py
│   ├── test_model_risk_audit.py
│   ├── test_monte_carlo_ui.py
│   ├── test_msci_barra_risk_engine.py
│   ├── test_multi_portfolio.py
│   ├── test_new_quant_features.py
│   ├── test_optimization.py
│   ├── test_personal_balance_sheet.py
│   ├── test_personal_balance_sheet_pdf.py
│   ├── test_phase1_hardening.py
│   ├── test_phase2_performance_engine.py
│   ├── test_phase3_services_and_api.py
│   ├── test_plotly_framework.py
│   ├── test_pretrade_compliance_and_scenarios.py
│   ├── test_prescriptive_rebalancer_and_agents.py
│   ├── test_property_euler_var.py
│   ├── test_property_fifo_accounting.py
│   ├── test_property_numerical_ratios.py
│   ├── test_quant_audit_gates.py
│   ├── test_quant_tax_graveyard_enhancements.py
│   ├── test_realistic_portfolio_generator.py
│   ├── test_rebalancer_and_advisor.py
│   ├── test_regime_and_options.py
│   ├── test_reinforcement_learning.py
│   ├── test_reporting_standardization.py
│   ├── test_resilient_market_engine.py
│   ├── test_risk_engine.py
│   ├── test_risk_engine_institutional.py
│   ├── test_risk_math_approx.py
│   ├── test_screener_engine.py
│   ├── test_sec_rag.py
│   ├── test_security_engine.py
│   ├── test_sidebar_profile_sync.py
│   ├── test_sidebar_subtab_sync.py
│   ├── test_splash_component.py
│   ├── test_sqlite_upsert_and_quality_gate.py
│   ├── test_structured_logging_and_support_bundle.py
│   ├── test_tax_engine.py
│   ├── test_tax_engine_deep_stress.py
│   ├── test_tax_engine_edge_cases.py
│   ├── test_tax_engine_normative_audit.py
│   ├── test_tbs_monte_carlo.py
│   ├── test_tca_and_optimal_execution.py
│   ├── test_technical_analysis.py
│   ├── test_temporal_engine.py
│   ├── test_terminal_engine.py
│   ├── test_terminal_ergonomics_sprint1_3.py
│   ├── test_ui_export_utils.py
│   ├── test_ui_lifecycle.py
│   ├── test_ui_modernization.py
│   ├── test_ui_ux_overhaul.py
│   ├── test_unified_archetype_sync.py
│   ├── test_universal_ingestion.py
│   ├── test_universal_ledger_engine.py
│   ├── test_v911_institutional_suite.py
│   ├── test_v912_institutional_suite.py
│   ├── test_v913_institutional_suite.py
│   ├── test_v914_institutional_suite.py
│   ├── test_v915_institutional_suite.py
│   ├── test_v916_ux_ui_overhaul.py
│   ├── test_v917_institutional_suite.py
│   ├── test_v918_ux_visual_canvas.py
│   ├── test_validator.py
│   ├── test_var_backtest.py
│   ├── test_var_cvar.py
│   ├── test_var_lookback.py
│   ├── test_volatility_surface.py
│   ├── test_wealth_engine.py
│   ├── test_wealth_enhancements.py
│   ├── test_wealth_olap.py
│   ├── test_wealth_reporting_hub.py
│   ├── test_wealth_sync.py
│   ├── test_wealth_temporal_engine.py
│   ├── test_wealth_validator.py
│   ├── test_workspace_context.py
│   ├── test_workspace_manager.py
│   └── test_yield_curve.py
├── .env.example                 # Esempio configurazione variabili d'ambiente
├── .pre-commit-config.yaml      # Pipeline hook pre-commit (Ruff lint/format, secret check)
├── CHANGELOG.md                 # Registro cronologico dettagliato delle versioni (v1.0.0 -> v9.19.0)
├── CODE_OF_CONDUCT.md           # Codice di Condotta per i contributori
├── CONTRIBUTING.md              # Guida ai contributi e workflow pull request
├── LICENSE.md                   # Licenza Open Source MIT
├── README.md                    # Documentazione Principale del Progetto
├── SECURITY.md                  # Politica di Sicurezza & Compliance
├── app.py                       # Launcher alias per l'applicazione Streamlit
├── argus_desktop.spec           # Spec PyInstaller per build standalone con isolamento percorsi
├── desktop_launcher.py          # Entry point nativo Desktop App (PyWebView + Backup pre-flight)
├── docker-compose.yml           # Configurazione Docker Compose (App + MySQL 8.0)
├── mkdocs.yml                   # Configurazione documentazione MkDocs Material con supporto KaTeX
├── pyproject.toml               # Configurazione tool di sviluppo, PyTest e linter Ruff
├── pytest.ini                   # Configurazione test runner PyTest e filtri warning
├── requirements.txt             # Dipendenze Python di produzione (pyarrow, pydantic v2, duckdb, ecc.)
├── requirements-dev.txt         # Dipendenze per sviluppo, linting e testing (pytest, ruff, mkdocs)
├── setup_desktop.bat            # Script di setup 1-Click per ambiente Desktop Windows
├── start_dashboard.bat          # Script d'avvio rapido per Windows
└── start_dashboard.sh           # Script d'avvio per Linux/macOS
```

---

## 🧪 Esecuzione della Test Suite Automatizzata

Il progetto include **864 test automatizzati PyTest** distribuiti su 134 file di test (inclusi l'ottimizzatore Michaud Resampled Efficient Frontier e API expansion `test_michaud_and_api_expansion.py`, i controlli pre-trade MiFID II RTS 28 `test_pretrade_compliance_and_scenarios.py`, i test istituzionali di validazione Basilea IV, EVT POT-GPD e ottimizzatori MDP/Min-CVaR `test_risk_engine_institutional.py`, la generazione del Dossier PDF a 4 pagine `test_personal_balance_sheet_pdf.py`, test property-based con **Hypothesis**, audit normativo fiscale TUIR/L. 197/2022, test di resilienza SRE Circuit Breaker/Jitter, simulazioni successorie del Codice Civile / TUS, test DBRE di migrazione/rollback, la suite di logging strutturato con mascheramento PII/finanziario e Support Bundle, il generatore di portafogli realistici ed archetipi didattici, la suite di internazionalizzazione e cambi `test_i18n_and_fx_engine.py`, il framework di esecuzione algoritmica e Pre/Post-Trade TCA `test_tca_and_optimal_execution.py`, e il motore di persistenza bitemporale e audit crittografico `test_bitemporal_engine.py`) con copertura end-to-end del 100%:

```bash
py -m pytest
```

Output atteso:
```text
======================= 864 passed in ~45.00s (100%) =======================
```

---

## 📄 Licenza

Questo progetto è distribuito sotto licenza open-source **MIT License**. Consulta il file [LICENSE.md](LICENSE.md) per i dettagli.

---

*ARGUS — Institutional Risk & Wealth Intelligence Ecosystem v9.19.0 Institutional Enterprise Release.*
