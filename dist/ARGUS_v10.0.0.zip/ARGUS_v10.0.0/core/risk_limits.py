"""
ARGUS — Risk Analytics Platform
Core Module: Risk Limits & Early Warning Engine
"""

from typing import Any, Dict, List, Optional, Tuple, Union

import pandas as pd

DEFAULT_RISK_LIMITS = {
    "max_single_asset_pct": {"label": "Peso Max Singola Posizione", "limit": 20.0, "unit": "%", "comparator": "le"},
    "max_sector_pct": {"label": "Concentrazione Max Settoriale", "limit": 35.0, "unit": "%", "comparator": "le"},
    "max_var_95_pct": {"label": "Value at Risk Max (VaR 95%)", "limit": 3.00, "unit": "%", "comparator": "le"},
    "max_beta": {"label": "Beta Sistemico Massimo", "limit": 1.25, "unit": "x", "comparator": "le"},
    "min_diversification_ratio": {
        "label": "Diversification Ratio Minimo",
        "limit": 1.20,
        "unit": "x",
        "comparator": "ge",
    },
    "max_hhi": {"label": "Indice Concentrazione HHI Max", "limit": 0.2500, "unit": "", "comparator": "le"},
}


def check_risk_limits(results: Dict[str, Any], custom_limits: Dict[str, float] = None) -> Dict[str, Any]:
    """
    Evaluates institutional risk limits against active portfolio metrics.
    Returns status per rule (PASS, WARNING, BREACH) and total compliance ratio.
    """
    limits_config = DEFAULT_RISK_LIMITS.copy()
    if custom_limits:
        for k, v in custom_limits.items():
            if k in limits_config:
                limits_config[k]["limit"] = float(v)

    pos = results.get("positions", pd.DataFrame())
    active_pos = pos[pos["qty_net"] > 0] if "qty_net" in pos.columns else pos
    tot_val = active_pos["current_value"].sum() if "current_value" in active_pos.columns else 0.0

    # Metric extractions
    max_asset_w = (active_pos["current_value"].max() / tot_val * 100.0) if tot_val > 0 else 0.0

    if "sector" in active_pos.columns and tot_val > 0:
        max_sector_w = active_pos.groupby("sector")["current_value"].sum().max() / tot_val * 100.0
    else:
        max_sector_w = max_asset_w

    # Sub-dictionaries resolution
    m_dict = results.get("metrics") if isinstance(results.get("metrics"), dict) else {}
    mr_dict = m_dict.get("market_risk", {}) if isinstance(m_dict.get("market_risk"), dict) else {}
    mc_dict = m_dict.get("concentration", {}) if isinstance(m_dict.get("concentration"), dict) else {}
    if not mr_dict and isinstance(results.get("market_risk"), dict):
        mr_dict = results.get("market_risk")
    if not mc_dict and isinstance(results.get("concentration"), dict):
        mc_dict = results.get("concentration")

    # VaR 95%
    raw_var = (
        results.get("var_95_hist")
        or results.get("var_95")
        or m_dict.get("var_95_hist")
        or m_dict.get("var_95")
        or mr_dict.get("var_95_hist")
        or mr_dict.get("var_95")
        or 0.02
    )
    v_val = float(raw_var)
    var_95 = v_val * 100.0 if abs(v_val) < 0.20 else v_val

    # Beta
    raw_beta = (
        results.get("portfolio_beta")
        or results.get("beta")
        or m_dict.get("portfolio_beta")
        or m_dict.get("beta")
        or mr_dict.get("portfolio_beta")
        or mr_dict.get("beta")
        or 1.0
    )
    beta = float(raw_beta)

    # Diversification Ratio
    raw_dr = (
        results.get("diversification_ratio")
        or m_dict.get("diversification_ratio")
        or mc_dict.get("diversification_ratio")
        or mr_dict.get("diversification_ratio")
        or 1.30
    )
    dr = float(raw_dr)

    # HHI Index
    raw_hhi = (
        results.get("hhi")
        or m_dict.get("hhi")
        or mc_dict.get("hhi_index")
        or mc_dict.get("hhi")
        or 0.10
    )
    hhi = float(raw_hhi)

    metric_values = {
        "max_single_asset_pct": max_asset_w,
        "max_sector_pct": max_sector_w,
        "max_var_95_pct": var_95,
        "max_beta": beta,
        "min_diversification_ratio": dr,
        "max_hhi": hhi,
    }

    evaluations = []
    pass_count, warn_count, breach_count = 0, 0, 0

    for key, cfg in limits_config.items():
        curr_val = metric_values.get(key, 0.0)
        lim_val = cfg["limit"]
        comp = cfg["comparator"]

        if comp == "le":
            if curr_val <= lim_val:
                if curr_val >= lim_val * 0.85:
                    status = "WARNING"
                    status_icon = "🟡 WARNING"
                    warn_count += 1
                else:
                    status = "PASS"
                    status_icon = "🟢 PASS"
                    pass_count += 1
            else:
                status = "BREACH"
                status_icon = "🔴 BREACH"
                breach_count += 1
        else:  # "ge"
            if curr_val >= lim_val:
                if curr_val <= lim_val * 1.15:
                    status = "WARNING"
                    status_icon = "🟡 WARNING"
                    warn_count += 1
                else:
                    status = "PASS"
                    status_icon = "🟢 PASS"
                    pass_count += 1
            else:
                status = "BREACH"
                status_icon = "🔴 BREACH"
                breach_count += 1

        evaluations.append(
            {
                "key": key,
                "rule_name": cfg["label"],
                "status": status,
                "status_icon": status_icon,
                "current_value": round(curr_val, 2),
                "limit_threshold": round(lim_val, 2),
                "unit": cfg["unit"],
                "margin_delta": round(curr_val - lim_val, 2),
            }
        )

    total_rules = len(evaluations)
    compliance_pct = round((pass_count + warn_count * 0.5) / total_rules * 100.0, 1)

    return {
        "compliance_pct": compliance_pct,
        "pass_count": pass_count,
        "warning_count": warn_count,
        "breach_count": breach_count,
        "total_rules": total_rules,
        "evaluations": pd.DataFrame(evaluations),
    }
