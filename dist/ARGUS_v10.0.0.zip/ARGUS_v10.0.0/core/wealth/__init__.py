# ============================================================
# core/wealth/__init__.py
# ARGUS — Wealth Management & Personal Finance Package
# ============================================================

from core.wealth.asset_protection_engine import (
    AssetProtectionEngine,
    FamilyHeir,
    FamilyProfile,
    GenerationalTransferOptimizer,
    OptimizationComparisonResult,
    PlanningLevers,
    ProtectionVehicleAnalysis,
    StatutoryShareItem,
    SuccessionSharesResult,
)
from core.wealth.private_markets_engine import (
    DesmoothingResult,
    EconometricDesmoother,
    PacingYearRecord,
    PrivateEquityFundReport,
    TakahashiAlexanderPacingModel,
    compute_private_markets_analytics,
)
from core.wealth.succession_optimizer import (
    FamilyOfficeSuccessionOptimizer,
    compute_family_succession_optimization,
)
from core.wealth.tbs_monte_carlo import (
    TBSLifecycleConfig,
    TBSMonteCarloEngine,
    compute_stochastic_cash_flow_decumulation,
)
from core.wealth.total_wealth_reverse_stress import compute_total_wealth_reverse_stress
from core.wealth.wealth_db import (
    cleanup_empty_wealth_portfolios,
    clear_wealth_accounts,
    clear_wealth_cashflow,
    clear_wealth_fixed_expenses,
    clear_wealth_snapshots,
    create_wealth_portfolio,
    deduplicate_wealth_accounts,
    delete_wealth_account,
    delete_wealth_portfolio,
    delete_wealth_snapshot,
    get_available_risk_portfolios,
    get_cashflow_records,
    get_linked_risk_portfolios,
    get_linked_risk_portfolios_summary,
    get_pension_plans,
    get_physical_assets,
    get_wealth_accounts,
    get_wealth_categories,
    get_wealth_fixed_expenses,
    get_wealth_portfolios,
    get_wealth_snapshots_history,
    init_wealth_db,
    insert_cashflow_tx,
    load_wealth_snapshot_details,
    reset_all_wealth_database,
    reset_wealth_portfolio_data,
    save_pension_plan,
    save_physical_asset,
    save_wealth_account,
    save_wealth_category,
    save_wealth_fixed_expense,
    save_wealth_snapshot_to_db,
    set_linked_risk_portfolios,
)
from core.wealth.wealth_engine import (
    compute_ai_quarterly_wealth_review,
    compute_ai_wealth_diagnostics,
    compute_buy_vs_rent_comparison,
    compute_cashflow_analytics,
    compute_cashflow_forecast_and_anomalies,
    compute_consolidated_net_worth,
    compute_estate_planning_analytics,
    compute_family_governance_and_patti_di_famiglia,
    compute_family_office_multi_entity_consolidation,
    compute_fire_analytics,
    compute_fiscal_analytics,
    compute_mortgage_amortization,
    compute_multi_currency_fx_hedging_engine,
    compute_multi_year_balance_comparison,
    compute_personal_balance_sheet,
    compute_private_equity_deal_metrics,
    compute_real_estate_net_equity_and_ltv,
    compute_real_estate_roi,
    compute_recurring_subscriptions_analytics,
    compute_sequence_of_returns_risk_engine,
    compute_smart_cashflow_reconciliation,
    compute_tax_loss_harvesting_and_latent_taxes,
    compute_tax_smart_rebalancing_watchdog,
    compute_total_wealth_brinson_attribution,
    compute_wealth_health_score,
    compute_wealth_risk_integrated_analytics,
    compute_wealth_stress_test,
    generate_advisory_pitchbook_html,
    generate_executive_tear_sheet_html,
    generate_executive_tear_sheet_pdf,
    simulate_pension_projection,
)
from core.wealth.wealth_exporter import export_wealth_master_excel_workbook
from core.wealth.wealth_importer import auto_categorize_transactions, bulk_import_statement, parse_universal_statement
from core.wealth.wealth_models import (
    AccountType,
    BrinsonWealthBucketItem,
    BrinsonWealthResult,
    CategoryNature,
    FamilyGovernancePlan,
    FamilyOfficeEntityItem,
    FXExposureItem,
    FXHedgingResult,
    LegalEntityType,
    NetWorthSummary,
    PattoFamigliaResult,
    PECashflowItem,
    PEDealMetrics,
    PensionPlanItem,
    PhysicalAssetCategory,
    PhysicalAssetItem,
    PrivateEquityDealItem,
    QuarterlyReviewResult,
    ReconciliationMatchItem,
    ReconciliationResult,
    SRRScenarioResult,
    WealthAccount,
    WealthCashflowItem,
    WealthCategory,
    WealthConsolidatedSummary,
)
from core.wealth.wealth_olap import (
    compute_wealth_cashflow_olap_cube,
    compute_wealth_snapshot_trajectory_olap,
    is_wealth_olap_available,
)
from core.wealth.wealth_stress_engine import (
    PRESET_STRESS_SCENARIOS,
    UnifiedMacroStressEngine,
    calculate_liquidity_squeeze,
    calculate_stressed_mortgage_impact,
    create_liquidity_squeeze_timeline_chart,
    create_wealth_waterfall_chart,
    run_wealth_stress_test,
    simulate_wealth_recovery_trajectories,
)
from core.wealth.wealth_sync import (
    sync_all_historical_expenses_from_gsheets,
    sync_expenses_tracker_2026_from_gsheets,
    sync_wealth_from_payload,
)
from core.wealth.wealth_validator import (
    validate_accounts_df,
    validate_cashflow_df,
    validate_pension_df,
    validate_physical_assets_df,
)

