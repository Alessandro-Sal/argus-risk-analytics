# Slide di Presentazione per la Discussione del Capstone Project
**Titolo:** ARGUS — Business Intelligence, Financial Valuation & Quantitative Risk Management Platform  
**Autore:** Candidato Master in Data Analytics  

---

## Slide 1: Titolo della Presentazione
- **Titolo**: ARGUS — Risk Analytics & Financial BI Platform
- **Sottotitolo**: Framework Quantitativo per l'Analisi di Portafoglio, Valutazione Aziendale e Protezione dal Rischio
- **Candidato**: Master in Data Analytics (Finanza Quantitativa & Risk Management)
- **Visual**: Logo / Banner "L'Occhio di Argus" e Badge Version v5.2 Capstone Release.

---

## Slide 2: Il Problema & Gli Obiettivi di Progetto
- **La Sfida**: Gli investitori privati e i family office mancano di strumenti integrati ad alta precisione che combinino contabilità fiscale FIFO, stima rigorosa del rischio di coda (VaR/CVaR), bilanci di esercizio e reporting direzionale.
- **La Soluzione (ARGUS)**:
  - Piattaforma end-to-end che converte CSV di negoziazione o export DeGiro in un framework quantitativo completo.
  - Nessun dato sintetico: validazione su **~400 operazioni REALI** (2021–2026).
  - Estetica ad alta densità informativa (Dark Terminal) fruibile sia Web sia Desktop Nativo Windows.

---

## Slide 3: Architettura del Sistema a 5 Livelli
- **Layer 1 (Ingestion)**: CSV Universale, DeGiro Adapter, yfinance API per prezzi e tassi FX.
- **Layer 2 (ETL & Validation)**: Pipeline a 11 passaggi (`validator.py`), contratti Pydantic (`schemas.py`), mapping ISIN-Ticker (`fetcher.py`).
- **Layer 3 (Data Warehouse)**: Storage relazionale SQLAlchemy ORM (MySQL 8.0 & SQLite fallback locale `argus_local.db`).
- **Layer 4 (Analytics Engine)**: FIFO Basis, VaR Cornish-Fisher, Markowitz SLSQP, Ledoit-Wolf, Fama-French, Altman Z-Score, DCF Monte Carlo, TUIR Art. 67.
- **Layer 5 (Presentation & Reporting)**: Streamlit (7 Pagine Live), Native Desktop App (PyWebView + Edge WebView2), Exporter PDF/Excel/HTML/Power BI Star Schema ZIP.

---

## Slide 4: Motore Quantitativo di Rischio & Tail Risk
- **Contabilità FIFO**: Prezzo medio ponderato di carico (WACP) e separazione PnL realizzato/non realizzato.
- **Value at Risk (VaR) & CVaR**: Stima a confidenza 95% e 99% con modello Cornish-Fisher (correzione per Skewness & Kurtosis).
- **Validazione Regolamentare VaR**: Backtest Kupiec POF su 252 giorni con classificazione a semaforo dell'Accordo di Basilea (*Verde/Giallo/Rosso*).
- **Style Analysis Fama-French**: Regressione a 3 fattori per determinare $\alpha_{FF}$, Beta di mercato, Size tilt (SMB) e Value tilt (HML).

---

## Slide 5: Simulazione Stocastica Monte Carlo & Stress Testing
- **Monte Carlo Fan / Ribbon Chart**: Proiezione a nastro su 10.000 cammini con Moto Browniano Geometrico, decomposizione di Cholesky e supporto per code grasse (Student-t $\nu=5$).
- **MSCI Barra Multi-Scenario Matrix**: Stima immediata dell'impatto finanziario nei 5 grandi crolli storici (*Dot-Com 2000*, *Lehman 2008*, *US Downgrade 2011*, *COVID-19*, *Rate Shock 2022*).
- **Custom Beta Shock Waterfall**: Simulazione di shock arbitrari sul benchmark ($\Delta R_b \in [-50, +30]$%).

---

## Slide 6: Analisi dei Bilanci & Solvibilità Aziendale (Pagina 5)
- **Altman Z-Score Model**: Previsione del rischio di insolvenza a 24 mesi con verdetto a semaforo (*Safe*, *Grey*, *Distress*).
- **Scomposizione DuPont (3 & 5 Fattori)**: Decomposizione del ROE nei driver di redditività, efficienza dell'attivo e leva finanziaria.
- **Piotroski F-Score (9 Punti Stanford)**: Diagnosi di salute contabile su Profittabilità, Liquidità ed Efficienza.
- **Valutazione Intrinseca DCF Monte Carlo**: 2-Stage Discounted Cash Flow a 1.000 iterazioni stocastiche con probabilità % di sottovalutazione.
- **Comparativa Multiaziendale**: Confronto affiancato di 2+ aziende con grafico Radar sovrapposto e bilanci 10-K.

---

## Slide 7: Ribilanciamento, Dividendi & Fiscalità TUIR Art. 67
- **Smart Rebalancer**: Generatore esatto di ordini di negoziazione ad azioni intere ($BUY/SELL$) per allocazioni target Markowitz/Equal Weight.
- **Calendario Dividendi**: Stima del Dividend Yield medio e calendario mensile per azienda pagatrice.
- **Normativa Fiscale Italiana**: Aliquote 12.5% Titoli di Stato vs 26.0% Azioni/ETF, regola non-compensabilità minusvalenze da plusvalenze ETF e Tax-Loss Harvesting Advisor.

---

## Slide 8: Centro Esportazione Report & Business Intelligence
- **Report PDF Factsheet (2 Pagine)**: Factsheet sintetico in-memory generato con ReportLab.
- **Workbook Excel Multi-Tab (.xlsx)**: File vettoriale con 4 schede tematiche.
- **Report Standalone HTML**: Esportazione di un file HTML interattivo standalone in dark mode.
- **Star Schema ZIP per Power BI**: Archivio `.zip` con `dim_assets.csv`, `fact_positions.csv` e `fact_portfolio_summary.csv` per Power BI e Looker Studio.

---

## Slide 9: Architettura Desktop Nativa Windows
- **Native Window Shell**: Finestra nativa basata su **PyWebView** (Edge WebView2) senza barre del browser.
- **Lifecycle Manager & Protection**: Polling attivo `wait_for_server` ed arresto automatico del sottoprocesso Streamlit alla chiusura della finestra.
- **Standalone Executable & Setup**: Pacchetto `.exe` compilato con PyInstaller e script di installazione 1-Click (`setup_desktop.bat`) con l'icona dell'**Occhio di Argus**.

---

## Slide 10: Risultati Sperimentali & Test Suite (54/54 PASSED)
- **Validazione su Dataset Reale**: Precisione centesimale su ~400 transazioni reali del dataset WealthApp.
- **Test Suite Automatizzata**: 54 test PyTest superati su engine quantitativo, ETL, modelli di bilancio, fiscalità ed esportazione report.
- **Performance**: Risposta dell'interfaccia sub-secondo per la maggior parte dei calcoli analitici.

---

## Slide 11: Conclusioni & Sviluppi Futuri
- **Risultati**: Realizzazione di una piattaforma completa, modulare, istituzionale ed esaustiva per il risk management ed il business intelligence.
- **Prossimi Passi**: Integrazione API Broker Live (Interactive Brokers API) e sync notturno con alert via webhook.
