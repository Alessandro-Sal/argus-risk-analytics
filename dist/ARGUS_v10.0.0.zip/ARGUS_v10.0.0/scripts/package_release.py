"""
Script di packaging per la creazione dell'archivio ZIP della release v10.0.0 di ARGUS.
Esegue un'ispezione preventiva di sicurezza per garantire che NESSUN file sensibile
(credenziali, chiavi, .env, secrets.toml, token, database locali, backup compressi, file temporanei o cache) venga incluso.
"""

import os
import re
import shutil
import sys
import zipfile


def create_secure_release_zip(version: str = ""):
    project_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    dist_dir = os.path.join(project_dir, "dist")
    os.makedirs(dist_dir, exist_ok=True)
    
    if not version:
        version = os.environ.get("ARGUS_VERSION", "")
    if not version and len(sys.argv) > 1:
        version = sys.argv[1]
    if not version:
        version = "v10.0.0"
    if not version.startswith("v"):
        version = f"v{version}"
    
    zip_filename = f"ARGUS_{version}.zip"
    zip_path = os.path.join(dist_dir, zip_filename)
    
    print("=" * 70)
    print(f" [ARGUS {version}] Generazione Archivio Release ZIP con Audit di Sicurezza")
    print("=" * 70)
    
    # Cartelle e file rigorosamente ESCLUSI
    EXCLUDED_DIRS = {
        ".git", ".github", ".agents", ".dsp", ".pytest_cache", ".ruff_cache",
        "__pycache__", "scratch", "_temp_scripts", "logs", "build", "dist",
        ".venv", "venv", "ENV", ".gemini", ".idea", ".vscode",
        "backups", "cache", "multi_portfolios", "tax_documents_vault",
        "vault_backups", "exports", ".ipynb_checkpoints", "site", "htmlcov",
        "credentials"
    }
    
    EXCLUDED_FILE_PATTERNS = [
        r"^\.env$",
        r"^\.env\..*$",
        r"^secrets\.toml$",
        r"^Transactions\.csv$",
        r"^\.coverage$",
        r"^coverage\.xml$",
        r"^uv\.lock$",
        r".*\.sqlite$",
        r".*\.sqlite3$",
        r".*\.db$",
        r".*\.db\.gz$",
        r".*\.gz$",
        r".*\.pkl$",
        r".*\.parquet$",
        r".*\.duckdb$",
        r".*\.enc$",
        r".*\.py[cod]$",
        r".*\.log$",
        r".*credentials.*\.json$",
        r".*service_account.*\.json$",
        r".*\.pem$",
        r".*\.key$",
        r"Thumbs\.db$",
        r"\.DS_Store$"
    ]
    
    # Eccezioni ammesse esplicitamente (non sensibili)
    ALLOWED_SPECIAL_FILES = {
        ".env.example",
        "config.json",
        "argus-architecture.json",
        ".dockerignore",
        ".nojekyll",
        ".gitkeep"
    }

    files_to_zip = []
    
    for root, dirs, files in os.walk(project_dir):
        # Filtra cartelle escluse inline
        dirs[:] = [d for d in dirs if d not in EXCLUDED_DIRS and not d.startswith(".agent") and not d.endswith(".egg-info")]
        
        rel_root = os.path.relpath(root, project_dir)
        if rel_root == ".":
            rel_root = ""
            
        for f in files:
            rel_file_path = os.path.normpath(os.path.join(rel_root, f)).replace("\\", "/")
            
            # Controllo blacklist pattern
            is_excluded = False
            if f not in ALLOWED_SPECIAL_FILES:
                for pattern in EXCLUDED_FILE_PATTERNS:
                    if re.match(pattern, f, re.IGNORECASE):
                        is_excluded = True
                        break
                        
            if is_excluded:
                print(f"  [ESCLUSO SICUREZZA] -> {rel_file_path}")
                continue
                
            full_path = os.path.join(root, f)
            files_to_zip.append((full_path, rel_file_path))
            
    print(f"\n[INFO] Totale file validati per l'inclusione: {len(files_to_zip)}")
    
    # Controllo di sicurezza aggiuntivo sul contenuto
    sensitive_keywords = [
        "sk" + "-proj-",
        "AI" + "zaSy",
        "BEGIN" + " PRIVATE KEY",
        "BEGIN" + " RSA PRIVATE KEY",
        "Modena" + "works"
    ]
    flagged_files = []
    SAFE_EXAMPLE_MOCK_FILES = {
        "scripts/package_release.py",
        "gsheets_sync_subproject/google_service_account.json.example",
        "gsheets_sync_subproject/tests/test_gsheets_sync.py",
    }
    for full_p, rel_p in files_to_zip:
        if rel_p in SAFE_EXAMPLE_MOCK_FILES:
            continue
        try:
            with open(full_p, "r", encoding="utf-8", errors="ignore") as file_handle:
                content = file_handle.read()
                for kw in sensitive_keywords:
                    if kw in content:
                        flagged_files.append((rel_p, kw))
        except Exception:
            pass
            
    if flagged_files:
        print("\n[ERRORE CRITICO SICUREZZA] Rilevate potenziali credenziali nei seguenti file:")
        for fp, kw in flagged_files:
            print(f"  [X] {fp} (Keyword: {kw})")
        sys.exit(1)
        
    print("[SICUREZZA CERTIFICATA] Nessuna chiave o credenziale sensibile rilevata nei file ammessi.")
    
    # Creazione del file ZIP
    if os.path.exists(zip_path):
        os.remove(zip_path)
        
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for full_p, rel_p in files_to_zip:
            archive_name = f"ARGUS_{version}/{rel_p}"
            zf.write(full_p, archive_name)
            
    zip_size_mb = os.path.getsize(zip_path) / (1024 * 1024)
    
    # Crea copia con naming alternativo per convenzione repo/standard open-source
    alt_zip_filename = f"argus-risk-analytics-{version}.zip"
    alt_zip_path = os.path.join(dist_dir, alt_zip_filename)
    shutil.copyfile(zip_path, alt_zip_path)

    print("\n" + "=" * 70)
    print(f" [OK] ARCHIVIO ZIP DELLA RELEASE {version} CREATO CON SUCCESSO!")
    print(f"      Percorso 1:   {zip_path}")
    print(f"      Percorso 2:   {alt_zip_path}")
    print(f"      Dimensione:   {zip_size_mb:.2f} MB")
    print(f"      File inclusi: {len(files_to_zip)}")
    print("=" * 70)

    # -------------------------------------------------------------
    # Compilazione Eseguibile Desktop Standalone (se richiesta con --build-exe)
    # -------------------------------------------------------------
    build_exe_requested = "--build-exe" in sys.argv or os.environ.get("ARGUS_BUILD_EXE", "").lower() in ("1", "true")
    if build_exe_requested:
        print("\n" + "=" * 70)
        print(" [DESKTOP BUILD] Avvio compilazione PyInstaller standalone (argus_desktop.spec)...")
        print("=" * 70)
        import subprocess
        spec_file = os.path.join(project_dir, "argus_desktop.spec")
        if os.path.exists(spec_file):
            cmd = [sys.executable, "-m", "PyInstaller", "--noconfirm", "--clean", spec_file]
            print(f"[CMD] {' '.join(cmd)}")
            res = subprocess.run(cmd, cwd=project_dir)
            if res.returncode == 0:
                desktop_dist_dir = os.path.join(dist_dir, "ARGUS_Desktop")
                if os.path.exists(desktop_dist_dir):
                    desktop_zip_filename = f"ARGUS_{version}_Windows_Desktop_Standalone.zip"
                    desktop_zip_path = os.path.join(dist_dir, desktop_zip_filename)
                    if os.path.exists(desktop_zip_path):
                        os.remove(desktop_zip_path)
                    print(f"[INFO] Creazione archivio standalone: {desktop_zip_filename}...")
                    shutil.make_archive(os.path.splitext(desktop_zip_path)[0], "zip", dist_dir, "ARGUS_Desktop")
                    desktop_size_mb = os.path.getsize(desktop_zip_path) / (1024 * 1024)
                    print(f" [OK] Pacchetto desktop standalone creato: {desktop_zip_path} ({desktop_size_mb:.2f} MB)")
            else:
                print(f"[WARN] Compilazione PyInstaller terminata con errore (codice {res.returncode}).")
        else:
            print(f"[WARN] File spec non trovato: {spec_file}")

if __name__ == "__main__":
    create_secure_release_zip()
