# ============================================================
# 0_Control_Room.py (Main Entry Point)
# ARGUS Risk Analytics & Wealth Ecosystem | Control Room v10.0.0
# ============================================================

import sys
from pathlib import Path

# Ensure root directory is in sys.path for 'core' module imports
_root_dir = str(Path(__file__).resolve().parent.parent)
if _root_dir not in sys.path:
    sys.path.insert(0, _root_dir)

import streamlit as st

try:
    import importlib

    import core.supabase_cloud as _supa_early

    importlib.reload(_supa_early)
    _supa_early.harvest_active_streamlit_sessions_for_supabase()
except Exception:
    pass

# Gestione parametri URL e calcolo stato sidebar (collassata all'avvio su login/splash, aperta nei moduli)
_qp = getattr(st, "query_params", None)
_is_splash = not st.session_state.get("_app_initialized", False) and not st.session_state.get("splash_dismissed", False)
_is_auth_locked = False
try:
    from core.supabase_cloud import get_supabase_config

    if get_supabase_config().get("require_login", False) and not st.session_state.get("argus_auth_verified", False):
        _is_auth_locked = True
except Exception:
    pass
if _qp is not None:
    if any(k in _qp for k in ("reset", "clear_cache", "reset_cache", "splash")):
        _is_splash = True
    elif "skip_splash" in _qp:
        _is_splash = False

st.set_page_config(
    page_title="Control Room | ARGUS Risk Analytics",
    page_icon="👁️",
    layout="wide",
    initial_sidebar_state="collapsed" if (_is_splash or _is_auth_locked) else "expanded",
)

if _qp is not None:
    if any(k in _qp for k in ("reset", "clear_cache", "reset_cache")):
        st.cache_data.clear()
        st.cache_resource.clear()
        st.session_state["_app_initialized"] = False
        st.session_state["splash_dismissed"] = False
        for k in ("reset", "clear_cache", "reset_cache"):
            if k in _qp:
                try:
                    del st.query_params[k]
                except Exception:
                    pass
    elif "splash" in _qp:
        st.session_state["_app_initialized"] = False
        st.session_state["splash_dismissed"] = False
        try:
            del st.query_params["splash"]
        except Exception:
            pass

# ── Splash Screen & Bootloader Istituzionale (All'avvio) ──────
import components.splash as _splash_mod

try:
    importlib.reload(_splash_mod)
except Exception:
    pass
from components.splash import auto_expand_sidebar
from components.splash import render_splash_screen as render_argus_splash
from core.ux_institutional_hub import APP_VERSION

if render_argus_splash(app_version=APP_VERSION):
    st.stop()

# Reindirizzamento garantito al desk Wealth se selezionato (dallo splash o da switch rapido)
if st.session_state.get("argus_portal_mode") == "🏛️ Wealth Management":
    from core.sidebar import switch_to_page
    switch_to_page("pages/12_🎛️_Wealth_Control_Room.py")
    st.stop()

# Apertura automatica della sidebar una volta entrati nella Control Room
auto_expand_sidebar()


import datetime
import html
import json
import logging
import os
import re

import numpy as np
import pandas as pd
import requests

logger = logging.getLogger("argus.control_room")

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

import core.adapters.broker_hub as broker_hub
import core.duckdb_engine as duckdb_engine
import core.multi_portfolio
import core.ui_utils
from components.splash import render_splash_screen as render_argus_splash
from core.cache_shield import clear_cache
from core.db_exporter import save_snapshot_to_db
from core.diagnostics import (
    clean_expired_cache_records,
    generate_support_bundle,
    get_hardware_and_environment_specs,
    get_recent_logs,
    optimize_database_storage,
    reindex_databases,
    run_system_health_check,
    setup_logging,
)
from core.fetcher import fetch_and_store, get_engine
from core.multi_portfolio import (
    compute_multi_portfolio_comparison,
    consolidate_multi_portfolios,
    delete_saved_portfolio_profile,
    list_saved_portfolio_profiles,
    load_portfolio_profile,
    save_portfolio_profile,
)
from core.risk_engine import compute_risk
from core.ui_utils import (
    fmt_eur,
    fmt_pct,
    get_display_portfolio_name,
    glossary_modal,
    inject_custom_css,
    metric_card,
    render_broker_hub_modal,
    render_command_bar,
    render_control_room_hero,
    render_duckdb_modal,
    render_export_toolbar,
    render_info_modal,
    render_table_with_export,
    render_validation_report,
    render_workflow_stepper,
    section,
)
from core.validator import validate_csv

# Inizializzazione Centralizzata Logging SRE & Sanitizzazione PII
setup_logging()

# ── Mappatura ISIN / Yahoo Ticker (Module-Level Caching) ─────
@st.cache_data(show_spinner=False, ttl=86400)
def fetch_yahoo_ticker_for_isin(isin: str) -> str:
    from core.adapters.isin_resolver import search_yahoo_isin_details
    try:
        sym, _ = search_yahoo_isin_details(isin, timeout=5)
        return sym
    except Exception:
        return ""

inject_custom_css()

# ── Sidebar (Caricata solo dopo l'accesso al terminale) ───────
try:
    import importlib

    import core.supabase_cloud as _supa_mod

    if not hasattr(_supa_mod, "harvest_active_streamlit_sessions_for_supabase"):
        importlib.reload(_supa_mod)
    _supa_mod.harvest_active_streamlit_sessions_for_supabase()
except Exception:
    pass

from core.sidebar import render_sidebar

render_sidebar()

# Fetch parameters safely from session_state
offline_mode = st.session_state.get("offline_mode", False)
data_environment = st.session_state.get("data_environment", "Auto (Ibrido)")
if data_environment == "Local SQLite":
    offline_mode = True
db_host = st.session_state.get("db_host", "localhost")
try:
    db_port = int(st.session_state.get("db_port", 3306))
except Exception:
    db_port = 3306
db_user = st.session_state.get("db_user", "root")
db_pass = st.session_state.get("db_pass", "root")
db_name = st.session_state.get("db_name", "investment_risk_bi")
portfolio_name = st.session_state.get("portfolio_name", "")
run_name = st.session_state.get("run_name", "")

benchmark = st.session_state.get("benchmark", "SPY")

# ── Funzioni di Supporto Database ─────────────────────────────

@st.cache_resource(show_spinner=False)
def get_db_engine(user, password, host, port, db, data_env="Auto (Ibrido)", supa_fp="", auth_ctx="owner:user"):
    is_off = data_env == "Local SQLite"
    return get_engine(user=user, password=password, host=host, port=port, db=db, offline=is_off)


def get_analysis_history(engine):
    """Recupera la lista degli snapshot storici salvati nel database per il richiamo rapido (isolata per utente)."""
    if engine is None:
        return []
    from sqlalchemy import text as sqlt

    role = str(st.session_state.get("argus_auth_role", "owner") or "owner").strip().lower()
    uname = str(st.session_state.get("argus_auth_user", "user") or "user").strip().lower()
    owner_clause = "WHERE LOWER(COALESCE(p.owner, '')) = :uowner" if role == "user" else ""
    params = {"uowner": uname} if role == "user" else {}

    try:
        with engine.connect() as conn:
            rows = conn.execute(
                sqlt(f"""
                SELECT 
                    s.snapshot_id,
                    s.calc_date,
                    s.run_id,
                    s.run_name,
                    s.portfolio_id,
                    p.name as port_name,
                    s.total_value,
                    s.cagr_pct,
                    s.sharpe_ratio,
                    s.max_drawdown_pct,
                    s.var_95_pct
                FROM portfolio_snapshots s
                JOIN portfolios p ON s.portfolio_id = p.portfolio_id
                {owner_clause}
                ORDER BY s.calc_date DESC
                LIMIT 50
            """),
                params,
            ).fetchall()
            return rows
    except Exception:
        return []

# ── Main layout Top ──────────────────────────────────────────

render_command_bar()
render_control_room_hero()

engine_sidebar = None
db_error = None
if not offline_mode:
    try:
        from core.supabase_cloud import get_supabase_config

        supa_fp = get_supabase_config().get("masked_db_url", "")
        auth_ctx = (
            f"{st.session_state.get('argus_auth_role', 'owner')}:"
            f"{st.session_state.get('argus_auth_user', 'user')}:"
            f"{st.session_state.get('argus_user_custom_db_url', '')}"
        )
        engine_sidebar = get_db_engine(
            db_user, db_pass, db_host, db_port, db_name, data_env=data_environment, supa_fp=supa_fp, auth_ctx=auth_ctx
        )
        st.session_state["engine"] = engine_sidebar
        st.session_state["db_engine"] = engine_sidebar
    except Exception as e:
        db_error = e

# ── SEZIONE: Storico Analisi (Recall da Database) ────────────

with st.expander(f"📚 Storico Snapshot & Recall Analisi ({st.session_state.get('db_name', 'investment_risk_bi')})", expanded=not st.session_state.get("pipeline_done")):
    if offline_mode:
        st.info("ℹ️ **Modalità Offline Attiva.** Lo storico delle analisi salvate nel Database non è disponibile in questa modalità In-Memory. Disattiva la modalità offline nella barra laterale a sinistra per connetterti a MySQL e visualizzare lo storico.")
    elif db_error:
        st.warning(f"⚠️ **Accesso al Database non riuscito.**\n\nVerifica host, porta, utente e password nella barra laterale a sinistra per connetterti al Database `{db_name}`. Errore: `{db_error}`")
    elif engine_sidebar:
        history = get_analysis_history(engine_sidebar)
        if not history:
            st.info(f"Nessuna analisi salvata nel Database '{st.session_state.get('db_name', 'investment_risk_bi')}'. Carica un CSV, un Preset o sincronizza Google Sheets per salvare la prima analisi!")
        else:
            st.caption(f"Sfoglia gli snapshot salvati nel database **`{st.session_state.get('db_name', 'investment_risk_bi')}`** per ricaricarli istantaneamente nella Dashboard senza ri-elaborare i prezzi storici.")
            
            # ── BARRA DI RICERCA & FILTRI DINAMICI ──
            col_search, col_port_filter, col_sort = st.columns([2.2, 1.4, 1.4])
            
            with col_search:
                search_query = st.text_input(
                    "🔍 Cerca Analisi (Nome, Tipologia, Data, ID):",
                    placeholder="es. Crypto, Automatic, 2026-08, ANI...",
                    key="hist_search_query"
                ).strip().lower()
                
            unique_ports = sorted(list({r.port_name for r in history if r.port_name and str(r.port_name).strip()}))
            with col_port_filter:
                selected_port_filter = st.selectbox(
                    "💼 Filtra Portafoglio:",
                    options=["Tutti i Portafogli"] + unique_ports,
                    key="hist_port_filter"
                )
                
            with col_sort:
                sort_mode = st.selectbox(
                    "⚡ Ordina per:",
                    options=[
                        "📅 Più recenti",
                        "📅 Meno recenti",
                        "📈 CAGR (Decrescente)",
                        "⚡ Sharpe (Decrescente)",
                        "💰 Valore € (Decrescente)"
                    ],
                    key="hist_sort_mode"
                )

            # Applicazione filtri
            filtered_history = []
            for r in history:
                p_name = r.port_name if (r.port_name and str(r.port_name).strip()) else "Portafoglio Quantitativo"
                r_name = r.run_name if getattr(r, 'run_name', None) else "Analisi Standard"
                dt_str = r.calc_date.strftime("%Y-%m-%d %H:%M")
                
                # Filtro Portafoglio
                if selected_port_filter != "Tutti i Portafogli" and p_name != selected_port_filter:
                    continue
                    
                # Filtro Testuale
                if search_query:
                    search_corpus = f"{p_name} {r_name} {dt_str} {r.run_id}".lower()
                    if search_query not in search_corpus:
                        continue
                        
                filtered_history.append(r)

            # Ordinamento
            if sort_mode == "📅 Più recenti":
                filtered_history.sort(key=lambda x: x.calc_date, reverse=True)
            elif sort_mode == "📅 Meno recenti":
                filtered_history.sort(key=lambda x: x.calc_date, reverse=False)
            elif sort_mode == "📈 CAGR (Decrescente)":
                filtered_history.sort(key=lambda x: float(x.cagr_pct) if x.cagr_pct is not None else -999.0, reverse=True)
            elif sort_mode == "⚡ Sharpe (Decrescente)":
                filtered_history.sort(key=lambda x: float(x.sharpe_ratio) if x.sharpe_ratio is not None else -999.0, reverse=True)
            elif sort_mode == "💰 Valore € (Decrescente)":
                filtered_history.sort(key=lambda x: float(x.total_value) if getattr(x, 'total_value', None) is not None else -999.0, reverse=True)

            if not filtered_history:
                st.warning("🔍 Nessuna analisi salvata corrisponde ai filtri di ricerca impostati. Prova a reimpostare i criteri.")
            else:
                st.markdown(f"<div style='font-size: 11.5px; color: #8b949e; margin-bottom: 6px;'>🎯 Trovati <b>{len(filtered_history)}</b> snapshot su {len(history)} totali</div>", unsafe_allow_html=True)
                
                history_rows = []
                options_map = {}
                for r in filtered_history:
                    dt_str = r.calc_date.strftime("%Y-%m-%d %H:%M")
                    n_str = r.run_name if getattr(r, 'run_name', None) else "Analisi Standard"
                    tot_val = float(r.total_value) if getattr(r, 'total_value', None) is not None else 0.0
                    cagr_val = f"{float(r.cagr_pct):+.2f}%" if getattr(r, 'cagr_pct', None) is not None else "N/A"
                    sharpe_val = f"{float(r.sharpe_ratio):.2f}" if getattr(r, 'sharpe_ratio', None) is not None else "N/A"
                    max_dd_val = f"{float(r.max_drawdown_pct):.2f}%" if getattr(r, 'max_drawdown_pct', None) is not None else "N/A"
                    
                    p_name_display = r.port_name if (r.port_name and str(r.port_name).strip()) else "Portafoglio Quantitativo"
                    history_rows.append({
                        "Data Esecuzione": dt_str,
                        "Portafoglio": p_name_display,
                        "Tipologia": n_str,
                        "Valore (€)": tot_val,
                        "CAGR": cagr_val,
                        "Sharpe": sharpe_val,
                        "Max Drawdown": max_dd_val,
                        "Run ID": r.run_id
                    })
                    
                    # Etichetta formattata pulita con separatore punto centrale
                    label = f"{dt_str} · {p_name_display} · {n_str} (CAGR: {cagr_val} | Sharpe: {sharpe_val})"
                    options_map[label] = r
                
                df_hist = pd.DataFrame(history_rows)
                
                # Tabella riassuntiva formattata con selezione visiva
                st.dataframe(
                    df_hist.style.format({"Valore (€)": "€ {:,.2f}"}),
                    use_container_width=True,
                    height=160,
                    hide_index=True
                )
                
                scelta = st.selectbox(
                    "🎯 Seleziona l'Analisi da Ricaricare:",
                    options=list(options_map.keys()),
                    key="select_history_run",
                    help="Seleziona la sessione di calcolo da ripristinare nella Dashboard."
                )
                
                sel_row = options_map[scelta]
                sel_dt = sel_row.calc_date.strftime("%d/%m/%Y alle %H:%M")
                sel_port = sel_row.port_name if sel_row.port_name else "Portafoglio Quantitativo"
                sel_run_name = sel_row.run_name if sel_row.run_name else "Analisi Standard"
                sel_cagr = f"{float(sel_row.cagr_pct):+.2f}%" if sel_row.cagr_pct is not None else "N/A"
                sel_sharpe = f"{float(sel_row.sharpe_ratio):.2f}" if sel_row.sharpe_ratio is not None else "N/A"
                sel_dd = f"{float(sel_row.max_drawdown_pct):.2f}%" if getattr(sel_row, 'max_drawdown_pct', None) is not None else "N/A"
                sel_val = f"€ {float(sel_row.total_value):,.2f}" if getattr(sel_row, 'total_value', None) is not None else "N/A"

                # ── CARD DI ANTEPRIMA SNAPSHOT SELEZIONATO ──
                st.markdown(f"""
                <div style="background: rgba(22, 27, 34, 0.7); backdrop-filter: blur(12px); border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 12px; padding: 14px 18px; margin: 10px 0 16px 0; box-shadow: 0 4px 16px rgba(0,0,0,0.25);">
                    <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 10px;">
                        <div style="font-weight: 700; font-size: 14.5px; color: #ffffff; display: flex; align-items: center; gap: 8px;">
                            <span>💼 {sel_port}</span>
                            <span style="font-size: 11px; color: #8b949e; font-weight: normal;">({sel_run_name})</span>
                        </div>
                        <span style="background: rgba(88, 166, 255, 0.12); color: #58a6ff; border: 1px solid rgba(88, 166, 255, 0.3); border-radius: 6px; padding: 2px 8px; font-size: 11px; font-family: 'JetBrains Mono', monospace; font-weight: 600;">
                            ID: {sel_row.run_id}
                        </span>
                    </div>
                    <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; text-align: center;">
                        <div style="background: rgba(255,255,255,0.03); padding: 8px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.04);">
                            <div style="font-size: 10px; color: #8b949e; font-weight: 600; text-transform: uppercase;">Controvalore</div>
                            <div style="font-size: 14px; font-weight: 800; color: #ffffff; font-family: 'JetBrains Mono', monospace;">{sel_val}</div>
                        </div>
                        <div style="background: rgba(255,255,255,0.03); padding: 8px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.04);">
                            <div style="font-size: 10px; color: #8b949e; font-weight: 600; text-transform: uppercase;">CAGR %</div>
                            <div style="font-size: 14px; font-weight: 800; color: {'#3fb950' if '+' in sel_cagr else '#f85149'}; font-family: 'JetBrains Mono', monospace;">{sel_cagr}</div>
                        </div>
                        <div style="background: rgba(255,255,255,0.03); padding: 8px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.04);">
                            <div style="font-size: 10px; color: #8b949e; font-weight: 600; text-transform: uppercase;">Sharpe Ratio</div>
                            <div style="font-size: 14px; font-weight: 800; color: #58a6ff; font-family: 'JetBrains Mono', monospace;">{sel_sharpe}</div>
                        </div>
                        <div style="background: rgba(255,255,255,0.03); padding: 8px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.04);">
                            <div style="font-size: 10px; color: #8b949e; font-weight: 600; text-transform: uppercase;">Max Drawdown</div>
                            <div style="font-size: 14px; font-weight: 800; color: #f85149; font-family: 'JetBrains Mono', monospace;">{sel_dd}</div>
                        </div>
                    </div>
                </div>
                """, unsafe_allow_html=True)
                
                col_load, col_del = st.columns([3.2, 1.1])
                with col_load:
                    btn_load = st.button("⚡ Ricarica Analisi in Dashboard", type="primary", use_container_width=True, key="btn_load_hist_analysis")
                with col_del:
                    btn_del = st.button("🗑️ Elimina Snapshot", type="secondary", use_container_width=True, key="btn_del_hist_analysis", help="Elimina questo singolo snapshot dal database.")
                
                if btn_load:
                    with st.spinner(f"Ricalcolo rapido dell'analisi {sel_row.run_id}..."):
                        from core.workspace_context import WorkspaceContext
                        WorkspaceContext.sanitize_risk_portfolio_state(preserve_db_creds=True)
                        rf_val = st.session_state.get("active_rf_rate")
                        base_curr = st.session_state.get("base_currency", "EUR")
                        from sqlalchemy import text as sqlt
                        target_pid = sel_row.portfolio_id
                        try:
                            with engine_sidebar.connect() as conn:
                                tx_cnt = conn.execute(sqlt("SELECT COUNT(*) FROM transactions WHERE portfolio_id = :pid"), {"pid": target_pid}).scalar()
                                if not tx_cnt or tx_cnt == 0:
                                    # Cerca se le transazioni sono archiviate sotto un altro ID con lo stesso nome
                                    alt_pid = conn.execute(sqlt("""
                                        SELECT t.portfolio_id 
                                        FROM transactions t 
                                        JOIN portfolios p ON t.portfolio_id = p.portfolio_id 
                                        WHERE p.name = :pname 
                                        GROUP BY t.portfolio_id 
                                        ORDER BY COUNT(*) DESC LIMIT 1
                                    """), {"pname": sel_row.port_name}).scalar()
                                    if alt_pid:
                                        target_pid = int(alt_pid)
                        except Exception:
                            pass

                        results = compute_risk(target_pid, engine_sidebar, benchmark_ticker=benchmark, risk_free_rate=rf_val, base_currency=base_curr)
                        st.session_state["pipeline_done"]  = True
                        st.session_state["portfolio_id"]   = target_pid
                        st.session_state["portfolio_name"] = sel_row.port_name
                        st.session_state["engine"]         = engine_sidebar
                        st.session_state["results"]        = results
                        st.session_state["run_id"]         = sel_row.run_id
                        st.session_state["fetch_report"]   = {"success": [], "skipped": [], "rows_written": 0, "errors": []}
                        from core.workspace_manager import save_session_snapshot_to_cache
                        save_session_snapshot_to_cache()
                    st.success(f"Analisi {sel_row.run_id} ricaricata con successo!")
                    try:
                        st.switch_page("pages/1_📈_Dashboard_Generale.py")
                    except Exception:
                        st.rerun()
                
                if btn_del:
                    from core.confirm_dialogs import confirm_delete_snapshot_dialog

                    confirm_delete_snapshot_dialog(
                        engine_sidebar, sel_row.run_id, sel_row.port_name, sel_row.portfolio_id
                    )

# ── BANNER SESSIONE ATTIVA & RESET / ONBOARDING ─────────────
if st.session_state.get("pipeline_done"):
    col_act1, col_act2, col_act3, col_act4, col_act5 = st.columns([2.5, 0.95, 0.95, 0.95, 0.65], vertical_alignment="center")
    with col_act1:
        port_name = st.session_state.get("portfolio_name", "Portafoglio")
        run_id = st.session_state.get("run_id", "N/A")
        run_id_display = (run_id[:16] + "…") if len(run_id) > 18 else run_id
        st.markdown(
            f"""
            <div style="background: rgba(88, 166, 255, 0.08); border: 1px solid rgba(88, 166, 255, 0.25); border-radius: 8px; padding: 0 12px; height: 38px; display: flex; align-items: center; gap: 8px; box-sizing: border-box; overflow: hidden; white-space: nowrap;" title="Analisi Attiva: {port_name} | Run ID: {run_id}">
                <span style="font-size: 15px; flex-shrink: 0;">📌</span>
                <span style="font-size: 11.5px; color: #8b949e; flex-shrink: 0; font-weight: 600;">Attivo:</span>
                <span style="font-size: 12.5px; color: #58a6ff; font-weight: 700; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; flex-shrink: 1; min-width: 0;">{port_name}</span>
                <span style="color: rgba(255,255,255,0.18); flex-shrink: 0; margin: 0 2px;">|</span>
                <span style="font-size: 11px; color: #8b949e; flex-shrink: 0;">ID:</span>
                <span style="font-size: 11px; color: #ff9900; background: rgba(255,153,0,0.12); border: 1px solid rgba(255,153,0,0.25); padding: 1px 6px; border-radius: 4px; font-family: monospace; flex-shrink: 0;">{run_id_display}</span>
            </div>
            """,
            unsafe_allow_html=True,
        )
    with col_act2:
        with st.popover("📑 Board Pack", use_container_width=True):
            st.markdown("##### 📑 Executive Master Board Pack")
            st.caption("Dossier unificato Risk & Wealth pronto per CDA e Family Office.")
            prof_nm = st.session_state.get("portfolio_name", "Portfolio Master")
            try:
                from core.fetcher import get_engine
                from core.wealth.wealth_reporting_hub import (
                    _get_cached_master_board_pack_html,
                    _get_cached_master_board_pack_pdf,
                )
                eng = get_engine()
                st.download_button(
                    "📥 Scarica PDF Master",
                    data=lambda: _get_cached_master_board_pack_pdf(eng, pid=1, prof_name=prof_nm),
                    file_name=f"argus_master_board_pack_{prof_nm.lower().replace(' ', '_')}.pdf",
                    mime="application/pdf",
                    use_container_width=True,
                    type="primary",
                    key="dl_mb_pdf_ctrl_room",
                )
                st.download_button(
                    "🌐 Scarica HTML Master",
                    data=lambda: _get_cached_master_board_pack_html(eng, pid=1, prof_name=prof_nm),
                    file_name=f"argus_master_board_pack_{prof_nm.lower().replace(' ', '_')}.html",
                    mime="text/html",
                    use_container_width=True,
                    key="dl_mb_html_ctrl_room",
                )
            except Exception as ex:
                st.error(f"Errore generazione Master Board Pack: {ex}")
    with col_act3:
        from core.priips_kid_generator import render_priips_kid_popover
        prof_nm = st.session_state.get("portfolio_name", "Portafoglio Master")
        r_bundle = st.session_state.get("risk_bundle", {})
        render_priips_kid_popover(portfolio_name=prof_nm, risk_data=r_bundle, key_suffix="ctrl_room_kid")
    with col_act4:
        with st.popover("🎙️ Morning Note", use_container_width=True):
            from core.morning_meeting_engine import generate_morning_meeting_script, render_morning_meeting_audio_widget
            prof_nm = st.session_state.get("portfolio_name", "Portafoglio Master")
            r_bundle = st.session_state.get("risk_bundle", {})
            briefing_obj = generate_morning_meeting_script(portfolio_name=prof_nm, risk_data=r_bundle)
            render_morning_meeting_audio_widget(briefing_obj, key_suffix="ctrl_room_mm")
    with col_act5:
        if st.button("🔄 Reset", type="secondary", use_container_width=True, help="Azzera lo stato corrente della sessione per caricare o elaborare un nuovo portafoglio."):
            from core.confirm_dialogs import confirm_reset_session_dialog

            confirm_reset_session_dialog()
else:
    col_onb1, col_onb2 = st.columns([3.2, 1.2])
    with col_onb1:
        st.markdown("""
        <div style="background: rgba(56, 189, 248, 0.08); border: 1px dashed rgba(56, 189, 248, 0.35); border-radius: 10px; padding: 10px 14px; margin-bottom: 12px; display:flex; align-items:center; gap:10px;">
            <span style="font-size:20px;">🛡️</span>
            <div style="font-size:12.5px; color:#cbd5e1;">
                <b>Primo Avvio / Nessun Portafoglio Attivo:</b> Vuoi esplorare subito l'intera suite senza caricare file?
                <span style="color:#38bdf8;">Avvia lo scenario dimostrativo a 5 pilastri patrimoniali con un singolo click.</span>
            </div>
        </div>
        """, unsafe_allow_html=True)
    with col_onb2:
        if st.button("⚡ Carica Demo (5 Pilastri)", type="primary", use_container_width=True, help="Inizializza istantaneamente uno scenario completo con Azioni, BTP, Cassa, Immobile e Mutuo.", key="btn_onboarding_top_demo"):
            from core.unified_demo_seeder import seed_unified_demo_scenario
            seed_unified_demo_scenario()
            st.toast("✅ Portafoglio Demo Istituzionale caricato con successo!", icon="🚀")
            st.rerun()

# ── COMMAND TABS DELLA CONTROL ROOM ──────────────────────────

tab_ingest, tab_wealth, tab_isin_mapping, tab_diagnostics, tab_duckdb, tab_bitemporal = st.tabs([
    "🚀 1. Ingestione Dati & Calcolo Pipeline",
    "🗂️ 2. Total Wealth Hub (Multi-Portafoglio)",
    "🏷️ 3. Anagrafica & Mappatura ISIN / Ticker DB",
    "🩺 4. Telemetria di Sistema & Storage Profiler",
    "⚡ 5. Motore Analitico Embedded DuckDB (OLAP & SQL)",
    "🕰️ 6. Bitemporal Time-Travel & Audit Ledger"
])

# =============================================================
# TAB 1: INGESTIONE DATI & CALCOLO PIPELINE
# =============================================================
with tab_ingest:
    
    current_wf_step = 1
    if st.session_state.get("pipeline_done"):
        current_wf_step = 3

    section("① Carica la Sorgente Dati (Multi-Broker Ingestion Hub, CSV Standard o Google Sheets)")
    col_sec1_h1, col_sec1_h2 = st.columns([3.2, 1.1])
    with col_sec1_h1:
        st.caption("Importa e consolida transazioni da oltre 10 broker internazionali, sincronizza da Google Sheets o scarica il template CSV standard ARGUS.")
    with col_sec1_h2:
        render_broker_hub_modal(use_popover=False)

    template_csv = """tx_date,ticker,tx_type,quantity,price,currency,fees,asset_class,notes
2021-03-15,AAPL,buy,10,121.03,USD,1.50,stock,Esempio acquisto
2021-06-01,VWRL.L,buy,5,89.20,GBP,0.00,etf,
2022-01-10,BTC-USD,buy,0.05,41800.00,USD,2.00,crypto,
2022-08-20,AAPL,sell,5,162.50,USD,1.50,stock,Presa profitto
2023-03-01,AAPL,dividend,0,0.23,USD,0.00,stock,Dividendo Q1"""

    # ── Helper Iniezione Archetipo Unificato ─────────────────────
    from core.archetype_manager import (
        clear_unified_archetype,
        execute_unified_archetype_load,
        render_unified_archetype_hud,
    )

    arch_status_placeholder = st.empty()

    def _execute_archetype_load(arch_code: str, auto_run: bool = False):
        with arch_status_placeholder.container():
            with st.spinner("⏳ Generazione quantitativa e salvataggio cross-modulo dell'archetipo in corso..."):
                execute_unified_archetype_load(arch_code, auto_run=auto_run, source_module="risk")
                st.rerun()

    def _clear_active_archetype():
        clear_unified_archetype()

    expander_is_open = bool(st.session_state.get("keep_archetype_expander_open", False) or st.session_state.get("active_archetype_code"))
    with st.expander("🧪 Scenari Didattici & Archetipi Pre-configurati (Caricamento 1-Click)", expanded=expander_is_open):
        st.caption("Carica istantaneamente un portafoglio pluriennale sintetico realistico con solvibilità e date borsistiche garantite. Ideale per didattica e collaudo immediato sia su Risk Analytics che su Wealth Management.")
        
        active_code = st.session_state.get("active_archetype_code")
        if active_code:
            render_unified_archetype_hud(current_module="risk")

        arch_c1, arch_c2, arch_c3 = st.columns(3)
        with arch_c1:
            with st.container(border=True):
                badge_young = " :green[**[● ATTIVO]**]" if active_code == "young_accumulator" else ""
                st.markdown(f"""
                **🚀 Giovane Accumulatore**{badge_young}
                - **Rischio**: Aggressivo (25 anni)
                - **Asset**: Global ETF, QQQ, Big Tech, Crypto
                - **PAC**: €850/mese su stipendio in crescita
                """, unsafe_allow_html=True)
                col_b1_a, col_b1_b = st.columns([1.1, 0.9])
                with col_b1_a:
                    if st.button("⚡ 1-Click Analisi", key="btn_load_run_young", type="primary", use_container_width=True, help="Genera l'archetipo, registra su DB ed esegue immediatamente l'analisi completa."):
                        _execute_archetype_load("young_accumulator", auto_run=True)
                with col_b1_b:
                    lbl_y = "Ricarica" if active_code == "young_accumulator" else "Carica Dati"
                    if st.button(lbl_y, key="btn_load_arch_young", type="secondary", use_container_width=True, help="Carica i dati su DB e sessione senza avviare subito il calcolo."):
                        _execute_archetype_load("young_accumulator", auto_run=False)

        with arch_c2:
            with st.container(border=True):
                badge_fire = " :green[**[● ATTIVO]**]" if active_code == "fire_decumulation" else ""
                st.markdown(f"""
                **🏖️ FIRE / Decumulo**{badge_fire}
                - **Rischio**: Conservativo / Cedolare
                - **Asset**: Dividend Aristocrats, BND Bond, Value
                - **Decumulo**: SWR 3.5% costante, zero debiti
                """, unsafe_allow_html=True)
                col_b2_a, col_b2_b = st.columns([1.1, 0.9])
                with col_b2_a:
                    if st.button("⚡ 1-Click Analisi", key="btn_load_run_fire", type="primary", use_container_width=True, help="Genera l'archetipo, registra su DB ed esegue immediatamente l'analisi completa."):
                        _execute_archetype_load("fire_decumulation", auto_run=True)
                with col_b2_b:
                    lbl_f = "Ricarica" if active_code == "fire_decumulation" else "Carica Dati"
                    if st.button(lbl_f, key="btn_load_arch_fire", type="secondary", use_container_width=True, help="Carica i dati su DB e sessione senza avviare subito il calcolo."):
                        _execute_archetype_load("fire_decumulation", auto_run=False)

        with arch_c3:
            with st.container(border=True):
                badge_hnwi = " :green[**[● ATTIVO]**]" if active_code == "hnwi_family" else ""
                st.markdown(f"""
                **👑 HNWI / Famiglia**{badge_hnwi}
                - **Rischio**: Multi-Asset Istituzionale (€4.0M)
                - **Asset**: Big Tech, Global ETF, Bond, Gold, Watches
                - **Wealth**: Mutuo francese, affitti, max pensione
                """, unsafe_allow_html=True)
                col_b3_a, col_b3_b = st.columns([1.1, 0.9])
                with col_b3_a:
                    if st.button("⚡ 1-Click Analisi", key="btn_load_run_hnwi", type="primary", use_container_width=True, help="Genera l'archetipo, registra su DB ed esegue immediatamente l'analisi completa."):
                        _execute_archetype_load("hnwi_family", auto_run=True)
                with col_b3_b:
                    lbl_h = "Ricarica" if active_code == "hnwi_family" else "Carica Dati"
                    if st.button(lbl_h, key="btn_load_arch_hnwi", type="secondary", use_container_width=True, help="Carica i dati su DB e sessione senza avviare subito il calcolo."):
                        _execute_archetype_load("hnwi_family", auto_run=False)

    col_ds_sel, col_ds_tpl = st.columns([3.2, 1.2], vertical_alignment="bottom")
    with col_ds_sel:
        data_source = st.selectbox(
            "Sorgente Dati / Piattaforma Broker",
            options=[
                "⚡ Auto-Detect Broker (Riconoscimento Automatico Formato)",
                "📄 CSV Standard (Template ARGUS)",
                "🟡 DeGiro (Export Transazioni)",
                "🔵 Directa SIM (Ordini Eseguiti / Estratto Conto)",
                "🔴 Fineco Bank (Movimenti Conto Trading)",
                "🟠 Interactive Brokers - IBKR (Activity Statement / Trades)",
                "🟢 Trade Republic (Transazioni / PAC)",
                "🔷 Scalable Capital (Transazioni / Baader Bank)",
                "🟩 eToro (Account Statement / Closed Trades)",
                "🟪 Revolut Trading (Estratto Conto Transazioni)",
                "🌐 Google Sheets Live Sync"
            ],
            help="Seleziona il broker da cui proviene il file CSV oppure usa 'Auto-Detect' per il riconoscimento automatico intelligente."
        )
    with col_ds_tpl:
        st.download_button(
            "⬇️ Template CSV",
            data=template_csv,
            file_name="template_portfolio.csv",
            mime="text/csv",
            use_container_width=True,
            help="Scarica il file CSV di esempio con lo schema standard ARGUS a 9 colonne."
        )

    uploaded_file = None
    df_raw = None

    if data_source == "🌐 Google Sheets Live Sync":
        st.markdown("##### 🌐 Sincronizzazione Diretta Google Sheets (Service Account)")
        st.caption("Estrai automaticamente le transazioni sia dall'azionario che dalle criptovalute, separando i portafogli su DB e registrandoli nel Total Wealth Hub.")
        
        gs_mode_label = st.radio(
            "Modalità di Estrazione Google Sheets:",
            [
                "⚡ Sincronizzazione Completa (Stocks + Crypto separati)",
                "📈 Solo Stocks (History B/S Stocks)",
                "🪙 Solo Crypto (History B/S Crypto)",
                "⚙️ Personalizzato"
            ],
            horizontal=True
        )
        
        gs_name = st.text_input("Nome/ID dello Spreadsheet Google Sheets:", value="My All financial Statements")
        
        mode_param = "both"
        stocks_tab_val = "History B/S Stocks"
        crypto_tab_val = "History B/S Crypto"
        custom_tab_val = "History B/S Stocks"
        custom_pname_val = "Wealth Custom Portfolio"
        
        if gs_mode_label == "⚡ Sincronizzazione Completa (Stocks + Crypto separati)":
            mode_param = "both"
            col_gs1, col_gs2 = st.columns(2)
            stocks_tab_val = col_gs1.text_input("Nome Tab Stocks/ETF:", value="History B/S Stocks")
            crypto_tab_val = col_gs2.text_input("Nome Tab Crypto:", value="History B/S Crypto")
            st.info("💡 I portafogli verranno creati come **`Wealth Stocks Portfolio`** e **`Wealth Crypto Portfolio`**, con snapshot indipendenti su DB e registrazione automatica nel Total Wealth Hub.")
        elif gs_mode_label == "📈 Solo Stocks (History B/S Stocks)":
            mode_param = "stocks"
            stocks_tab_val = st.text_input("Nome Tab Stocks/ETF:", value="History B/S Stocks")
        elif gs_mode_label == "🪙 Solo Crypto (History B/S Crypto)":
            mode_param = "crypto"
            crypto_tab_val = st.text_input("Nome Tab Crypto:", value="History B/S Crypto")
        else:
            mode_param = "custom"
            col_c1, col_c2 = st.columns(2)
            custom_tab_val = col_c1.text_input("Nome del Tab:", value="History B/S Stocks")
            custom_pname_val = col_c2.text_input("Nome Portafoglio su DB:", value="Wealth Custom Portfolio")
        
        btn_gs_sync = st.button("🔄 Avvia Sincronizzazione Live Google Sheets", type="primary", use_container_width=True)
        if btn_gs_sync:
            with st.spinner("⏳ Connessione a Google Sheets ed esecuzione ETL in corso..."):
                try:
                    import importlib

                    import core.db_exporter
                    importlib.reload(core.db_exporter)
                    import core.risk_engine
                    importlib.reload(core.risk_engine)
                    import gsheets_sync_subproject.sync_google_sheets
                    importlib.reload(gsheets_sync_subproject.sync_google_sheets)
                    from gsheets_sync_subproject.sync_google_sheets import run_daily_pipeline

                    res_tuple = run_daily_pipeline(
                        spreadsheet_identifier=gs_name,
                        mode=mode_param,
                        stocks_tab=stocks_tab_val,
                        crypto_tab=crypto_tab_val,
                        custom_tab=custom_tab_val,
                        custom_portfolio_name=custom_pname_val,
                        return_results=True
                    )
                    if isinstance(res_tuple, tuple) and len(res_tuple) >= 5 and res_tuple[0]:
                        success, res_sync, run_id_sync, p_name_sync, f_rep = res_tuple[0:5]
                        dual_info = res_tuple[5] if len(res_tuple) > 5 else None

                        st.session_state["results"] = res_sync
                        st.session_state["pipeline_done"] = True
                        st.session_state["portfolio_name"] = p_name_sync or "Google Sheets Portfolio"
                        st.session_state["run_id"] = run_id_sync
                        st.session_state["fetch_report"] = f_rep
                        st.session_state.pop("session_cleared", None)

                        # Preservazione consistenza DataFrame transazioni per l'intera sessione
                        df_tx_sync = None
                        if isinstance(res_sync, dict):
                            df_tx_sync = res_sync.get("df_tx") if isinstance(res_sync.get("df_tx"), pd.DataFrame) else res_sync.get("df_tx_raw")
                        if df_tx_sync is not None and not df_tx_sync.empty:
                            st.session_state["df_clean"] = df_tx_sync
                            st.session_state["df_tx"] = df_tx_sync

                        # Sincronizzazione automatica immediata nel Ledger Bitemporale DuckDB
                        try:
                            from core.bitemporal_engine import BitemporalLedgerEngine
                            if "bitemp_engine" not in st.session_state or not isinstance(st.session_state.get("bitemp_engine"), BitemporalLedgerEngine):
                                st.session_state["bitemp_engine"] = BitemporalLedgerEngine()
                                st.session_state["bitemp_seed_info"] = st.session_state["bitemp_engine"].seed_demonstration_scenario()
                            b_eng = st.session_state["bitemp_engine"]
                            
                            p_target_name = st.session_state["portfolio_name"]
                            if df_tx_sync is not None and not df_tx_sync.empty:
                                b_eng.ingest_portfolio_dataframe(df_tx_sync, portfolio_id=p_target_name, recorded_by="GSHEETS_LIVE_SYNC")
                                st.session_state["selected_bitemp_port"] = p_target_name

                            # Se presente sincronizzazione duale, ingerisci anche i singoli tab Stocks e Crypto
                            if dual_info and isinstance(dual_info, dict):
                                for sub_k in ("stocks", "crypto"):
                                    sub_d = dual_info.get(sub_k)
                                    if isinstance(sub_d, dict):
                                        s_df = sub_d.get("results", {}).get("df_tx")
                                        s_name = sub_d.get("portfolio_name")
                                        if isinstance(s_df, pd.DataFrame) and not s_df.empty and s_name:
                                            b_eng.ingest_portfolio_dataframe(s_df, portfolio_id=s_name, recorded_by=f"GSHEETS_{sub_k.upper()}")
                        except Exception as e_bitemp_auto:
                            logger.warning(f"Auto-ingest bitemporale Google Sheets: {e_bitemp_auto}")
                        
                        if dual_info and "stocks" in dual_info and "crypto" in dual_info:
                            st.session_state["gs_dual_sync_success"] = {
                                "stocks_name": dual_info["stocks"]["portfolio_name"],
                                "crypto_name": dual_info["crypto"]["portfolio_name"],
                                "run_id": run_id_sync
                            }
                            st.success(f"✅ Sincronizzazione duale completata! Creati **{dual_info['stocks']['portfolio_name']}** e **{dual_info['crypto']['portfolio_name']}** su DB e registrati nel Total Wealth Hub.")
                        else:
                            st.success(f"✅ Sincronizzazione completata! Portafoglio **{p_name_sync}** caricato in sessione (Run ID: `{run_id_sync}`).")
                        st.rerun()
                    elif res_tuple is True:
                        st.success("✅ Sincronizzazione con Google Sheets completata con successo!")
                        st.rerun()
                except Exception as ex:
                    st.error(f"❌ Errore durante la sincronizzazione Google Sheets: {ex}")
                    ex_str = str(ex).lower()
                    if any(w in ex_str for w in ["segnaposto", "placeholder", "pem", "credenziali", "private_key", "invalidbyte"]):
                        st.info(
                            "🔑 **Come configurare le credenziali Google Sheets:**\n\n"
                            "1. Il file `gsheets_sync_subproject/google_service_account.json` contiene attualmente valori segnaposto per sicurezza.\n"
                            "2. Per abilitare la sincronizzazione, incolla le tue credenziali JSON reali (scaricate da Google Cloud Console) nel file `gsheets_sync_subproject/google_service_account.json` (il file è protetto e ignorato da Git via `.gitignore`).\n"
                            "3. In alternativa, imposta la variabile d'ambiente `GOOGLE_SERVICE_ACCOUNT_JSON` o configurala in `.streamlit/secrets.toml`."
                        )
    else:
        is_arch_active = bool(st.session_state.get("active_archetype_code") or st.session_state.get("df_raw_injected") is not None)
        if is_arch_active and st.session_state.get("df_raw_injected") is not None:
            df_raw = st.session_state["df_raw_injected"].copy().astype(str)
            st.info(f"🧪 **Scenario Didattico Attivo**: `{st.session_state.get('portfolio_name', 'Archetipo')}` con **{len(df_raw)} transazioni** simulate con solvibilità e date borsistiche conformi.")

        uploaded_file = st.file_uploader(
            "Trascina qui il tuo file CSV esportato dal broker (o usa il template ARGUS):",
            type=["csv", "xlsx", "xls", "txt"],
            help="Carica il file in formato CSV, Excel o TXT. L'Auto-Detector riconoscerà automaticamente la struttura del broker."
        )
        if uploaded_file and not st.session_state.get("archetype_just_injected"):
            st.session_state.pop("df_raw_injected", None)
            st.session_state.pop("active_archetype_code", None)
            st.session_state.pop("active_archetype_name", None)
            st.session_state.pop("keep_archetype_expander_open", None)
            from core.ingestion_utils import read_tabular_stream
            try:
                df_raw = read_tabular_stream(uploaded_file.getvalue(), filename=uploaded_file.name).astype(str)
            except Exception as e_stream:
                st.error(f"Errore lettura file: {e_stream}")
                df_raw = None
            if df_raw is not None and not df_raw.empty:
                st.session_state.pop("session_cleared", None)
                if not st.session_state.get("portfolio_name") or st.session_state.get("portfolio_name") == "Nessun Portafoglio (In attesa)":
                    auto_name = os.path.splitext(uploaded_file.name)[0].replace("_", " ").replace("-", " ").title()
                    st.session_state["portfolio_name"] = auto_name
        elif uploaded_file and st.session_state.get("archetype_just_injected"):
            st.caption("ℹ️ Un file è presente nel caricatore, ma lo Scenario Didattico ha la precedenza. Clicca su 'Rimuovi Scenario' nell'expander in alto se desideri analizzare il file.")

    if st.session_state.get("pipeline_done"):
        current_wf_step = 3
    elif df_raw is not None:
        current_wf_step = 2
    else:
        current_wf_step = 1

    render_workflow_stepper(current_wf_step)

    # ── STEP 2: Validazione Dati & Data Health HUD ───────────────
    if df_raw is not None:
        broker_key_map = {
            "⚡ Auto-Detect Broker (Riconoscimento Automatico Formato)": "auto",
            "📄 CSV Standard (Template ARGUS)": "standard",
            "🟡 DeGiro (Export Transazioni)": "degiro",
            "🔵 Directa SIM (Ordini Eseguiti / Estratto Conto)": "directa",
            "🔴 Fineco Bank (Movimenti Conto Trading)": "fineco",
            "🟠 Interactive Brokers - IBKR (Activity Statement / Trades)": "ibkr",
            "🟢 Trade Republic (Transazioni / PAC)": "traderepublic",
            "🔷 Scalable Capital (Transazioni / Baader Bank)": "scalable",
            "🟩 eToro (Account Statement / Closed Trades)": "etoro",
            "🟪 Revolut Trading (Estratto Conto Transazioni)": "revolut"
        }
        selected_broker_key = broker_key_map.get(data_source, "auto")

        is_archetype = bool(st.session_state.get("active_archetype_code") or st.session_state.get("df_raw_injected") is not None)
        if is_archetype:
            arch_pname = st.session_state.get("active_archetype_name") or st.session_state.get("portfolio_name", "Archetipo")
            st.success(f"✅ Scenario Didattico Verificato: **🧪 {arch_pname}** ({len(df_raw)} transazioni normalizzate per standard ARGUS).")
        elif selected_broker_key != "standard":
            from core.adapters.broker_hub import parse_broker_csv
            try:
                with st.spinner("⏳ Analisi struttura broker e normalizzazione ISIN via Multi-Broker Hub..."):
                    df_raw, detected_key, b_report = parse_broker_csv(df_raw, broker_key=selected_broker_key)
                
                b_name = b_report.get("broker_name", detected_key.title())
                b_icon = b_report.get("broker_icon", "📄")
                if b_report.get("is_auto_detected"):
                    st.success(f"✅ Formato riconosciuto automaticamente: **{b_icon} {b_name}** ({b_report.get('rows_parsed', 0)} transazioni convertite con successo).")
                else:
                    st.success(f"✅ File **{b_icon} {b_name}** convertito con successo ({b_report.get('rows_parsed', 0)} transazioni normalizzate).")
            except Exception as e:
                st.error(f"❌ Errore durante il parsing del file broker: {e}")
                st.stop()

        section("② Validazione Dati & Data Health HUD")
        df_clean, report = validate_csv(df_raw)
        st.session_state["df_clean"] = df_clean

        render_validation_report(report)

        s = report["stats"]
        
        # Data Health Summary Grid
        c1, c2, c3, c4, c5 = st.columns(5)
        with c1: metric_card("Righe Valide", f"{s['total_rows']}", help_text="Numero totale di transazioni valide nel file.")
        with c2: metric_card("Ticker Unici", f"{len(s['tickers'])}", help_text="Numero di asset finanziari distinti identificati.")
        with c3: metric_card("Valute Rilevate", f"{len(s['currencies'])}", help_text="Valute delle transazioni (EUR, USD, GBP, ecc.).")
        with c4: metric_card("Data Inizio", f"{s['date_range'][0]}", help_text="Data della prima transazione a storico.")
        with c5: metric_card("Data Fine", f"{s['date_range'][1]}", help_text="Data dell'ultima transazione a storico.")

        # Mini Asset Class Breakdown Pills
        if "asset_class" in df_clean.columns:
            ac_counts = df_clean["asset_class"].fillna("other").value_counts().to_dict()
            ac_pills = " ".join([
                f'<span class="argus-asset-pill" style="border-color:rgba(88,166,255,0.3); color:#58a6ff;">● {ac.upper()}: <b>{cnt}</b> tx</span>'
                for ac, cnt in ac_counts.items()
            ])
            st.markdown(f"""
            <div style="background: rgba(13, 17, 23, 0.6); border: 1px solid rgba(255, 255, 255, 0.06); border-radius: 8px; padding: 8px 12px; margin: 8px 0 12px 0; display:flex; align-items:center; gap: 8px; flex-wrap:wrap;">
                <span style="font-size:11px; font-weight:700; color:#8b949e; text-transform:uppercase; letter-spacing:0.4px;">Asset Allocation Rilevata:</span>
                {ac_pills}
            </div>
            """, unsafe_allow_html=True)

        with st.expander("🔍 Ispeziona Anteprima Dati Validati", expanded=False):
            df_display = df_clean.copy()
            if "tx_date" in df_display.columns:
                df_display["tx_date"] = df_display["tx_date"].dt.strftime("%Y-%m-%d")
            df_display_renamed = df_display.rename(columns={
                "tx_date": "Data Operazione",
                "ticker": "Ticker / ISIN",
                "tx_type": "Tipo Operazione",
                "quantity": "Quantità",
                "price": "Prezzo (€)",
                "currency": "Valuta",
                "fees": "Commissioni (€)",
                "asset_class": "Classe Asset",
                "notes": "Note"
            })
            st.dataframe(df_display_renamed, use_container_width=True, height=200)

        # Mappatura ISIN / Yahoo Ticker (utilizza la funzione cached a livello modulo)
        ISIN_PATTERN = re.compile(r"^[A-Z]{2}[A-Z0-9]{10}$")
        unmapped_isins = [t for t in s["tickers"] if ISIN_PATTERN.match(t)]
        
        from core.fetcher import _get_config_file_path
        cfg_path_ing = _get_config_file_path()
        loaded_mapping = {}
        if cfg_path_ing.exists():
            try:
                with open(cfg_path_ing, "r", encoding="utf-8") as f:
                    config_data = json.load(f)
                    loaded_mapping = config_data.get("ticker_mapping", {})
            except Exception:
                pass

        if engine_sidebar is not None:
            try:
                with engine_sidebar.connect() as conn:
                    db_maps = conn.execute(sqlt("SELECT input_ticker, yfinance_ticker FROM asset_mapping")).fetchall()
                    for r_m in db_maps:
                        loaded_mapping[str(r_m[0]).strip().upper()] = str(r_m[1]).strip().upper()
            except Exception:
                pass

        if unmapped_isins:
            missing_isins = [i for i in unmapped_isins if not loaded_mapping.get(i)]
            if missing_isins:
                st.warning(f"⚠️ Rilevati {len(missing_isins)} ISIN non mappati ai ticker Yahoo Finance.")
                mapping_data = []
                for isin in missing_isins:
                    nome_prodotto = df_clean.loc[df_clean["ticker"] == isin, "notes"].dropna().unique()
                    nome = nome_prodotto[0] if len(nome_prodotto) > 0 else "Sconosciuto"
                    suggerimento = fetch_yahoo_ticker_for_isin(isin)
                    mapping_data.append({"ISIN": isin, "Nome Prodotto": nome, "Yahoo Ticker": suggerimento})
                
                mapping_df = pd.DataFrame(mapping_data)
                edited_mapping_df = st.data_editor(mapping_df, use_container_width=True, hide_index=True, key="new_mapping")
                
                if st.button("💾 Salva Nuova Mappatura nel DB & Config", type="primary", key="save_new_mapping"):
                    new_mapping = dict(zip(edited_mapping_df["ISIN"], edited_mapping_df["Yahoo Ticker"]))
                    new_mapping = {k: v.strip().upper() for k, v in new_mapping.items() if v and v.strip()}
                    if new_mapping:
                        config_data = {}
                        if cfg_path_ing.exists():
                            try:
                                with open(cfg_path_ing, "r", encoding="utf-8") as f: config_data = json.load(f)
                            except Exception: pass
                        if "ticker_mapping" not in config_data: config_data["ticker_mapping"] = {}
                        config_data["ticker_mapping"].update(new_mapping)
                        with open(cfg_path_ing, "w", encoding="utf-8") as f: json.dump(config_data, f, indent=4)
                        
                        if engine_sidebar is not None:
                            try:
                                with engine_sidebar.begin() as conn:
                                    for isin_k, yf_v in new_mapping.items():
                                        if engine_sidebar.dialect.name == "sqlite":
                                            conn.execute(sqlt("""
                                                INSERT INTO asset_mapping (input_ticker, yfinance_ticker, description)
                                                VALUES (:input_ticker, :yfinance_ticker, :description)
                                                ON CONFLICT(input_ticker) DO UPDATE SET yfinance_ticker = excluded.yfinance_ticker
                                            """), {"input_ticker": isin_k, "yfinance_ticker": yf_v, "description": "Ingestione CSV"})
                                        else:
                                            conn.execute(sqlt("""
                                                INSERT INTO asset_mapping (input_ticker, yfinance_ticker, description)
                                                VALUES (:input_ticker, :yfinance_ticker, :description)
                                                ON DUPLICATE KEY UPDATE yfinance_ticker = VALUES(yfinance_ticker)
                                            """), {"input_ticker": isin_k, "yfinance_ticker": yf_v, "description": "Ingestione CSV"})
                            except Exception: pass
                            
                        st.success("Mappatura salvata con successo nel DB e in Config!")
                        st.rerun()

        # ── STEP 3: Elaborazione Dati e Calcolo Rischio ───────────────
        section("③ Elaborazione Dati e Calcolo Rischio")

        if not st.session_state.get("pipeline_done"):
            col_cfg1, col_cfg2 = st.columns([2.5, 1.5])
            with col_cfg1:
                custom_pname = st.text_input(
                    "Nome del Portafoglio da Salvare:",
                    value=st.session_state.get("portfolio_name") or "Portafoglio Quantitativo",
                    help="Nome descrittivo con cui salvare questo portafoglio nel Database e nel Total Wealth Hub."
                )
                if custom_pname:
                    st.session_state["portfolio_name"] = custom_pname.strip()
            with col_cfg2:
                benchmark = st.selectbox(
                    "Benchmark di Mercato:",
                    options=["SPY", "VWCE.DE", "^GSPC", "QQQ", "IEI"],
                    index=0,
                    help="Indice/ETF di confronto per il calcolo di Beta, Alpha e correlazione."
                )

            st.markdown('<div style="height: 6px;"></div>', unsafe_allow_html=True)
            run_fetch = st.button("🚀 Avvia Analisi Quantitativa ARGUS", type="primary", use_container_width=True, key="btn_run_argus_pipeline")
            auto_run = st.session_state.pop("auto_run_pipeline_requested", False)

            if run_fetch or auto_run:
                if not offline_mode:
                    try:
                        engine = get_db_engine(db_user, db_pass, db_host, int(db_port), db_name)
                    except Exception as e:
                        st.error(f"Connessione MySQL fallita: {e}")
                        st.stop()
                else:
                    engine = None
                    portfolio_id = 999999

                with st.spinner("⏳ Sincronizzazione dati di mercato (Yahoo Finance) e calcolo metriche di rischio..."):
                    p_name_final = st.session_state.get("portfolio_name") or "Portafoglio Quantitativo"
                    
                    if not offline_mode:
                        from sqlalchemy import text as sqlt

                        from core.db_exporter import get_or_create_portfolio_id
                        with engine.begin() as conn:
                            portfolio_id = get_or_create_portfolio_id(
                                conn,
                                name=p_name_final,
                                owner="streamlit_user",
                                base_currency=st.session_state.get("base_currency", "EUR")
                            )
                            conn.execute(sqlt("DELETE FROM transactions WHERE portfolio_id = :pid"), {"pid": portfolio_id})

                            is_sqlite = "sqlite" in str(engine.url)
                            for _, row in df_clean.iterrows():
                                t_sym = str(row["ticker"]).strip().upper()
                                a_class = "stock" if pd.isna(row.get("asset_class")) else row.get("asset_class")
                                curr = row["currency"]
                                
                                if is_sqlite:
                                    conn.execute(sqlt("""
                                        INSERT INTO assets (ticker, name, asset_class, currency)
                                        VALUES (:ticker, :ticker, :asset_class, :currency)
                                        ON CONFLICT(ticker) DO UPDATE SET 
                                            name = excluded.name, 
                                            asset_class = excluded.asset_class, 
                                            currency = excluded.currency
                                    """), {
                                        "ticker":      t_sym,
                                        "asset_class": a_class,
                                        "currency":    curr,
                                    })
                                else:
                                    conn.execute(sqlt("""
                                        INSERT INTO assets (ticker, name, asset_class, currency)
                                        VALUES (:ticker, :ticker, :asset_class, :currency)
                                        ON DUPLICATE KEY UPDATE name=VALUES(name), asset_class=VALUES(asset_class), currency=VALUES(currency)
                                    """), {
                                        "ticker":      t_sym,
                                        "asset_class": a_class,
                                        "currency":    curr,
                                    })

                                asset_id = conn.execute(
                                    sqlt("SELECT asset_id FROM assets WHERE ticker=:t"),
                                    {"t": t_sym}
                                ).scalar()

                                conn.execute(sqlt("""
                                    INSERT INTO transactions
                                        (portfolio_id, asset_id, tx_date, tx_type,
                                         quantity, price, currency, fees, notes)
                                    VALUES
                                        (:pid, :aid, :tx_date, :tx_type,
                                         :quantity, :price, :currency, :fees, :notes)
                                """), {
                                    "pid":      portfolio_id,
                                    "aid":      asset_id,
                                    "tx_date":  str(row["tx_date"])[:10],
                                    "tx_type":  row["tx_type"],
                                    "quantity": float(row["quantity"]),
                                    "price":    float(row["price"]),
                                    "currency": row["currency"],
                                    "fees":     0.0 if pd.isna(row.get("fees")) else float(row["fees"]),
                                    "notes":    None if pd.isna(row.get("notes")) else row.get("notes"),
                                })

                    from core.workspace_context import WorkspaceContext
                    WorkspaceContext.sanitize_risk_portfolio_state(preserve_db_creds=True)
                    rf_val = st.session_state.get("active_rf_rate")
                    base_curr = st.session_state.get("base_currency", "EUR")

                    if offline_mode:
                        fetch_report, df_tx, df_prices = fetch_and_store(df_clean, engine, portfolio_id, benchmark_ticker=benchmark)
                        results = compute_risk(portfolio_id, engine, benchmark_ticker=benchmark, df_tx=df_tx, df_prices=df_prices, risk_free_rate=rf_val, base_currency=base_curr)
                    else:
                        fetch_report = fetch_and_store(df_clean, engine, portfolio_id, benchmark_ticker=benchmark)
                        results = compute_risk(portfolio_id, engine, benchmark_ticker=benchmark, risk_free_rate=rf_val, base_currency=base_curr)

                    timestamp_str = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
                    run_id = f"ANL-{timestamp_str}"
                    
                    if not offline_mode:
                        save_snapshot_to_db(results, engine, portfolio_id, run_id, run_name)

                    st.session_state["pipeline_done"]  = True
                    st.session_state["portfolio_id"]   = portfolio_id
                    st.session_state["portfolio_name"] = p_name_final
                    st.session_state["engine"]         = engine
                    st.session_state["fetch_report"]   = fetch_report
                    st.session_state["results"]        = results
                    st.session_state["run_id"]         = run_id
                    from core.workspace_manager import save_session_snapshot_to_cache
                    save_session_snapshot_to_cache()
                    st.rerun()

        else:
            fr = st.session_state.get("fetch_report", {})
            res = st.session_state.get("results", {})
            m = res.get("metrics", {})
            ret = m.get("returns", {})
            mk = m.get("market_risk", {})
            var_m = m.get("var_models", {})

            # ── EXECUTIVE COCKPIT SUMMARY CARD ────────────────────────
            cagr_v = ret.get('cagr_pct', 0.0)
            cagr_color = "#3fb950" if cagr_v >= 0 else "#f85149"
            
            sharpe_v = ret.get('sharpe_ratio')
            if sharpe_v is None:
                sharpe_v = mk.get('sharpe_ratio', 0.0)
            sharpe_color = "#3fb950" if sharpe_v >= 1.0 else ("#ff9900" if sharpe_v >= 0.5 else "#f85149")
            
            vol_ann_v = mk.get('volatility_annual_pct', 0.0)
            max_dd_v = mk.get('max_drawdown_pct', 0.0)
            
            var_95_v = mk.get('var_95')
            if var_95_v is None:
                var_95_v = var_m.get('hist_var_95', 0.0)
            if var_95_v is not None and 0 < abs(var_95_v) < 0.1:
                var_95_v = var_95_v * 100
            var_95_v = var_95_v if var_95_v is not None else 0.0
            
            p_val = ret.get('portfolio_value', 0.0)
            n_tickers_ok = len(fr.get('success', [])) if fr.get('success') else len(s.get('tickers', []))

            st.markdown(f"""
            <div style="background: rgba(22, 27, 34, 0.85); backdrop-filter: blur(16px); border: 1px solid rgba(63, 185, 80, 0.35); border-left: 4px solid #3fb950; border-radius: 14px; padding: 20px; margin-bottom: 20px; box-shadow: 0 8px 24px rgba(0,0,0,0.4);">
                <div style="display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:10px; margin-bottom: 14px;">
                    <div>
                        <div style="font-size: 17px; font-weight:800; color:#ffffff; letter-spacing:0.3px;">🎉 Analisi Quantitativa Completata con Successo</div>
                        <div style="font-size: 11.5px; color:#8b949e; margin-top:2px;">Portafoglio <b>{st.session_state.get('portfolio_name')}</b> sincronizzato ed indicizzato a storico.</div>
                    </div>
                    <div style="display:flex; gap:8px;">
                        <span class="argus-command-pill" style="border-color: rgba(63, 185, 80, 0.5); color: #3fb950; font-weight:700;">RUN: {st.session_state.get('run_id', 'N/A')}</span>
                        <span class="argus-command-pill" style="border-color: rgba(88, 166, 255, 0.4); color: #58a6ff;">VALORE: € {p_val:,.2f}</span>
                    </div>
                </div>
                <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(130px, 1fr)); gap: 10px;">
                    <div style="background: rgba(255,255,255,0.03); padding: 10px; border-radius: 8px; text-align:center;">
                        <div style="font-size:10px; font-weight:600; color:#8b949e;">CAGR ANNUO</div>
                        <div style="font-size:17px; font-weight:800; color:{cagr_color};">{cagr_v:+.2f}%</div>
                    </div>
                    <div style="background: rgba(255,255,255,0.03); padding: 10px; border-radius: 8px; text-align:center;">
                        <div style="font-size:10px; font-weight:600; color:#8b949e;">SHARPE RATIO</div>
                        <div style="font-size:17px; font-weight:800; color:{sharpe_color};">{sharpe_v:.2f}</div>
                    </div>
                    <div style="background: rgba(255,255,255,0.03); padding: 10px; border-radius: 8px; text-align:center;">
                        <div style="font-size:10px; font-weight:600; color:#8b949e;">VOLATILITÀ ANNUA</div>
                        <div style="font-size:17px; font-weight:800; color:#58a6ff;">{vol_ann_v:.2f}%</div>
                    </div>
                    <div style="background: rgba(255,255,255,0.03); padding: 10px; border-radius: 8px; text-align:center;">
                        <div style="font-size:10px; font-weight:600; color:#8b949e;">MAX DRAWDOWN</div>
                        <div style="font-size:17px; font-weight:800; color:#f85149;">{max_dd_v:.2f}%</div>
                    </div>
                    <div style="background: rgba(255,255,255,0.03); padding: 10px; border-radius: 8px; text-align:center;">
                        <div style="font-size:10px; font-weight:600; color:#8b949e;">VaR 95% (1-DAY)</div>
                        <div style="font-size:17px; font-weight:800; color:#e3b341;">{var_95_v:.2f}%</div>
                    </div>
                    <div style="background: rgba(255,255,255,0.03); padding: 10px; border-radius: 8px; text-align:center;">
                        <div style="font-size:10px; font-weight:600; color:#8b949e;">TICKER ONLINE</div>
                        <div style="font-size:17px; font-weight:800; color:#3fb950;">{n_tickers_ok}</div>
                    </div>
                </div>
            </div>
            """, unsafe_allow_html=True)

            if fr.get("errors"):
                for e in fr["errors"]:
                    st.markdown(f'<div class="error-box">🔴 {html.escape(str(e))}</div>', unsafe_allow_html=True)

            # Fast Navigation Ribbon
            st.markdown("##### 🧭 Navigazione Rapida Moduli Analitici")
            nav_c1, nav_c2, nav_c3, nav_c4 = st.columns(4)
            with nav_c1:
                st.page_link("pages/1_📈_Dashboard_Generale.py", label="📈 Executive Cockpit ➔", use_container_width=True)
            with nav_c2:
                st.page_link("pages/2_🖥️_Live_Terminal.py", label="🖥️ Live Terminal OMS ➔", use_container_width=True)
            with nav_c3:
                st.page_link("pages/3_🔴_Analisi_Rischio.py", label="🔴 Analisi Rischio & VaR ➔", use_container_width=True)
            with nav_c4:
                st.page_link("pages/4_🔬_Modelli_Quantitativi.py", label="🔬 Modelli Quantitativi ➔", use_container_width=True)

            nav_r2_1, nav_r2_2, nav_r2_3, nav_r2_4 = st.columns(4)
            with nav_r2_1:
                st.page_link("pages/5_📋_Posizioni_e_Dettagli.py", label="📋 Posizioni & Fisco ➔", use_container_width=True)
            with nav_r2_2:
                st.page_link("pages/6_🏛️_Valutazione_Aziendale.py", label="🏛️ Valutazione Fair Value ➔", use_container_width=True)
            with nav_r2_3:
                st.page_link("pages/7_🌪️_Stress_Testing.py", label="🌪️ Stress Testing Macro ➔", use_container_width=True)
            with nav_r2_4:
                st.page_link("pages/10_🔍_Screener_Opportunita.py", label="🔍 Screener & Pre-Trade ➔", use_container_width=True)

            with st.expander("🔄 Opzioni di Ricalcolo / Modifica Parametri", expanded=False):
                col_re1, col_re2 = st.columns([2, 1])
                with col_re1:
                    new_bm = st.selectbox("Cambia Benchmark:", options=["SPY", "VWCE.DE", "^GSPC", "QQQ", "IEI"], index=0, key="recalc_bm")
                with col_re2:
                    st.markdown('<div style="height: 28px;"></div>', unsafe_allow_html=True)
                    if st.button("⚡ Ricalcola Analisi", type="secondary", use_container_width=True, key="btn_recalc_now"):
                        st.session_state["pipeline_done"] = False
                        st.session_state["session_cleared"] = False
                        st.rerun()


# =============================================================
# TAB 2: TOTAL WEALTH HUB & MULTI-PORTAFOGLIO
# =============================================================
with tab_wealth:
    section("🗂️ Total Wealth Hub & Gestione Multi-Portafoglio")
    st.caption("Gestisci più conti o strategie contemporaneamente (es. Crescita, Dividendi, Previdenza, Crypto), confrontali affiancati e consolidali in un unico Portafoglio Master.")

    render_info_modal(
        title="Come Funziona il Total Wealth Hub (Multi-Account)",
        content="""
<div style="font-size: 13.5px; line-height: 1.5; color: #c9d1d9;">

<div style="background: rgba(255, 153, 0, 0.08); border-left: 3px solid #ff9900; padding: 10px 14px; border-radius: 4px; margin-bottom: 12px;">
  <b style="color: #ff9900;">🎯 Visione Olistica del Patrimonio</b><br>
  Gli investitori gestiscono spesso posizioni frammentate tra broker diversi o conti a finalità distinte (Crescita Tech, Dividendi, Pensione). Il Total Wealth Hub consente di salvare e consolidare questi profili in una singola analisi unificata.
</div>

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px; margin-bottom: 8px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">1. Salvataggio Profili Multipli</div>
  <div>Permette di etichettare lo stato di analisi corrente con un nome e una strategia specifica (es. <i>Portafoglio Core</i>, <i>Satellite Crypto</i>, <i>ETF Passive</i>).</div>
</div>

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px; margin-bottom: 8px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">2. Consolidamento Master Portfolio</div>
  <div>Selezionando 2 o più portafogli salvati, ARGUS:
    <br>• Aggrega le posizioni sommando le quote e ricalcolando il prezzo medio ponderato di carico (WACP).
    <br>• Fonde le serie storiche dei rendimenti ponderate per il rispettivo controvalore patrimoniale.
    <br>• Calcola istantaneamente il nuovo VaR 95%, Sharpe Ratio, Volatilità e diversificazione globale.
  </div>
</div>

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">3. Scorecard Comparativa</div>
  <div>Confronta affiancati i portafogli per rendimento (CAGR), volatilità, Sharpe Ratio, drawdown e massima posizione di rischio.</div>
</div>

</div>
""",
        button_label="📖 Guida al Multi-Portafoglio"
    )

    # 1. Box Salvataggio Portafoglio Attivo
    has_active_res = st.session_state.get("results") is not None and isinstance(st.session_state.get("results"), dict)

    with st.expander("💾 Salva Portafoglio Attivo nel Registro Multi-Account", expanded=False):
        if not has_active_res:
            st.info("Esegui prima un'analisi per salvare il portafoglio corrente nel registro.")
        else:
            col_s_name, col_s_tag, col_s_btn = st.columns([3, 2, 2])
            with col_s_name:
                save_name_in = st.text_input("Nome Portafoglio / Conto:", value=st.session_state.get("portfolio_name", "Portafoglio_1"), key="mp_save_name")
            with col_s_tag:
                save_tag_in = st.selectbox("Tag Strategia:", ["Crescita (Growth)", "Dividendi & Rendita", "Previdenza / Pensione", "Core / Satellite", "Crypto & Speculativo", "Generale"], key="mp_save_tag")
            with col_s_btn:
                st.markdown('<div style="height: 28px;"></div>', unsafe_allow_html=True)
                if st.button("💾 Salva nel Registro", type="primary", use_container_width=True, key="btn_save_mp"):
                    if save_portfolio_profile(save_name_in.strip(), st.session_state["results"], tag=save_tag_in):
                        st.success(f"Portafoglio '{save_name_in}' salvato con successo nel registro multi-account!")
                        st.rerun()
                    else:
                        st.error("Errore durante il salvataggio del profilo.")

    # 2. Elenco Portafogli e Azioni di Consolidamento
    saved_profiles = list_saved_portfolio_profiles()
    if saved_profiles:
        st.markdown('<div style="margin-top: 15px;"></div>', unsafe_allow_html=True)
        
        # Intestazione e Barra di Controllo Unificata
        col_t_title, col_t_actions = st.columns([3, 4])
        with col_t_title:
            st.markdown(f"##### 📋 Portafogli Registrati <span style='font-size:13px; color:#8b949e; font-weight:normal;'>({len(saved_profiles)} disponibili)</span>", unsafe_allow_html=True)
        
        selected_for_merge = []
        
        with col_t_actions:
            col_btn_merge, col_btn_comp = st.columns(2)
            with col_btn_merge:
                btn_merge = st.button("🔗 Consolida in Master Wealth", type="primary", use_container_width=True, key="btn_merge_master", help="Fonde i portafogli selezionati tramite checkbox in un unico Master Wealth")
            with col_btn_comp:
                btn_comp = st.button("📊 Scorecard Comparativa", use_container_width=True, key="btn_comp_portfolios", help="Visualizza la tabella comparativa dei portafogli")
        
        st.markdown('<div style="margin-top: 6px;"></div>', unsafe_allow_html=True)

        for p in saved_profiles:
            with st.container():
                st.markdown("""
                <div style="background: rgba(22, 27, 34, 0.65); border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 10px; padding: 10px 14px; margin-bottom: 8px;">
                """, unsafe_allow_html=True)
                
                c_chk, c_meta, c_val, c_kpi, c_load, c_del = st.columns([0.35, 2.5, 2.0, 2.6, 1.3, 0.65])
                
                with c_chk:
                    st.markdown('<div style="height: 6px;"></div>', unsafe_allow_html=True)
                    chk = st.checkbox(" ", key=f"chk_mp_{p['name']}", value=False, label_visibility="collapsed")
                    if chk:
                        selected_for_merge.append(p["name"])
                
                with c_meta:
                    st.markdown(f"""
                    <div style="font-weight: 700; font-size: 14.5px; color: #f0f6fc; margin-bottom: 2px;">{p['name']}</div>
                    <div><span style="font-size: 11px; background: rgba(88,166,255,0.15); color: #58a6ff; border: 1px solid rgba(88,166,255,0.25); padding: 1px 7px; border-radius: 10px; font-weight: 600;">{p['tag']}</span></div>
                    """, unsafe_allow_html=True)
                    
                with c_val:
                    st.markdown(f"""
                    <div style="font-size: 14.5px; font-weight: 700; color: #ffb74d;">€ {p['portfolio_value']:,.2f}</div>
                    <div style="font-size: 11px; color: #8b949e;">📦 <b>{p['asset_count']}</b> posizioni aperte</div>
                    """, unsafe_allow_html=True)
                    
                with c_kpi:
                    cagr_color = "#3fb950" if p['cagr_pct'] >= 0 else "#f85149"
                    st.markdown(f"""
                    <div style="font-size: 12.5px; color: #c9d1d9;">📈 Sharpe: <b style="color: #58a6ff;">{p['sharpe_ratio']:.2f}</b> &nbsp;|&nbsp; CAGR: <b style="color: {cagr_color};">{p['cagr_pct']:+.1f}%</b></div>
                    <div style="font-size: 11px; color: #8b949e;">🛡️ VaR 95%: <b>{p['var_95_pct']:.2f}%</b> &nbsp;|&nbsp; MaxDD: <b>{p['max_dd_pct']:.1f}%</b></div>
                    """, unsafe_allow_html=True)
                    
                with c_load:
                    st.markdown('<div style="height: 2px;"></div>', unsafe_allow_html=True)
                    if st.button("📂 Carica", key=f"btn_load_{p['name']}", use_container_width=True, help=f"Imposta '{p['name']}' come portafoglio attivo"):
                        prof_data = load_portfolio_profile(p["name"])
                        if prof_data:
                            loaded_res = prof_data.get("results_full") or prof_data
                            st.session_state["results"] = loaded_res
                            st.session_state["pipeline_done"] = True
                            st.session_state["portfolio_name"] = p["name"]
                            st.session_state["run_id"] = f"LOAD-{p['name'][:10]}"
                            from core.workspace_manager import save_session_snapshot_to_cache
                            save_session_snapshot_to_cache()
                            st.success(f"Portafoglio '{p['name']}' caricato con successo!")
                            try:
                                st.switch_page("pages/1_📈_Dashboard_Generale.py")
                            except Exception:
                                st.rerun()
                                
                with c_del:
                    st.markdown('<div style="height: 2px;"></div>', unsafe_allow_html=True)
                    if st.button("🗑️", key=f"btn_del_{p['name']}", use_container_width=True, help="Elimina dal registro"):
                        from core.confirm_dialogs import confirm_delete_portfolio_profile_dialog

                        confirm_delete_portfolio_profile_dialog(p["name"])
                        
                st.markdown("</div>", unsafe_allow_html=True)

        n_sel = len(selected_for_merge)
        if n_sel > 0:
            st.markdown(f"<div style='font-size: 12px; color: #8b949e; margin-top: 4px;'>🎯 Portafogli selezionati per fusione o confronto: <b style='color: #ff9900;'>{n_sel}</b> su {len(saved_profiles)}</div>", unsafe_allow_html=True)

        if btn_merge:
            if len(selected_for_merge) < 2:
                st.warning("⚠️ Seleziona almeno **2 portafogli** tramite le caselle di spunta per creare il Master Wealth.")
            else:
                with st.spinner("Consolidamento delle posizioni e ricalcolo quantitativo del Master Portfolio..."):
                    merged_res = consolidate_multi_portfolios(selected_for_merge)
                    if merged_res:
                        st.session_state["results"] = merged_res
                        st.session_state["pipeline_done"] = True
                        st.session_state["portfolio_name"] = merged_res["portfolio_name"]
                        st.session_state["run_id"] = merged_res["run_id"]
                        from core.workspace_manager import save_session_snapshot_to_cache
                        save_session_snapshot_to_cache()
                        st.success("Master Portfolio consolidato con successo! Reindirizzamento...")
                        try:
                            st.switch_page("pages/1_📈_Dashboard_Generale.py")
                        except Exception:
                            st.rerun()
                    else:
                        st.error("Impossibile consolidare i portafogli selezionati.")

        if btn_comp or st.session_state.get("show_mp_comparison"):
            st.session_state["show_mp_comparison"] = True
            st.markdown('<div style="margin-top: 15px;"></div>', unsafe_allow_html=True)
            st.markdown("##### 📊 Scorecard Comparativa Multi-Portafoglio")
            target_comp = selected_for_merge if selected_for_merge else [p["name"] for p in saved_profiles]
            df_comp = compute_multi_portfolio_comparison(target_comp)
            if not df_comp.empty:
                st.dataframe(df_comp, use_container_width=True, hide_index=True)
    else:
        st.info("Nessun profilo salvato finora. Esegui un'analisi e usa il modulo sopra per salvare il tuo primo portafoglio!")


# =============================================================
# TAB 3: ANAGRAFICA & MAPPATURA ISIN / TICKER DB
# =============================================================
with tab_isin_mapping:
    section("🏷️ Anagrafica & Mappatura ISIN / Ticker nel Database (asset_mapping)")
    
    col_head_map1, col_head_map2 = st.columns([3.2, 1.1])
    with col_head_map1:
        st.caption("Gestisci l'anagrafica centralizzata di conversione tra codici ISIN bancari / Ticker locali e simboli Yahoo Finance. Le mappature vengono salvate sia nella tabella SQL **`asset_mapping`** che nel file di configurazione.")
    with col_head_map2:
        glossary_modal("ℹ️ Guida alla Mappatura ISIN / Ticker", """
<div style="font-size: 13.5px; line-height: 1.5; color: #c9d1d9;">

<!-- 1. TABELLA DB ASSET MAPPING -->
<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,153,0,0.25); border-radius: 10px; padding: 14px; margin-bottom: 12px;">
  <div style="color: #ff9900; font-size: 15px; font-weight: 700; margin-bottom: 6px;">📌 1. Tabella DB Centralizzata (asset_mapping)</div>
  <div style="margin-bottom: 6px;"><b>Cos'è:</b> Il dizionario anagrafico che converte i codici ISIN bancari internazionali (es. <code>IE00B4L5Y983</code>) e i ticker proprietari broker (es. <code>BIT:ISP</code>) nei simboli standard Yahoo Finance (<code>SWDA.MI</code>, <code>ISP.MI</code>).</div>
  <div style="margin-bottom: 6px;"><b>📐 Schema di Risoluzione:</b>
    <div style="background: rgba(255,153,0,0.08); border-left: 3px solid #ff9900; padding: 6px 10px; border-radius: 6px; margin: 4px 0; color: #ffb74d; text-align: center; font-size: 13px;">
      <b>ISIN / Broker Code</b> &rarr; <b>Asset Mapping SQL</b> &rarr; <b>Yahoo Finance Ticker</b>
    </div>
  </div>
  <div><b>🎯 A cosa serve:</b> Garantisce il download automatico a latenza zero delle serie storiche dei prezzi anche per file CSV esportati da banche italiane ed europee.</div>
</div>

<!-- 2. RISOLUZIONE AUTOMATICA -->
<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(56,189,248,0.25); border-radius: 10px; padding: 14px; margin-bottom: 12px;">
  <div style="color: #38bdf8; font-size: 15px; font-weight: 700; margin-bottom: 6px;">🔍 2. Risoluzione Intelligente & Ricerca Live</div>
  <div style="margin-bottom: 6px;"><b>Autocompletamento:</b> Inserendo un codice ISIN, ARGUS interroga le API di ricerca per identificare automaticamente la borsa di quotazione principale (Milano <code>.MI</code>, Francoforte <code>.DE</code>, Londra <code>.L</code>, NYSE/NASDAQ).</div>
  <div><b>Persistenza:</b> Ogni nuova mappatura inserita viene salvata istantaneamente sia nel Database SQL che nel file locale <code>config.json</code>.</div>
</div>

</div>
""", button_label="💡 Come funziona la Mappatura ISIN?")

    from core.fetcher import _get_config_file_path
    cfg_file = _get_config_file_path()
    
    # 1. Carica Mappature dal Database (tabella asset_mapping) e da config.json
    db_mapping_dict = {}
    engine_curr = st.session_state.get("engine") or engine_sidebar
    
    if engine_curr is not None:
        try:
            from core.models import Base
            Base.metadata.create_all(engine_curr)
            with engine_curr.connect() as conn:
                res_map = conn.execute(sqlt("SELECT input_ticker, yfinance_ticker, description FROM asset_mapping")).fetchall()
                for r in res_map:
                    db_mapping_dict[str(r[0]).strip().upper()] = {
                        "input_ticker": str(r[0]).strip().upper(),
                        "yfinance_ticker": str(r[1]).strip().upper(),
                        "description": str(r[2] or "DB Record")
                    }
        except Exception:
            pass
            
    # Merge con config.json
    cfg_mapping_dict = {}
    if cfg_file.exists():
        try:
            with open(cfg_file, "r", encoding="utf-8") as f:
                cfg_data = json.load(f)
                for k, v in cfg_data.get("ticker_mapping", {}).items():
                    k_clean = str(k).strip().upper()
                    cfg_mapping_dict[k_clean] = str(v).strip().upper()
                    if k_clean not in db_mapping_dict:
                        db_mapping_dict[k_clean] = {
                            "input_ticker": k_clean,
                            "yfinance_ticker": str(v).strip().upper(),
                            "description": "Config JSON"
                        }
        except Exception:
            pass

    # Metriche Anagrafica
    m_c1, m_c2, m_c3 = st.columns(3)
    with m_c1:
        metric_card("Totale ISIN / Ticker Mappati", f"{len(db_mapping_dict)}", "Anagrafica attiva", positive=True)
    with m_c2:
        db_rec_count = len([v for v in db_mapping_dict.values() if v.get('description') != 'Config JSON'])
        metric_card("Tabella DB `asset_mapping`", f"{db_rec_count} Record", "SQLite / MySQL", positive=True)
    with m_c3:
        metric_card("File config.json", f"{len(cfg_mapping_dict)} Voci", str(cfg_file.name), positive=True)

    st.markdown('<div style="margin-top: 10px;"></div>', unsafe_allow_html=True)
    
    # 2. Tool di Risoluzione Rapida & Aggiunta Singolo ISIN
    with st.expander("🔍 Risolutore Istantaneo Singolo ISIN / Ticker (Yahoo Search API)", expanded=True):
        col_res1, col_res2, col_res3 = st.columns([1.5, 1.5, 1.8])
        with col_res1:
            input_isin_code = st.text_input("Codice ISIN o Ticker Locale (Input):", placeholder="es. IE00B4L5Y983 o BIT:ISP", key="input_isin_code_m").strip().upper()
        with col_res2:
            input_asset_desc = st.text_input("Descrizione / Nome Strumento:", placeholder="es. iShares Core MSCI World", key="input_asset_desc_m").strip()
        with col_res3:
            st.markdown('<div style="height: 28px;"></div>', unsafe_allow_html=True)
            col_b1, col_b2 = st.columns(2)
            with col_b1:
                btn_resolve_isin = st.button("🔎 Risolvi Yahoo", use_container_width=True, key="btn_resolve_isin_m")
            with col_b2:
                btn_add_manual = st.button("➕ Inserisci Mappatura", type="primary", use_container_width=True, key="btn_add_manual_m")

        if btn_resolve_isin and input_isin_code:
            with st.spinner(f"Ricerca ticker Yahoo per {input_isin_code}..."):
                try:
                    from core.adapters.isin_resolver import search_yahoo_isin_details
                    sug_sym, long_name = search_yahoo_isin_details(input_isin_code, timeout=5)
                    if sug_sym:
                        st.success(f"🎯 Risolto con successo: **`{sug_sym}`** {f'({long_name})' if long_name else ''}")
                        st.session_state["suggested_yf_val"] = sug_sym
                        if not input_asset_desc and long_name:
                            st.session_state["suggested_yf_name"] = long_name
                    else:
                        st.warning(f"Nessun ticker trovato automaticamente per '{input_isin_code}'. Inseriscilo manualmente.")
                except Exception as e_srch:
                    st.error(f"Errore durante la ricerca online: {e_srch}")

        # Se cliccato Inserisci o risolto
        if btn_add_manual and input_isin_code:
            final_yf_ticker = st.session_state.get("suggested_yf_val") or input_isin_code
            desc_val = input_asset_desc or st.session_state.get("suggested_yf_name", "Manuale")
            
            # 1. Salva su DB
            if engine_curr is not None:
                try:
                    with engine_curr.begin() as conn:
                        if engine_curr.dialect.name == "sqlite":
                            conn.execute(sqlt("""
                                INSERT INTO asset_mapping (input_ticker, yfinance_ticker, description)
                                VALUES (:input_ticker, :yfinance_ticker, :description)
                                ON CONFLICT(input_ticker) DO UPDATE SET
                                    yfinance_ticker = excluded.yfinance_ticker,
                                    description = excluded.description
                            """), {"input_ticker": input_isin_code, "yfinance_ticker": final_yf_ticker, "description": desc_val})
                        else:
                            conn.execute(sqlt("""
                                INSERT INTO asset_mapping (input_ticker, yfinance_ticker, description)
                                VALUES (:input_ticker, :yfinance_ticker, :description)
                                ON DUPLICATE KEY UPDATE
                                    yfinance_ticker = VALUES(yfinance_ticker),
                                    description = VALUES(description)
                            """), {"input_ticker": input_isin_code, "yfinance_ticker": final_yf_ticker, "description": desc_val})
                except Exception as e_db:
                    st.warning(f"Nota DB: {e_db}")

            # 2. Salva su config.json
            cfg_save_data = {}
            if cfg_file.exists():
                try:
                    with open(cfg_file, "r", encoding="utf-8") as f:
                        cfg_save_data = json.load(f)
                except Exception:
                    pass
            if "ticker_mapping" not in cfg_save_data:
                cfg_save_data["ticker_mapping"] = {}
            cfg_save_data["ticker_mapping"][input_isin_code] = final_yf_ticker
            with open(cfg_file, "w", encoding="utf-8") as f:
                json.dump(cfg_save_data, f, indent=4)
                
            st.success(f"✅ Mappatura **{input_isin_code} ➔ {final_yf_ticker}** registrata nel DB e nel Config!")
            if "suggested_yf_val" in st.session_state: del st.session_state["suggested_yf_val"]
            if "suggested_yf_name" in st.session_state: del st.session_state["suggested_yf_name"]
            st.rerun()

    # 3. Tabella Anagrafica Completa (Data Editor)
    st.markdown("##### 📋 Anagrafica Mappature Attive (Tabella Database & Config)")
    df_mappings = pd.DataFrame(list(db_mapping_dict.values()))
    if not df_mappings.empty:
        df_mappings = df_mappings[["input_ticker", "yfinance_ticker", "description"]].rename(columns={
            "input_ticker": "ISIN / Ticker Input",
            "yfinance_ticker": "Ticker Yahoo Finance",
            "description": "Descrizione / Strumento"
        }).sort_values("ISIN / Ticker Input")
    else:
        df_mappings = pd.DataFrame(columns=["ISIN / Ticker Input", "Ticker Yahoo Finance", "Descrizione / Strumento"])

    edited_mappings_df = st.data_editor(
        df_mappings,
        use_container_width=True,
        num_rows="dynamic",
        hide_index=True,
        key="editor_isin_mappings"
    )

    col_save_m1, col_save_m2, col_save_m3 = st.columns([1.5, 1.5, 1.2])
    with col_save_m1:
        if st.button("💾 Salva Tutte le Modifiche nel DB & Config", type="primary", use_container_width=True, key="btn_save_all_mappings"):
            if not edited_mappings_df.empty:
                clean_json_map = {}
                db_recs = []
                for _, r in edited_mappings_df.iterrows():
                    in_t = str(r.get("ISIN / Ticker Input", "")).strip().upper()
                    yf_t = str(r.get("Ticker Yahoo Finance", "")).strip().upper()
                    d_t = str(r.get("Descrizione / Strumento", "")).strip()
                    if in_t and yf_t and in_t != "NAN":
                        clean_json_map[in_t] = yf_t
                        db_recs.append({"input_ticker": in_t, "yfinance_ticker": yf_t, "description": d_t})

                # Scrittura config.json
                cfg_obj = {}
                if cfg_file.exists():
                    try:
                        with open(cfg_file, "r", encoding="utf-8") as f: cfg_obj = json.load(f)
                    except Exception: pass
                cfg_obj["ticker_mapping"] = clean_json_map
                with open(cfg_file, "w", encoding="utf-8") as f:
                    json.dump(cfg_obj, f, indent=4)

                # Scrittura Database
                if engine_curr is not None and db_recs:
                    try:
                        with engine_curr.begin() as conn:
                            conn.execute(sqlt("DELETE FROM asset_mapping"))
                            for rec in db_recs:
                                conn.execute(sqlt("""
                                    INSERT INTO asset_mapping (input_ticker, yfinance_ticker, description)
                                    VALUES (:input_ticker, :yfinance_ticker, :description)
                                """), rec)
                    except Exception as e_dbs:
                        st.warning(f"Nota aggiornamento DB: {e_dbs}")

                st.success("✅ Tutte le modifiche sono state allineate su Database (`asset_mapping`) e `config.json`!")
                st.rerun()

    with col_save_m2:
        if st.button("🔄 Sincronizza config.json ➔ Tabella DB", use_container_width=True, key="btn_sync_cfg_to_db"):
            if cfg_file.exists() and engine_curr is not None:
                try:
                    with open(cfg_file, "r", encoding="utf-8") as f: cfg_d = json.load(f)
                    tk_map = cfg_d.get("ticker_mapping", {})
                    with engine_curr.begin() as conn:
                        for k, v in tk_map.items():
                            k_c = str(k).strip().upper()
                            v_c = str(v).strip().upper()
                            if k_c and v_c and k_c != "NAN":
                                if engine_curr.dialect.name == "sqlite":
                                    conn.execute(sqlt("""
                                        INSERT INTO asset_mapping (input_ticker, yfinance_ticker, description)
                                        VALUES (:input_ticker, :yfinance_ticker, :description)
                                        ON CONFLICT(input_ticker) DO UPDATE SET yfinance_ticker = excluded.yfinance_ticker
                                    """), {"input_ticker": k_c, "yfinance_ticker": v_c, "description": "Sincronizzato da config.json"})
                                else:
                                    conn.execute(sqlt("""
                                        INSERT INTO asset_mapping (input_ticker, yfinance_ticker, description)
                                        VALUES (:input_ticker, :yfinance_ticker, :description)
                                        ON DUPLICATE KEY UPDATE yfinance_ticker = VALUES(yfinance_ticker)
                                    """), {"input_ticker": k_c, "yfinance_ticker": v_c, "description": "Sincronizzato da config.json"})
                    st.success(f"✅ Sincronizzate con successo {len(tk_map)} mappature nella tabella DB `asset_mapping`!")
                    st.rerun()
                except Exception as e_syn:
                    st.error(f"Errore sincronizzazione: {e_syn}")

    with col_save_m3:
        render_export_toolbar(
            edited_mappings_df,
            file_prefix="asset_mapping_argus",
            key_suffix="ctrl_room_mapping",
            table_title="Mappature Ticker"
        )


# =============================================================
# TAB 4: TELEMETRIA DI SISTEMA & STORAGE PROFILER
# =============================================================
with tab_diagnostics:
    section("🩺 Diagnostica di Sistema, Memoria DB & Multi-Tier Cache Shield")
    
    col_head_diag1, col_head_diag2 = st.columns([3.2, 1.1])
    with col_head_diag1:
        st.caption("Profilazione avanzata dello storage su disco, memoria RAM di processo, integrità database e benchmark latenza dei 26 motori quantitativi.")
    with col_head_diag2:
        glossary_modal("ℹ️ Guida alla Diagnostica & Storage Profiler", """
<div style="font-size: 13.5px; line-height: 1.5; color: #c9d1d9;">

<!-- 1. STORAGE & MEMORIA -->
<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,153,0,0.25); border-radius: 10px; padding: 14px; margin-bottom: 12px;">
  <div style="color: #ff9900; font-size: 15px; font-weight: 700; margin-bottom: 6px;">🩺 1. Profiler di Memoria, DB & Multi-Tier Cache Shield</div>
  <div style="margin-bottom: 6px;"><b>Cos'è:</b> Il centro di diagnostica che monitora l'occupazione fisica del database SQL, la memoria RAM (RSS), la frammentazione su disco e la cache multi-tier anti-rate limit.</div>
  <div><b>🎯 Obiettivo:</b> Garantire prestazioni sub-millisecondo per tutti i 26 motori quantitativi senza memory leak.</div>
</div>

<!-- 2. AZIONI 1-CLICK -->
<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(56,189,248,0.25); border-radius: 10px; padding: 14px; margin-bottom: 12px;">
  <div style="color: #38bdf8; font-size: 15px; font-weight: 700; margin-bottom: 6px;">📐 2. Azioni di Manutenzione 1-Click</div>
  <div style="background: rgba(56,189,248,0.08); border-left: 3px solid #38bdf8; padding: 6px 10px; border-radius: 6px; margin: 5px 0; color: #7dd3fc; font-size: 12.5px; line-height: 1.45;">
    • <b>VACUUM & Compatta DB:</b> Rilascia lo spazio su disco dei record cancellati.<br>
    • <b>Pulisci Cache Scaduta:</b> Rimuove i prezzi storici più vecchi del TTL di 24h.<br>
    • <b>Reindicizza DB:</b> Rigenera gli indici B-Tree per query istantanee.
  </div>
  <div><b>🔍 Come leggerlo:</b> Stato <i>🟢 Integro (100% Operativo)</i> e frammentazione &lt; 5% indicano un ambiente ad efficienza massima.</div>
</div>

</div>
""", button_label="💡 Come funziona la Diagnostica?")

    diag_res = run_system_health_check(st.session_state.get("results"))
    cache_st = diag_res["cache_metrics"]
    storage_st = diag_res["storage_profile"]

    # KPI Cards Superiori
    col_d1, col_d2, col_d3, col_d4 = st.columns(4)
    with col_d1:
        metric_card(
            "Stato Piattaforma",
            diag_res["overall_status"],
            f"{diag_res['health_score']:.0f}% Efficienza",
            positive=True
        )
    with col_d2:
        metric_card(
            "Storage Totale Disco",
            f"{storage_st['total_storage_mb']:.2f} MB",
            f"{storage_st['reclaimable_kb']} KB compattabili",
            positive=(storage_st['reclaimable_kb'] == 0)
        )
    with col_d3:
        metric_card(
            "Memoria RAM Processo",
            f"{storage_st['process_ram_mb']:.1f} MB",
            f"Oggetti Sessione: {storage_st['session_objects_ram_kb']:.1f} KB",
            positive=True
        )
    with col_d4:
        metric_card(
            "Multi-Tier Cache Shield",
            f"{cache_st['l2_disk_entries']} Voci SQLite",
            f"{cache_st['payload_size_kb']} KB salvati (TTL 24h)",
            positive=True
        )

    st.markdown('<div style="margin-top: 10px;"></div>', unsafe_allow_html=True)

    # Tabs Tematiche per Diagnostica
    tab_diag_db, tab_diag_cache, tab_diag_lat, tab_diag_logs, tab_diag_bundle = st.tabs([
        "🗄️ Storage & Memoria DB (Footprint)",
        "🛡️ Multi-Tier Cache Shield (Yahoo Finance)",
        "⚡ Benchmark Latenza Motori Quantitativi",
        "📜 Log di Sistema & Audit Contabile",
        "📦 Export Support Bundle & Diagnostica"
    ])

    with tab_diag_db:
        col_chart, col_maint = st.columns([1.6, 1.4])
        
        with col_chart:
            st.markdown("##### 📊 Ripartizione Storage per Tabella / File")
            df_tb = storage_st["table_breakdown"]
            if not df_tb.empty and "Spazio Reale (Bytes)" in df_tb.columns:
                import plotly.express as px
                fig_donut = px.pie(
                    df_tb,
                    names="Tabella / Risorsa",
                    values="Spazio Reale (Bytes)",
                    hole=0.45,
                    color_discrete_sequence=["#ff9900", "#58a6ff", "#3fb950", "#d29922", "#a371f7", "#f85149"]
                )
                fig_donut.update_traces(
                    textposition="inside",
                    textinfo="percent+label",
                    hoverinfo="label+value+percent",
                    marker=dict(line=dict(color="#161b22", width=2))
                )
                fig_donut.update_layout(
                    showlegend=False,
                    margin=dict(l=10, r=10, t=10, b=10),
                    height=240,
                    paper_bgcolor="rgba(0,0,0,0)",
                    plot_bgcolor="rgba(0,0,0,0)",
                    font=dict(color="#c9d1d9", size=11)
                )
                st.plotly_chart(fig_donut, use_container_width=True)
            else:
                st.info("Nessuna tabella presente nei database locali.")

        with col_maint:
            st.markdown("##### 🛠️ Strumenti di Manutenzione 1-Click")
            st.markdown('<div style="background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.08); border-radius:10px; padding:12px; margin-bottom:10px;">', unsafe_allow_html=True)
            
            c_btn_vac, c_btn_clean = st.columns(2)
            with c_btn_vac:
                if st.button("🧹 VACUUM & Compatta DB", use_container_width=True, help="Esegue VACUUM su tutti i file SQLite recuperando lo spazio dei record cancellati", key="diag_btn_vacuum"):
                    opt_res = optimize_database_storage()
                    st.success(f"Compattazione completata! Recuperati: {opt_res['reclaimed_kb']} KB.")
                    st.rerun()
                    
            with c_btn_clean:
                if st.button("⚡ Pulisci Cache Scaduta", use_container_width=True, help="Elimina solo i record di prezzo e info più vecchi di 24 ore", key="diag_btn_clean_cache"):
                    del_cnt = clean_expired_cache_records()
                    st.success(f"Pulizia cache completata! Eliminati {del_cnt} record scaduti.")
                    st.rerun()
                    
            if st.button("🔄 Rigenera Indici B-Tree (Reindex)", use_container_width=True, help="Rigenera gli indici su ticker e data per accelerare le query storiche", key="diag_btn_reindex"):
                if reindex_databases():
                    st.success("Reindicizzazione completata con successo!")
                    st.rerun()
                else:
                    st.error("Errore durante la reindicizzazione.")
                    
            st.markdown(f"""
            <div style="font-size:11.5px; color:#8b949e; margin-top:8px;">
            • <b>Integrità Totale:</b> <span style="color:#3fb950;">{storage_st['integrity_summary']}</span><br>
            • <b>Profili Multi-Portafoglio:</b> {storage_st['multi_portfolios_count']} file ({storage_st['multi_portfolios_kb']} KB)
            </div>
            """, unsafe_allow_html=True)

            # ── V10.0.0: ARGUS DATA VAULT AT-REST SECURITY & ENCRYPTED SNAPSHOT ──
            import hashlib
            from pathlib import Path

            from core.security_engine import ArgusDataVault

            st.markdown("""
            <div style="margin-top: 12px; padding: 10px 12px; background: rgba(56, 189, 248, 0.06); border: 1px solid rgba(56, 189, 248, 0.2); border-radius: 6px;">
                <b style="color: #38bdf8; font-size: 12.5px;">🔐 ArgusDataVault — Sicurezza At-Rest & Cifratura</b><br>
                <span style="font-size: 11px; color: #94a3b8;">Protezione crittografica AES-128 Fernet per database locali e snapshot.</span>
            </div>
            """, unsafe_allow_html=True)

            c_vault1, c_vault2 = st.columns(2)
            with c_vault1:
                if st.button("🔒 Snapshot Cifrato AES-128", use_container_width=True, key="btn_create_vault_snapshot", help="Genera uno snapshot cifrato di argus_local.db e argus_wealth.db"):
                    vault = ArgusDataVault()
                    snap_dir = Path("data/vault_backups")
                    snap_dir.mkdir(parents=True, exist_ok=True)
                    backed_up = []
                    for db_name in ["argus_local.db", "argus_wealth.db"]:
                        p = Path("data") / db_name
                        if p.exists():
                            enc_dst = snap_dir / f"{db_name}.enc"
                            vault.encrypt_file(p, enc_dst)
                            backed_up.append(db_name)
                    if backed_up:
                        st.success(f"Snapshot cifrati con successo: {', '.join(backed_up)} in `data/vault_backups/`")
                    else:
                        st.info("Nessun database locale trovato da cifrare.")
            with c_vault2:
                if st.button("🔍 Calcola Hash SHA-256 DB", use_container_width=True, key="btn_calc_db_hash", help="Verifica l'integrità dei file di database"):
                    hashes = {}
                    for db_name in ["argus_local.db", "argus_wealth.db"]:
                        p = Path("data") / db_name
                        if p.exists():
                            h = hashlib.sha256(p.read_bytes()).hexdigest()
                            hashes[db_name] = h[:16] + "…"
                    if hashes:
                        st.info(" | ".join([f"**{k}**: `{v}`" for k, v in hashes.items()]))
                    else:
                        st.info("Database non inizializzati su disco.")

            st.markdown('</div>', unsafe_allow_html=True)

        st.markdown("##### 📋 Dettaglio Volumi e Tabelle nel Database")
        if not df_tb.empty:
            st.dataframe(
                df_tb[["Contenitore", "Tabella / Risorsa", "N° Record", "Dimensione Stimata", "Stato Integrità", "Categoria"]],
                use_container_width=True,
                hide_index=True
            )

    with tab_diag_cache:
        col_c_left, col_c_right = st.columns([1.5, 1.5])
        with col_c_left:
            st.markdown("##### 🛡️ Parametri Operativi Cache Multi-Tier")
            st.markdown(f"""
            * **Stato Scudo Anti-429**: `{cache_st['status']}`
            * **Architettura Caching**: `{cache_st['shield_version']}`
            * **Oggetti in RAM L1 (Fast Cache)**: `{cache_st['l1_memory_items']}`
            * **Record su Disco SQLite (Tier 2)**: `{cache_st['l2_disk_entries']}`
            * **Ticker Distinti in Cache**: `{cache_st['distinct_tickers']}`
            * **Spazio Occupato da Payload JSON**: `{cache_st['payload_size_kb']} KB`
            """)
        with col_c_right:
            st.markdown("##### 🧹 Azioni Rapide Cache")
            st.warning("Lo svuotamento totale della cache richiederà di riscaricare i dati di mercato da Yahoo Finance alla prossima esecuzione.")
            if st.button("🗑️ Svuota Interamente Cache L1 & L2", type="secondary", use_container_width=True, key="diag_btn_flush_all_cache"):
                from core.confirm_dialogs import confirm_flush_cache_dialog

                confirm_flush_cache_dialog()

    with tab_diag_lat:
        st.markdown("##### ⚡ Latenza Algoritmi Quantitativi (Millisecondi)")
        st.dataframe(diag_res["engine_benchmarks"], use_container_width=True, hide_index=True)
        
        st.markdown("##### 🖥️ Specifiche Ambiente di Esecuzione")
        env_dict = diag_res["environment"]
        st.markdown(f"""
        * **Python Version**: `{env_dict['python_version']}`
        * **Piattaforma OS**: `{env_dict['os_platform']}`
        * **NumPy Version**: `{env_dict['numpy_version']}`
        * **Pandas Version**: `{env_dict['pandas_version']}`
        * **Determinismo Seed Stocastico**: `{'🟢 Confermato (Numpy 100% Deterministico)' if diag_res['seed_deterministic'] else '🔴 Non Deterministico'}`
        """)

    with tab_diag_logs:
        st.markdown("##### 📜 Registro Eventi Strutturato & Audit Trail Contabile")
        col_l_chan, col_l_level, col_l_limit, col_l_ref = st.columns([1.5, 1.2, 1.0, 0.8], vertical_alignment="bottom")
        with col_l_chan:
            sel_channel = st.selectbox(
                "Canale Registro",
                options=["system", "audit"],
                format_func=lambda x: "💻 Sistema & Ops (argus_system.jsonl)" if x == "system" else "🏛️ Audit Contabile (argus_audit.jsonl)",
                key="diag_sel_channel"
            )
        with col_l_level:
            sel_level = st.selectbox(
                "Livello Minimo",
                options=["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"],
                index=1,
                key="diag_sel_level"
            )
        with col_l_limit:
            sel_limit = st.selectbox(
                "Righe Max",
                options=[25, 50, 100, 250],
                index=1,
                key="diag_sel_limit"
            )
        with col_l_ref:
            if st.button("🔄 Ricarica", key="diag_btn_reload_logs", use_container_width=True):
                st.rerun()

        st.caption("🔒 **Filtro di Redazione Attivo**: IBAN, Codici Fiscali, numeri di carte, controvalori e credenziali vengono automaticamente oscurati a monte.")

        recent_logs = get_recent_logs(channel=sel_channel, limit=sel_limit, min_level=sel_level)
        if not recent_logs:
            st.info(f"Nessun evento registrato per il canale `{sel_channel}` con livello `>= {sel_level}`.")
        else:
            rows_display = []
            for r in recent_logs:
                lvl = r.get("level", "INFO")
                icon = "🟢" if lvl == "INFO" else ("🟡" if lvl == "WARNING" else ("🔴" if lvl in ("ERROR", "CRITICAL") else "⚪"))
                rows_display.append({
                    "Stato": f"{icon} {lvl}",
                    "Timestamp (UTC)": r.get("timestamp", "").replace("T", " ")[:19],
                    "Modulo": r.get("module", "N/A"),
                    "Funzione": r.get("function", "N/A"),
                    "Messaggio Sanificato": r.get("message", ""),
                    "Latenza (ms)": f"{r['execution_time_ms']:.1f}" if "execution_time_ms" in r else "-"
                })
            df_logs = pd.DataFrame(rows_display)
            st.dataframe(df_logs, use_container_width=True, hide_index=True)

            with st.expander("🔍 Ispezione JSON Strutturato Grezzo (Ultimi Eventi)"):
                st.json(recent_logs[:10])

    with tab_diag_bundle:
        st.markdown("##### 📦 Self-Service Diagnostics & Esportazione Support Bundle")
        st.markdown("""
        Genera un archivio compresso **ZIP completo e sanificato** contenente metriche hardware, benchmark motori,
        stato dei database embedded e gli ultimi log. Il pacchetto è pronto per essere allegato a ticket di supporto o issue GitHub.
        """)

        specs = get_hardware_and_environment_specs()
        
        c_b1, c_b2, c_b3 = st.columns(3)
        with c_b1:
            st.markdown(f"""
            **🖥️ Piattaforma & CPU**
            * OS: `{specs.get('os_system')} {specs.get('os_release')}`
            * Architettura: `{specs.get('machine')}`
            * Core Fisici / Logici: `{specs.get('cpu', {}).get('physical_cores')}` / `{specs.get('cpu', {}).get('logical_cores')}`
            """)
        with c_b2:
            st.markdown(f"""
            **🧠 Memoria & Storage**
            * RAM Totale: `{specs.get('memory', {}).get('total_gb')} GB`
            * RAM Disponibile: `{specs.get('memory', {}).get('available_gb')} GB`
            * Disco Libero: `{specs.get('disk', {}).get('free_gb')} GB`
            """)
        with c_b3:
            st.markdown(f"""
            **🐍 Runtime & Versioni**
            * Python: `{specs.get('python_version')}`
            * SQLite: `{specs.get('packages', {}).get('sqlite3')}`
            * DuckDB: `{specs.get('packages', {}).get('duckdb')}`
            * Streamlit: `{specs.get('packages', {}).get('streamlit')}`
            """)

        st.markdown("""
        <div style="background: rgba(46, 160, 67, 0.08); border: 1px solid rgba(46, 160, 67, 0.3); border-radius: 8px; padding: 12px; margin: 12px 0;">
            <span style="color: #3fb950; font-weight: 700;">🔒 Garanzia di Riservatezza & Conformità GDPR Art. 32 / PCI-DSS:</span><br>
            <span style="color: #c9d1d9; font-size: 12.5px;">
            Il generatore del Support Bundle esegue una doppia sanitizzazione. Nessun dato personale (Codice Fiscale, email, telefoni),
            coordinata bancaria (IBAN), numero di carta di credito, password o controvalore monetario patrimoniale viene esportato.
            </span>
        </div>
        """, unsafe_allow_html=True)

        include_logs_opt = st.checkbox("Includi gli ultimi 500 eventi di log sanificati (Sistema & Audit)", value=True, key="chk_include_logs_bundle")
        
        c_gen_b, c_dl_b = st.columns([1.5, 2.0])
        with c_gen_b:
            if st.button("⚡ Genera Support Bundle ZIP", type="primary", use_container_width=True, key="btn_gen_bundle_trigger"):
                with st.spinner("Creazione archivio diagnostico in corso..."):
                    st.session_state["_cached_support_bundle"] = generate_support_bundle(include_logs=include_logs_opt, max_log_lines=500)
                st.success("Support Bundle generato con successo!")

        with c_dl_b:
            bundle_bytes = st.session_state.get("_cached_support_bundle")
            if bundle_bytes:
                now_bundle_str = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
                bundle_name = f"argus_support_bundle_{now_bundle_str}.zip"
                st.download_button(
                    label=f"📥 Scarica Support Bundle ({len(bundle_bytes) / 1024.0:.1f} KB)",
                    data=bundle_bytes,
                    file_name=bundle_name,
                    mime="application/zip",
                    use_container_width=True,
                    type="primary",
                    key="btn_download_support_bundle"
                )
            else:
                st.caption("ℹ️ Clicca su **⚡ Genera Support Bundle ZIP** per compilare il pacchetto diagnostico.")

# =============================================================
# TAB 5: MOTORE ANALITICO EMBEDDED DUCKDB (OLAP & SQL SANDBOX)
# =============================================================
with tab_duckdb:
    col_d_title, col_d_modal = st.columns([3.5, 1.2])
    with col_d_title:
        st.markdown("### ⚡ Motore Analitico In-Process DuckDB & Accelerazione Parquet")
        st.caption("Interrogazione SQL analitica (OLAP) in-memory a latenza sub-millisecondo, aggregazioni multi-dimensionali ed esportazione colonnare Apache Parquet.")
    with col_d_modal:
        st.markdown('<div style="margin-top: 8px;"></div>', unsafe_allow_html=True)
        render_duckdb_modal(button_label="ℹ️ Guida al Motore DuckDB & Parquet", use_popover=False)

    duck_info = duckdb_engine.get_duckdb_system_info()

    # Prepara DataFrames di contesto
    pos_df = st.session_state.get("positions_df")
    tx_df = st.session_state.get("transactions_df")

    # Fallback se non ancora caricato
    if pos_df is None or pos_df.empty:
        pos_df = pd.DataFrame([
            {"ticker": "AAPL", "asset_name": "Apple Inc.", "asset_class": "Stock", "sector": "Technology", "currency": "USD", "current_value": 2200.0, "weight_pct": 20.0, "pnl_pct": 14.5},
            {"ticker": "MSFT", "asset_name": "Microsoft Corp.", "asset_class": "Stock", "sector": "Technology", "currency": "USD", "current_value": 4400.0, "weight_pct": 40.0, "pnl_pct": 22.1},
            {"ticker": "NVDA", "asset_name": "NVIDIA Corp.", "asset_class": "Stock", "sector": "Technology", "currency": "USD", "current_value": 1250.0, "weight_pct": 11.4, "pnl_pct": 68.3},
            {"ticker": "RACE.MI", "asset_name": "Ferrari N.V.", "asset_class": "Stock", "sector": "Consumer Cyclical", "currency": "EUR", "current_value": 2100.0, "weight_pct": 19.1, "pnl_pct": 8.4},
            {"ticker": "BTC-USD", "asset_name": "Bitcoin USD", "asset_class": "Crypto", "sector": "Digital Assets", "currency": "USD", "current_value": 1050.0, "weight_pct": 9.5, "pnl_pct": -4.2}
        ])

    if tx_df is None or tx_df.empty:
        tx_df = pd.DataFrame([
            {"tx_date": "2023-01-15", "ticker": "AAPL", "tx_type": "BUY", "quantity": 10, "price": 135.0, "currency": "USD", "fees": 1.5},
            {"tx_date": "2023-04-20", "ticker": "MSFT", "tx_type": "BUY", "quantity": 10, "price": 280.0, "currency": "USD", "fees": 1.5},
            {"tx_date": "2023-09-10", "ticker": "NVDA", "tx_type": "BUY", "quantity": 10, "price": 420.0, "currency": "USD", "fees": 2.0},
            {"tx_date": "2024-02-01", "ticker": "RACE.MI", "tx_type": "BUY", "quantity": 5, "price": 320.0, "currency": "EUR", "fees": 2.5},
            {"tx_date": "2024-06-15", "ticker": "BTC-USD", "tx_type": "BUY", "quantity": 0.02, "price": 62000.0, "currency": "USD", "fees": 3.0}
        ])

    context_tables = {
        "positions": pos_df,
        "transactions": tx_df
    }

    pq_stats = duckdb_engine.get_parquet_compression_ratio(pos_df)

    col_k1, col_k2, col_k3, col_k4 = st.columns(4)
    with col_k1:
        metric_card("Stato Motore DuckDB", f"v{duck_info['version']}", duck_info["engine_mode"], True)
    with col_k2:
        metric_card("SIMD Vectorization", duck_info["vectorization"], f"{duck_info['threads']} Core Paralleli", True)
    with col_k3:
        metric_card("Compressione Parquet", f"{pq_stats['space_saved_pct']:.1f}%", f"{pq_stats['parquet_bytes']} B vs {pq_stats['csv_bytes']} B CSV", True)
    with col_k4:
        metric_card("Tabelle In-Memory", f"{len(context_tables)} Registrate", "positions, transactions", True)

    st.markdown("---")

    st.markdown("#### ⚡ 1. Preset di Analisi OLAP Istituzionale (1-Click SQL):")
    st.caption("Seleziona una delle pipeline analitiche preconfigurate per eseguire all'istante aggregazioni complesse.")

    presets = duckdb_engine.get_preset_olap_queries()
    preset_cols = st.columns(4)

    if "current_duck_sql" not in st.session_state:
        st.session_state["current_duck_sql"] = presets["cube_exposure"]["sql"]

    with preset_cols[0]:
        if st.button("📦 Cubo Multi-Dimensionale", use_container_width=True, help=presets["cube_exposure"]["description"]):
            st.session_state["current_duck_sql"] = presets["cube_exposure"]["sql"]
    with preset_cols[1]:
        if st.button("🏆 Ranking & QUALIFY", use_container_width=True, help=presets["sector_ranking"]["description"]):
            st.session_state["current_duck_sql"] = presets["sector_ranking"]["sql"]
    with preset_cols[2]:
        if st.button("💰 Storico Volumi & Mese", use_container_width=True, help=presets["monthly_tx_rollup"]["description"]):
            st.session_state["current_duck_sql"] = presets["monthly_tx_rollup"]["sql"]
    with preset_cols[3]:
        if st.button("📊 Matrice Rischio FX", use_container_width=True, help=presets["fx_exposure_matrix"]["description"]):
            st.session_state["current_duck_sql"] = presets["fx_exposure_matrix"]["sql"]

    st.markdown("#### 💻 2. Console SQL Interattiva (Interactive SQL Sandbox):")
    st.caption("Scrivi ed esegui qualsiasi query SQL sulle tabelle in-memory `positions` e `transactions`.")

    custom_sql = st.text_area(
        "Editor Query SQL (DuckDB Engine):",
        value=st.session_state["current_duck_sql"],
        height=140,
        key="duckdb_sql_editor_area"
    )

    col_btn_run, col_btn_pq = st.columns([2.5, 1.5])
    with col_btn_run:
        btn_run_sql = st.button("⚡ Esegui Query SQL (DuckDB Engine)", type="primary", use_container_width=True)
    with col_btn_pq:
        pq_bytes = duckdb_engine.export_portfolio_to_parquet(pos_df)
        st.download_button(
            label="📦 Scarica Portafoglio in Apache Parquet (.parquet)",
            data=pq_bytes,
            file_name="argus_portfolio_master.parquet",
            mime="application/octet-stream",
            use_container_width=True
        )

    if btn_run_sql or "last_duck_res" not in st.session_state:
        res = duckdb_engine.run_duckdb_olap_query(custom_sql, context_dfs=context_tables)
        st.session_state["last_duck_res"] = res

    last_res = st.session_state.get("last_duck_res")
    if last_res:
        if last_res["success"]:
            st.success(f"⚡ Query eseguita con successo in **{last_res['latency_ms']:.3f} ms** | Restituite **{last_res['row_count']} righe**.")
            render_table_with_export(
                last_res["df"],
                table_title="Risultati Query DuckDB OLAP",
                file_prefix="duckdb_query_result",
                key_suffix="ctrl_room_duckdb_res"
            )
        else:
            st.error(f"❌ Errore durante l'esecuzione della query SQL: {last_res['error']}")


# =============================================================
# TAB 6: BITEMPORAL TIME-TRAVEL & AUDIT LEDGER
# =============================================================
with tab_bitemporal:
    st.markdown("### 🕰️ Motore di Persistenza Bitemporale & Audit Trail Crittografico")
    st.caption("Standard ISO/IEC 9075:2011 SQL Temporal, MiFID II / AIFMD Compliance & Certificazione Merkle Tree per Family Office e SGR.")

    import importlib

    import core.bitemporal_engine
    importlib.reload(core.bitemporal_engine)
    from core.bitemporal_engine import BitemporalLedgerEngine

    CURRENT_BITEMP_ENGINE_VERSION = "2026.09.11_v3_peak_deficit_stable"
    if (
        "bitemp_engine" not in st.session_state
        or st.session_state.get("bitemp_engine_version") != CURRENT_BITEMP_ENGINE_VERSION
        or not hasattr(st.session_state["bitemp_engine"], "get_available_portfolios")
        or not hasattr(st.session_state["bitemp_engine"], "ingest_portfolio_dataframe")
    ):
        st.session_state["bitemp_engine"] = BitemporalLedgerEngine()
        st.session_state["bitemp_seed_info"] = st.session_state["bitemp_engine"].seed_demonstration_scenario()
        st.session_state["bitemp_ingested_portfolios"] = set()
        st.session_state["bitemp_engine_version"] = CURRENT_BITEMP_ENGINE_VERSION

    b_engine: BitemporalLedgerEngine = st.session_state["bitemp_engine"]

    # ── HELPER RECUPERO E SCOPERTA MULTI-PORTAFOGLIO UTENTE ──
    def _get_all_available_user_portfolios() -> dict[str, pd.DataFrame]:
        """
        Rileva e cataloga tutti i portafogli e serie di transazioni accessibili nell'ambiente ARGUS:
        1. st.session_state["df_clean"] (upload CSV o file manuale)
        2. st.session_state["results"]["df_tx"] (output sincrono pipeline / Google Sheets)
        3. st.session_state["df_tx"] (assegnazioni dirette di sessione)
        4. WorkspaceContext attivo
        5. Directory multi-portafogli su disco: data/multi_portfolios/*.pkl (inclusi tutti i sync Google Sheets salvati)
        6. Tabelle database SQL ('portfolios' & 'transactions')
        7. Scenario didattico / archetipo iniettato in sessione
        """
        ports: dict[str, pd.DataFrame] = {}

        # 1. Session State df_clean
        if "df_clean" in st.session_state and isinstance(st.session_state["df_clean"], pd.DataFrame) and not st.session_state["df_clean"].empty:
            pname = st.session_state.get("portfolio_name") or "Portafoglio Attivo (CSV)"
            ports[pname] = st.session_state["df_clean"]

        # 2. Session State results["df_tx"] o results["df_tx_raw"]
        if "results" in st.session_state and isinstance(st.session_state["results"], dict):
            res = st.session_state["results"]
            df_tx_res = res.get("df_tx") if isinstance(res.get("df_tx"), pd.DataFrame) else (res.get("df_tx_raw") if isinstance(res.get("df_tx_raw"), pd.DataFrame) else None)
            if df_tx_res is not None and not df_tx_res.empty:
                pname = st.session_state.get("portfolio_name") or res.get("portfolio_name") or "Portafoglio Google Sheets"
                ports[pname] = df_tx_res

        # 3. Session State df_tx
        if "df_tx" in st.session_state and isinstance(st.session_state["df_tx"], pd.DataFrame) and not st.session_state["df_tx"].empty:
            pname = st.session_state.get("portfolio_name") or "Portafoglio Transazioni"
            if pname not in ports:
                ports[pname] = st.session_state["df_tx"]

        # 4. WorkspaceContext
        try:
            from core.workspace_context import WorkspaceContext
            ws = WorkspaceContext.get_current()
            if ws and ws.risk and ws.risk.results and isinstance(ws.risk.results, dict):
                df_tx_ws = ws.risk.results.get("df_tx") if isinstance(ws.risk.results.get("df_tx"), pd.DataFrame) else (ws.risk.results.get("df_tx_raw") if isinstance(ws.risk.results.get("df_tx_raw"), pd.DataFrame) else None)
                if df_tx_ws is not None and not df_tx_ws.empty:
                    pname = ws.portfolio_name or st.session_state.get("portfolio_name") or "Portafoglio Workspace"
                    if pname not in ports:
                        ports[pname] = df_tx_ws
        except Exception:
            pass

        # 5. Profili persistiti in data/multi_portfolios/*.pkl (solo per il Titolare / Owner)
        role_active = str(st.session_state.get("argus_auth_role", "owner") or "owner").strip().lower()
        uname_active = str(st.session_state.get("argus_auth_user", "user") or "user").strip().lower()
        if role_active == "owner":
            try:
                import os
                import pickle

                from core.multi_portfolio import PORTFOLIOS_DIR
                if os.path.exists(PORTFOLIOS_DIR):
                    for fn in sorted(os.listdir(PORTFOLIOS_DIR)):
                        if fn.endswith(".pkl"):
                            fp = os.path.join(PORTFOLIOS_DIR, fn)
                            try:
                                with open(fp, "rb") as f:
                                    pdata = pickle.load(f)
                                rf = pdata.get("results_full", {}) if isinstance(pdata.get("results_full"), dict) else {}
                                df_tx_f = rf.get("df_tx") if isinstance(rf.get("df_tx"), pd.DataFrame) else (rf.get("df_tx_raw") if isinstance(rf.get("df_tx_raw"), pd.DataFrame) else None)
                                if df_tx_f is not None and not df_tx_f.empty:
                                    p_label = pdata.get("name") or fn.replace(".pkl", "")
                                    if p_label not in ports:
                                        ports[p_label] = df_tx_f
                            except Exception:
                                continue
            except Exception:
                pass

        # 6. Database SQL (isolato per utente)
        eng = st.session_state.get("engine")
        if eng:
            try:
                from sqlalchemy import text as sqlt
                with eng.connect() as conn:
                    if role_active == "user":
                        sql_p = (
                            "SELECT DISTINCT p.portfolio_id, p.name "
                            "FROM portfolios p JOIN transactions t ON p.portfolio_id = t.portfolio_id "
                            "WHERE LOWER(COALESCE(p.owner, '')) = :uowner"
                        )
                        df_plist = pd.read_sql(sqlt(sql_p), conn, params={"uowner": uname_active})
                    else:
                        sql_p = "SELECT DISTINCT p.portfolio_id, p.name FROM portfolios p JOIN transactions t ON p.portfolio_id = t.portfolio_id"
                        df_plist = pd.read_sql(sqlt(sql_p), conn)
                    for _, prow in df_plist.iterrows():
                        db_pid = prow["portfolio_id"]
                        db_pname = prow["name"] or f"Portafoglio #{db_pid}"
                        if db_pname not in ports:
                            sql_tx = """
                                SELECT t.tx_date, a.ticker, t.tx_type, t.quantity, t.price, t.currency, t.fees, t.notes
                                FROM transactions t
                                JOIN assets a ON t.asset_id = a.asset_id
                                WHERE t.portfolio_id = :pid
                                ORDER BY t.tx_date ASC
                            """
                            df_db = pd.read_sql(sqlt(sql_tx), conn, params={"pid": db_pid})
                            if not df_db.empty:
                                ports[db_pname] = df_db
            except Exception:
                pass

        # 7. Scenario didattico iniettato
        if "df_raw_injected" in st.session_state and isinstance(st.session_state["df_raw_injected"], pd.DataFrame) and not st.session_state["df_raw_injected"].empty:
            pname = st.session_state.get("active_archetype_name") or "Scenario Archetipo"
            if pname not in ports:
                try:
                    from core.validator import validate_csv
                    df_c, _ = validate_csv(st.session_state["df_raw_injected"])
                    if df_c is not None and not df_c.empty:
                        ports[pname] = df_c
                except Exception:
                    pass

        return ports

    user_portfolios_catalog = _get_all_available_user_portfolios()

    # Ingestione automatica trasparente nel Ledger Bitemporale DuckDB
    if "bitemp_ingested_portfolios" not in st.session_state:
        st.session_state["bitemp_ingested_portfolios"] = set()

    for p_name_item, p_df_item in user_portfolios_catalog.items():
        p_sig = f"{p_name_item}_{len(p_df_item)}_{CURRENT_BITEMP_ENGINE_VERSION}"
        if p_sig not in st.session_state["bitemp_ingested_portfolios"]:
            try:
                b_engine.ingest_portfolio_dataframe(p_df_item, portfolio_id=p_name_item, recorded_by="AUTO_SYNC_CATALOG")
                st.session_state["bitemp_ingested_portfolios"].add(p_sig)
            except Exception as e_auto_item:
                logger.warning(f"Auto-ingest portafoglio '{p_name_item}': {e_auto_item}")

    # Portafogli disponibili nel ledger
    available_ports = b_engine.get_available_portfolios()
    if "DEMO_FAMILY_OFFICE" not in available_ports:
        available_ports.insert(0, "DEMO_FAMILY_OFFICE")

    # Identificazione del portafoglio primario attivo
    preferred_active = st.session_state.get("portfolio_name")
    if preferred_active and preferred_active in user_portfolios_catalog:
        active_pname = preferred_active
    elif user_portfolios_catalog:
        if "Master Wealth Google Sheets" in user_portfolios_catalog:
            active_pname = "Master Wealth Google Sheets"
        else:
            active_pname = list(user_portfolios_catalog.keys())[0]
    else:
        active_pname = ""

    active_df = user_portfolios_catalog.get(active_pname)

    # Banner concettuale sulle due dimensioni ortogonali
    st.markdown("""
    <div style="background: rgba(13, 17, 23, 0.7); border: 1px solid rgba(88, 166, 255, 0.3); border-radius: 10px; padding: 14px 18px; margin-bottom: 16px;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
            <span style="color: #58a6ff; font-weight: 700; font-size: 14px;">📐 Le Due Dimensioni Ortogonali del Tempo di Bilancio:</span>
            <span style="font-size: 12px; color: #8b949e;">ISO/IEC 9075:2011 • Append-Only Ledger</span>
        </div>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px; font-size: 13px; color: #c9d1d9;">
            <div style="background: rgba(56, 189, 248, 0.08); padding: 10px 14px; border-radius: 8px; border-left: 3px solid #38bdf8;">
                <b style="color: #38bdf8;">1. Valid Time (Data Evento Reale / As-At):</b><br>
                Quando il fatto è accaduto nella realtà economica (es. stacco dividendo il 15 Marzo, data perizia immobile, data stipula mutuo).
            </div>
            <div style="background: rgba(245, 158, 11, 0.08); padding: 10px 14px; border-radius: 8px; border-left: 3px solid #f59e0b;">
                <b style="color: #f59e0b;">2. System Time (Data Conoscenza / As-Of):</b><br>
                Quando il sistema informativo ha registrato tale affermazione (es. estratto conto broker pervenuto il 20 Marzo alle 18:30).
            </div>
        </div>
    </div>
    """, unsafe_allow_html=True)

    # ── BARRA DI SINCRONIZZAZIONE PORTAFOGLIO UTENTE ──
    col_sync_info, col_sync_btn = st.columns([3.2, 1.3])
    with col_sync_info:
        if active_df is not None:
            tx_min = str(active_df['tx_date'].min())[:10] if 'tx_date' in active_df.columns else 'N/D'
            tx_max = str(active_df['tx_date'].max())[:10] if 'tx_date' in active_df.columns else 'N/D'
            in_ledger = active_pname in available_ports
            badge_sync = "🟢 Sincronizzato nel Ledger" if in_ledger else "🟡 Non ancora sincronizzato nel Ledger"
            other_ports_count = len(user_portfolios_catalog) - 1
            extra_msg = f" • Trovati altri <b>{other_ports_count}</b> portafogli utente nel catalogo." if other_ports_count > 0 else ""
            st.markdown(f"""
            <div style="background: rgba(22, 27, 34, 0.8); border: 1px solid rgba(88, 166, 255, 0.3); border-radius: 10px; padding: 12px 16px;">
                <div style="display: flex; align-items: center; justify-content: space-between;">
                    <div style="font-size: 13.5px; color: #ffffff; font-weight: 600;">
                        💼 Portafoglio Rilevato: <span style="color: #58a6ff;">{active_pname}</span>
                    </div>
                    <span style="font-size: 11px; color: {'#3fb950' if in_ledger else '#f59e0b'}; font-weight: 600; font-family: monospace;">{badge_sync}</span>
                </div>
                <div style="font-size: 12px; color: #8b949e; margin-top: 4px;">
                    Rilevate <b>{len(active_df)}</b> transazioni contabili valide (intervallo: <code>{tx_min}</code> ➔ <code>{tx_max}</code>){extra_msg}.
                    Puoi sincronizzarlo nel motore bitemporale o forzare una nuova ingestione.
                </div>
            </div>
            """, unsafe_allow_html=True)
        else:
            st.markdown("""
            <div style="background: rgba(22, 27, 34, 0.8); border: 1px solid rgba(255, 255, 255, 0.1); border-radius: 10px; padding: 12px 16px;">
                <div style="font-size: 13.5px; color: #ffffff; font-weight: 600;">
                    📁 Portafoglio Utente: <span style="color: #8b949e;">Nessun portafoglio caricato in sessione o su disco</span>
                </div>
                <div style="font-size: 12px; color: #8b949e; margin-top: 4px;">
                    Carica un file CSV nella <b>Tab 1</b> oppure sincronizza da Google Sheets per vederlo apparire nel Ledger Bitemporale.
                </div>
            </div>
            """, unsafe_allow_html=True)

    with col_sync_btn:
        st.markdown('<div style="height: 4px;"></div>', unsafe_allow_html=True)
        if active_df is not None:
            btn_sync_user = st.button(
                "🔄 Re-sincronizza nel Ledger" if active_pname in available_ports else "📥 Sincronizza nel Ledger",
                type="primary" if active_pname not in available_ports else "secondary",
                use_container_width=True,
                help=f"Ingerisce le {len(active_df)} transazioni di '{active_pname}' nel motore bitemporale con marcatura [VT, TT) e calcolo Merkle Tree.",
                key="btn_sync_user_bitemporal"
            )
            if btn_sync_user:
                with st.spinner(f"Sincronizzazione di '{active_pname}' nel Ledger Bitemporale..."):
                    cnt = b_engine.ingest_portfolio_dataframe(active_df, portfolio_id=active_pname, recorded_by="USER_MANUAL_SYNC")
                    st.session_state["bitemp_ingested_portfolios"].add(active_pname)
                    st.session_state["bitemp_ingested_portfolios"].add(f"{active_pname}_{len(active_df)}_{CURRENT_BITEMP_ENGINE_VERSION}")
                    st.session_state["selected_bitemp_port"] = active_pname
                st.success(f"✅ Sincronizzate {cnt} transazioni contabili di '{active_pname}' nel Ledger Bitemporale!")
                st.rerun()
        else:
            if st.button("🔄 Ripristina Demo VWCE", type="secondary", use_container_width=True, key="btn_reseed_demo_top"):
                st.session_state["bitemp_seed_info"] = b_engine.seed_demonstration_scenario()
                st.session_state["selected_bitemp_port"] = "DEMO_FAMILY_OFFICE"
                st.rerun()

    st.markdown('<div style="height: 6px;"></div>', unsafe_allow_html=True)

    # ── SELETTORE DEL PORTAFOGLIO DA ISPEZIONARE ──
    col_sel_p, col_reseed_p = st.columns([3.2, 1.3])
    with col_sel_p:
        pref_sel = st.session_state.get("selected_bitemp_port")
        if not pref_sel or pref_sel not in available_ports:
            if active_pname and active_pname in available_ports:
                pref_sel = active_pname
            else:
                pref_sel = available_ports[0] if available_ports else "DEMO_FAMILY_OFFICE"
        sel_idx = available_ports.index(pref_sel) if pref_sel in available_ports else 0

        selected_bitemp_pid = st.selectbox(
            "📁 Seleziona Portafoglio da Ispezionare nella Time-Travel Machine:",
            available_ports,
            index=sel_idx,
            key="sb_bitemp_selected_port"
        )
        st.session_state["selected_bitemp_port"] = selected_bitemp_pid

    with col_reseed_p:
        st.markdown('<div style="height: 28px;"></div>', unsafe_allow_html=True)
        if st.button("🔄 Reset Demo", use_container_width=True, help="Ripristina lo scenario didattico VWCE/BTP/Immobile.", key="btn_reseed_demo_sub"):
            st.session_state["bitemp_seed_info"] = b_engine.seed_demonstration_scenario()
            st.session_state["selected_bitemp_port"] = "DEMO_FAMILY_OFFICE"
            st.rerun()

    # Verifica stato catena crittografica per il portafoglio selezionato
    chain_ok, chain_msg, chain_cnt = b_engine.verify_audit_chain_integrity()
    tx_port_cnt = b_engine.con.execute("SELECT COUNT(*) FROM bitemporal_transactions WHERE portfolio_id = ?", [selected_bitemp_pid]).fetchone()[0] if b_engine.con else 0
    app_port_cnt = b_engine.con.execute("SELECT COUNT(*) FROM bitemporal_asset_appraisals WHERE portfolio_id = ?", [selected_bitemp_pid]).fetchone()[0] if b_engine.con else 0
    audit_port_cnt = b_engine.con.execute("SELECT COUNT(*) FROM audit_decision_log WHERE entity_id = ?", [selected_bitemp_pid]).fetchone()[0] if b_engine.con else 0

    col_kpi1, col_kpi2, col_kpi3, col_kpi4 = st.columns(4)
    with col_kpi1:
        metric_card("Catena Crittografica", "🟢 Integra (100%)" if chain_ok else "🔴 Manomessa", f"{chain_cnt} Blocchi Hash Verificati", positive=chain_ok)
    with col_kpi2:
        metric_card("Transazioni Portafoglio", f"{tx_port_cnt} Record", f"Portafoglio: {selected_bitemp_pid[:15]}", True)
    with col_kpi3:
        metric_card("Perizie Illiquidi", f"{app_port_cnt} Stime", "Immobili & Illiquidi", True)
    with col_kpi4:
        metric_card("Audit Log Decisioni", f"{audit_port_cnt} Variazioni", f"Su {chain_cnt} totali sistema", True)

    st.markdown('<div style="height: 10px;"></div>', unsafe_allow_html=True)

    # Sub-tabs tematiche
    sub_tt, sub_drift, sub_audit = st.tabs([
        "🕰️ Time-Travel Machine (Point-in-Time Query)",
        "🔍 Riconciliazione Forense & Drift Tardivi",
        "🛡️ Audit Trail Immutabile & Merkle Root"
    ])

    # -------------------------------------------------------------
    # SUB-TAB 1: TIME-TRAVEL MACHINE
    # -------------------------------------------------------------
    with sub_tt:
        st.markdown(f"##### 🕰️ Ricostruzione di '{selected_bitemp_pid}' a un Punto Bitemporale Esatto")
        st.caption("Interroga il sistema combinando la data dell'evento reale (Valid Time) con la data di conoscenza del database (System Time).")

        col_tt1, col_tt2 = st.columns(2)
        
        is_demo = (selected_bitemp_pid == "DEMO_FAMILY_OFFICE")

        if is_demo:
            with col_tt1:
                st.markdown("**1. Data Evento Economico (Valid Time / As-At):**")
                vt_choice = st.selectbox(
                    "Seleziona la data dell'evento reale da analizzare:",
                    [
                        "2026-03-15 23:59:59 (Data Stacco Dividendo VWCE)",
                        "2026-03-18 23:59:59 (Riunione Comitato Rischi)",
                        "2026-03-25 23:59:59 (Fine Mese Marzo)",
                        "Personalizzato..."
                    ],
                    index=0,
                    key="sb_vt_choice"
                )
                if vt_choice.startswith("2026-03-15"):
                    valid_time_input = "2026-03-15 23:59:59"
                elif vt_choice.startswith("2026-03-18"):
                    valid_time_input = "2026-03-18 23:59:59"
                elif vt_choice.startswith("2026-03-25"):
                    valid_time_input = "2026-03-25 23:59:59"
                else:
                    valid_time_input = st.text_input("Inserisci Valid Time (YYYY-MM-DD HH:MM:SS):", value="2026-03-15 23:59:59", key="txt_vt_demo")

            with col_tt2:
                st.markdown("**2. Stato di Conoscenza del Sistema (System Time / As-Of):**")
                tt_choice = st.selectbox(
                    "Cosa sapeva il sistema informativo a questa data?",
                    [
                        "2026-03-18 10:00:00 (Stato cognitivo alla Riunione - Dividendo non ancora noto)",
                        "2026-03-21 10:00:00 (Stato cognitivo dopo ricezione estratto conto broker del 20 Marzo)",
                        "Oggi / Live (Massima conoscenza attuale)",
                        "Personalizzato..."
                    ],
                    index=0,
                    key="sb_tt_choice"
                )
                if "2026-03-18" in tt_choice:
                    sys_time_input = "2026-03-18 10:00:00"
                elif "2026-03-21" in tt_choice:
                    sys_time_input = "2026-03-21 10:00:00"
                elif "Oggi" in tt_choice:
                    sys_time_input = None
                else:
                    sys_time_input = st.text_input("Inserisci System Time (YYYY-MM-DD HH:MM:SS):", value="2026-03-18 10:00:00", key="txt_tt_demo")
        else:
            # Calcolo date per il portafoglio utente
            row_dates = b_engine.con.execute("""
                SELECT MIN(valid_from), MAX(valid_from) 
                FROM bitemporal_transactions 
                WHERE portfolio_id = ?
            """, [selected_bitemp_pid]).fetchone()
            
            min_vt_dt = row_dates[0] if row_dates and row_dates[0] else datetime.datetime.now()
            max_vt_dt = row_dates[1] if row_dates and row_dates[1] else datetime.datetime.now()
            min_vt_str = str(min_vt_dt)[:10] + " 23:59:59"
            max_vt_str = str(max_vt_dt)[:10] + " 23:59:59"

            with col_tt1:
                st.markdown("**1. Data Evento Economico (Valid Time / As-At):**")
                vt_choice = st.selectbox(
                    "Seleziona il punto storico del portafoglio da ricostruire:",
                    [
                        f"{max_vt_str} (Data Ultima Transazione)",
                        f"{min_vt_str} (Data Prima Transazione)",
                        "Oggi / Tempo Reale",
                        "Personalizzato..."
                    ],
                    index=0,
                    key="sb_vt_user_choice"
                )
                if "(Data Ultima Transazione)" in vt_choice:
                    valid_time_input = max_vt_str
                elif "(Data Prima Transazione)" in vt_choice:
                    valid_time_input = min_vt_str
                elif "Oggi" in vt_choice:
                    valid_time_input = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                else:
                    valid_time_input = st.text_input("Inserisci Valid Time (YYYY-MM-DD HH:MM:SS):", value=max_vt_str, key="txt_vt_user")

            with col_tt2:
                st.markdown("**2. Stato di Conoscenza del Sistema (System Time / As-Of):**")
                tt_choice = st.selectbox(
                    "Quale stato di conoscenza del database vuoi interrogare?",
                    [
                        "Oggi / Live (Massima conoscenza attuale)",
                        f"{max_vt_str} (Alla data dell'ultima operazione)",
                        "Personalizzato..."
                    ],
                    index=0,
                    key="sb_tt_user_choice"
                )
                if "Oggi" in tt_choice:
                    sys_time_input = None
                elif "ultima operazione" in tt_choice:
                    sys_time_input = max_vt_str
                else:
                    sys_time_input = st.text_input("Inserisci System Time (YYYY-MM-DD HH:MM:SS):", value=max_vt_str, key="txt_tt_user")

        # Esecuzione della ricostruzione
        recon = b_engine.reconstruct_portfolio_at_times(selected_bitemp_pid, valid_time_input, sys_time_input)
        df_tt = b_engine.time_travel_query(selected_bitemp_pid, valid_time_input, sys_time_input)

        if is_demo:
            has_dividend = "TX_DIV_VWCE_004" in df_tt["tx_business_id"].values if not df_tt.empty else False
            if not has_dividend:
                st.markdown("""
                <div style="background: rgba(239, 68, 68, 0.1); border: 1px solid rgba(239, 68, 68, 0.4); border-radius: 8px; padding: 10px 14px; margin: 10px 0;">
                    <b style="color: #ef4444;">🛡️ Audit Replay Certificato:</b><br>
                    <span style="font-size: 13px; color: #c9d1d9;">
                    Alla data di conoscenza del <b>18 Marzo ore 10:00</b>, il dividendo di € 1.250 staccato il 15 Marzo <b>NON ERA NOTO AL SISTEMA</b>.
                    La query bitemporale lo esclude rigorosamente, comprovando la diligenza del gestore nella riunione di comitato.
                    </span>
                </div>
                """, unsafe_allow_html=True)
            else:
                st.markdown("""
                <div style="background: rgba(16, 185, 129, 0.1); border: 1px solid rgba(16, 185, 129, 0.4); border-radius: 8px; padding: 10px 14px; margin: 10px 0;">
                    <b style="color: #10b981;">✅ Conoscenza Acquisita (Post-Ricezione):</b><br>
                    <span style="font-size: 13px; color: #c9d1d9;">
                    Alla data di conoscenza del <b>21 Marzo</b>, il file broker pervenuto il 20 Marzo è stato integrato.
                    Il dividendo di € 1.250 è retroattivamente incluso e visibile sul 15 Marzo, garantendo la corretta quadratura fiscale.
                    </span>
                </div>
                """, unsafe_allow_html=True)

        col_res1, col_res2, col_res3, col_res4, col_res5 = st.columns(5)
        with col_res1:
            metric_card("Saldo Cassa", f"€ {recon['cash_balance_eur']:,.2f}", f"{recon['tx_count']} Movimenti Validi", True)
        with col_res2:
            metric_card("Controvalore Carico", f"€ {recon.get('positions_cost_eur', sum(p['cost_value_eur'] for p in recon.get('positions', []))):,.2f}", "Carico FIFO (TUIR Art. 68)", True)
        with col_res3:
            metric_card("Asset Illiquidi", f"€ {recon['illiquid_appraisals_eur']:,.2f}", f"{recon['appraisals_count']} Perizie Attive", True)
        with col_res4:
            metric_card("Valore Contabile Book", f"€ {recon['total_book_value_eur']:,.2f}", "Cassa + Costo Titoli + Immobili", True)
        with col_res5:
            metric_card("Posizioni in Portafoglio", f"{recon['positions_count']} Titoli", "Consistenze WACP", True)

        if recon.get("positions"):
            with st.expander(f"📊 Dettaglio Posizioni Contabili Ricostruite ({recon['positions_count']} titoli attivi al {valid_time_input[:10]})", expanded=True):
                df_p = pd.DataFrame(recon["positions"]).rename(columns={
                    "asset_id": "Asset / Ticker",
                    "shares": "Quote / Quantità",
                    "wacp_eur": "PMC / WACP (€)",
                    "cost_value_eur": "Controvalore Carico (€)"
                })
                render_table_with_export(
                    df_p,
                    table_title=f"Posizioni Contabili Ricostruite ({recon['positions_count']} titoli)",
                    file_prefix="bitemporal_positions",
                    key_suffix="bitemp_recon_pos"
                )

        st.markdown(f"##### 📋 Transazioni Valide Ricostruite nel Ledger per '{selected_bitemp_pid}':")
        if not df_tt.empty:
            df_show = df_tt.copy()
            df_show["valid_from"] = df_show["valid_from"].astype(str)
            df_show["sys_from"] = df_show["sys_from"].astype(str)
            render_table_with_export(
                df_show,
                table_title=f"Transazioni Valide nel Ledger ({selected_bitemp_pid})",
                file_prefix="bitemporal_transactions",
                key_suffix="bitemp_tx_ledger"
            )
        else:
            st.info("Nessuna transazione soddisfa i vincoli bitemporali specificati per questo portafoglio.")

    # -------------------------------------------------------------
    # SUB-TAB 2: DRIFT FORENSICS
    # -------------------------------------------------------------
    with sub_drift:
        st.markdown(f"##### 🔍 Riconciliazione Forense tra Due Stati di Conoscenza ({selected_bitemp_pid})")
        st.caption("Confronta cosa sapeva il database a due date distinte (T1 vs T2) rispetto alla medesima data evento (Valid Time).")

        is_demo = (selected_bitemp_pid == "DEMO_FAMILY_OFFICE")
        if is_demo:
            d_vt_val = "2026-03-15 23:59:59"
            d_s1_val = "2026-03-18 10:00:00"
            d_s2_val = "2026-03-21 10:00:00"
        else:
            row_d = b_engine.con.execute("""
                SELECT MIN(valid_from), MAX(valid_from) 
                FROM bitemporal_transactions 
                WHERE portfolio_id = ?
            """, [selected_bitemp_pid]).fetchone()
            d_vt_val = str(row_d[1])[:10] + " 23:59:59" if row_d and row_d[1] else "2026-01-01 23:59:59"
            d_s1_val = str(row_d[0])[:10] + " 10:00:00" if row_d and row_d[0] else "2025-01-01 10:00:00"
            d_s2_val = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        col_d1, col_d2, col_d3 = st.columns(3)
        with col_d1:
            drift_vt = st.text_input("Data Evento Reale (Valid Time):", value=d_vt_val, key="drift_vt")
        with col_d2:
            drift_s1 = st.text_input("Stato Conoscenza T1 (Prima):", value=d_s1_val, key="drift_s1")
        with col_d3:
            drift_s2 = st.text_input("Stato Conoscenza T2 (Dopo):", value=d_s2_val, key="drift_s2")

        drift_res = b_engine.detect_retroactive_drifts(selected_bitemp_pid, drift_vt, drift_s1, drift_s2)

        if drift_res["has_drift"]:
            st.warning(f"⚠️ **Rilevato Drift Retroattivo**: Trovate **{drift_res['new_transactions_count']} nuove transazioni tardive** e **{drift_res['modified_transactions_count']} transazioni rettificate** tra T1 e T2!")
            
            if drift_res["new_transactions"]:
                st.markdown("**Nuove Transazioni Ingestite Retroattivamente (Late-Arriving Data):**")
                st.dataframe(pd.DataFrame(drift_res["new_transactions"]), use_container_width=True)
            
            if drift_res["modified_transactions"]:
                st.markdown("**Transazioni Modificate Retroattivamente (Restatements):**")
                st.dataframe(pd.DataFrame(drift_res["modified_transactions"]), use_container_width=True)
        else:
            st.success("✅ Nessun drift retroattivo rilevato tra le due date di conoscenza per questo portafoglio.")

    # -------------------------------------------------------------
    # SUB-TAB 3: AUDIT TRAIL IMMUTABILE & MERKLE TREE
    # -------------------------------------------------------------
    with sub_audit:
        st.markdown(f"##### 🛡️ Audit Trail Immutabile & Merkle Root ({selected_bitemp_pid})")
        st.caption("Ogni cambio di allocazione, importazione batch o rettifica contabile è sigillato con hash a catena crittografica SHA-256.")

        col_audit_btn, col_filter_chk = st.columns([3, 1.5])
        with col_audit_btn:
            btn_verify = st.button("🛡️ Esegui Audit Computazionale di Integrità (Tamper Detection)", type="primary", use_container_width=True, key="btn_verify_audit_trail")
        with col_filter_chk:
            show_all_audit = st.checkbox("Mostra audit di tutti i portafogli", value=False, help="Se deselezionato, mostra solo le decisioni collegate al portafoglio selezionato.")

        if btn_verify:
            is_valid, msg, count = b_engine.verify_audit_chain_integrity()
            if is_valid:
                st.success(f"✅ {msg}")
            else:
                st.error(f"❌ {msg}")

        # Tabella dell'audit trail
        if show_all_audit:
            df_audit = b_engine.con.execute("""
                SELECT sequence_id, entity_id, decision_type, actor_id, rationale, sys_timestamp,
                       prev_record_hash, entry_hash
                FROM audit_decision_log ORDER BY sequence_id ASC
            """).df()
        else:
            df_audit = b_engine.con.execute("""
                SELECT sequence_id, entity_id, decision_type, actor_id, rationale, sys_timestamp,
                       prev_record_hash, entry_hash
                FROM audit_decision_log 
                WHERE entity_id = ?
                ORDER BY sequence_id ASC
            """, [selected_bitemp_pid]).df()

        if not df_audit.empty:
            render_table_with_export(
                df_audit,
                table_title=f"Audit Trail Immutabile ({selected_bitemp_pid})",
                file_prefix="audit_trail_ledger",
                key_suffix="bitemp_audit_trail"
            )
        else:
            st.info(f"Nessuna decisione registrata per '{selected_bitemp_pid}'.")

        st.markdown("---")
        st.markdown("##### 🌲 Certificazione Merkle Tree per Report Patrimoniali Esportati")
        st.caption("Costruisce un albero Merkle foglia-per-foglia sulle consistenze attive e imprime il Root Hash nel piè di pagina della reportistica istituzionale.")

        active_txs = b_engine.con.execute("""
            SELECT * FROM bitemporal_transactions 
            WHERE portfolio_id = ? AND sys_to = ?::TIMESTAMP
        """, [selected_bitemp_pid, b_engine.INFINITY_TIMESTAMP]).fetchdf()

        merkle_root = b_engine.generate_merkle_root(active_txs.to_dict(orient="records"))

        st.code(f"MERKLE_ROOT_SEAL = \"{merkle_root}\"", language="python")
        st.caption(f"Sigillo di integrità calcolato su {len(active_txs)} transazioni contabili attive del portafoglio '{selected_bitemp_pid}'. Verificabile in tempo sub-millisecondo.")

