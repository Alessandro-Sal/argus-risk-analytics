# ============================================================
# src/pages/12_🎛️_Wealth_Control_Room.py
# ARGUS Wealth Management — Dedicated Control Room & Ingestion Hub
# ============================================================

import json
import os
from datetime import date, datetime

import pandas as pd
import streamlit as st

import core.ui_utils
import core.wealth.wealth_db
import core.wealth.wealth_engine
import core.wealth.wealth_sync
from core.archetype_manager import (
    clear_unified_archetype,
    execute_unified_archetype_load,
    render_unified_archetype_hud,
)
from core.fetcher import get_engine
from core.sidebar import render_sidebar
from core.ui_utils import (
    ensure_portal_context,
    fmt_eur,
    fmt_pct,
    inject_custom_css,
    metric_card,
    render_data_table,
    render_institutional_telemetry_ribbon,
    render_kpi_card,
    render_omni_command_bar,
    render_segmented_tabs,
    render_wealth_command_bar,
    render_wealth_control_room_hero,
    render_wealth_executive_badges,
    section,
)
from core.wealth.wealth_db import (
    cleanup_empty_wealth_portfolios,
    clear_wealth_accounts,
    clear_wealth_cashflow,
    clear_wealth_snapshots,
    create_wealth_portfolio,
    deduplicate_wealth_accounts,
    delete_wealth_account,
    delete_wealth_portfolio,
    delete_wealth_snapshot,
    get_available_risk_portfolios,
    get_cashflow_records,
    get_linked_risk_portfolios,
    get_linked_risk_portfolios_summary,
    get_wealth_accounts,
    get_wealth_categories,
    get_wealth_portfolios,
    get_wealth_snapshots_history,
    init_wealth_db,
    load_wealth_snapshot_details,
    reset_all_wealth_database,
    reset_wealth_portfolio_data,
    save_pension_plan,
    save_physical_asset,
    save_wealth_account,
    save_wealth_category,
    save_wealth_snapshot_to_db,
    set_linked_risk_portfolios,
)
from core.wealth.wealth_engine import compute_consolidated_net_worth
from core.wealth.wealth_importer import auto_categorize_transactions, bulk_import_statement, parse_universal_statement
from core.wealth.wealth_sync import sync_all_historical_expenses_from_gsheets, sync_expenses_tracker_2026_from_gsheets
from core.wealth.wealth_validator import (
    validate_accounts_df,
    validate_cashflow_df,
    validate_pension_df,
    validate_physical_assets_df,
)

# ── CONFIGURAZIONE PAGINA & SIDEBAR ─────────────────────────
st.set_page_config(
    page_title="Wealth Control Room | ARGUS",
    page_icon="🎛️",
    layout="wide",
    initial_sidebar_state="expanded"
)
st.session_state.argus_portal_mode = "🏛️ Wealth Management"
inject_custom_css()
render_sidebar()

ctx = ensure_portal_context(module="wealth")
engine = ctx["engine"]
current_pid = ctx["portfolio_id"]
active_p_name = ctx["profile_name"]
profile_map = ctx["profile_map"]
nw_curr = ctx["net_worth"]

render_omni_command_bar(portal="wealth", context_name=active_p_name, key_suffix="p12")
render_institutional_telemetry_ribbon(page_badge="WEALTH CONTROL ROOM & INGESTION")
render_wealth_control_room_hero(profile_map=profile_map, current_pid=current_pid)

# ── SELETTORE PROFILO & TOOLBAR IN LINEA ─────────────────────
p_bar_c1, p_bar_c2, p_bar_c3, p_bar_c4, p_bar_c5 = st.columns([2.7, 0.9, 0.9, 1.3, 1.3])
with p_bar_c1:
    opts = [None] + list(profile_map.keys())
    curr_idx = opts.index(current_pid) if current_pid in opts else 0
    if st.session_state.get("wealth_profile_selector_widget") != current_pid and current_pid in opts:
        st.session_state["wealth_profile_selector_widget"] = current_pid

    def _on_wealth_profile_change():
        new_val = st.session_state.get("wealth_profile_selector_widget")
        prof_nm = profile_map.get(new_val) if new_val is not None else None
        try:
            from core.workspace_context import WorkspaceContext

            WorkspaceContext.switch_wealth_profile(new_val, profile_name=prof_nm)
        except Exception:
            st.session_state["wealth_active_portfolio_id"] = new_val
            st.session_state.pop("wealth_active_snapshot", None)

    selected_pid = st.selectbox(
        "💼 Profilo Patrimoniale Attivo:",
        options=opts,
        format_func=lambda pid: "-- Seleziona Profilo Patrimoniale --" if pid is None else f"📁 {profile_map[pid]} (ID #{pid})",
        index=curr_idx,
        key="wealth_profile_selector_widget",
        on_change=_on_wealth_profile_change
    )

with p_bar_c2:
    st.write("")
    with st.popover("➕ Nuovo", use_container_width=True):
        st.markdown("##### ➕ Crea Profilo Patrimoniale")
        new_p_name = st.text_input("Nome Profilo *", placeholder="es. Famiglia, Holding, P.IVA...")
        new_p_desc = st.text_input("Descrizione (opzionale)", placeholder="Spese e patrimonio familiare")
        if st.button("Crea Profilo", type="primary", use_container_width=True, key="btn_create_prof_pop"):
            if new_p_name.strip():
                try:
                    n_pid = create_wealth_portfolio(engine, new_p_name.strip(), new_p_desc.strip() if new_p_desc else None)
                    st.session_state["wealth_active_portfolio_id"] = n_pid
                    st.success(f"Profilo '{new_p_name.strip()}' selezionato ed attivo!")
                    st.rerun()
                except Exception as ex:
                    st.error(f"Impossibile creare il profilo: {ex}")


with p_bar_c3:
    st.write("")
    if current_pid is not None and len(profile_map) > 1:
        if st.button("🗑️ Elimina", type="secondary", use_container_width=True, key="btn_del_prof_pop"):
            from core.confirm_dialogs import confirm_delete_wealth_portfolio_dialog

            remaining = [p for p in profile_map.keys() if p != current_pid]
            prof_name = profile_map.get(current_pid, f"Profilo #{current_pid}")
            confirm_delete_wealth_portfolio_dialog(engine, current_pid, prof_name, remaining)
    elif current_pid is not None:
        st.button("🔒 Unico", disabled=True, use_container_width=True, help="Non puoi eliminare l'unico profilo presente. Creane prima un altro con ➕ Nuovo.")


with p_bar_c4:
    st.write("")
    if current_pid is not None:
        with st.popover("📑 Master Pack", use_container_width=True):
            st.markdown("##### 📑 Executive Master Board Pack")
            st.caption("Dossier istituzionale unificato Risk & Wealth.")
            prof_nm = profile_map.get(current_pid, "Family Office Master")
            try:
                from core.wealth.wealth_reporting_hub import (
                    _get_cached_master_board_pack_html,
                    _get_cached_master_board_pack_pdf,
                )
                st.download_button(
                    "📥 Scarica PDF Master",
                    data=lambda: _get_cached_master_board_pack_pdf(engine, pid=current_pid, prof_name=prof_nm),
                    file_name=f"argus_master_board_pack_{prof_nm.lower().replace(' ', '_')}.pdf",
                    mime="application/pdf",
                    use_container_width=True,
                    type="primary",
                    key="dl_mb_pdf_w_ctrl",
                )
                st.download_button(
                    "🌐 Scarica HTML Master",
                    data=lambda: _get_cached_master_board_pack_html(engine, pid=current_pid, prof_name=prof_nm),
                    file_name=f"argus_master_board_pack_{prof_nm.lower().replace(' ', '_')}.html",
                    mime="text/html",
                    use_container_width=True,
                    key="dl_mb_html_w_ctrl",
                )
            except Exception as ex:
                st.error(f"Errore generazione Master Board Pack: {ex}")

with p_bar_c5:
    st.write("")
    if current_pid is not None:
        if st.button("🏛️ Vai al Net Worth →", type="secondary", use_container_width=True, key="btn_goto_nw_top"):
            st.switch_page("pages/13_🏛️_Patrimonio_e_NetWorth.py")

if current_pid is None:
    from core.ui_utils import render_wealth_profile_picker
    render_wealth_profile_picker(engine, profile_map, key_prefix="p12_picker")
    st.stop()


# ── BANNER FEEDBACK SINCRONIZZAZIONE O SNAPSHOT ATTIVO ───────
if "wealth_sync_feedback" in st.session_state and st.session_state["wealth_sync_feedback"]:
    fb = st.session_state["wealth_sync_feedback"]
    fb_c1, fb_c2 = st.columns([5, 1])
    with fb_c1:
        st.success(f"""
        🚀 **Sincronizzazione Google Sheets Eseguita con Successo!**
        - 📜 **Transazioni Elaborate**: `{fb.get('total_transactions_synced', 0):,}`
        - 🏦 **Conti Aggiornati**: `{fb.get('accounts_count', 0)}` ({', '.join(fb.get('accounts_list', []))})
        - 📸 **Snapshot Automatico Generato**: ID `#{fb.get('snapshot_id', '-')}` (*{fb.get('snapshot_name', '')}*)
        """)
    with fb_c2:
        st.write("")
        if st.button("✖ Chiudi", key="btn_close_sync_fb_main"):
            st.session_state.pop("wealth_sync_feedback", None)
            st.rerun()

if "wealth_active_snapshot" in st.session_state and st.session_state["wealth_active_snapshot"]:
    act_snap = st.session_state["wealth_active_snapshot"]
    st.info(f"""
    📸 **Visualizzazione Snapshot Storico Attivo**: **"{act_snap.get('snapshot_name', 'Senza Nome')}"** del **{act_snap.get('snapshot_date')}** 
    (Patrimonio Netto Consolidato: **{fmt_eur(act_snap.get('total_net_worth', 0.0))}**).
    """)
    if st.button("🔄 Ripristina Dati Live / Esci da Snapshot Storico", type="secondary", key="btn_exit_wealth_snap"):
        st.session_state.pop("wealth_active_snapshot", None)
        st.rerun()

# ── TOP KPI METRIC STRIP ────────────────────────────────────
df_accs = get_wealth_accounts(engine, portfolio_id=current_pid)
df_txs = get_cashflow_records(engine, portfolio_id=current_pid)
df_snaps = get_wealth_snapshots_history(engine, portfolio_id=current_pid)

tot_cash = float(df_accs[df_accs["balance"] > 0]["balance"].sum()) if not df_accs.empty else 0.0
tot_tx_count = len(df_txs) if not df_txs.empty else 0
tot_acc_count = len(df_accs) if not df_accs.empty else 0
last_tx_date = str(df_txs["tx_date"].max()) if not df_txs.empty else "Nessuna"
tot_snaps_count = len(df_snaps) if not df_snaps.empty else 0

nw_curr = compute_consolidated_net_worth(engine, portfolio_id=current_pid)
render_wealth_executive_badges(nw_curr)

from core.wealth.unified_stress_bridge import render_cross_portal_stress_bridge_banner

render_cross_portal_stress_bridge_banner(
    wealth_snapshot={
        "total_net_worth": nw_curr.total_net_worth,
        "liquid_cash": nw_curr.liquid_cash,
        "financial_investments": nw_curr.financial_investments,
        "real_estate_total": nw_curr.real_estate_total,
        "total_liabilities": nw_curr.total_liabilities,
        "runway_months": nw_curr.runway_months,
        "fixed_mortgages_balance": getattr(nw_curr, "fixed_mortgages_balance", nw_curr.total_liabilities * 0.7),
        "variable_mortgages_balance": getattr(nw_curr, "variable_mortgages_balance", nw_curr.total_liabilities * 0.3),
    },
    portfolio_id=current_pid,
    key_suffix="p12_main",
)

st.markdown("<div style='margin-top: 10px; margin-bottom: 18px;'>", unsafe_allow_html=True)
k1, k2, k3, k4 = st.columns(4)


with k1:
    metric_card("Liquidità Consolidata", fmt_eur(tot_cash), delta=f"{tot_acc_count} Conti Attivi", delta_color="normal")
with k2:
    metric_card("Libro Mastro Cassa", f"{tot_tx_count:,}", delta="Movimenti Registrati", delta_color="normal")
with k3:
    metric_card("Ultima Registrazione", str(last_tx_date), delta="Data Valuta", delta_color="normal")
with k4:
    metric_card("Snapshot Storici", f"{tot_snaps_count} Snapshot", delta=f"Profilo #{current_pid}", delta_color="normal")

st.markdown("</div>", unsafe_allow_html=True)

# ── SEZIONE: Storico Snapshot & Recall Analisi (Stile Risk Module) ────
with st.expander("📚 Storico Snapshot & Recall Analisi Patrimoniale", expanded=bool(st.session_state.get("wealth_active_snapshot"))):
    df_all_snaps = get_wealth_snapshots_history(engine)
    if df_all_snaps.empty:
        st.info("ℹ️ Nessuno snapshot patrimoniale salvato. Carica un estratto conto CSV, sincronizza Google Sheets o inserisci i saldi per registrare il primo snapshot!")
    else:
        st.caption("Sfoglia gli snapshot storici salvati nel database per ricaricare istantaneamente lo stato del patrimonio netto in un dato momento senza ricalcoli.")

        col_search, col_port_filter, col_sort = st.columns([2.2, 1.4, 1.4])
        with col_search:
            search_query = st.text_input(
                "🔍 Cerca Snapshot (Nome, ID, Data):",
                placeholder="es. GSheets, Fineco, 2026-08, RUN-WLT...",
                key="wealth_hist_search_query"
            ).strip().lower()

        unique_ports = sorted(list({str(r) for r in df_all_snaps["portfolio_name"].dropna().unique() if str(r).strip()}))
        with col_port_filter:
            selected_port_filter = st.selectbox(
                "💼 Filtra Profilo:",
                options=["Tutti i Profili"] + unique_ports,
                key="wealth_hist_port_filter"
            )

        with col_sort:
            sort_mode = st.selectbox(
                "⚡ Ordina per:",
                options=[
                    "📅 Più recenti",
                    "📅 Meno recenti",
                    "💰 Net Worth (Decrescente)",
                    "💧 Liquidità (Decrescente)",
                    "🛡️ Health Score (Decrescente)"
                ],
                key="wealth_hist_sort_mode"
            )

        # Filtraggio
        filtered_df = df_all_snaps.copy()
        if selected_port_filter != "Tutti i Profili":
            filtered_df = filtered_df[filtered_df["portfolio_name"] == selected_port_filter]

        if search_query:
            filtered_df = filtered_df[
                filtered_df.apply(
                    lambda row: search_query in f"{row.get('snapshot_name', '')} {row.get('snapshot_date', '')} {row.get('run_id', '')} {row.get('portfolio_name', '')} {row.get('notes', '')}".lower(),
                    axis=1
                )
            ]

        # Ordinamento
        if sort_mode == "📅 Più recenti":
            filtered_df = filtered_df.sort_values(by=["snapshot_date", "snapshot_id"], ascending=[False, False])
        elif sort_mode == "📅 Meno recenti":
            filtered_df = filtered_df.sort_values(by=["snapshot_date", "snapshot_id"], ascending=[True, True])
        elif sort_mode == "💰 Net Worth (Decrescente)":
            filtered_df = filtered_df.sort_values(by="total_net_worth", ascending=False)
        elif sort_mode == "💧 Liquidità (Decrescente)":
            filtered_df = filtered_df.sort_values(by="liquid_assets", ascending=False)
        elif sort_mode == "🛡️ Health Score (Decrescente)":
            filtered_df = filtered_df.sort_values(by="wealth_health_score", ascending=False)

        if filtered_df.empty:
            st.warning("🔍 Nessuno snapshot corrisponde ai criteri di ricerca impostati.")
        else:
            st.markdown(f"<div style='font-size: 11.5px; color: #8b949e; margin-bottom: 6px;'>🎯 Trovati <b>{len(filtered_df)}</b> snapshot su {len(df_all_snaps)} totali</div>", unsafe_allow_html=True)

            # ── TABELLA RIASSUNTIVA SNAPSHOT (STILE MODULO QUANT) ──
            disp_rows = []
            snap_options = {}
            for _, r in filtered_df.iterrows():
                sid = int(r["snapshot_id"])
                dt_str = str(r["snapshot_date"])
                p_name_display = r.get("portfolio_name") or f"Profilo #{r.get('portfolio_id', 1)}"
                s_name = r.get("snapshot_name") or "Snapshot Standard"
                tot_nw_val = float(r.get("total_net_worth", 0.0))
                liq_val = float(r.get("liquid_assets", 0.0))
                inv_val = float(r.get("financial_investments", 0.0))
                phys_val = float(r.get("physical_assets_total", 0.0))
                pen_val = float(r.get("pension_total", 0.0))
                deb_val = float(r.get("total_liabilities", 0.0))
                health_val = f"{float(r.get('wealth_health_score', 0.0)):.0f}/100" if r.get("wealth_health_score") is not None else "N/A"
                run_id_val = r.get("run_id") or f"ID #{sid}"

                disp_rows.append({
                    "Data": dt_str,
                    "Profilo": p_name_display,
                    "Tipologia": s_name,
                    "Net Worth (€)": tot_nw_val,
                    "Liquidità (€)": liq_val,
                    "Investimenti (€)": inv_val,
                    "Asset Caveau (€)": phys_val,
                    "Previdenza (€)": pen_val,
                    "Passività (€)": deb_val,
                    "Health Score": health_val,
                    "Run ID": run_id_val
                })

                label = f"{dt_str} · {p_name_display} · {s_name} (Net Worth: {fmt_eur(tot_nw_val)} | Cassa: {fmt_eur(liq_val)} | {run_id_val})"
                snap_options[label] = sid

            df_disp = pd.DataFrame(disp_rows)
            st.dataframe(
                df_disp.style.format({
                    "Net Worth (€)": "€ {:,.2f}",
                    "Liquidità (€)": "€ {:,.2f}",
                    "Investimenti (€)": "€ {:,.2f}",
                    "Asset Caveau (€)": "€ {:,.2f}",
                    "Previdenza (€)": "€ {:,.2f}",
                    "Passività (€)": "€ {:,.2f}"
                }),
                use_container_width=True,
                height=160,
                hide_index=True
            )

            selected_snap_label = st.selectbox(
                "🎯 Seleziona lo Snapshot da Ricaricare o Gestire:",
                options=list(snap_options.keys()),
                key="wealth_select_snapshot_recall",
                help="Seleziona la sessione o lo snapshot patrimoniale da ripristinare nella Dashboard."
            )
            sel_sid = snap_options[selected_snap_label]

            # ── CARD DI ANTEPRIMA SNAPSHOT SELEZIONATO (STILE QUANT) ──
            sel_row = filtered_df[filtered_df["snapshot_id"] == sel_sid].iloc[0]
            sel_dt = str(sel_row.get("snapshot_date", ""))
            sel_port = sel_row.get("portfolio_name") if sel_row.get("portfolio_name") else f"Profilo #{sel_row.get('portfolio_id', 1)}"
            sel_snap_name = sel_row.get("snapshot_name") if sel_row.get("snapshot_name") else "Snapshot Standard"
            sel_nw = fmt_eur(float(sel_row.get("total_net_worth", 0.0)))
            sel_liq = fmt_eur(float(sel_row.get("liquid_assets", 0.0)))
            sel_inv = fmt_eur(float(sel_row.get("financial_investments", 0.0)))
            sel_phys = fmt_eur(float(sel_row.get("physical_assets_total", 0.0)))
            sel_pens = fmt_eur(float(sel_row.get("pension_total", 0.0)))
            sel_deb = fmt_eur(float(sel_row.get("total_liabilities", 0.0)))
            sel_score = f"{float(sel_row.get('wealth_health_score', 0.0)):.0f}/100" if sel_row.get("wealth_health_score") is not None else "N/A"
            sel_run_id = sel_row.get("run_id") or f"ID #{sel_sid}"

            st.markdown(f"""
            <div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 10px; padding: 12px 16px; margin: 10px 0 14px 0;">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 8px;">
                    <span style="font-size: 13px; font-weight: 700; color: #f0f6fc;">🏛️ {sel_port} &bull; <span style="color:#10b981;">{sel_snap_name}</span></span>
                    <span style="font-size: 11px; color: #8b949e; font-family: monospace;">{sel_run_id}</span>
                </div>
                <div style="display: flex; gap: 20px; flex-wrap: wrap; font-size: 12px; color: #8b949e;">
                    <div>📅 Data: <b style="color:#f0f6fc;">{sel_dt}</b></div>
                    <div>💰 Net Worth: <b style="color:#34d399;">{sel_nw}</b></div>
                    <div>💧 Liquidità: <b style="color:#38bdf8;">{sel_liq}</b></div>
                    <div>📈 Investimenti: <b style="color:#a78bfa;">{sel_inv}</b></div>
                    <div>⌚ Caveau: <b style="color:#fbbf24;">{sel_phys}</b></div>
                    <div>🛡️ Previdenza: <b style="color:#60a5fa;">{sel_pens}</b></div>
                    <div>📉 Debiti: <b style="color:#ef4444;">{sel_deb}</b></div>
                    <div>🛡️ Health Score: <b style="color:#10b981;">{sel_score}</b></div>
                </div>
            </div>
            """, unsafe_allow_html=True)

            col_recall, col_del_snap, col_goto_dash = st.columns([2.5, 1.3, 1.8])
            with col_recall:
                if st.button("⚡ Carica Snapshot & Visualizza Analisi", type="primary", use_container_width=True, key="btn_recall_snap_action"):
                    snap_data = load_wealth_snapshot_details(engine, sel_sid)
                    if snap_data:
                        st.session_state["wealth_active_snapshot"] = snap_data
                        st.session_state["wealth_active_portfolio_id"] = snap_data.get("portfolio_id")
                        st.success(f"✅ Snapshot '{snap_data.get('snapshot_name')}' ({snap_data.get('snapshot_date')}) caricato con successo!")
                        st.rerun()
                    else:
                        st.error("Errore nel caricamento del payload dello snapshot.")

            with col_del_snap:
                if st.button("🗑️ Elimina Snapshot", type="secondary", use_container_width=True, key="btn_del_snap_action"):
                    from core.confirm_dialogs import confirm_delete_wealth_snapshot_dialog

                    confirm_delete_wealth_snapshot_dialog(engine, sel_sid, str(sel_snap_name), str(sel_dt))

            with col_goto_dash:
                if st.button("🏛️ Vai alla Dashboard Net Worth →", type="secondary", use_container_width=True, key="btn_goto_nw_from_recall"):
                    st.switch_page("pages/13_🏛️_Patrimonio_e_NetWorth.py")


from core.wealth.wealth_reporting_hub import render_wealth_reporting_and_exports_hub

# ── SELETTORE MODULI CONTROL ROOM STILE BLOOMBERG TERMINAL ───────
WEALTH_CR_MODELS_CATALOG = {
    "📥 Data Pipeline & Ingestion": {
        "title": "Pipeline di Ingestione Dati, Connettori Bancari & Calcolo Patrimoniale",
        "badge": "ETL Ingestion • Parsing CSV • Sync",
        "badge_color": "#10b981",
        "category": "Ingestione & Data Pipeline",
        "desc": "Processo guidato a step per importare estratti conto bancari, sincronizzare fogli Google Sheets, caricare posizioni finanziarie e consolidare automaticamente il Net Worth.",
    },
    "⚙️ Gestione Conti & Categorie": {
        "title": "Anagrafica Conti, Categorie di Spesa & Perimetri Patrimoniali",
        "badge": "Conti Bancari • Categorie • Wallet",
        "badge_color": "#38bdf8",
        "category": "Configurazione & Anagrafica",
        "desc": "Configurazione e censimento dei rapporti di conto corrente, depositi titoli, wallet crypto, carte di credito e definizione dell'albero delle categorie di spesa/entrata.",
    },
    "📑 Hub Reportistica & Esportazioni": {
        "title": "Hub Reportistica Istituzionale, Esportazioni Dati & Audit Log",
        "badge": "PDF Dossier • Excel • CSV Audit",
        "badge_color": "#a855f7",
        "category": "Reporting & Compliance",
        "desc": "Generazione e download dei report patrimoniali consolidati: Dossier PDF per Private Banking, prospetti contabili in Excel (XLSX) e dump certificati in formato CSV.",
    },
}

active_cr_tab = render_segmented_tabs(
    WEALTH_CR_MODELS_CATALOG,
    key="wealth_cr_active_tab",
    select_label="Seleziona Modulo Control Room:",
)

# =============================================================
# TAB 1: PIPELINE GUIDATA A STEP
# =============================================================
if active_cr_tab == "📥 Data Pipeline & Ingestion":
    st.markdown(f"""
    <div style="background: linear-gradient(135deg, rgba(16, 185, 129, 0.08) 0%, rgba(99, 102, 241, 0.06) 100%); border: 1px solid rgba(16, 185, 129, 0.25); border-radius: 12px; padding: 14px 18px; margin-bottom: 20px;">
        <div style="display:flex; justify-content:space-between; align-items:center;">
            <div>
                <span style="font-weight:800; color:#34d399; font-size:14px; text-transform:uppercase; letter-spacing:0.5px;">🚀 Pipeline di Ingestione & Calcolo Patrimoniale</span>
                <p style="font-size:12px; color:#94a3b8; margin: 4px 0 0 0;">
                    Processo guidato a step per caricare estratti conto bancari, sincronizzare Google Sheets o registrare asset e consolidare automaticamente il Net Worth.
                </p>
            </div>
            <div style="font-size:12px; color:#cbd5e1; background:rgba(255,255,255,0.06); padding:5px 12px; border-radius:6px; border:1px solid rgba(255,255,255,0.08);">
                Profilo Attivo: <b style="color:#34d399;">{profile_map.get(current_pid, 'Principale')} (ID #{current_pid})</b>
            </div>
        </div>
    </div>
    """, unsafe_allow_html=True)

    active_code = st.session_state.get("active_archetype_code")
    if active_code:
        render_unified_archetype_hud(current_module="wealth")

    section("① Scegli la Sorgente Dati")
    
    expander_is_open = bool(st.session_state.get("keep_archetype_expander_open", False) or active_code)
    with st.expander("🧪 Scenari Didattici & Archetipi Pre-configurati (Iniezione 1-Click su DB)", expanded=expander_is_open):
        st.caption("Inietta istantaneamente un intero ecosistema patrimoniale realistico (conti, cashflow pluriennale solvibile, mutui francesi, perizie e fondo pensione) nel database e sincronizzalo automaticamente sia con il Wealth Management che con il Risk Analytics.")
        
        w_status_placeholder = st.empty()

        def _execute_wealth_archetype(arch_code: str, label_name: str):
            with w_status_placeholder.container():
                with st.spinner("⏳ Generazione quantitativa e iniezione cross-modulo in corso..."):
                    db_res = execute_unified_archetype_load(arch_code, auto_run=False, source_module="wealth")
                    st.success(f"✅ Profilo '{label_name}' sincronizzato con successo (Wealth #{db_res['wealth_profile_id']} • Risk #{db_res['risk_portfolio_id']})!")
                    st.rerun()

        w_col1, w_col2, w_col3 = st.columns(3)
        with w_col1:
            with st.container(border=True):
                badge_young = " :green[**[● ATTIVO]**]" if active_code == "young_accumulator" else ""
                st.markdown(f"""
                **🚀 Giovane Accumulatore**{badge_young}
                - **Patrimonio**: €116k (Orizzonte 25 anni)
                - **Conti**: Checking, Risparmio, Emergenza, Broker
                - **Wealth**: Zero debiti/immobili, stipendio indicizzato, PAC €850
                """, unsafe_allow_html=True)
                lbl_y = "Ricarica Giovane Accumulatore" if active_code == "young_accumulator" else "Inietta Giovane Accumulatore"
                if st.button(lbl_y, key="btn_w_arch_young", use_container_width=True):
                    _execute_wealth_archetype("young_accumulator", "Giovane Accumulatore")

        with w_col2:
            with st.container(border=True):
                badge_fire = " :green[**[● ATTIVO]**]" if active_code == "fire_decumulation" else ""
                st.markdown(f"""
                **🏖️ FIRE / Decumulo**{badge_fire}
                - **Patrimonio**: €1.7M (Orizzonte 35 anni)
                - **Conti**: Liquidità cuscinetto, Brokerage cedolare
                - **Wealth**: Villa proprietà (€420k, 0 mutui), SWR 3.5%, dividendi
                """, unsafe_allow_html=True)
                lbl_f = "Ricarica FIRE Decumulo" if active_code == "fire_decumulation" else "Inietta FIRE Decumulo"
                if st.button(lbl_f, key="btn_w_arch_fire", use_container_width=True):
                    _execute_wealth_archetype("fire_decumulation", "FIRE / Decumulo")

        with w_col3:
            with st.container(border=True):
                badge_hnwi = " :green[**[● ATTIVO]**]" if active_code == "hnwi_family" else ""
                st.markdown(f"""
                **👑 HNWI / Famiglia**{badge_hnwi}
                - **Patrimonio**: €4.0M+ (Istituzionale)
                - **Conti**: Private Banking, Depositi, Broker
                - **Wealth**: Mutuo francese (€420k), orologi & oro, affitto, max pensione
                """, unsafe_allow_html=True)
                lbl_h = "Ricarica HNWI Famiglia" if active_code == "hnwi_family" else "Inietta HNWI Famiglia"
                if st.button(lbl_h, key="btn_w_arch_hnwi", use_container_width=True):
                    _execute_wealth_archetype("hnwi_family", "HNWI / Famiglia")

    src_options = [
        "🌐 Google Sheets — Sincronizzazione Veloce 2026 ('Expenses Tracker 2026' & 'Net Worth OGGI')",
        "🌐 Google Sheets — Archivio Storico Multi-Anno (2021 – 2026, oltre 4.000 transazioni)",
        "💳 Estratto Conto Bancario / CSV Spese (Intesa, Revolut, Fineco, N26, template)",
        "🏦 Saldi & Conti Bancari (CSV / Template)",
        "⌚ Caveau Orologi, Immobili & Metalli Preziosi (CSV / Template)",
        "🛡️ Piani Previdenziali & Fondi Pensione (CSV / Template)"
    ]
    
    src_selected_label = st.selectbox(
        "Sorgente Dati / Formato di Ingestione:",
        options=src_options,
        key="wealth_pipeline_src_selectbox"
    )

    uploaded_data_df = None
    target_account_id = None
    gsheet_name_val = "My All financial Statements"
    multi_years_val = [2021, 2022, 2023, 2024, 2025, 2026]
    is_ready_for_step2 = False

    st.markdown("<div style='margin-top: 10px;'></div>", unsafe_allow_html=True)

    if src_selected_label.startswith("🌐 Google Sheets — Sincronizzazione Veloce"):
        col_gq1, col_gq2 = st.columns([3, 1])
        with col_gq1:
            gsheet_name_val = st.text_input("Nome Spreadsheet Google Sheets:", value="My All financial Statements", key="pipe_gsheet_quick_name")
        with col_gq2:
            st.write("")
            st.write("")
            st.caption("✅ Lettura automatica di 'Expenses Tracker 2026'")
        is_ready_for_step2 = True

    elif src_selected_label.startswith("🌐 Google Sheets — Archivio Storico"):
        col_gm1, col_gm2 = st.columns([2.5, 2])
        with col_gm1:
            gsheet_name_val = st.text_input("Nome Spreadsheet Google Sheets:", value="My All financial Statements", key="pipe_gsheet_multi_name")
        with col_gm2:
            multi_years_val = st.multiselect(
                "Anni da sincronizzare:",
                options=[2021, 2022, 2023, 2024, 2025, 2026],
                default=[2021, 2022, 2023, 2024, 2025, 2026],
                key="pipe_gsheet_multi_years"
            )
        is_ready_for_step2 = bool(multi_years_val)

    elif src_selected_label.startswith("💳 Estratto Conto Bancario"):
        tcol1, tcol2 = st.columns([3, 1.5])
        with tcol1:
            if not df_accs.empty:
                acc_dict = {f"{r['name']} ({r['institution']}) — Saldo: {fmt_eur(r['balance'])}": r["account_id"] for _, r in df_accs.iterrows()}
                sel_acc_label = st.selectbox("Conto di Destinazione transazioni:", list(acc_dict.keys()), key="pipe_csv_cf_acc_select")
                target_account_id = acc_dict[sel_acc_label]
            else:
                st.warning("⚠️ Nessun conto bancario presente. Creane uno nella Tab 2 prima di importare transazioni.")
                target_account_id = None
        with tcol2:
            st.write("")
            if os.path.exists("data/wealth/template_cashflow_spese.csv"):
                with open("data/wealth/template_cashflow_spese.csv", "rb") as f:
                    st.download_button("📥 Scarica Template CSV", f, file_name="template_cashflow_spese.csv", mime="text/csv", use_container_width=True)

        uploaded_file = st.file_uploader("Carica Estratto Conto Bancario (.csv, .xlsx, .xls):", type=["csv", "xlsx", "xls"], key="pipe_up_cf")
        if uploaded_file and target_account_id:
            df_parsed, errs = parse_universal_statement(uploaded_file, uploaded_file.name)
            if errs:
                for e in errs: st.error(e)
            elif df_parsed is not None and not df_parsed.empty:
                is_val, val_errs, df_clean = validate_cashflow_df(df_parsed)
                if val_errs:
                    for ve in val_errs[:5]: st.warning(f"⚠️ {ve}")
                uploaded_data_df = auto_categorize_transactions(df_clean, engine)
                is_ready_for_step2 = True

    elif src_selected_label.startswith("🏦 Saldi & Conti"):
        tcol1, tcol2 = st.columns([3, 1.5])
        with tcol1:
            up_acc = st.file_uploader("Carica File Saldi Conti (.csv):", type=["csv"], key="pipe_up_accs")
        with tcol2:
            st.write("")
            if os.path.exists("data/wealth/template_conti_bancari.csv"):
                with open("data/wealth/template_conti_bancari.csv", "rb") as f:
                    st.download_button("📥 Scarica Template Conti", f, file_name="template_conti_bancari.csv", mime="text/csv", use_container_width=True)
        if up_acc:
            df_a_raw = pd.read_csv(up_acc)
            is_val, val_errs, df_a_clean = validate_accounts_df(df_a_raw)
            if not df_a_clean.empty:
                uploaded_data_df = df_a_clean
                is_ready_for_step2 = True

    elif src_selected_label.startswith("⌚ Caveau Orologi"):
        tcol1, tcol2 = st.columns([3, 1.5])
        with tcol1:
            up_phys = st.file_uploader("Carica File Orologi & Caveau (.csv):", type=["csv"], key="pipe_up_phys")
        with tcol2:
            st.write("")
            if os.path.exists("data/wealth/template_orologi_asset_fisici.csv"):
                with open("data/wealth/template_orologi_asset_fisici.csv", "rb") as f:
                    st.download_button("📥 Scarica Template Caveau", f, file_name="template_orologi_asset_fisici.csv", mime="text/csv", use_container_width=True)
        if up_phys:
            df_p_raw = pd.read_csv(up_phys)
            is_val, val_errs, df_p_clean = validate_physical_assets_df(df_p_raw)
            if not df_p_clean.empty:
                uploaded_data_df = df_p_clean
                is_ready_for_step2 = True

    elif src_selected_label.startswith("🛡️ Piani Previdenziali"):
        tcol1, tcol2 = st.columns([3, 1.5])
        with tcol1:
            up_pens = st.file_uploader("Carica File Previdenza & Pensione (.csv):", type=["csv"], key="pipe_up_pens")
        with tcol2:
            st.write("")
            if os.path.exists("data/wealth/template_fondi_pensione.csv"):
                with open("data/wealth/template_fondi_pensione.csv", "rb") as f:
                    st.download_button("📥 Scarica Template Pensione", f, file_name="template_fondi_pensione.csv", mime="text/csv", use_container_width=True)
        if up_pens:
            df_pen_raw = pd.read_csv(up_pens)
            is_val, val_errs, df_pen_clean = validate_pension_df(df_pen_raw)
            if not df_pen_clean.empty:
                uploaded_data_df = df_pen_clean
                is_ready_for_step2 = True

    st.divider()

    # ── STEP 2: ANTEPRIMA, VALIDAZIONE & PARAMETRI RUN ──────
    section("② Validazione Dati, Parametri Snapshot & Multi-Portafoglio")
    
    default_snap_label = f"Ingestione {src_selected_label.split('—')[0].strip()} · {datetime.now().strftime('%d/%m/%Y %H:%M')}"
    
    col_p1, col_p2, col_p3 = st.columns([2.5, 1.3, 2.2])
    with col_p1:
        run_snap_name = st.text_input("🏷️ Nome Snapshot / Ingestione:", value=default_snap_label, key="pipe_input_snap_name")
    with col_p2:
        run_snap_date = st.date_input("📅 Data Riferimento:", value=date.today(), key="pipe_input_snap_date")
    with col_p3:
        run_snap_notes = st.text_input("📝 Note Snapshot:", placeholder="es. Aggiornamento Q3, Chiusura mese...", key="pipe_input_snap_notes")

    # Anteprima Tabellare se file caricato
    if uploaded_data_df is not None and not uploaded_data_df.empty:
        st.markdown(f"**📋 Anteprima Dati Riconosciuti ({len(uploaded_data_df)} Record):**")
        st.dataframe(uploaded_data_df.head(8), use_container_width=True, hide_index=True)
    elif src_selected_label.startswith("🌐 Google Sheets"):
        st.info("ℹ️ I dati verranno estratti, validati e categorizzati direttamente dalle schede dello spreadsheet durante l'esecuzione.")

    # ── SEZIONE MULTI-PORTAFOGLIO RISK ──────────────────────
    st.markdown("<div style='margin-top: 14px;'></div>", unsafe_allow_html=True)
    st.markdown("##### 🔗 Multi-Portafoglio Risk Analytics (Investimenti Finanziari)")
    st.caption("Seleziona uno o più portafogli dal modulo Risk per aggregare e consolidare il controvalore di azioni, ETF, obbligazioni e crypto nel Net Worth:")

    currently_linked_risk = get_linked_risk_portfolios(engine, wealth_portfolio_id=current_pid)
    df_avail_risk = get_available_risk_portfolios(engine, exclude_wealth_portfolio_id=current_pid)


    if df_avail_risk.empty:
        st.info("ℹ️ Nessun portafoglio calcolato presente nel database collegato. Vai nel modulo Risk Analytics per importare e calcolare i tuoi titoli.")
    else:
        risk_opt_map = {
            int(r["portfolio_id"]): f"ID #{r['portfolio_id']} · {r['name']} — {fmt_eur(r['latest_value'])}"
            for _, r in df_avail_risk.iterrows()
        }
        all_risk_ids = list(risk_opt_map.keys())

        # Bottoni Rapidi Selezione Multi-Portafoglio
        col_m_all, col_m_none, col_m_space = st.columns([1.8, 1.8, 2.4])
        with col_m_all:
            if st.button("🌟 Seleziona Tutti (Multi-Portafoglio)", type="secondary", use_container_width=True, key=f"btn_sel_all_risk_{current_pid}"):
                set_linked_risk_portfolios(engine, current_pid, all_risk_ids)
                st.rerun()
        with col_m_none:
            if st.button("🚫 Solo Transazionale (€ 0,00)", type="secondary", use_container_width=True, key=f"btn_sel_none_risk_{current_pid}"):
                set_linked_risk_portfolios(engine, current_pid, [])
                st.rerun()

        def_linked = [pid for pid in currently_linked_risk if pid in risk_opt_map]
        
        pipe_sel_risk = st.multiselect(
            "Portafogli Risk Analytics selezionati per questo Profilo:",
            options=all_risk_ids,
            format_func=lambda x: risk_opt_map[x],
            default=def_linked,
            key=f"pipe_risk_multisel_{current_pid}",
            help="Puoi selezionare più portafogli per calcolare il controvalore complessivo aggregato."
        )
        
        if sorted(pipe_sel_risk) != sorted(currently_linked_risk):
            set_linked_risk_portfolios(engine, current_pid, pipe_sel_risk)

        # Statistiche Multi-Portafoglio in tempo reale
        tot_risk_val_live, df_linked_live = get_linked_risk_portfolios_summary(engine, wealth_portfolio_id=current_pid)
        if not df_linked_live.empty:
            df_disp_live = df_linked_live.copy()
            df_disp_live["Peso (%)"] = (df_disp_live["latest_value"] / tot_risk_val_live * 100.0) if tot_risk_val_live > 0 else 0.0
            
            st.markdown(f"""
            <div style="background: rgba(99, 102, 241, 0.08); border: 1px solid rgba(99, 102, 241, 0.3); border-radius: 8px; padding: 10px 16px; margin: 8px 0 14px 0; display:flex; justify-content:space-between; align-items:center;">
                <span style="font-weight:700; color:#818cf8; font-size:13px;">💼 Multi-Portafoglio Consolidato: {len(df_disp_live)} Portafogli Collegati</span>
                <span style="font-size:14px; font-weight:800; color:#ffffff; font-family:'JetBrains Mono', monospace;">Totale Investimenti: {fmt_eur(tot_risk_val_live)}</span>
            </div>
            """, unsafe_allow_html=True)
            
            st.dataframe(
                df_disp_live[["portfolio_id", "name", "base_currency", "last_calc_date", "latest_value", "Peso (%)"]].rename(columns={
                    "portfolio_id": "ID Portafoglio",
                    "name": "Nome Portafoglio",
                    "base_currency": "Valuta",
                    "last_calc_date": "Ultimo Snapshot",
                    "latest_value": "Valore (€)",
                    "Peso (%)": "Peso (%)"
                }),
                use_container_width=True,
                hide_index=True
            )
        else:
            st.caption("💳 Nessun portafoglio Risk collegato: Profilo impostato come 'Solo Transazionale' (Investimenti = € 0,00).")

    st.markdown("<div style='margin-bottom: 24px;'></div>", unsafe_allow_html=True)
    st.divider()


    # ── STEP 3: ESEGUI INGESTIONE & AUTO-SNAPSHOT ────────────
    section("③ Esecuzione Pipeline & Generazione Snapshot")

    # 1. Deck di Riepilogo Configurazione Pre-Esecuzione
    p_name_cur = profile_map.get(current_pid, f"Profilo #{current_pid}")
    tot_risk_disp = fmt_eur(tot_risk_val_live) if tot_risk_val_live > 0 else "€ 0,00 (Solo Transazionale)"
    risk_ports_cnt_str = f"{len(df_linked_live)} Portafogli ({tot_risk_disp})" if not df_linked_live.empty else "Nessuno (Solo Cassa & Conti)"

    st.markdown(f"""
    <div style="background: rgba(13, 17, 23, 0.75); border: 1px solid rgba(255, 153, 0, 0.25); border-radius: 12px; padding: 16px 20px; margin-bottom: 18px;">
        <div style="font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.8px; color: #ff9900; margin-bottom: 10px;">
            ⚡ Riepilogo Configurazione Pipeline Pronta per il Calcolo
        </div>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 12px; font-size: 13px;">
            <div>
                <span style="color: #8b949e;">📁 Profilo Destinazione:</span><br/>
                <b style="color: #ffffff;">{p_name_cur}</b> <span style="color: #ff9900; font-size: 11px;">(ID #{current_pid})</span>
            </div>
            <div>
                <span style="color: #8b949e;">📥 Sorgente Dati:</span><br/>
                <b style="color: #ffffff;">{src_selected_label.split('(')[0].strip()}</b>
            </div>
            <div>
                <span style="color: #8b949e;">💼 Multi-Portafoglio Risk:</span><br/>
                <b style="color: #60a5fa;">{risk_ports_cnt_str}</b>
            </div>
            <div>
                <span style="color: #8b949e;">📸 Snapshot Risultante:</span><br/>
                <b style="color: #10b981;">{run_snap_name}</b> <span style="color: #8b949e; font-size: 11px;">({run_snap_date})</span>
            </div>
        </div>
    </div>
    """, unsafe_allow_html=True)

    col_btn_run, col_btn_nw = st.columns([2.5, 1.5])
    with col_btn_run:
        btn_run_pipeline = st.button(
            "🚀 ESEGUI INGESTIONE & GENERA SNAPSHOT PATRIMONIALE",
            type="primary",
            use_container_width=True,
            disabled=not is_ready_for_step2,
            key="btn_run_wealth_pipeline_master"
        )
    with col_btn_nw:
        if st.button("🏛️ Vai al Patrimonio & Net Worth →", type="secondary", use_container_width=True, key="btn_goto_nw_from_pipe"):
            st.switch_page("pages/13_🏛️_Patrimonio_e_NetWorth.py")

    if not is_ready_for_step2:
        st.caption("ℹ️ Completa lo **Step ①** (carica il file o verifica lo spreadsheet) per abilitare l'esecuzione.")

    if btn_run_pipeline:
        with st.status("🚀 Esecuzione Pipeline Wealth & Consolidamento in corso...", expanded=True) as status_box:
            s_id = None
            tot_synced_cnt = 0
            
            st.write("📡 **Fase 1/4**: Connessione e lettura della sorgente dati...")
            if src_selected_label.startswith("🌐 Google Sheets — Sincronizzazione Veloce"):
                sync_res = sync_expenses_tracker_2026_from_gsheets(
                    engine,
                    spreadsheet_name=gsheet_name_val,
                    worksheet_name="Expenses Tracker 2026",
                    portfolio_id=current_pid
                )
                tot_synced_cnt = sync_res.get("total_transactions_synced", 0)
                s_id = sync_res.get("snapshot_id")

            elif src_selected_label.startswith("🌐 Google Sheets — Archivio Storico"):
                sync_res = sync_all_historical_expenses_from_gsheets(
                    engine,
                    spreadsheet_name=gsheet_name_val,
                    years=multi_years_val,
                    portfolio_id=current_pid
                )
                tot_synced_cnt = sync_res.get("total_transactions_synced", 0)
                s_id = sync_res.get("snapshot_id")

            elif src_selected_label.startswith("💳 Estratto Conto Bancario"):
                st.write("📊 **Fase 2/4**: Categorizzazione semantica transazioni ed eliminazione duplicati...")
                tot_synced_cnt = bulk_import_statement(engine, target_account_id, uploaded_data_df, portfolio_id=current_pid)
                st.write("🏦 **Fase 3/4**: Consolidamento saldi e patrimonio...")
                s_id = save_wealth_snapshot_to_db(
                    engine,
                    run_name=run_snap_name,
                    notes=run_snap_notes,
                    snapshot_date_val=run_snap_date,
                    portfolio_id=current_pid
                )

            elif src_selected_label.startswith("🏦 Saldi & Conti"):
                st.write("🏦 **Fase 2/4**: Aggiornamento saldi bancari...")
                for _, row in uploaded_data_df.iterrows():
                    r_dict = row.to_dict()
                    r_dict["portfolio_id"] = current_pid
                    save_wealth_account(engine, r_dict)
                tot_synced_cnt = len(uploaded_data_df)
                st.write("📸 **Fase 3/4**: Calcolo Patrimonio Netto...")
                s_id = save_wealth_snapshot_to_db(
                    engine,
                    run_name=run_snap_name,
                    notes=run_snap_notes,
                    snapshot_date_val=run_snap_date,
                    portfolio_id=current_pid
                )

            elif src_selected_label.startswith("⌚ Caveau Orologi"):
                st.write("⌚ **Fase 2/4**: Censimento asset fisici e orologi...")
                for _, row in uploaded_data_df.iterrows():
                    r_dict = row.to_dict()
                    r_dict["portfolio_id"] = current_pid
                    save_physical_asset(engine, r_dict)
                tot_synced_cnt = len(uploaded_data_df)
                st.write("📸 **Fase 3/4**: Aggiornamento Snapshot...")
                s_id = save_wealth_snapshot_to_db(
                    engine,
                    run_name=run_snap_name,
                    notes=run_snap_notes,
                    snapshot_date_val=run_snap_date,
                    portfolio_id=current_pid
                )

            elif src_selected_label.startswith("🛡️ Piani Previdenziali"):
                st.write("🛡️ **Fase 2/4**: Aggiornamento piani previdenziali...")
                for _, row in uploaded_data_df.iterrows():
                    r_dict = row.to_dict()
                    r_dict["portfolio_id"] = current_pid
                    save_pension_plan(engine, r_dict)
                tot_synced_cnt = len(uploaded_data_df)
                st.write("📸 **Fase 3/4**: Aggiornamento Snapshot...")
                s_id = save_wealth_snapshot_to_db(
                    engine,
                    run_name=run_snap_name,
                    notes=run_snap_notes,
                    snapshot_date_val=run_snap_date,
                    portfolio_id=current_pid
                )

            st.write(f"📸 **Fase 4/4**: Generazione Snapshot #{s_id} e ricalcolo indici 50/30/20...")
            status_box.update(label="🎉 Pipeline completata con successo!", state="complete", expanded=False)

            if "sync_res" in locals() and isinstance(sync_res, dict):
                fb_payload = dict(sync_res)
                fb_payload["status"] = "success"
                fb_payload["snapshot_id"] = s_id
                fb_payload["snapshot_name"] = sync_res.get("snapshot_name") or run_snap_name
                fb_payload["total_transactions_synced"] = tot_synced_cnt
                fb_payload["total_records"] = tot_synced_cnt
                st.session_state["wealth_sync_feedback"] = fb_payload
            else:
                st.session_state["wealth_sync_feedback"] = {
                    "status": "success",
                    "snapshot_id": s_id,
                    "snapshot_name": run_snap_name,
                    "total_transactions_synced": tot_synced_cnt,
                    "total_records": tot_synced_cnt,
                    "accounts_count": len(df_accs) if not df_accs.empty else 6,
                    "accounts_list": df_accs["name"].tolist() if not df_accs.empty else []
                }
            st.rerun()





# =============================================================
# TAB 2: GESTIONE CONTI, PORTAFOGLI RISK & CATEGORIE
# =============================================================
elif active_cr_tab == "⚙️ Gestione Conti & Categorie":
    subtab_accs, tab_risk_sub, subtab_cats = st.tabs([
        "🏦 Anagrafica Conti Bancari",
        "🔗 Portafogli Risk Analytics",
        "🏷️ Categorie & Regola 50/30/20"
    ])

    # ── SUBTAB A: ANAGRAFICA CONTI ──────────────────────────
    with subtab_accs:
        tab_acc_c1, tab_acc_c2 = st.columns([3, 1.2])
        with tab_acc_c1:
            st.markdown(f"##### 🏦 Conti Bancari del Profilo '{profile_map.get(current_pid, 'Principale')}'")
            st.caption("Visualizza i saldi correnti, gestisci l'IBAN e attiva/disattiva conti.")
        with tab_acc_c2:
            with st.popover("➕ Aggiungi Conto", use_container_width=True):
                st.markdown("##### ➕ Nuovo Conto Bancario")
                with st.form("form_new_acc_tab2"):
                    n_name = st.text_input("Nome Conto *", placeholder="es. Intesa Sanpaolo")
                    n_inst = st.text_input("Istituto / Banca *", placeholder="es. Intesa Sanpaolo, Revolut")
                    n_type = st.selectbox("Tipo di Conto *", [
                        ("checking", "Conto Corrente"),
                        ("savings", "Conto Deposito"),
                        ("emergency_fund", "Fondo Emergenza"),
                        ("credit_card", "Carta di Credito (Passività)"),
                        ("loan", "Prestito Personale (Passività)"),
                        ("mortgage", "Mutuo Casa (Passività)"),
                        ("brokerage_cash", "Liquidità Broker / Titoli")
                    ], format_func=lambda x: x[1])
                    n_bal = st.number_input("Saldo Attuale (€) *", value=0.0, step=100.0)
                    n_iban = st.text_input("IBAN (Opzionale)")
                    n_notes = st.text_input("Note")
                    
                    if st.form_submit_button("Salva Conto", type="primary"):
                        if n_name and n_inst:
                            save_wealth_account(engine, {
                                "portfolio_id": current_pid,
                                "name": n_name,
                                "institution": n_inst,
                                "account_type": n_type[0],
                                "balance": n_bal,
                                "iban": n_iban,
                                "notes": n_notes,
                                "is_active": 1
                            })
                            st.success(f"Conto '{n_name}' salvato con successo!")
                            st.rerun()

        df_accs_view = get_wealth_accounts(engine, portfolio_id=current_pid)
        if not df_accs_view.empty:
            st.dataframe(
                df_accs_view[["account_id", "name", "institution", "account_type", "currency", "balance", "iban", "is_active"]].rename(columns={
                    "account_id": "ID",
                    "name": "Nome Conto",
                    "institution": "Banca / Istituto",
                    "account_type": "Tipo",
                    "currency": "Valuta",
                    "balance": "Saldo Attuale (€)",
                    "iban": "IBAN",
                    "is_active": "Attivo"
                }),
                use_container_width=True,
                hide_index=True
            )

            with st.expander("✏️ Gestisci / Elimina / Disattiva Singolo Conto"):
                acc_options = {r["account_id"]: f"{r['name']} ({r['institution']}) — Saldo: €{r['balance']:,.2f}" for _, r in df_accs_view.iterrows()}
                sel_del_id = st.selectbox("Seleziona Conto da Modificare:", options=list(acc_options.keys()), format_func=lambda x: acc_options[x], key="sel_mod_acc_tab2")
                
                dc1, dc2 = st.columns(2)
                with dc1:
                    if st.button("🗑️ Elimina Definitivamente Conto", type="primary", use_container_width=True, key="btn_confirm_del_acc_tab2"):
                        from core.confirm_dialogs import confirm_delete_wealth_account_dialog

                        acc_match = df_accs_view[df_accs_view["account_id"] == sel_del_id]
                        acc_row_del = acc_match.iloc[0] if not acc_match.empty else {}
                        confirm_delete_wealth_account_dialog(
                            engine,
                            sel_del_id,
                            str(acc_row_del.get("name", f"Conto #{sel_del_id}")),
                            str(acc_row_del.get("institution", "")),
                            float(acc_row_del.get("balance", 0.0)),
                        )
                with dc2:
                    is_currently_active = bool(df_accs_view[df_accs_view["account_id"] == sel_del_id]["is_active"].iloc[0])
                    toggle_label = "⏸️ Disattiva Conto" if is_currently_active else "▶️ Riattiva Conto"
                    if st.button(toggle_label, use_container_width=True, key="btn_toggle_active_acc_tab2"):
                        acc_row = df_accs_view[df_accs_view["account_id"] == sel_del_id].iloc[0]
                        save_wealth_account(engine, {
                            "account_id": sel_del_id,
                            "portfolio_id": current_pid,
                            "name": acc_row["name"],
                            "institution": acc_row["institution"],
                            "account_type": acc_row["account_type"],
                            "balance": float(acc_row["balance"]),
                            "is_active": 0 if is_currently_active else 1,
                            "iban": acc_row.get("iban"),
                            "notes": str(acc_row.get("notes", ""))
                        })
                        st.info(f"Stato conto #{sel_del_id} aggiornato.")
                        st.rerun()
        else:
            st.info("Nessun conto bancario censito in questo profilo.")

    # ── SUBTAB B: PORTAFOGLI RISK ANALYTICS ─────────────────
    with tab_risk_sub:
        st.markdown(f"##### 🔗 Portafogli Risk Analytics Collegati al Profilo '{profile_map.get(current_pid, 'Principale')}'")
        st.caption("Collega uno o più portafogli titoli, ETF o crypto del modulo Risk per sommare il loro controvalore agli investimenti finanziari del Net Worth.")

        df_risk_avail = get_available_risk_portfolios(engine, exclude_wealth_portfolio_id=current_pid)
        currently_linked_ids = get_linked_risk_portfolios(engine, wealth_portfolio_id=current_pid)


        if df_risk_avail.empty:
            st.info("ℹ️ Nessun portafoglio censito nel database collegato. Vai nella **Control Room del Rischio** per importare il tuo primo portafoglio titoli o crypto!")
        else:
            risk_options = {}
            for _, r in df_risk_avail.iterrows():
                pid = int(r["portfolio_id"])
                p_val = float(r["latest_value"])
                dt_calc = str(r["last_calc_date"]) if pd.notnull(r["last_calc_date"]) else "Nessun calcolo"
                risk_options[pid] = f"ID #{pid} · {r['name']} — Valore: {fmt_eur(p_val)} (Ultimo: {dt_calc})"

            has_active_links = len(currently_linked_ids) > 0
            profile_mode_choice = st.radio(
                "Modalità Operativa Investimenti per questo Profilo:",
                [
                    ("transational_only", "🚫 Solo Transazionale & Cassa (Nessun portafoglio titoli / Investimenti = € 0,00)"),
                    ("linked_risk", "🔗 Profilo con Investimenti (Collega uno o più portafogli dal modulo Risk Analytics)")
                ],
                format_func=lambda x: x[1],
                index=1 if has_active_links else 0,
                key=f"wealth_mgmt_profile_mode_radio_{current_pid}"
            )

            if profile_mode_choice[0] == "transational_only":
                st.markdown("""
                <div style="background: rgba(16, 185, 129, 0.08); border: 1px solid rgba(16, 185, 129, 0.3); border-radius: 10px; padding: 14px 18px; margin: 12px 0;">
                    <span style="font-weight:700; color:#34d399; font-size:13.5px;">💳 Modalità Solo Transazionale Attiva</span>
                    <p style="font-size:12px; color:#94a3b8; margin: 6px 0 0 0;">
                        Questo profilo gestisce unicamente flussi di spesa/entrata, liquidità e 50/30/20. Gli investimenti finanziari restano a € 0,00.
                    </p>
                </div>
                """, unsafe_allow_html=True)
                if has_active_links:
                    if st.button("🚫 Conferma e Scollega Portafogli Risk", type="primary", key=f"btn_confirm_trans_mgmt_{current_pid}"):
                        set_linked_risk_portfolios(engine, current_pid, [])
                        st.success("✅ Profilo impostato in modalità Solo Transazionale!")
                        st.rerun()
            else:
                default_selected = [pid for pid in currently_linked_ids if pid in risk_options]
                col_sel_r, col_save_r = st.columns([3.2, 1.8])
                with col_sel_r:
                    selected_risk_pids = st.multiselect(
                        "Seleziona i Portafogli Risk da collegare:",
                        options=list(risk_options.keys()),
                        format_func=lambda x: risk_options[x],
                        default=default_selected,
                        key=f"wealth_risk_mgmt_multisel_{current_pid}"
                    )
                with col_save_r:
                    st.write("")
                    st.write("")
                    bcol1, bcol2 = st.columns(2)
                    with bcol1:
                        if st.button("💾 Salva Link", type="primary", use_container_width=True, key=f"btn_save_risk_mgmt_{current_pid}"):
                            set_linked_risk_portfolios(engine, current_pid, selected_risk_pids)
                            st.success(f"✅ Collegati {len(selected_risk_pids)} portafogli Risk!")
                            st.rerun()
                    with bcol2:
                        if st.button("🗑️ Scollega", type="secondary", use_container_width=True, key=f"btn_clear_risk_mgmt_{current_pid}"):
                            from core.confirm_dialogs import confirm_unlink_risk_portfolio_dialog

                            confirm_unlink_risk_portfolio_dialog(engine, current_pid)

                tot_risk_val, df_linked_summary = get_linked_risk_portfolios_summary(engine, wealth_portfolio_id=current_pid)
                st.markdown(f"##### 📊 Investimenti Consolidati: **{fmt_eur(tot_risk_val)}**")
                if not df_linked_summary.empty:
                    df_disp_link = df_linked_summary.copy()
                    df_disp_link["Peso (%)"] = (df_disp_link["latest_value"] / tot_risk_val * 100.0) if tot_risk_val > 0 else 0.0
                    st.dataframe(
                        df_disp_link[["portfolio_id", "name", "base_currency", "last_calc_date", "latest_value", "Peso (%)"]].rename(columns={
                            "portfolio_id": "ID Portafoglio Risk",
                            "name": "Nome Portafoglio",
                            "base_currency": "Valuta",
                            "last_calc_date": "Ultimo Snapshot Calcolato",
                            "latest_value": "Controvalore (€)",
                            "Peso (%)": "Peso su Investimenti (%)"
                        }),
                        use_container_width=True,
                        hide_index=True
                    )

    # ── SUBTAB C: CATEGORIE 50/30/20 ─────────────────────────
    with subtab_cats:
        st.markdown("##### 🏷️ Categorie Standard & Regola 50/30/20")
        st.caption("Tutte le spese ed entrate sono mappate semanticamente secondo il framework di pianificazione finanziaria istituzionale:")

        r_c1, r_c2, r_c3 = st.columns(3)
        with r_c1:
            st.markdown("""
            <div style="background: rgba(239, 68, 68, 0.1); border: 1px solid rgba(239, 68, 68, 0.3); border-radius: 12px; padding: 14px;">
                <b style="color: #f87171;">🔴 50% — Bisogni Primari (Needs)</b><br>
                <span style="font-size:12px; color:#cbd5e1;">Spese essenziali non negoziabili: Casa, Affitto, Utenze, Spesa Supermercato, Trasporti, Tasse e Salute.</span>
            </div>
            """, unsafe_allow_html=True)
        with r_c2:
            st.markdown("""
            <div style="background: rgba(245, 158, 11, 0.1); border: 1px solid rgba(245, 158, 11, 0.3); border-radius: 12px; padding: 14px;">
                <b style="color: #fbbf24;">🟡 30% — Desideri & Stile di Vita (Wants)</b><br>
                <span style="font-size:12px; color:#cbd5e1;">Spese discrezionali: Ristoranti, Viaggi, Shopping, Abbonamenti, Svago e Tempo Libero.</span>
            </div>
            """, unsafe_allow_html=True)
        with r_c3:
            st.markdown("""
            <div style="background: rgba(16, 185, 129, 0.1); border: 1px solid rgba(16, 185, 129, 0.3); border-radius: 12px; padding: 14px;">
                <b style="color: #34d399;">🟢 20% — Risparmio & Investimenti (Savings)</b><br>
                <span style="font-size:12px; color:#cbd5e1;">Accantonamenti patrimoniali: Investimenti Titoli/ETF, Criptovalute, Fondo Pensione e Fondo Emergenza.</span>
            </div>
            """, unsafe_allow_html=True)

        st.markdown("<br>", unsafe_allow_html=True)
        df_cats = get_wealth_categories(engine)
        if not df_cats.empty:
            st.dataframe(
                df_cats[["category_id", "icon", "name", "flow_type", "nature", "color", "is_system"]].rename(columns={
                    "category_id": "ID",
                    "icon": "Icona",
                    "name": "Nome Categoria",
                    "flow_type": "Flusso (Entrata/Uscita)",
                    "nature": "Natura 50/30/20",
                    "color": "Colore",
                    "is_system": "Sistema"
                }),
                use_container_width=True,
                hide_index=True
            )

# =============================================================
# TAB 3: HUB DI REPORTISTICA ED ESPORTAZIONI ISTITUZIONALI
# =============================================================
else:
    render_wealth_reporting_and_exports_hub(
        engine=engine,
        portfolio_id=current_pid,
        prof_name=profile_map.get(current_pid, "Principale")
    )

