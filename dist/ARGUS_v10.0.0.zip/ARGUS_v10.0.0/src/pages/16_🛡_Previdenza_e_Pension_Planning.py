# ============================================================
# src/pages/16_🛡️_Previdenza_e_Pension_Planning.py
# ARGUS Wealth Management — Pension Planning & Tax Optimization
# ============================================================

import importlib
import json
from datetime import datetime

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

import core.ui_utils

importlib.reload(core.ui_utils)

from core.fetcher import get_engine
from core.sidebar import render_sidebar
from core.ui_lifecycle import teardown_view_state
from core.ui_utils import (
    apply_plotly_theme,
    ensure_portal_context,
    ensure_portfolio_loaded,
    fmt_eur,
    fmt_pct,
    inject_custom_css,
    metric_card,
    render_institutional_telemetry_ribbon,
    render_omni_command_bar,
    render_segmented_tabs,
    render_sr117_audit_drawer,
    render_standard_hero,
    render_wealth_command_bar,
    render_wealth_executive_badges,
    render_wealth_telemetry_ribbon,
    section,
)
from core.wealth import (
    compute_consolidated_net_worth,
    get_pension_plans,
    get_wealth_portfolios,
    init_wealth_db,
    save_pension_plan,
    simulate_pension_projection,
)
from core.wealth.wealth_modals import render_goal_methodology_modal

st.set_page_config(page_title="Previdenza & Pensione | ARGUS Wealth", page_icon="🛡️", layout="wide")

ctx = ensure_portal_context(module="wealth")
ensure_portfolio_loaded(module_type="wealth")
engine = ctx["engine"]
current_pid = ctx["portfolio_id"]
prof_title = ctx["profile_name"]
prof_map = ctx["profile_map"]
nw_curr = ctx["net_worth"]

if current_pid is None:
    render_omni_command_bar(portal="wealth", context_name="Nessun Profilo", key_suffix="p16")
    from core.ui_utils import render_wealth_profile_picker
    render_wealth_profile_picker(engine, prof_map, key_prefix="p16_picker")
    st.stop()

# ── ATOMIC STATE TEARDOWN ───────────────────────────────────
teardown_view_state(current_pid, active_page="16_Previdenza_e_Pension_Planning")

render_omni_command_bar(portal="wealth", context_name=prof_title, key_suffix="p16")
render_wealth_telemetry_ribbon(nw_summary=nw_curr, page_badge="PREVIDENZA & PENSION PLANNING", profile_name=prof_title)
render_wealth_executive_badges(nw_curr)

render_standard_hero(
    title="Previdenza & Pensione Integrativa",
    subtitle="Ottimizzazione fiscale art. 51 TUIR (€ 5.164,57), simulazione Monte Carlo e montante pensionistico.",
    icon="🛡️",
    profile_map=prof_map,
    current_pid=current_pid,
    dialog_callback=render_goal_methodology_modal,
    dialog_btn_label="ℹ️ Guida Previdenza",
)

df_plans = get_pension_plans(engine, portfolio_id=current_pid)

# Calcoli aggregati
tot_pension_val = float(df_plans["accumulated_value"].sum()) if not df_plans.empty else 0.0
tot_monthly_contrib = float((df_plans["monthly_employee_contrib"] + df_plans["monthly_employer_contrib"]).sum()) if not df_plans.empty else 0.0
annual_deductible = float(df_plans["tax_deductible_annual"].sum()) if not df_plans.empty else (tot_monthly_contrib * 12.0)
MAX_TAX_DEDUCTION = 5164.57
tax_shield_used_pct = min(100.0, (annual_deductible / MAX_TAX_DEDUCTION) * 100.0)

# ── TOP KPI ROW ─────────────────────────────────────────────
c1, c2, c3, c4 = st.columns(4)
with c1:
    metric_card("Montante Accumulato", fmt_eur(tot_pension_val), delta="Valore Attuale Fondi", delta_color="normal")
with c2:
    metric_card("Versamento Mensile Totale", fmt_eur(tot_monthly_contrib), delta="Lavoratore + Datore", delta_color="normal")
with c3:
    metric_card("Deducibilità Utilizzata", f"{tax_shield_used_pct:.1f}%", delta=f"{fmt_eur(annual_deductible)} / {fmt_eur(MAX_TAX_DEDUCTION)}", delta_color="normal")
with c4:
    tax_savings = annual_deductible * 0.43  # Aliquota marginale IRPEF stimata 43%
    metric_card("Risparmio Fiscale IRPEF", fmt_eur(tax_savings), delta="All'anno (Aliq. 43%)", delta_color="normal")

st.divider()

# ── SELETTORE MODULI PREVIDENZA STILE BLOOMBERG TERMINAL ───────
WEALTH_PENSION_MODELS_CATALOG = {
    "📋 Piani Attivi & Scudo Fiscale": {
        "title": "Piani Pensionistici Attivi & Scudo Fiscale Art. 51 TUIR",
        "badge": "Pillar II & III • Deducibilità €5.164 • Cronistoria",
        "badge_color": "#3b82f6",
        "category": "Previdenza Integrativa",
        "desc": "Monitoraggio dei fondi pensione attivi, calcolo del plafond deducibile residuo (€ 5.164,57 annui) e cronistoria pluriennale dei versamenti con risparmio IRPEF.",
    },
    "🎲 Simulatore Monte Carlo & Cono Evolutivo": {
        "title": "Simulatore Stocastico Monte Carlo & Rendita Vitalizia",
        "badge": "Monte Carlo • Percentili P10/P50/P90 • Annuity",
        "badge_color": "#10b981",
        "category": "Simulazione Attuariale",
        "desc": "Proiezione stocastica del montante pensionistico a scadenza, cono di confidenza (P10, P50, P90), guadagno da capitalizzazione composta e stima della rendita mensile vitalizia.",
    },
    "➕ Censimento & Gestione Fondi": {
        "title": "Registrazione Nuovo Fondo Pensione / PIP / TFR",
        "badge": "Onboarding • PIP • FPA • TFR",
        "badge_color": "#f59e0b",
        "category": "Anagrafica Piani",
        "desc": "Interfaccia guidata per censire nuovi fondi negoziali di categoria, fondi pensione aperti, piani individuali pensionistici (PIP) o TFR accantonato in azienda.",
    },
}

active_pension_tab = render_segmented_tabs(
    WEALTH_PENSION_MODELS_CATALOG,
    key="wealth_pension_active_tab",
    select_label="Seleziona Modulo Previdenza:",
)

type_map = {
    "fondo_pensione_aperto": "Fondo Pensione Aperto (FPA)",
    "fondo_negoziale_chiuso": "Fondo Negoziale di Categoria",
    "pip_individuale": "PIP (Piano Individuale Pensionistico)",
    "tfr_in_azienda": "TFR Accantonato in Azienda",
    "gestione_separata": "Gestione Separata Assicurativa",
}

# ── 1. PIANI ATTIVI & SCUDO FISCALE ────────────────────────
if active_pension_tab == "📋 Piani Attivi & Scudo Fiscale":
    section("📋 Piani Pensionistici Attivi & Scudo Fiscale (Art. 51 TUIR)")

    if not df_plans.empty:
        for _, p in df_plans.iterrows():
            p_name = p.get("plan_name", "Fondo Pensione Integrativo")
            provider = p.get("provider", "GSheets")
            p_type_code = p.get("plan_type", "fondo_pensione_aperto")
            p_type_label = type_map.get(p_type_code, p_type_code.replace("_", " ").title())
            inv_line = p.get("investment_line", "Azionario / Crescita")

            acc_val = float(p.get("accumulated_value", 0.0) or 0.0)
            m_emp = float(p.get("monthly_employee_contrib", 0.0) or 0.0)
            m_comp = float(p.get("monthly_employer_contrib", 0.0) or 0.0)
            m_tot = m_emp + m_comp
            annual_ded = float(p.get("tax_deductible_annual", 0.0) or (m_tot * 12.0))
            rem_cap = max(0.0, MAX_TAX_DEDUCTION - annual_ded)
            tax_pot_saving = rem_cap * 0.43

            st.markdown(
                f"""
            <div style="background:rgba(22,27,34,0.85); border:1px solid rgba(255,255,255,0.08); border-left:4px solid #3b82f6; border-radius:10px; padding:18px 22px; margin-bottom:16px;">
                <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px; margin-bottom:14px;">
                    <div>
                        <div style="font-size:18px; font-weight:700; color:#ffffff; margin-bottom:4px;">🛡️ {p_name}</div>
                        <div style="display:flex; flex-wrap:wrap; gap:6px;">
                            <span style="background:rgba(59,130,246,0.15); border:1px solid rgba(59,130,246,0.3); padding:3px 8px; border-radius:4px; font-size:11px; color:#60a5fa;">🏛️ {provider}</span>
                            <span style="background:rgba(255,255,255,0.06); border:1px solid rgba(255,255,255,0.12); padding:3px 8px; border-radius:4px; font-size:11px; color:#c9d1d9;">📜 {p_type_label}</span>
                            <span style="background:rgba(16,185,129,0.15); border:1px solid rgba(16,185,129,0.3); padding:3px 8px; border-radius:4px; font-size:11px; color:#34d399;">📈 {inv_line}</span>
                        </div>
                    </div>
                    <div style="display:flex; gap:20px; align-items:center;">
                        <div style="text-align:right;">
                            <div style="font-size:11px; font-weight:600; color:#8b949e; text-transform:uppercase; letter-spacing:0.5px;">Montante Accumulato</div>
                            <div style="font-size:20px; font-weight:700; color:#ffffff;">{fmt_eur(acc_val)}</div>
                        </div>
                        <div style="text-align:right;">
                            <div style="font-size:11px; font-weight:600; color:#8b949e; text-transform:uppercase; letter-spacing:0.5px;">Versamento Mensile</div>
                            <div style="font-size:20px; font-weight:700; color:#38bdf8;">{fmt_eur(m_tot)}<span style="font-size:12px; color:#8b949e;">/m</span></div>
                        </div>
                    </div>
                </div>
                <div style="background:rgba(0,0,0,0.25); border-radius:8px; padding:12px 16px;">
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px;">
                        <span style="font-size:12px; color:#c9d1d9; font-weight:600;">Deducibilità IRPEF Utilizzata (Esercizio {datetime.now().year}): <b style="color:#ffffff;">{fmt_eur(annual_ded)} / {fmt_eur(MAX_TAX_DEDUCTION)}</b> ({tax_shield_used_pct:.1f}%)</span>
                        <span style="font-size:11.5px; color:#34d399;">Risparmio Fiscale Immediato: <b>{fmt_eur(annual_ded * 0.43)}</b></span>
                    </div>
                    <div style="background:rgba(255,255,255,0.08); border-radius:4px; height:8px; overflow:hidden; margin-bottom:8px;">
                        <div style="background:#3b82f6; width:{min(100.0, tax_shield_used_pct)}%; height:100%; border-radius:4px;"></div>
                    </div>
                    <div style="font-size:11.5px; color:#8b949e;">
                        💡 <i>Plafond residuo deducibile: <b style="color:#ffffff;">{fmt_eur(rem_cap)}</b> entro il 31/12. Versando l'intero importo residuo otterresti un ulteriore rimborso IRPEF di <b style="color:#34d399;">{fmt_eur(tax_pot_saving)}</b>.</i>
                    </div>
                </div>
            </div>
            """,
                unsafe_allow_html=True,
            )

            yearly_json = p.get("yearly_data_json")
            if yearly_json:
                try:
                    yd = json.loads(yearly_json) if isinstance(yearly_json, str) else yearly_json
                    hist_rows = []
                    for yr_k, yr_info in sorted(yd.items()):
                        tot_y = yr_info.get("tot_year", 0.0) or 0.0
                        if tot_y > 0 or yr_k in ["2023", "2024", "2025", "2026"]:
                            tot_cum = yr_info.get("tot_cumulato", 0.0) or 0.0
                            tax_ded = min(tot_y, MAX_TAX_DEDUCTION)
                            tax_sav = tax_ded * 0.43
                            plaf_res = max(0.0, MAX_TAX_DEDUCTION - tax_ded)
                            hist_rows.append({
                                "Esercizio": yr_k,
                                "Versamenti Annui (€)": fmt_eur(tot_y),
                                "Cumulato Versato (€)": fmt_eur(tot_cum),
                                "Deducibilità Fiscale (€)": fmt_eur(tax_ded),
                                "Risparmio IRPEF 43% (€)": fmt_eur(tax_sav),
                                "Plafond Residuo (€)": fmt_eur(plaf_res),
                                "_raw_y": tot_y,
                                "_raw_cum": tot_cum,
                                "_year": yr_k,
                            })

                    if hist_rows:
                        st.markdown(f"###### 📊 Cronistoria Versamenti & Ottimizzazione Fiscale ({hist_rows[0]['_year']} - {hist_rows[-1]['_year']})")
                        df_h = pd.DataFrame(hist_rows)
                        st.dataframe(
                            df_h[["Esercizio", "Versamenti Annui (€)", "Cumulato Versato (€)", "Deducibilità Fiscale (€)", "Risparmio IRPEF 43% (€)", "Plafond Residuo (€)"]],
                            use_container_width=True,
                            hide_index=True,
                        )

                        fig_prev = go.Figure()
                        fig_prev.add_trace(go.Bar(
                            x=[r["_year"] for r in hist_rows],
                            y=[r["_raw_y"] for r in hist_rows],
                            name="Versamento Annuo",
                            marker_color="#3b82f6",
                            text=[fmt_eur(r["_raw_y"]) for r in hist_rows],
                            textposition="auto",
                        ))
                        fig_prev.add_trace(go.Scatter(
                            x=[r["_year"] for r in hist_rows],
                            y=[r["_raw_cum"] for r in hist_rows],
                            name="Montante Cumulato",
                            mode="lines+markers+text",
                            line=dict(color="#10b981", width=3),
                            marker=dict(size=8, color="#10b981"),
                            text=[fmt_eur(r["_raw_cum"]) for r in hist_rows],
                            textposition="top center",
                            yaxis="y2",
                        ))
                        fig_prev.update_layout(
                            height=280,
                            margin=dict(l=30, r=30, t=30, b=20),
                            legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
                            yaxis=dict(title="Versamento Annuo (€)"),
                            yaxis2=dict(title="Cumulato (€)", overlaying="y", side="right"),
                        )
                        apply_plotly_theme(fig_prev)
                        st.plotly_chart(fig_prev, use_container_width=True)
                except Exception:
                    pass
    else:
        st.info("Nessun fondo pensione registrato. Registra il tuo fondo dalla scheda '➕ Censimento & Gestione Fondi'.")

# ── 2. SIMULATORE MONTE CARLO & CONO EVOLUTIVO ─────────────
elif active_pension_tab == "🎲 Simulatore Monte Carlo & Cono Evolutivo":
    section("🎲 Simulatore Monte Carlo Pensione Integrativa")

    sc1, sc2, sc3 = st.columns(3)
    with sc1:
        years_retire = st.slider("Anni al Pensionamento", min_value=5, max_value=40, value=25)
    with sc2:
        exp_ret = st.slider("Rendimento Annuo Atteso (%)", min_value=1.0, max_value=12.0, value=6.0, step=0.5)
    with sc3:
        vol_pct = st.slider("Volatilità Annua (%)", min_value=2.0, max_value=20.0, value=10.0, step=1.0)

    sim_res = simulate_pension_projection(
        current_pot=max(1000.0, tot_pension_val),
        monthly_contrib=max(100.0, tot_monthly_contrib),
        years_to_retirement=years_retire,
        expected_return_pct=exp_ret,
        volatility_pct=vol_pct,
    )

    rc1, rc2, rc3 = st.columns(3)
    with rc1:
        metric_card(
            "Montante Reale Mediano (Oggi)",
            fmt_eur(sim_res["real_pot_median"]),
            delta=f"Nominale a scadenza: {fmt_eur(sim_res['nominal_pot_median'])}",
            delta_color="normal",
        )
    with rc2:
        metric_card(
            "Rendita Mensile Vitalizia Stimata",
            f"{fmt_eur(sim_res['estimated_monthly_annuity_real'])} / mese",
            delta="Al netto dell'inflazione (Coeff. 5.575%)",
            delta_color="normal",
        )
    with rc3:
        metric_card(
            "Guadagno da Capitalizzazione",
            fmt_eur(sim_res["estimated_capital_gain"]),
            delta=f"Capitale Versato: {fmt_eur(sim_res['total_contributions'])}",
            delta_color="normal",
        )

    year_ticks = sim_res["year_ticks"]
    p10_curve = sim_res["p10_curve"]
    p50_curve = sim_res["p50_curve"]
    p90_curve = sim_res["p90_curve"]
    contrib_curve = sim_res["contrib_curve"]

    st.write("")
    section(f"📈 Proiezione Evolutiva Montante Pensionistico nei Prossimi {years_retire} Anni")

    fig_cone = go.Figure()
    fig_cone.add_trace(go.Scatter(
        x=year_ticks,
        y=p90_curve,
        mode="lines",
        line=dict(color="#10b981", width=1.5, dash="dot"),
        name="Scenario Ottimistico (90° %)",
        hovertemplate="<b>%{fullData.name}</b><br>Anno: %{x}<br>Montante: €%{y:,.2f}<extra></extra>",
    ))
    fig_cone.add_trace(go.Scatter(
        x=year_ticks,
        y=p10_curve,
        mode="lines",
        line=dict(color="#f59e0b", width=1.5, dash="dot"),
        name="Scenario Conservativo (10° %)",
        hovertemplate="<b>%{fullData.name}</b><br>Anno: %{x}<br>Montante: €%{y:,.2f}<extra></extra>",
    ))
    fig_cone.add_trace(go.Scatter(
        x=year_ticks,
        y=p50_curve,
        mode="lines",
        line=dict(color="#38bdf8", width=3),
        fill="tonexty",
        fillcolor="rgba(56, 189, 248, 0.12)",
        name="Scenario Base Mediano (50° %)",
        hovertemplate="<b>%{fullData.name}</b><br>Anno: %{x}<br>Montante: €%{y:,.2f}<extra></extra>",
    ))
    fig_cone.add_trace(go.Scatter(
        x=year_ticks,
        y=contrib_curve,
        mode="lines",
        line=dict(color="#94a3b8", width=2, dash="dash"),
        name="Capitale Versato Cumulativo",
        hovertemplate="<b>%{fullData.name}</b><br>Anno: %{x}<br>Totale Versato: €%{y:,.2f}<extra></extra>",
    ))
    fig_cone.update_layout(
        xaxis_title="Anni da Oggi",
        yaxis_title="Montante Stimato (€)",
        height=380,
        margin=dict(t=15, l=15, r=15, b=45),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        legend=dict(
            orientation="h",
            yanchor="top",
            y=-0.18,
            xanchor="center",
            x=0.5,
            font=dict(size=11, color="#c9d1d9"),
        ),
        font=dict(family="Outfit, sans-serif", color="#c9d1d9", size=11),
    )
    st.plotly_chart(fig_cone, use_container_width=True)

# ── 3. CENSIMENTO & GESTIONE FONDI ─────────────────────────
elif active_pension_tab == "➕ Censimento & Gestione Fondi":
    section("➕ Censimento & Registrazione Nuovo Fondo Pensione / PIP / TFR")
    st.caption("Aggiungi o aggiorna i piani previdenziali integrativi associati al profilo patrimoniale attivo.")

    with st.form("form_add_pension"):
        pf1, pf2, pf3 = st.columns(3)
        with pf1:
            p_name = st.text_input("Nome Fondo *", placeholder="es. Fondo Pensione Aperto Amundi SecondaPensione")
            p_prov = st.text_input("Società / Provider *", placeholder="es. Amundi, Allianz, Fonchim, Cometa...")
        with pf2:
            p_type = st.selectbox(
                "Tipologia Fondo *",
                [
                    ("fondo_pensione_aperto", "Fondo Pensione Aperto"),
                    ("fondo_negoziale_chiuso", "Fondo Negoziale di Categoria"),
                    ("pip_individuale", "PIP (Piano Individuale Pensionistico)"),
                    ("tfr_in_azienda", "TFR Accantonato"),
                    ("gestione_separata", "Gestione Separata"),
                ],
                format_func=lambda x: x[1],
            )
            p_val = st.number_input("Montante Attuale Accumulato (€) *", min_value=0.0, value=15000.0, step=500.0)
        with pf3:
            p_contr_emp = st.number_input("Versamento Mensile Lavoratore (€)", min_value=0.0, value=300.0, step=50.0)
            p_contr_com = st.number_input("Contributo Datore di Lavoro (€)", min_value=0.0, value=100.0, step=50.0)
            p_line = st.text_input("Linea di Investimento", placeholder="es. 100% Azionario Sviluppo")

        btn_save_p = st.form_submit_button("💾 Salva Fondo Pensione", use_container_width=True)
        if btn_save_p:
            if p_name and p_prov:
                save_pension_plan(engine, {
                    "portfolio_id": current_pid,
                    "plan_name": p_name,
                    "provider": p_prov,
                    "plan_type": p_type[0],
                    "accumulated_value": p_val,
                    "monthly_employee_contrib": p_contr_emp,
                    "monthly_employer_contrib": p_contr_com,
                    "tax_deductible_annual": (p_contr_emp * 12.0),
                    "investment_line": p_line,
                })

                st.success(f"Fondo '{p_name}' registrato con successo!")
                st.rerun()
            else:
                st.error("Compila i campi obbligatori (Nome Fondo e Provider).")
