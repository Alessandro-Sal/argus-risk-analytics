# ============================================================
# 18_📑_Fiscalita_e_Quadro_RW.py
# ARGUS Wealth — Fiscalità, Minusvalenze & Monitoraggio Quadro RW / RT
# ============================================================

import importlib
from datetime import datetime

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

import core.ui_utils
import core.wealth
import core.wealth.wealth_db
import core.wealth.wealth_engine

importlib.reload(core.ui_utils)
importlib.reload(core.wealth.wealth_db)
importlib.reload(core.wealth.wealth_engine)
importlib.reload(core.wealth)

from core.fetcher import get_engine
from core.sidebar import render_sidebar
from core.ui_lifecycle import teardown_view_state
from core.ui_utils import (
    apply_plotly_theme,
    ensure_portfolio_loaded,
    fmt_eur,
    fmt_pct,
    inject_custom_css,
    metric_card,
    render_institutional_telemetry_ribbon,
    render_page_header,
    render_segmented_tabs,
    render_sr117_audit_drawer,
    render_table_with_export,
    render_wealth_command_bar,
    render_wealth_executive_badges,
    render_wealth_telemetry_ribbon,
    resolve_active_subtab,
    section,
)
from core.wealth.tax_history_engine import (
    compute_crypto_tax_reporting,
    compute_fiscal_reform_2026_etf_harmonization,
)
from core.wealth.tax_history_ui import render_tax_history_tab
from core.wealth.wealth_db import get_wealth_portfolios, init_wealth_db
from core.wealth.wealth_engine import (
    compute_consolidated_net_worth,
    compute_fiscal_analytics,
    compute_tax_loss_harvesting_and_latent_taxes,
)

st.set_page_config(page_title="Fiscalità & Quadro RW | ARGUS Wealth", page_icon="📑", layout="wide")
inject_custom_css()
render_sidebar()

st.session_state.argus_portal_mode = "🏛️ Wealth Management"

db_user = st.session_state.get("db_user", "root")
db_pass = st.session_state.get("db_pass", "root")
db_host = st.session_state.get("db_host", "localhost")
db_name = st.session_state.get("wealth_db_name") or st.session_state.get("db_name") or "wealth"
st.session_state.wealth_db_name = db_name
st.session_state.db_name = db_name
offline_mode = bool(st.session_state.get("offline_mode", False))
db_port = int(st.session_state.get("db_port", 3306))

engine = get_engine(db_user, db_pass, db_host, db_port, db_name, database=db_name, offline=offline_mode)
init_wealth_db(engine)

ensure_portfolio_loaded(module_type="wealth")

df_prof = get_wealth_portfolios(engine)
prof_map = {row["portfolio_id"]: row["name"] for _, row in df_prof.iterrows()}
current_pid = st.session_state.get("wealth_active_portfolio_id")

if current_pid is None or current_pid not in prof_map:
    current_pid = None
    st.session_state["wealth_active_portfolio_id"] = None
    from core.ui_utils import render_wealth_profile_picker
    render_wealth_profile_picker(engine, prof_map, key_prefix="p18_picker")
    st.stop()

# ── ATOMIC STATE TEARDOWN ───────────────────────────────────
teardown_view_state(current_pid, active_page="18_Fiscalita_e_Quadro_RW")

prof_title = prof_map.get(current_pid, "Nessun Profilo")
render_wealth_command_bar(engine, current_pid=current_pid, prof_name=prof_title, key_suffix="p18")
nw_curr = compute_consolidated_net_worth(engine, portfolio_id=current_pid)
render_wealth_telemetry_ribbon(nw_summary=nw_curr, page_badge="FISCALITÀ & QUADRO RW", profile_name=prof_title)
render_wealth_executive_badges(nw_curr)

# Header
render_page_header(
    title="ARGUS Wealth — Fiscalità, Quadro RW & Tax-Loss Harvesting",
    subtitle="Calcolo automatico IVAFE (0,20%), Imposta di Bollo, Zainetto Minusvalenze, Tax-Loss Harvesting e Prospetto Fiscale.",
    icon="📑"
)

from core.wealth.wealth_modals import render_fiscal_methodology_modal

col_fisc_h1, col_fisc_h2 = st.columns([3.5, 1.2])
with col_fisc_h1:
    if len(prof_map) > 1:
        if current_pid in prof_map and st.session_state.get("fiscal_profile_selector_widget") != current_pid:
            st.session_state["fiscal_profile_selector_widget"] = current_pid
        sel_pid = st.selectbox(
            "Profilo Patrimoniale:",
            options=list(prof_map.keys()),
            format_func=lambda pid: f"📁 {prof_map[pid]}",
            index=list(prof_map.keys()).index(current_pid) if current_pid in prof_map else 0,
            key="fiscal_profile_selector_widget",
        )
        if sel_pid != current_pid:
            from core.workspace_context import WorkspaceContext

            WorkspaceContext.switch_wealth_profile(sel_pid, profile_name=prof_map.get(sel_pid))
            st.rerun()

with col_fisc_h2:
    st.markdown("<div style='height: 28px;'></div>", unsafe_allow_html=True)
    if st.button("ℹ️ Guida Quadro RW & TUIR", key="btn_modal_fisc_p18", use_container_width=True):
        render_fiscal_methodology_modal()

fiscal = compute_fiscal_analytics(engine, portfolio_id=current_pid)

# ── TOP KPI ROW ─────────────────────────────────────────────
k1, k2, k3, k4, k5 = st.columns(5)
with k1:
    metric_card("IVAFE Estero", fmt_eur(fiscal['total_ivafe']), delta="Dossier & C/C Esteri", help_text="Imposta sul valore delle attività finanziarie detenute all'estero (0,20% su dossier esteri + € 34,20 su c/c con giacenza > € 5k).")
with k2:
    metric_card("Imposta Bollo IT", fmt_eur(fiscal['total_bollo']), delta="0.20% + C/C Italia", help_text="0,20% proporzionale su dossier titoli italiani + € 34,20 su c/c italiani con giacenza > € 5k.")
with k3:
    metric_card("Zainetto Minus", fmt_eur(fiscal['total_minusvalenze']), delta="Recuperabili 4 Anni", delta_color="inverse", help_text="Minusvalenze pregresse totali ancora compensabili entro i 4 anni solari successivi.")
with k4:
    metric_card("Scudo Fiscale", fmt_eur(fiscal['tax_shield_potential']), delta="Credito d'Imposta 26%", delta_color="normal", help_text="Valore effettivo del risparmio fiscale recuperabile compensando le minusvalenze.")
with k5:
    metric_card("Costo Fiscale Annuo", fmt_eur(fiscal['estimated_annual_fiscal_cost']), delta="Drag Fiscale Totale", delta_color="inverse", help_text="Somma complessiva di IVAFE e Bollo su base annuale.")


st.markdown("<div style='margin-top: 15px;'></div>", unsafe_allow_html=True)

# ── SELETTORE MODULI FISCALITÀ STILE BLOOMBERG TERMINAL ─────────
WEALTH_TAX_MODELS_CATALOG = {
    "🏛️ Storico 730 & Riconciliazione": {
        "title": "Archivio Storico Dichiarazioni (730 / Redditi PF) & Riconciliazione Fiscale",
        "badge": "Archivio 730 • Riconciliazione • Art. 36-bis",
        "badge_color": "#38bdf8",
        "category": "Dichiarazione Fiscale",
        "desc": "Archivio storico dei modelli 730 e Redditi PF, importazione PDF/JSON, tracciamento minusvalenze all'AdE, alert art. 36-bis e riconciliazione automatica con i broker ARGUS.",
    },
    "📑 Prospetto Quadro RW / RT": {
        "title": "Prospetto Monitoraggio Fiscale, Quadro RW & Quadro RT (Modello Redditi PF)",
        "badge": "Quadro RW • IVAFE • Conti Esteri",
        "badge_color": "#10b981",
        "category": "Dichiarazione Fiscale",
        "desc": "Prospetto analitico delle attività finanziarie e conti detenuti all'estero, giacenze medie, picchi di consistenza e calcolo dell'IVAFE dovuta.",
    },
    "📉 Zainetto Fiscale & Scadenze": {
        "title": "Zainetto Fiscale Minusvalenze & Monitoraggio Scadenze Quinquennali",
        "badge": "Zainetto • Minusvalenze • Scadenze 4Y",
        "badge_color": "#f85149",
        "category": "Compensazione Fiscale",
        "desc": "Tracciamento dello stock di minusvalenze pregresse, calendario delle scadenze fiscali a 4 anni e simulatore di compensazione con plusvalenze future.",
    },
    "🌾 Tax-Loss Harvesting & Plusvalenze": {
        "title": "Tax-Loss Harvesting Autonomo & Compensazione Plusvalenze",
        "badge": "Harvesting • Wash Sale • Tax Credit",
        "badge_color": "#38bdf8",
        "category": "Ottimizzazione Tributaria",
        "desc": "Identificazione proattiva di minusvalenze latenti da realizzare per compensare plusvalenze maturate, minimizzando l'imposta sostitutiva del 26%.",
    },
    "⚖️ Ripartizione Italia vs Estero": {
        "title": "Asset Location & Ripartizione Geografica (Italia vs Estero)",
        "badge": "Asset Location • Regime Dichiarativo • Amministrato",
        "badge_color": "#fbbf24",
        "category": "Allocazione Giurisdizionale",
        "desc": "Mappatura dell'allocazione tra intermediari residenti (Regime Amministrato con ritenuta alla fonte) e conti esteri (Regime Dichiarativo).",
    },
    "💡 Strategie di Efficienza Fiscale": {
        "title": "Strategie Istituzionali di Efficienza Fiscale & Riforma 2026",
        "badge": "Riforma 2026 • Armonizzazione • Tax Drag",
        "badge_color": "#a855f7",
        "category": "Consulenza Avanzata",
        "desc": "Guida alle strategie di abbattimento del tax drag: armonizzazione redditi di capitale/diversi, polizze PIR e holding di famiglia.",
    },
    "🌍 Fiscalità Internazionale & Cross-Border": {
        "title": "Fiscalità Internazionale, Trattati Bilaterali & Withholding Tax",
        "badge": "WHT • W-8BEN • Doppia Imposizione",
        "badge_color": "#06b6d4",
        "category": "Cross-Border Wealth",
        "desc": "Gestione delle ritenute alla fonte estere (Withholding Tax dividendi USA/UE), modulistica W-8BEN e recupero credito d'imposta per doppie imposizioni.",
    },
}

active_tax_tab = render_segmented_tabs(
    WEALTH_TAX_MODELS_CATALOG,
    key="wealth_tax_active_tab",
    select_label="Seleziona Modulo Fiscale:",
)

if active_tax_tab == "🏛️ Storico 730 & Riconciliazione":
    render_tax_history_tab(engine, current_pid)

elif active_tax_tab == "📑 Prospetto Quadro RW / RT":
    st.markdown("### 📑 Prospetto di Monitoraggio Fiscale (Quadro RW & RT)")
    st.caption("Quadro riassuntivo per la compilazione del Modello Redditi PF o trasmissione al commercialista per le attività finanziarie e conti esteri.")
    
    if fiscal["quadro_rw_rows"]:
        df_rw = pd.DataFrame(fiscal["quadro_rw_rows"])
        rw_cfg = {
            "rigo": st.column_config.TextColumn("Rigo RW", width="small"),
            "descrizione": st.column_config.TextColumn("Descrizione / Intermediario", width="large"),
            "codice_investimento": st.column_config.NumberColumn("Cod. Investimento", width="small"),
            "codice_stato_estero": st.column_config.TextColumn("Paese Estero", width="medium"),
            "giacenza_media": st.column_config.NumberColumn("Giacenza Media (€)", format="€ %,.2f", width="medium"),
            "valore_massimo": st.column_config.NumberColumn("Picco Max (€)", format="€ %,.2f", width="medium"),
            "valore_finale": st.column_config.NumberColumn("Valore al 31/12 (€)", format="€ %,.2f", width="medium"),
            "ivafe_dovuta": st.column_config.NumberColumn("IVAFE Dovuta (€)", format="€ %,.2f", width="medium"),
            "monitoraggio_solo": st.column_config.TextColumn("Monitoraggio", width="medium")
        }
        render_table_with_export(
            df=df_rw,
            table_title="Quadro RW (Monitoraggio Attività Estere)",
            file_prefix=f"argus_quadro_rw_portfolio_{current_pid}",
            key_suffix=f"p18_rw_{current_pid}",
            column_config=rw_cfg,
            hide_index=True
        )
        st.info("💡 **Nota Normativa**: I conti correnti esteri con giacenza media annua inferiore a € 5.000 e picco massimo non superiore a € 15.000 non richiedono versamento IVAFE.")

    # ── SEZIONE CRIPTO-ATTIVITÀ (L. 197/2022 & QUADRO RW / RT) ──
    st.markdown("---")
    st.markdown("#### ₿ Monitoraggio & Liquidazione Cripto-Attività (L. 197/2022)")
    st.caption(
        "Disciplina fiscale delle cripto-attività: obbligo di monitoraggio in Quadro RW con codice investimento 21 "
        "e tassazione del 2‰ sul valore al 31/12 (Tributo F24 1727), oltre all'imposta sostitutiva 26% sulle plusvalenze nette (Tributo F24 1715)."
    )
    crypto_data = compute_crypto_tax_reporting(engine, profile_id=str(current_pid), tax_year=datetime.now().year - 1)
    c_p18_cr1, c_p18_cr2, c_p18_cr3, c_p18_cr4 = st.columns(4)
    with c_p18_cr1:
        metric_card("Valore Cripto al 31/12", fmt_eur(crypto_data["crypto_balance_31_12"]), "Consistenza Totale")
    with c_p18_cr2:
        metric_card("Picco Massimo Anno", fmt_eur(crypto_data["crypto_peak_value"]), "Rilevazione RW Cod. 21")
    with c_p18_cr3:
        metric_card("Imposta Valore (0,20%)", fmt_eur(crypto_data["imposta_valore_crypto_2_permille"]), "Codice F24 1727", delta_color="inverse")
    with c_p18_cr4:
        metric_card("Sostitutiva 26% Plusvalenze", fmt_eur(crypto_data["substitute_tax_26pct"]), "Codice F24 1715", delta_color="inverse")

    c_cr_t1, c_cr_t2 = st.columns([1.5, 1.5])
    with c_cr_t1:
        st.markdown("###### 📋 Quadro RW — Cripto-Attività & Wallet Esteri")
        st.dataframe(pd.DataFrame(crypto_data["quadro_rw_rows"]), hide_index=True, use_container_width=True)
    with c_cr_t2:
        st.markdown("###### 📈 Quadro RT Sez. II-B — Plusvalenze Cripto")
        st.dataframe(pd.DataFrame(crypto_data["quadro_rt_rows"]), hide_index=True, use_container_width=True)


elif active_tax_tab == "📉 Zainetto Fiscale & Scadenze":
    st.markdown("### 📉 Monitoraggio Zainetto Fiscale & Scadenza Minusvalenze (Art. 68 TUIR)")
    st.caption("Le minusvalenze realizzate hanno una durata di validità di 4 anni solari oltre all'anno di realizzo. Se non compensate entro il 31 dicembre del 4° anno, decadono definitivamente.")
    
    col_m1, col_m2 = st.columns([3, 2])
    with col_m1:
        df_min = pd.DataFrame(fiscal["minusvalenze_schedule"])
        fig_min = go.Figure()
        fig_min.add_trace(go.Bar(
            x=[f"Anno {r['anno_origine']} (Scad. {r['scadenza']})" for _, r in df_min.iterrows()],
            y=df_min["importo"],
            text=[f"€ {val:,.2f}" for val in df_min["importo"]],
            textposition="auto",
            hovertemplate="<b>%{x}</b><br>Minusvalenza: <b>€ %{y:,.2f}</b><extra></extra>",
            marker_color=["#ef4444" if "Quest'Anno" in r["stato"] else "#f59e0b" for _, r in df_min.iterrows()]
        ))
        fig_min.update_layout(
            title=dict(text="Distribuzione Temporale Minusvalenze", font=dict(size=14, color="#ffffff")),
            template="plotly_dark",
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            height=340,
            margin=dict(l=10, r=10, t=50, b=10)
        )
        st.plotly_chart(fig_min, use_container_width=True, config={'displayModeBar': False})

    with col_m2:
        st.markdown("##### ⏳ Dettaglio Scadenze e Urgenza")
        for m in fiscal["minusvalenze_schedule"]:
            color = "#ef4444" if "Quest'Anno" in m["stato"] else "#34d399"
            bg = "rgba(239, 68, 68, 0.12)" if "Quest'Anno" in m["stato"] else "rgba(16, 185, 129, 0.10)"
            st.markdown(f"""
            <div style="background:{bg}; border-left: 4px solid {color}; padding: 10px 14px; border-radius: 6px; margin-bottom: 8px;">
                <div style="display:flex; justify-content:space-between;">
                    <b>Anno {m['anno_origine']} &rarr; Scadenza: {m['scadenza']}</b>
                    <span style="color:{color}; font-weight:800;">€ {m['importo']:,.2f}</span>
                </div>
                <div style="font-size: 11.5px; color: #94a3b8;">Stato: {m['stato']} &bull; Risparmio potenziale: <b>€ {m['importo'] * 0.26:,.2f}</b></div>
            </div>
            """, unsafe_allow_html=True)

elif active_tax_tab == "🌾 Tax-Loss Harvesting & Plusvalenze":
    st.markdown("### 🌾 Tax-Loss Harvesting & Gestione Plusvalenze Latenti")
    st.caption("Ottimizzazione quantitativa del carico fiscale: calcolo del debito fiscale latente da liquidazione e strategie di compensazione minusvalenze prima del 31 dicembre.")

    tlh = compute_tax_loss_harvesting_and_latent_taxes(engine, portfolio_id=current_pid)

    th1, th2, th3, th4 = st.columns(4)
    with th1:
        metric_card("Imposte Latenti", fmt_eur(tlh["total_latent_tax_liability"]), delta="Debito Fiscale Teorico", delta_color="inverse", help_text="Imposte complessive stimate in caso di liquidazione integrale delle posizioni in plusvalenza (26% su azioni/crypto/ETF + 12.5% su titoli di stato).")
    with th2:
        metric_card("Patrimonio Reale Netto", fmt_eur(tlh["net_worth_post_latent_tax"]), delta="Net Worth Post-Tasse", delta_color="normal", help_text="Valore effettivo del patrimonio netto al netto del debito fiscale latente stimato.")
    with th3:
        metric_card("Minusvalenze Latenti", fmt_eur(tlh["total_unrealized_losses"]), delta="Potenziale Harvesting", delta_color="normal", help_text="Minusvalenze latenti non ancora realizzate presenti nei dossier del portafoglio.")
    with th4:
        metric_card("Scudo Recuperabile", fmt_eur(tlh["tax_shield_recoverable"]), delta="Risparmio Fiscale 26%", delta_color="normal", help_text="Credito d'imposta netto generabile realizzando le minusvalenze a compensazione delle plusvalenze.")

    st.write("")
    st.write("")
    if tlh["harvesting_opportunities"]:
        df_th = pd.DataFrame(tlh["harvesting_opportunities"])
        th_cfg = {
            "asset": st.column_config.TextColumn("Asset / Posizione", width="medium"),
            "tipo": st.column_config.TextColumn("Classe", width="small"),
            "minus_latente": st.column_config.NumberColumn("Minus Latente (€)", format="€ %,.2f", width="small"),
            "risparmio_fiscale_26": st.column_config.NumberColumn("Risparmio 26% (€)", format="€ %,.2f", width="small"),
            "azione_consigliata": st.column_config.TextColumn("Azione Consigliata", width="large"),
            "priorita": st.column_config.TextColumn("Priorità", width="medium")
        }
        render_table_with_export(
            df=df_th[["asset", "tipo", "minus_latente", "risparmio_fiscale_26", "azione_consigliata", "priorita"]],
            table_title="Opportunità di Tax-Loss Harvesting Rilevate",
            file_prefix=f"tax_loss_harvesting_{current_pid}",
            key_suffix=f"p18_tlh_{current_pid}",
            column_config=th_cfg,
            hide_index=True
        )
    else:
        st.info("Nessuna minusvalenza latente rilevata nel portafoglio.")

    st.write("")

    from core.tax_engine import compute_tax_loss_harvesting_opportunities
    pos_df = st.session_state.get("portfolio_positions", pd.DataFrame())
    if pos_df.empty and "positions" in st.session_state:
        pos_df = st.session_state["positions"]

    tlh_opps = compute_tax_loss_harvesting_opportunities(pos_df)
    if tlh_opps["has_harvesting_opportunities"]:
        st.markdown("##### 🔄 Switch di Tax-Loss Harvesting & Proxy Compliant")
        st.caption("Strumenti sostitutivi ad elevata correlazione (ρ ≥ 0.97) consigliati per monetizzare la perdita fiscale mantenendo intatta l'asset allocation.")
        df_switches = pd.DataFrame(tlh_opps["opportunities"])
        render_table_with_export(
            df=df_switches[["ticker", "name", "unrealized_loss_eur", "potential_tax_alpha_eur", "suggested_substitute_ticker", "suggested_substitute_name", "substitute_correlation", "recommended_action"]],
            table_title="Strategie di Switch e Proxy per Recupero Minusvalenze",
            file_prefix=f"tax_loss_switches_{current_pid}",
            key_suffix=f"p18_switches_{current_pid}",
            column_config={
                "ticker": st.column_config.TextColumn("Ticker Attuale", width="small"),
                "name": st.column_config.TextColumn("Nome Asset", width="medium"),
                "unrealized_loss_eur": st.column_config.NumberColumn("Perdita Non Realizzata", format="€ %,.2f"),
                "potential_tax_alpha_eur": st.column_config.NumberColumn("Tax Alpha (Credito 26%)", format="€ %,.2f"),
                "suggested_substitute_ticker": st.column_config.TextColumn("Proxy Sostitutivo", width="small"),
                "suggested_substitute_name": st.column_config.TextColumn("Nome Benchmark Proxy", width="medium"),
                "substitute_correlation": st.column_config.NumberColumn("Correlazione ρ", format="%.2f"),
                "recommended_action": st.column_config.TextColumn("Azione Consigliata", width="large"),
            },
            hide_index=True
        )
        st.write("")

    # RIGA 2: Simulatore Deduzione IRPEF Fondo Pensione (Full Width)
    st.markdown("##### 🛡️ Simulatore Deduzione IRPEF Fondo Pensione (Art. 51 TUIR)")
    irp = tlh["irpef_pension_optimization"]
    st.markdown(f"""
    <div style="background: linear-gradient(135deg, rgba(22, 27, 34, 0.9) 0%, rgba(13, 17, 23, 0.98) 100%); border: 1px solid rgba(56, 189, 248, 0.25); border-left: 4px solid #38bdf8; border-radius: 12px; padding: 18px 22px; box-shadow: 0 4px 20px rgba(0, 0, 0, 0.25);">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 12px; border-bottom: 1px solid rgba(255,255,255,0.08); padding-bottom: 10px; flex-wrap: wrap; gap: 10px;">
            <div>
                <span style="font-size: 14px; font-weight: 750; color: #ffffff;">Plafond Fiscale Deducibile Annuo (Art. 51 TUIR):</span>
                <span class="mono-num" style="font-weight: 800; color: #38bdf8; font-size: 16px; margin-left: 8px;">€ {irp['deduction_ceiling']:,.2f}</span>
            </div>
            <div style="font-size: 12.5px; color: #94a3b8;">
                Versamenti Stimati: <b style="color:#ffffff;">€ {irp['current_annual_contributions']:,.2f}</b> &nbsp;|&nbsp; Plafond Residuo: <b style="color:#fbbf24;">€ {irp['remaining_deductible_ceiling']:,.2f}</b>
            </div>
        </div>
        <div>
            <div style="font-size: 11.5px; font-weight: 700; color: #94a3b8; margin-bottom: 10px; text-transform: uppercase; letter-spacing: 0.5px;">Rimborso IRPEF Stimato in Busta Paga (Modello 730):</div>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 12px;">
                <div style="background: rgba(0,0,0,0.25); border-radius: 8px; padding: 10px 14px; border: 1px solid rgba(255,255,255,0.05);">
                    <div style="font-size: 11px; color: #94a3b8;">Scaglione 43% (Redditi &gt; € 50.000)</div>
                    <div class="mono-num" style="font-size: 17px; font-weight: 800; color: #34d399; margin-top: 2px;">+ € {irp['tax_refund_scaglione_43']:,.2f}</div>
                </div>
                <div style="background: rgba(0,0,0,0.25); border-radius: 8px; padding: 10px 14px; border: 1px solid rgba(255,255,255,0.05);">
                    <div style="font-size: 11px; color: #94a3b8;">Scaglione 35% (Redditi € 28k - € 50k)</div>
                    <div class="mono-num" style="font-size: 17px; font-weight: 800; color: #38bdf8; margin-top: 2px;">+ € {irp['tax_refund_scaglione_35']:,.2f}</div>
                </div>
                <div style="background: rgba(0,0,0,0.25); border-radius: 8px; padding: 10px 14px; border: 1px solid rgba(255,255,255,0.05);">
                    <div style="font-size: 11px; color: #94a3b8;">Scaglione 23% (Redditi &le; € 28.000)</div>
                    <div class="mono-num" style="font-size: 17px; font-weight: 800; color: #fbbf24; margin-top: 2px;">+ € {irp['tax_refund_scaglione_23']:,.2f}</div>
                </div>
            </div>
        </div>
    </div>
    """, unsafe_allow_html=True)


elif active_tax_tab == "⚖️ Ripartizione Italia vs Estero":

    st.markdown("### ⚖️ Ripartizione Patrimoniale Fiscale (Italia vs Estero)")
    st.caption("Confronto della localizzazione geografica degli asset e dell'incidenza delle imposte patrimoniali applicate (Bollo IT vs IVAFE).")
    
    tot_fisc_assets = fiscal["total_domestic_assets"] + fiscal["total_foreign_assets"]
    cs1, cs2 = st.columns([1.1, 1.2])
    with cs1:
        fig_pie = go.Figure(data=[go.Pie(
            labels=["Attività Italia", "Attività Estero & Crypto"],
            values=[fiscal["total_domestic_assets"], fiscal["total_foreign_assets"]],
            hole=0.60,
            marker_colors=["#3b82f6", "#10b981"],
            textinfo="percent",
            textposition="inside",
            hovertemplate="<b>%{label}</b><br>Controvalore: <b>€ %{value:,.2f}</b> (%{percent})<extra></extra>"
        )])
        fig_pie.update_layout(
            title=dict(text="Localizzazione Geografica del Patrimonio", font=dict(size=14, color="#ffffff")),
            template="plotly_dark",
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            height=340,
            margin=dict(l=10, r=10, t=50, b=30),
            legend=dict(orientation="h", yanchor="top", y=-0.05, xanchor="center", x=0.5),
            annotations=[dict(
                text=f"<span style='font-size:11px; color:#94a3b8;'>TOTALE</span><br><b style='font-size:14px; color:#ffffff;'>€ {tot_fisc_assets:,.0f}</b>",
                x=0.5, y=0.5, font_size=12, showarrow=False
            )]
        )
        st.plotly_chart(fig_pie, use_container_width=True, config={'displayModeBar': False})

    with cs2:
        st.markdown(f"""
        <div style="background: linear-gradient(135deg, rgba(22, 27, 34, 0.9) 0%, rgba(13, 17, 23, 0.98) 100%); border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 12px; padding: 18px 20px; box-shadow: 0 4px 20px rgba(0, 0, 0, 0.25);">
            <div style="font-size: 14px; font-weight: 700; color: #ffffff; margin-bottom: 12px; border-bottom: 1px solid rgba(255,255,255,0.08); padding-bottom: 8px;">
                🏛️ Confronto Imposte Patrimoniali Annuali
            </div>
            <table style="width: 100%; border-collapse: collapse; font-size: 13px; font-family: 'Outfit', sans-serif;">
                <tr style="border-bottom: 1px solid rgba(255,255,255,0.05);">
                    <td style="padding: 9px 0; color: #e2e8f0;"><span style="background: rgba(59, 130, 246, 0.2); color: #60a5fa; border: 1px solid rgba(59, 130, 246, 0.4); border-radius: 4px; padding: 1px 6px; font-size: 10.5px; font-weight: 700; margin-right: 6px;">IT</span> Patrimonio Domiciliato Italia:</td>
                    <td class="mono-num" style="padding: 9px 0; font-weight: 700; text-align: right; color: #ffffff;">€ {fiscal['total_domestic_assets']:,.2f}</td>
                </tr>
                <tr style="border-bottom: 1px solid rgba(255,255,255,0.05);">
                    <td style="padding: 9px 0 9px 24px; color: #94a3b8; font-size: 12px;">&bull; Imposta di Bollo IT (0,20% + C/C):</td>
                    <td class="mono-num" style="padding: 9px 0; font-weight: 700; text-align: right; color: #38bdf8;">€ {fiscal['total_bollo']:,.2f}</td>
                </tr>
                <tr style="border-bottom: 1px solid rgba(255,255,255,0.05);">
                    <td style="padding: 9px 0; color: #e2e8f0;"><span style="background: rgba(16, 185, 129, 0.2); color: #34d399; border: 1px solid rgba(16, 185, 129, 0.4); border-radius: 4px; padding: 1px 6px; font-size: 10.5px; font-weight: 700; margin-right: 6px;">EST</span> Patrimonio Domiciliato Estero:</td>
                    <td class="mono-num" style="padding: 9px 0; font-weight: 700; text-align: right; color: #ffffff;">€ {fiscal['total_foreign_assets']:,.2f}</td>
                </tr>
                <tr style="border-bottom: 1px solid rgba(255,255,255,0.08);">
                    <td style="padding: 9px 0 9px 24px; color: #94a3b8; font-size: 12px;">&bull; IVAFE Estero (0,20% + C/C):</td>
                    <td class="mono-num" style="padding: 9px 0; font-weight: 700; text-align: right; color: #34d399;">€ {fiscal['total_ivafe']:,.2f}</td>
                </tr>
                <tr style="font-weight: 800; font-size: 13.5px;">
                    <td style="padding: 12px 0; color: #f8fafc;">Totale Imposte Patrimoniali Ricorrenti:</td>
                    <td class="mono-num" style="padding: 12px 0; text-align: right; color: #fbbf24; font-size: 15px;">€ {fiscal['estimated_annual_fiscal_cost']:,.2f}</td>
                </tr>
            </table>
        </div>
        """, unsafe_allow_html=True)




elif active_tax_tab == "💡 Strategie di Efficienza Fiscale":
    st.markdown("### 💡 Strategie Istituzionali di Ottimizzazione Fiscale")
    st.caption("Linee guida e best practice operative per massimizzare il rendimento netto e minimizzare il drag fiscale del patrimonio.")
    
    st.markdown("""
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(340px, 1fr)); gap: 16px; margin-top: 10px;">
        <!-- Card 1 -->
        <div style="background: linear-gradient(135deg, rgba(22, 27, 34, 0.9) 0%, rgba(13, 17, 23, 0.98) 100%); border: 1px solid rgba(56, 189, 248, 0.25); border-left: 4px solid #38bdf8; border-radius: 12px; padding: 18px 20px; box-shadow: 0 4px 20px rgba(0, 0, 0, 0.25); display: flex; flex-direction: column;">
            <h5 style="color: #38bdf8; margin: 0 0 10px 0; font-size: 14.5px; font-weight: 750;">1. Compensazione Minusvalenze con ETC / Certificati</h5>
            <p style="color: #cbd5e1; font-size: 13px; margin: 0; line-height: 1.6; flex: 1;">
                In Italia, le plusvalenze da <b>ETF</b> sono considerate <i>Redditi di Capitale</i> e <u>non compensano</u> le minusvalenze pregresse. Per recuperare il credito dello zainetto fiscale prima della scadenza, è possibile utilizzare <b>Singoli Titoli Azionari</b>, <b>ETC/ETN</b> o <b>Certificates con Maxi-Cedola</b> (<i>Redditi Diversi</i>).
            </p>
        </div>
        <!-- Card 2 -->
        <div style="background: linear-gradient(135deg, rgba(22, 27, 34, 0.9) 0%, rgba(13, 17, 23, 0.98) 100%); border: 1px solid rgba(52, 211, 153, 0.25); border-left: 4px solid #34d399; border-radius: 12px; padding: 18px 20px; box-shadow: 0 4px 20px rgba(0, 0, 0, 0.25); display: flex; flex-direction: column;">
            <h5 style="color: #34d399; margin: 0 0 10px 0; font-size: 14.5px; font-weight: 750;">2. Deducibilità Previdenza Integrativa (Art. 51 TUIR)</h5>
            <p style="color: #cbd5e1; font-size: 13px; margin: 0; line-height: 1.6; flex: 1;">
                Saturare ogni anno il plafond di <b>€ 5.164,57</b> sui Fondi Pensione garantisce una deduzione diretta dal reddito imponibile IRPEF, generando un risparmio immediato dal <b>23% al 43%</b> in base al proprio scaglione marginale.
            </p>
        </div>
        <!-- Card 3 -->
        <div style="background: linear-gradient(135deg, rgba(22, 27, 34, 0.9) 0%, rgba(13, 17, 23, 0.98) 100%); border: 1px solid rgba(251, 191, 36, 0.25); border-left: 4px solid #fbbf24; border-radius: 12px; padding: 18px 20px; box-shadow: 0 4px 20px rgba(0, 0, 0, 0.25); display: flex; flex-direction: column;">
            <h5 style="color: #fbbf24; margin: 0 0 10px 0; font-size: 14.5px; font-weight: 750;">3. Aliquota Agevolata White List (12,50%)</h5>
            <p style="color: #cbd5e1; font-size: 13px; margin: 0; line-height: 1.6; flex: 1;">
                I rendimenti dei Titoli di Stato italiani (BTP, BOT, CCT) e dei Paesi White List UE/OCSE sono tassati con aliquota agevolata al <b>12,50%</b> invece del <b>26,00%</b> ordinario. Inoltre, i titoli di stato sono <u>completamente esenti da imposta di successione</u>.
            </p>
        </div>
        <!-- Card 4 -->
        <div style="background: linear-gradient(135deg, rgba(22, 27, 34, 0.9) 0%, rgba(13, 17, 23, 0.98) 100%); border: 1px solid rgba(167, 139, 250, 0.25); border-left: 4px solid #a78bfa; border-radius: 12px; padding: 18px 20px; box-shadow: 0 4px 20px rgba(0, 0, 0, 0.25); display: flex; flex-direction: column;">
            <h5 style="color: #a78bfa; margin: 0 0 10px 0; font-size: 14.5px; font-weight: 750;">4. Asset Location &amp; Ottimizzazione IVAFE</h5>
            <p style="color: #cbd5e1; font-size: 13px; margin: 0; line-height: 1.6; flex: 1;">
                Mantenere i conti correnti liquidi esteri sotto la soglia di giacenza media di <b>€ 5.000</b> evita l'addebito dell'IVAFE di € 34,20 su ciascun conto senza penalizzare l'operatività quotidiana.
            </p>
        </div>
    </div>
    """, unsafe_allow_html=True)

    # ── SIMULATORE RIFORMA FISCALE 2026 (ARMONIZZAZIONE ETF & TUIR) ──
    st.markdown("---")
    st.markdown("#### 🏛️ Simulatore Riforma Fiscale 2026: Armonizzazione ETF & TUIR")
    st.caption(
        "Simulazione dell'impatto economico della Riforma Tributaria 2026: le plusvalenze da ETF (attualmente redditi di capitale non compensabili) "
        "potranno assorbire lo zainetto fiscale pregresso, generando un Tax Alpha immediato."
    )
    col_p18_rf1, col_p18_rf2 = st.columns([2, 2])
    with col_p18_rf1:
        etf_sim_val = st.number_input(
            "Plusvalenze ETF da Realizzare (€):",
            min_value=0.0,
            value=4000.0,
            step=500.0,
            key=f"p18_etf_sim_{current_pid}",
        )
    with col_p18_rf2:
        st.markdown("<div style='height: 25px;'></div>", unsafe_allow_html=True)
        use_port_pos = st.checkbox("Carica plusvalenze effettive dal portafoglio", value=True, key=f"p18_rf_pos_{current_pid}")

    rf_res = compute_fiscal_reform_2026_etf_harmonization(
        engine,
        profile_id=str(current_pid),
        tax_year=datetime.now().year - 1,
        simulated_etf_gain=None if use_port_pos else etf_sim_val,
    )

    c_rf_k1, c_rf_k2, c_rf_k3, c_rf_k4 = st.columns(4)
    with c_rf_k1:
        metric_card("Plusvalenze ETF", fmt_eur(rf_res["etf_unrealized_gains"]), "Base Imponibile")
    with c_rf_k2:
        metric_card("Zainetto Fiscale", fmt_eur(rf_res["total_active_losses"]), "Minusvalenze Attive")
    with c_rf_k3:
        metric_card("Tax Alpha Riforma", f"+{fmt_eur(rf_res['immediate_tax_alpha_eur'])}", delta=f"-{rf_res['delta_tax_pct_points']:.1f}% Aliquota Reale", delta_color="normal")
    with c_rf_k4:
        metric_card("Assorbimento Minus", f"{rf_res['reform_2026_regime']['loss_absorption_pct']:.1f}%", "Compensato con ETF", delta_color="normal")

    st.info(f"💡 **Verdetto Strategico ARGUS:** {rf_res['strategic_advice']}")

elif active_tax_tab == "🌍 Fiscalità Internazionale & Cross-Border":
    st.markdown("### 🌍 Cross-Border Tax & Global Wealth Structuring Engine")
    st.caption("Confronto comparato del carico fiscale e successorio su grandi patrimoni tra regimi e giurisdizioni internazionali (Italia Ordinaria, Art. 24-bis Neo-Residenti, Svizzera Zugo, Lussemburgo SOPARFI, Dubai Zero-Tax).")

    from core.cross_border_tax_engine import compute_cross_border_wealth_tax_comparison

    col_cb_in1, col_cb_in2, col_cb_in3 = st.columns(3)
    with col_cb_in1:
        cb_wealth_in = st.number_input("Patrimonio Complessivo (€):", min_value=500000.0, value=10000000.0, step=500000.0, format="%.2f")
    with col_cb_in2:
        cb_cgt_in = st.number_input("Plusvalenze Realizzate Annue (€):", min_value=0.0, value=400000.0, step=50000.0, format="%.2f")
    with col_cb_in3:
        cb_div_in = st.number_input("Rendite / Dividendi Esteri Annui (€):", min_value=0.0, value=250000.0, step=25000.0, format="%.2f")

    cb_res = compute_cross_border_wealth_tax_comparison(
        total_wealth_eur=cb_wealth_in,
        annual_capital_gain_eur=cb_cgt_in,
        annual_foreign_income_eur=cb_div_in
    )

    cb_k1, cb_k2, cb_k3 = st.columns(3)
    with cb_k1:
        metric_card("Giurisdizione Ottimale", cb_res["lowest_tax_jurisdiction"], delta="Minimo Carico Fiscale", delta_color="normal")
    with cb_k2:
        metric_card("Risparmio Annuo Max vs IT", fmt_eur(cb_res["max_annual_tax_savings_eur"]), delta="Tax Alpha Annuo", delta_color="normal")
    with cb_k3:
        metric_card("Patrimonio Simulato", fmt_eur(cb_res["simulated_wealth_eur"]), delta="Total Wealth Base", delta_color="normal")

    st.write("")
    st.markdown("##### 📊 Benchmark Comparativo dei Regimi Fiscali Internazionali")
    st.dataframe(
        cb_res["comparison_df"][["name", "annual_cgt_eur", "annual_income_tax_eur", "annual_wealth_tax_eur", "total_annual_tax_eur", "effective_annual_tax_rate_pct", "estimated_estate_succession_tax_eur"]].rename(columns={
            "name": "Giurisdizione / Regime Fiscale",
            "annual_cgt_eur": "Imposta CGT (€)",
            "annual_income_tax_eur": "Imposta Dividendi (€)",
            "annual_wealth_tax_eur": "Imposta Patrimoniale (€)",
            "total_annual_tax_eur": "Totale Imposte Annue (€)",
            "effective_annual_tax_rate_pct": "Aliquota Effettiva (%)",
            "estimated_estate_succession_tax_eur": "Imposta Successione (€)"
        }),
        use_container_width=True,
        hide_index=True
    )

