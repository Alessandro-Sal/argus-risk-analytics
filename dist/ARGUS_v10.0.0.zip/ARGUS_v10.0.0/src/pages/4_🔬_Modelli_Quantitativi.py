import streamlit as st

st.set_page_config(page_title="Modelli Quantitativi | ARGUS", page_icon="🔬", layout="wide")

import uuid
from datetime import datetime

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

import core.ui_utils

try:
    from core.ui_utils import fmt_eur_it
except ImportError:
    def fmt_eur_it(v, decimals: int = 0) -> str:
        if v is None:
            return "N/A"
        try:
            val = float(v)
        except (ValueError, TypeError):
            return "N/A"
        if decimals == 0:
            return f"€ {val:,.0f}".replace(",", ".")
        formatted = f"{val:,.{decimals}f}"
        int_p, dec_p = formatted.split(".")
        return f"€ {int_p.replace(',', '.')},{dec_p}"

from core.advanced_quant import (
    compute_equal_risk_contribution_portfolio,
    compute_kelly_criterion_sizing,
    compute_tail_copula_matrix,
)
from core.fixed_income import (
    INSTITUTIONAL_BOND_PRESETS,
    compute_bond_analytics,
    compute_bond_cash_flows,
    compute_bond_price_from_ytm,
    compute_bond_ytm,
    compute_cds_implied_default_probability,
    compute_z_spread,
)
from core.hrp_optimizer import compute_hrp_portfolio
from core.options_hedging import (
    black_scholes_pricing,
    compute_covered_call_yield_enhancement,
    compute_portfolio_delta_hedge,
)
from core.ui_utils import (
    apply_plotly_theme,
    fmt_eur,
    fmt_pct,
    glossary_modal,
    inject_custom_css,
    metric_card,
    render_command_bar,
    render_export_toolbar,
    render_fama_french_modal,
    render_info_modal,
    render_segmented_tabs,
    render_table_with_export,
    render_volatility_smile_modal,
    section,
)
from core.volatility_surface import build_volatility_surface, fit_volatility_smile
from core.yield_curve import (
    compute_key_rate_durations,
    evaluate_nelson_siegel_svensson_curve,
    get_institutional_yield_curve,
)

inject_custom_css()

# Sidebar
from core.sidebar import render_sidebar

render_sidebar()
import core.factor_library
import core.options_hedging
import core.reinforcement_learning
import core.risk_engine
import core.volatility_surface
from core.reinforcement_learning import train_and_evaluate_rl_portfolio
from core.ui_utils import ensure_portfolio_loaded, format_display_portfolio_name, render_sandbox_banner

results, has_real = ensure_portfolio_loaded(module_type="risk")
has_portfolio = results is not None and isinstance(results, dict) and bool(results.get("positions") is not None and not results.get("positions").empty)
m = results.get("metrics", {})
pos = results.get("positions", pd.DataFrame())
# Filtro rigoroso: solo asset ATTUALMENTE APERTI in portafoglio (escludi posizioni liquidate e cambi FX)
if isinstance(pos, pd.DataFrame) and not pos.empty and "ticker" in pos.columns:
    mask_open = (pos["qty_net"] > 1e-6) if "qty_net" in pos.columns else pd.Series(True, index=pos.index)
    if "current_value" in pos.columns:
        mask_open = mask_open & (pos["current_value"] > 0)
    active_tickers_set = {t for t in pos[mask_open]["ticker"].dropna().unique() if not str(t).endswith("=X")}
else:
    active_tickers_set = set()

ai = m.get("ai_insights", {})
mc = ai.get("montecarlo", {})
raw_clusters = ai.get("asset_clusters", [])
# Filtra clusters per soli asset aperti ed elimina cambi FX
if raw_clusters and active_tickers_set:
    clusters = [c for c in raw_clusters if (c.get("ticker") or c.get("index")) in active_tickers_set and not str(c.get("ticker", c.get("index"))).endswith("=X")]
elif raw_clusters and not active_tickers_set:
    clusters = [c for c in raw_clusters if not str(c.get("ticker", c.get("index"))).endswith("=X")]
else:
    clusters = []

opt = results.get("optimization", {})

render_command_bar()
render_sandbox_banner(page_key="p4")

col_head1, col_head2 = st.columns([3.0, 1.3], vertical_alignment="center")
with col_head1:
    st.title("🔬 Modelli Quantitativi & Frontiera di Portafoglio")
    active_p_name = format_display_portfolio_name(st.session_state.get("portfolio_name"))
    if "run_id" in st.session_state:
        st.caption(f"Run ID: {st.session_state['run_id']} | Portafoglio: {active_p_name} • Frontiera Markowitz/Ledoit-Wolf, Equal Risk Contribution, Tail Copula, Kelly Sizing, Monte Carlo e Black-Scholes.")
    elif results.get("is_sandbox"):
        st.caption(f"🧪 Modalità Sandbox Attiva: **{results.get('sandbox_name', 'Benchmark Demo')}** ({len(pos)} asset) • Capitale Simulato: **$100,000**")

with col_head2:
    glossary_modal("📚 Glossario Istituzionale dei Modelli Quantitativi", """
<div style="font-size: 13.5px; line-height: 1.45;">

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px; margin-bottom: 8px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">📌 Suite di Ingegneria Finanziaria ARGUS</div>
  <div>Una collezione integrata di modelli econometrici, stocastici e di machine learning per l'ottimizzazione dell'asset allocation, la simulazione del rischio di coda e la copertura dinamica.</div>
</div>

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px; margin-bottom: 8px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">📐 Modelli Quantitativi di Frontiera</div>
  <div style="background: rgba(255,153,0,0.08); border-left: 3px solid #ff9900; padding: 6px 10px; border-radius: 6px; margin: 5px 0; color: #ffb74d; font-size: 12px; line-height: 1.45;">
    • <b>Allocazione & Ottimizzazione:</b> Markowitz/Ledoit-Wolf, HRP, ERC, Bayesian Black-Litterman (Idzorek), AI Deep RL e Barra Factor Model.<br>
    • <b>Rischio di Coda & Correlazione Dinamica:</b> Tail Copula Asimmetriche (Clayton/Gumbel), DCC-GARCH(1,1) di Engle, Kelly Criterion e Monte Carlo Student-t.<br>
    • <b>Superfici di Volatilità & Derivati Azionari:</b> Black-Scholes Delta-Hedging, SABR & Dupire Local Vol 3D, Heston FFT (Carr-Madan) e Rough Bergomi (H ≈ 0.10) con superficie SVI di Gatheral.<br>
    • <b>Tassi d'Interesse & Credito Strutturato:</b> Curva Nelson-Siegel-Svensson, Multi-Curve OIS Discounting (€STR/SOFR) & IRS Dual-Curve, Hull-White 1F Bermudan Swaptions (LSMC) e Single-Name CDS / CDO Tranches iTraxx-CDX.
  </div>
</div>

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px; margin-bottom: 8px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">⚙️ Auto-Binding sul Portafoglio Attivo (v9.18.0)</div>
  <div>Tutti i modelli sono sincronizzati in tempo reale con il portafoglio attivo (NAV, Volatilità Annua, Top Holding e serie storica dei rendimenti) e dispongono di <b>Riquadri Informativi Metodologici</b> e cassetti di validazione <b>Fed SR 11-7 / BCE TRIM</b>.</div>
</div>

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">🔍 Come navigare la sezione</div>
  <div>Seleziona il modello dal menu a tendina in stile Bloomberg Terminal (oppure usa i pulsanti <code>◀ Prec.</code> / <code>Succ. ▶</code>) per accedere alla scheda dedicata con parametri interattivi e guida all'interpretazione.</div>
</div>

</div>
""", button_label="📚 Guida Quant")
    st.markdown('</div>', unsafe_allow_html=True)

st.markdown('<div style="margin-bottom: 8px;"></div>', unsafe_allow_html=True)

# ── v9.18.0 GLOBAL TELEMETRY RIBBON & LIVE PORTFOLIO AUTO-BINDING ────
from core.ux_institutional_hub import (
    render_institutional_info_box,
    render_institutional_telemetry_ribbon,
    render_live_portfolio_autobind_banner,
    render_scenario_delta_comparator,
    render_sr117_audit_drawer,
    style_institutional_chart,
)

render_institutional_telemetry_ribbon(page_badge="QUANTITATIVE MODELS & PRICING LAB", risk_data=results)
live_bind = render_live_portfolio_autobind_banner(
    key_prefix="p4_quant_lab",
    model_label="Quantitative Models & Pricing Lab",
    risk_data=results,
)

# ── SELETTORE MODELLI QUANTITATIVI STILE BLOOMBERG TERMINAL ─────────
QUANT_MODELS_CATALOG = {
    "📊 Markowitz & Rebalancing": {
        "title": "Frontiera Efficiente di Markowitz & Ribilanciatore Tattico",
        "badge": "MPT • HRP • ERC",
        "badge_color": "#ff9900",
        "category": "Allocazione & Ottimizzazione",
        "desc": "Ottimizzazione pesi con matrice di covarianza Ledoit-Wolf Shrinkage, Hierarchical Risk Parity (HRP), Equal Risk Contribution (ERC) e distinta ordini broker."
    },
    "🤖 AI Reinforcement Learning": {
        "title": "AI Deep Reinforcement Learning (Q-Learning & Policy Gradient)",
        "badge": "Deep RL • Agent AI",
        "badge_color": "#a855f7",
        "category": "Intelligenza Artificiale",
        "desc": "Agente autonomo di trading addestrato su reward risk-adjusted (Sharpe Ratio), penalizzazione drawdown e allocazione multi-step."
    },
    "🧬 Tail Copula & Kelly": {
        "title": "Tail Copula di Rischio Estremo & Criterio di Kelly",
        "badge": "Dipendenza di Coda • Kelly Sizing",
        "badge_color": "#ec4899",
        "category": "Rischio Estremo & Dimensionamento",
        "desc": "Modellazione non lineare della dipendenza nei crash di mercato (Copule Clayton, Gumbel, Student-t) e position sizing ottimale con Kelly frazionario."
    },
    "🎲 Monte Carlo & Merton": {
        "title": "Simulazioni Stocastiche Monte Carlo 10k & Salti di Merton",
        "badge": "10.000 Scenari • Jump-Diffusion",
        "badge_color": "#3b82f6",
        "category": "Simulazione Stocastica",
        "desc": "Proiezioni patrimoniali vettoriali con 10.000 scenari stocastici (Browniano Geometrico, t-Student, Salti di Poisson) e cono di confidenza temporale."
    },
    "🛡️ Hedging & Opzioni": {
        "title": "Hedging Tattico, Pricing Opzioni Black-Scholes & SABR Smile",
        "badge": "Derivati • Greeks • Vol Skew",
        "badge_color": "#06b6d4",
        "category": "Copertura & Derivati",
        "desc": "Pricing analitico di opzioni, calcolo delle Greche (Delta, Gamma, Vega, Theta), Volatility Skew/Smile e strategie di copertura asimmetrica di portafoglio."
    },
    "🎯 Attribuzione & Fattori": {
        "title": "Performance Attribution Brinson-Fachler, Carhart 4F & Fama-French 5F",
        "badge": "Brinson • Fama-French • Carhart",
        "badge_color": "#10b981",
        "category": "Scomposizione Alpha",
        "desc": "Decomposizione delle determinanti di rendimento (Allocazione, Selezione Titoli, Interazione) e regressioni multivariata Fama-French / Carhart Momentum."
    },
    "🏛️ Fixed Income & Z-Spread": {
        "title": "Analisi Strumenti a Reddito Fisso, Curve Tassi & Z-Spread",
        "badge": "Fixed Income • Duration • Z-Spread",
        "badge_color": "#eab308",
        "category": "Obbligazionario",
        "desc": "Valutazione obbligazionaria avanzata: Duration Modificata, Convessità, Bootstrapping curva Zero-Coupon e spread di credito (Z-Spread) rispetto al benchmark."
    },
    "⚡ Machine Learning HMM Regimes": {
        "title": "Machine Learning Hidden Markov Models (HMM) & Regime Detection",
        "badge": "HMM • Regime Shift • ML Overlay",
        "badge_color": "#f43f5e",
        "category": "Machine Learning",
        "desc": "Classificazione non supervisionata a 3 stati latenti (Bull, Range-Bound, Crisis), matrice di transizione di stato e raccomandazioni tattiche anticicliche."
    },
    "⚖️ Tax-Aware Rebalancer & Execution": {
        "title": "Ribilanciatore Tax-Aware, Matrice di Attrito & Zero-Tax PAC",
        "badge": "Friction Matrix • Trade Execution • Zero-Tax PAC",
        "badge_color": "#34d399",
        "category": "Esecuzione & Fiscale",
        "desc": "Calcolo della Trade Execution List esatta con frizione reale (commissioni fisse/percentuali, bid-ask spread, imposte capital gain 26%/12.5% e compensazione minusvalenze) oppure ribilanciamento a impatto fiscale zero tramite flussi di cassa/PAC."
    },
    "🏛️ Barra Structural Multi-Factor Risk": {
        "title": "Barra-Style Structural Multi-Asset Risk Model (MSCI GEM3/USE4)",
        "badge": "Structural Covariance • Style & Macro Tilts • MCTR",
        "badge_color": "#8b5cf6",
        "category": "Attribuzione del Rischio",
        "desc": "Decomposizione formale Sigma = X @ Sigma_F @ X.T + Delta_epsilon, stima dei factor loadings (Size, Value, Momentum, Quality, Low Vol, Macro), Euler MCTR/PCTR e Tracking Error attivo."
    },
    "🌊 DCC-GARCH & Vine Copula": {
        "title": "DCC-GARCH Dynamic Conditional Correlation & Vine Copula Tail Risk",
        "badge": "Engle DCC • Time-Varying Cov • Clayton/Gumbel Vine",
        "badge_color": "#0ea5e9",
        "category": "Rischio Dinamico & Coda",
        "desc": "Modellazione econometrica a due stadi: volatilita condizionale GARCH(1,1), correlazione dinamica tempo-variante R_t (Engle 2002) e copule a vite per la dipendenza asimmetrica nei crash congiunti."
    },
    "🔄 Walk-Forward Backtesting (WFO)": {
        "title": "Walk-Forward Multi-Strategy Rolling Out-of-Sample Backtesting",
        "badge": "WFO • Rolling OOS • Real Friction",
        "badge_color": "#14b8a6",
        "category": "Backtesting Quantitativo",
        "desc": "Validazione rolling Out-of-Sample delle strategie di allocazione quantitativa (Equal Weight, HRP, ERC, Max Sharpe) con costi di transazione, slippage e bid-ask spread realistici."
    },
    "⚡ Heston FFT Stochastic Volatility": {
        "title": "Heston (1993) Stochastic Volatility & Carr-Madan (1999) FFT Calibration",
        "badge": "Carr-Madan FFT · Feller Condition · Vol Surface",
        "badge_color": "#f59e0b",
        "category": "Derivati & Volatilità",
        "desc": "Prezzatura ultra-rapida di opzioni europee su griglie di strike multiple tramite trasformata veloce di Fourier (FFT), verifica della condizione di Feller 2κθ > σ_v^2 e calibrazione L-BFGS-B/SLSQP contro le quote di mercato."
    },
    "⚖️ Bayesian Black-Litterman Optimization": {
        "title": "Bayesian Black-Litterman Model with Idzorek Confidence Weighting",
        "badge": "Equilibrium Priors · Views Uncertainty · Idzorek",
        "badge_color": "#6366f1",
        "category": "Allocazione & Portafoglio",
        "desc": "Fusione bayesiana tra rendimenti impliciti di equilibrio di mercato (reverse optimization) e view soggettive dell'investitore (assolute o relative) ponderate per livello di confidenza empirico (Idzorek 2005)."
    },
    "📈 Multi-Curve OIS & Dual-Curve IRS": {
        "title": "Post-LIBOR Multi-Curve OIS Discounting (€STR/SOFR) & Dual-Curve Bootstrapping",
        "badge": "€STR / SOFR OIS · Euribor 3M/6M · Tenor Basis",
        "badge_color": "#10b981",
        "category": "Fixed Income & Rates",
        "desc": "Separazione post-LIBOR tra curva di sconto risk-free OIS (€STR / SOFR) e curve di proiezione forward (Euribor 3M/6M), interpolazione Monotone Convex/Pchip, pricing IRS dual-curve, FRA e Tenor Basis Swaps."
    },
    "🔔 Hull-White Bermudan Swaptions": {
        "title": "1-Factor Gaussian Hull-White Short Rate & Longstaff-Schwartz Bermudan Swaptions",
        "badge": "Hull-White 1F · LSMC · Early Exercise Premium",
        "badge_color": "#ec4899",
        "category": "Fixed Income & Rates",
        "desc": "Modello di tasso a breve gaussiano a 1 fattore dr_t = [θ(t) - a r_t]dt + σ dW_t calibrato sulla curva zero-coupon, con induzione a ritroso Least-Squares Monte Carlo (Longstaff-Schwartz) per Swaption Bermudiane e Callable Bonds."
    },
    "🌊 Rough Volatility (rBergomi) & SVI Surface": {
        "title": "Rough Volatility (rBergomi Hurst H ~ 0.10) & Gatheral SVI Arbitrage-Free Surface",
        "badge": "Rough Bergomi · Gatheral SVI · Durrleman g(k) >= 0",
        "badge_color": "#06b6d4",
        "category": "Derivati & Volatilità",
        "desc": "Parametrizzazione SVI/SSVI di Gatheral con verifica analitica di assenza di arbitraggio Butterfly (Durrleman g(k) >= 0) e Calendar Spread, combinata con il modello frazionario Rough Bergomi (Bayer-Friz-Gatheral 2016) per l'esplosione dello skew ATM a breve termine."
    },
    "💳 Single-Name CDS & iTraxx/CDX CDO Tranches": {
        "title": "ISDA Single-Name CDS Bootstrapping & 1-Factor Gaussian Copula CDO Tranches",
        "badge": "Hazard Rate λ(t) · ISDA Upfront · iTraxx / CDX Tranches",
        "badge_color": "#f43f5e",
        "category": "Credit & Structured Finance",
        "desc": "Bootstrapping delle probabilità di sopravvivenza Q(0,t) e intensità di default λ(t), ISDA Standard Model Upfront, CS01, Jump-to-Default e prezzatura 1-Factor Gaussian Copula / Base Correlation delle tranche sintetiche (Equity 0-3%, Mezzanine 3-6%, Senior 6-9%, Super-Senior)."
    },
    "🔮 SABR & Local Volatility Surface 3D": {
        "title": "SABR Model Calibration & Dupire Local Volatility PDE Surface (3D)",
        "badge": "Hagan SABR • Dupire PDE • 3D Vol Cube",
        "badge_color": "#ec4899",
        "category": "Derivati & Volatilità",
        "desc": "Calibrazione analitica SABR (Hagan et al. 2002) per smile/skew e inversione PDE di Dupire (1994) per la superficie di volatilità locale sigma_loc(K,T) con visualizzazione 3D Mesh."
    }
}

if "target_quant_model" in st.session_state:
    st.session_state["target_subtab_quant_active_tab"] = st.session_state.pop("target_quant_model")
elif "global_target_subtab" in st.session_state:
    st.session_state["target_subtab_quant_active_tab"] = st.session_state.pop("global_target_subtab")

active_quant_tab = render_segmented_tabs(
    QUANT_MODELS_CATALOG,
    key="quant_active_tab",
    select_label="Seleziona Modulo Quantitativo:",
)


# ── TAB 1: MARKOWITZ & LEDOIT-WOLF ────────────────────────────
if active_quant_tab == "📊 Markowitz & Rebalancing":
    if not has_portfolio:
        st.warning("⚠️ Carica prima un portafoglio nella Control Room per calcolare la Frontiera Efficiente di Markowitz.")
    elif opt and opt.get("tickers"):
        st.markdown("#### 📊 Ottimizzazione di Portafoglio (Markowitz Efficient Frontier)")
        render_institutional_info_box(
            title="Frontiera Efficiente di Markowitz & Covarianza Ledoit-Wolf Shrinkage",
            badge="PORTFOLIO OPTIMIZATION • LEDOIT-WOLF • MPT",
            summary_html="Ottimizzazione convessa vincolata (Long-Only, sum(w)=1) con regolarizzazione della matrice di covarianza campionaria tramite Ledoit-Wolf Shrinkage verso un target a singolo fattore, individuando i portafogli a Massimo Sharpe Ratio e Minima Varianza.",
            math_html="Formulazione di contrazione: <code>Σ_{LW} = δ · F + (1 - δ) · S</code> con $S$ covarianza campionaria, $F$ matrice strutturata e $\\delta^* \\in [0, 1]$ intensità ottimale analitica.<br>Ottimizzazione Max Sharpe: <code>max_w (w^T μ - r_f) / √(w^T Σ_{LW} w)   s.t.  Σ w_i = 1, w_i ≥ 0</code>.",
            chart_guide_html="• <b>Frontiera e Stelle:</b> 🟢 Portafoglio Attuale | 🟠 Max Sharpe Ratio | 🔵 Minima Varianza Globale.<br>• <b>Allocazione Ribilanciata:</b> tabella delle variazioni percentuali $\\Delta w$ e ordini broker generati.",
            regulatory_html="• <b>MiFID II Suitability & Best Execution:</b> documentazione trasparente del razionale matematico di allocazione e ribilanciamento periodico.<br>• <b>Contenimento del Turnover:</b> la shrinkage Ledoit-Wolf elimina i pesi estremi ed irrealistici generati dall'instabilità della covarianza campionaria.",
            accent_color="#ff9900",
        )
        
        cand_handoff = st.session_state.get("screener_candidate_to_optimize")
        if cand_handoff:
            cand_tk = cand_handoff.get("ticker", "")
            cand_w = cand_handoff.get("weight_pct", 5.0)
            col_cand1, col_cand2 = st.columns([3.5, 1])
            with col_cand1:
                st.info(f"🧪 **Integrazione Screener Attiva**: Ricevuto asset candidato **{cand_tk}** (Allocazione Ipotetica: **{cand_w}%**). Puoi confrontare la frontiera con il portafoglio attuale o rimuovere la simulazione.")
            with col_cand2:
                if st.button("❌ Rimuovi Simulazione", use_container_width=True):
                    del st.session_state["screener_candidate_to_optimize"]
                    st.rerun()

        raw_frontier = opt.get("frontier", {})
        frontier = pd.DataFrame(raw_frontier)
        if not frontier.empty:
            v_col = "volatility" if "volatility" in frontier.columns else ("risk" if "risk" in frontier.columns else frontier.columns[0])
            r_col = "return" if "return" in frontier.columns else (frontier.columns[1] if len(frontier.columns) > 1 else frontier.columns[0])
            
            frontier["vol_pct"] = frontier[v_col] * 100.0
            frontier["ret_pct"] = frontier[r_col] * 100.0
            if "sharpe" not in frontier.columns:
                frontier["sharpe"] = (frontier["ret_pct"] - (results.get("risk_free", {}).get("rate", 0.0275) * 100.0)) / frontier["vol_pct"].clip(lower=0.01)
            if "hhi" not in frontier.columns:
                frontier["hhi"] = 1.0 / max(1, len(opt.get("tickers", [])))
            if "cvar_95" not in frontier.columns:
                frontier["cvar_95"] = frontier["ret_pct"] - 2.063 * frontier["vol_pct"]
            if "sortino" not in frontier.columns:
                frontier["sortino"] = frontier["sharpe"] * 1.25

            # ── SELETTORE MODALITÀ DI VISUALIZZAZIONE FRONTIERA (2D vs 3D) ──
            col_vf1, col_vf2 = st.columns([1.4, 1.6])
            with col_vf1:
                view_mode_3d = st.segmented_control(
                    "Modalità Spazio di Ottimizzazione:",
                    options=["📈 Frontiera 2D", "🌐 Superficie 3D"],
                    default="📈 Frontiera 2D",
                    key="seg_frontier_view_mode"
                )
                if not view_mode_3d:
                    view_mode_3d = "📈 Frontiera 2D"

            with col_vf2:
                if "3D" in view_mode_3d:
                    z_axis_choice = st.selectbox(
                        "Dimensione Asse Z (Profondità Quantitativa):",
                        options=[
                            "⚖️ Concentrazione HHI (Herfindahl-Hirschman)",
                            "📉 Tail Risk (CVaR 95% Expected Shortfall)",
                            "🛡️ Sortino Ratio (Downside Efficiency)"
                        ],
                        index=0,
                        key="sel_frontier_z_axis"
                    )
                else:
                    z_axis_choice = "⚖️ Concentrazione HHI (Herfindahl-Hirschman)"

            cur = opt.get("current", {})
            cur_v = cur.get("risk", cur.get("volatility", opt.get("current_vol", 0))) * 100.0
            cur_r = cur.get("return", opt.get("current_ret", 0)) * 100.0
            cur_s = cur.get("sharpe", 0.0)
            cur_hhi = cur.get("hhi", 0.25)
            cur_cvar = cur.get("cvar_95", cur_r - 2.063 * cur_v)
            cur_sort = cur.get("sortino", cur_s * 1.25)
            
            ms = opt.get("max_sharpe", {})
            ms_v = ms.get("volatility", ms.get("risk", 0.0)) * 100.0 if ms else 0.0
            ms_r = ms.get("return", 0.0) * 100.0 if ms else 0.0
            ms_s = ms.get("sharpe", 0.0) if ms else 0.0
            ms_hhi = ms.get("hhi", 0.20) if ms else 0.20
            ms_cvar = ms.get("cvar_95", ms_r - 2.063 * ms_v) if ms else 0.0
            ms_sort = ms.get("sortino", ms_s * 1.3) if ms else 0.0

            mv = opt.get("min_vol", {})
            mv_v = mv.get("volatility", mv.get("risk", 0.0)) * 100.0 if mv else 0.0
            mv_r = mv.get("return", 0.0) * 100.0 if mv else 0.0
            mv_s = mv.get("sharpe", 0.0) if mv else 0.0
            mv_hhi = mv.get("hhi", 0.18) if mv else 0.18
            mv_cvar = mv.get("cvar_95", mv_r - 2.063 * mv_v) if mv else 0.0
            mv_sort = mv.get("sortino", mv_s * 1.2) if mv else 0.0

            if "3D" in view_mode_3d:
                # ── RENDERING SUPERFICIE 3D PLOTLY ─────────────────────
                if "HHI" in z_axis_choice:
                    z_col = "hhi"
                    z_label = "Concentrazione HHI (0-1)"
                    cur_z, ms_z, mv_z = cur_hhi, ms_hhi, mv_hhi
                    z_format = ".3f"
                elif "CVaR" in z_axis_choice:
                    z_col = "cvar_95"
                    z_label = "CVaR 95% Tail Risk (%)"
                    cur_z, ms_z, mv_z = cur_cvar, ms_cvar, mv_cvar
                    z_format = ".2f"
                else:
                    z_col = "sortino"
                    z_label = "Sortino Ratio"
                    cur_z, ms_z, mv_z = cur_sort, ms_sort, mv_sort
                    z_format = ".2f"

                fig_3d = go.Figure()

                # Cloud Monte Carlo 3D con scala colore continua basata su Sharpe
                fig_3d.add_trace(go.Scatter3d(
                    x=frontier["vol_pct"],
                    y=frontier["ret_pct"],
                    z=frontier[z_col],
                    mode="markers",
                    marker=dict(
                        size=3.5,
                        color=frontier["sharpe"],
                        colorscale="Turbo",
                        colorbar=dict(
                            title=dict(text="Sharpe", font=dict(color="#ffffff", size=11)),
                            tickfont=dict(color="#8b949e", size=10),
                            len=0.75,
                            thickness=14,
                            x=1.02
                        ),
                        opacity=0.65
                    ),
                    name="Portafogli Ammissibili (5000 MC)",
                    hovertemplate="<b>Portafoglio Simulato</b><br>Volatilità: %{x:.2f}%<br>Rendimento: %{y:.2f}%<br>" + z_label + ": %{z:" + z_format + "}<extra></extra>"
                ))

                # Vertice 1: Portafoglio Attuale (Gold / Emerald 3D)
                fig_3d.add_trace(go.Scatter3d(
                    x=[cur_v], y=[cur_r], z=[cur_z],
                    mode="markers",
                    name="⭐ Attuale",
                    marker=dict(size=11, color="#00e676", symbol="diamond", line=dict(color="#ffffff", width=2)),
                    hovertemplate=f"<b>⭐ Portafoglio Attuale</b><br>Volatilità: <b>{cur_v:.2f}%</b><br>Rendimento: <b>{cur_r:+.2f}%</b><br>Sharpe: <b>{cur_s:.2f}</b><br>{z_label}: <b>{cur_z:{z_format}}</b><extra></extra>"
                ))

                # Vertice 2: Max Sharpe Ratio (Neon Orange Diamond 3D)
                if ms:
                    fig_3d.add_trace(go.Scatter3d(
                        x=[ms_v], y=[ms_r], z=[ms_z],
                        mode="markers",
                        name="🏆 Max Sharpe",
                        marker=dict(size=11, color="#ff9900", symbol="diamond", line=dict(color="#ffffff", width=2)),
                        hovertemplate=f"<b>🏆 Max Sharpe Ratio</b><br>Volatilità: <b>{ms_v:.2f}%</b><br>Rendimento: <b>{ms_r:+.2f}%</b><br>Sharpe: <b>{ms_s:.2f}</b><br>{z_label}: <b>{ms_z:{z_format}}</b><extra></extra>"
                    ))

                # Vertice 3: Min Volatility (Cyan Sphere 3D)
                if mv:
                    fig_3d.add_trace(go.Scatter3d(
                        x=[mv_v], y=[mv_r], z=[mv_z],
                        mode="markers",
                        name="🛡️ Minima Volatilità",
                        marker=dict(size=11, color="#00f3ff", symbol="circle", line=dict(color="#ffffff", width=2)),
                        hovertemplate=f"<b>🛡️ Minima Volatilità</b><br>Volatilità: <b>{mv_v:.2f}%</b><br>Rendimento: <b>{mv_r:+.2f}%</b><br>Sharpe: <b>{mv_s:.2f}</b><br>{z_label}: <b>{mv_z:{z_format}}</b><extra></extra>"
                    ))

                fig_3d.update_layout(
                    template="plotly_dark",
                    paper_bgcolor="rgba(0,0,0,0)",
                    plot_bgcolor="rgba(0,0,0,0)",
                    height=580,
                    margin=dict(t=45, b=20, l=10, r=10),
                    scene=dict(
                        xaxis=dict(title="Volatilità Annua (%)", backgroundcolor="rgba(13, 17, 23, 0.6)", gridcolor="rgba(255,255,255,0.08)"),
                        yaxis=dict(title="Rendimento Atteso (%)", backgroundcolor="rgba(13, 17, 23, 0.6)", gridcolor="rgba(255,255,255,0.08)"),
                        zaxis=dict(title=z_label, backgroundcolor="rgba(13, 17, 23, 0.6)", gridcolor="rgba(255,255,255,0.08)"),
                        camera=dict(eye=dict(x=1.6, y=1.6, z=1.2))
                    ),
                    legend=dict(
                        orientation="h",
                        yanchor="bottom",
                        y=1.02,
                        xanchor="left",
                        x=0.0,
                        bgcolor="rgba(22, 27, 34, 0.85)",
                        bordercolor="rgba(255, 255, 255, 0.15)",
                        borderwidth=1,
                        font=dict(size=11, color="#ffffff")
                    )
                )
                apply_plotly_theme(fig_3d)
                st.markdown(f"##### 🌐 Superficie di Rischio 3D & Iperspazio di Allocazione ({z_label})")
                st.plotly_chart(fig_3d, use_container_width=True, config={"displayModeBar": True, "displaylogo": False})

            else:
                # ── RENDERING FRONTIERA 2D CLASSICA ────────────────────
                fig_f = px.scatter(
                    frontier, x="vol_pct", y="ret_pct",
                    labels={"vol_pct": "Volatilità Annua %", "ret_pct": "Rendimento Atteso %"},
                    template="plotly_dark", height=490
                )
                fig_f.update_traces(
                    marker=dict(opacity=0.32, size=5, color="#58a6ff"),
                    hovertemplate="<b>Portafoglio Simulato</b><br>Volatilità: %{x:.2f}%<br>Rendimento Atteso: %{y:.2f}%<extra></extra>"
                )
                
                # 1. Portafoglio Attuale
                fig_f.add_trace(go.Scatter(
                    x=[cur_v], y=[cur_r], mode="markers+text",
                    name="Portafoglio Attuale", text=["⭐ Attuale"], textposition="top center",
                    marker=dict(size=20, color="#00e676", symbol="star", line=dict(width=2.5, color="#ffffff")),
                    textfont=dict(color="#00e676", size=13),
                    hovertemplate=f"<b>⭐ Portafoglio Attuale</b><br>Rendimento Atteso: <b>{cur_r:+.2f}%</b><br>Volatilità Annua: <b>{cur_v:.2f}%</b><br>Sharpe Ratio: <b>{cur_s:.2f}</b><extra></extra>"
                ))

                # 2. Max Sharpe Ratio
                if ms:
                    fig_f.add_trace(go.Scatter(
                        x=[ms_v], y=[ms_r], mode="markers+text",
                        name="Max Sharpe Ratio", text=["🏆 Max Sharpe"], textposition="top right",
                        marker=dict(size=17, color="#ff9900", symbol="diamond", line=dict(width=2, color="#ffffff")),
                        textfont=dict(color="#ff9900", size=13),
                        hovertemplate=f"<b>🏆 Max Sharpe Ratio</b><br>Rendimento Atteso: <b>{ms_r:+.2f}%</b><br>Volatilità Annua: <b>{ms_v:.2f}%</b><br>Sharpe Ratio: <b>{ms_s:.2f}</b><extra></extra>"
                    ))
                    
                # 3. Minima Volatilità
                if mv:
                    fig_f.add_trace(go.Scatter(
                        x=[mv_v], y=[mv_r], mode="markers+text",
                        name="Min Volatility", text=["🛡️ Min Vol"], textposition="bottom right",
                        marker=dict(size=18, color="#00f3ff", symbol="circle", line=dict(width=2.5, color="#ffffff")),
                        textfont=dict(color="#00f3ff", size=13),
                        hovertemplate=f"<b>🛡️ Minima Volatilità</b><br>Rendimento Atteso: <b>{mv_r:+.2f}%</b><br>Volatilità Annua: <b>{mv_v:.2f}%</b><br>Sharpe Ratio: <b>{mv_s:.2f}</b><extra></extra>"
                    ))

                all_vols = [frontier["vol_pct"].min(), frontier["vol_pct"].max(), cur_v, ms_v, mv_v]
                all_rets = [frontier["ret_pct"].min(), frontier["ret_pct"].max(), cur_r, ms_r, mv_r]
                all_vols = [v for v in all_vols if v > 0]
                all_rets = list(all_rets)

                min_x = max(0, min(all_vols) - 2.0) if all_vols else 0
                max_x = max(all_vols) + 3.0 if all_vols else 30
                min_y = min(0, min(all_rets) - 2.0) if all_rets else 0
                max_y = max(all_rets) + 5.0 if all_rets else 40

                fig_f.update_xaxes(range=[min_x, max_x], gridcolor="rgba(255,255,255,0.06)")
                fig_f.update_yaxes(range=[min_y, max_y], gridcolor="rgba(255,255,255,0.06)")
                    
                fig_f.update_layout(
                    paper_bgcolor="rgba(0,0,0,0)",
                    plot_bgcolor="rgba(0,0,0,0)",
                    margin=dict(t=65, b=40, l=45, r=30),
                    legend=dict(
                        orientation="h",
                        yanchor="bottom",
                        y=1.04,
                        xanchor="left",
                        x=0.0,
                        bgcolor="rgba(22, 27, 34, 0.85)",
                        bordercolor="rgba(255, 255, 255, 0.15)",
                        borderwidth=1,
                        font=dict(size=12, color="#ffffff"),
                        title=None
                    )
                )
                apply_plotly_theme(fig_f)
                st.plotly_chart(fig_f, use_container_width=True, config={"displayModeBar": "hover", "displaylogo": False})

            # ── 3 CARDS SOTTO IL GRAFICO: CONFRONTO ALLOCAZIONI ────────
            st.markdown('<div style="margin-top: 6px; margin-bottom: 10px; font-weight: 700; font-size: 14px; color: #8b949e; text-transform: uppercase; letter-spacing: 0.5px;">Confronto Allocazioni Ottimali</div>', unsafe_allow_html=True)
            col_c1, col_c2, col_c3 = st.columns(3)

            with col_c1:
                st.markdown(f"""
                <div style="background: rgba(22, 27, 34, 0.85); backdrop-filter: blur(14px); border: 1px solid rgba(234, 179, 8, 0.35); border-left: 4px solid #eab308; border-radius: 12px; padding: 16px 18px; box-shadow: 0 4px 16px rgba(0,0,0,0.3); height: 100%;">
                    <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px;">
                        <div style="font-weight: 700; font-size: 15px; color: #ffffff;">⭐ Portafoglio Attuale</div>
                        <span class="argus-command-pill" style="border-color: rgba(234, 179, 8, 0.5); color: #eab308; font-size: 10.5px; font-weight: 700;">ATTUALE</span>
                    </div>
                    <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; text-align: center;">
                        <div style="background: rgba(255,255,255,0.03); padding: 8px 4px; border-radius: 8px;">
                            <div style="font-size: 10px; color: #8b949e; font-weight: 600;">RENDIMENTO</div>
                            <div style="font-size: 16px; font-weight: 800; color: #eab308;">{cur_r:.2f}%</div>
                        </div>
                        <div style="background: rgba(255,255,255,0.03); padding: 8px 4px; border-radius: 8px;">
                            <div style="font-size: 10px; color: #8b949e; font-weight: 600;">VOLATILITÀ</div>
                            <div style="font-size: 16px; font-weight: 800; color: #58a6ff;">{cur_v:.2f}%</div>
                        </div>
                        <div style="background: rgba(255,255,255,0.03); padding: 8px 4px; border-radius: 8px;">
                            <div style="font-size: 10px; color: #8b949e; font-weight: 600;">SHARPE</div>
                            <div style="font-size: 16px; font-weight: 800; color: #3fb950;">{cur_s:.2f}</div>
                        </div>
                    </div>
                </div>
                """, unsafe_allow_html=True)

            with col_c2:
                st.markdown(f"""
                <div style="background: rgba(22, 27, 34, 0.85); backdrop-filter: blur(14px); border: 1px solid rgba(255, 153, 0, 0.35); border-left: 4px solid #ff9900; border-radius: 12px; padding: 16px 18px; box-shadow: 0 4px 16px rgba(0,0,0,0.3); height: 100%;">
                    <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px;">
                        <div style="font-weight: 700; font-size: 15px; color: #ffffff;">🏆 Max Sharpe Ratio</div>
                        <span class="argus-command-pill" style="border-color: rgba(255, 153, 0, 0.5); color: #ff9900; font-size: 10.5px; font-weight: 700;">OTTIMALE</span>
                    </div>
                    <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; text-align: center;">
                        <div style="background: rgba(255,255,255,0.03); padding: 8px 4px; border-radius: 8px;">
                            <div style="font-size: 10px; color: #8b949e; font-weight: 600;">RENDIMENTO</div>
                            <div style="font-size: 16px; font-weight: 800; color: #ff9900;">{ms_r:.2f}%</div>
                        </div>
                        <div style="background: rgba(255,255,255,0.03); padding: 8px 4px; border-radius: 8px;">
                            <div style="font-size: 10px; color: #8b949e; font-weight: 600;">VOLATILITÀ</div>
                            <div style="font-size: 16px; font-weight: 800; color: #58a6ff;">{ms_v:.2f}%</div>
                        </div>
                        <div style="background: rgba(255,255,255,0.03); padding: 8px 4px; border-radius: 8px;">
                            <div style="font-size: 10px; color: #8b949e; font-weight: 600;">SHARPE</div>
                            <div style="font-size: 16px; font-weight: 800; color: #3fb950;">{ms_s:.2f}</div>
                        </div>
                    </div>
                </div>
                """, unsafe_allow_html=True)

            with col_c3:
                st.markdown(f"""
                <div style="background: rgba(22, 27, 34, 0.85); backdrop-filter: blur(14px); border: 1px solid rgba(0, 243, 255, 0.35); border-left: 4px solid #00f3ff; border-radius: 12px; padding: 16px 18px; box-shadow: 0 4px 16px rgba(0,0,0,0.3); height: 100%;">
                    <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px;">
                        <div style="font-weight: 700; font-size: 15px; color: #ffffff;">🛡️ Minima Volatilità</div>
                        <span class="argus-command-pill" style="border-color: rgba(0, 243, 255, 0.5); color: #00f3ff; font-size: 10.5px; font-weight: 700;">DIFENSIVO</span>
                    </div>
                    <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; text-align: center;">
                        <div style="background: rgba(255,255,255,0.03); padding: 8px 4px; border-radius: 8px;">
                            <div style="font-size: 10px; color: #8b949e; font-weight: 600;">RENDIMENTO</div>
                            <div style="font-size: 16px; font-weight: 800; color: #00f3ff;">{mv_r:.2f}%</div>
                        </div>
                        <div style="background: rgba(255,255,255,0.03); padding: 8px 4px; border-radius: 8px;">
                            <div style="font-size: 10px; color: #8b949e; font-weight: 600;">VOLATILITÀ</div>
                            <div style="font-size: 16px; font-weight: 800; color: #58a6ff;">{mv_v:.2f}%</div>
                        </div>
                        <div style="background: rgba(255,255,255,0.03); padding: 8px 4px; border-radius: 8px;">
                            <div style="font-size: 10px; color: #8b949e; font-weight: 600;">SHARPE</div>
                            <div style="font-size: 16px; font-weight: 800; color: #3fb950;">{mv_s:.2f}</div>
                        </div>
                    </div>
                </div>
                """, unsafe_allow_html=True)

            mdp_info = opt.get("mdp", {})
            mcvar_info = opt.get("min_cvar", {})
            if mdp_info or mcvar_info:
                mdp_dr = float(mdp_info.get("diversification_ratio", 1.0))
                mdp_v = float(mdp_info.get("portfolio_volatility_pct", 0.0))
                mcvar_ann = float(mcvar_info.get("cvar_annual_pct", 0.0))
                mcvar_d = float(mcvar_info.get("cvar_daily_pct", 0.0))

                st.markdown('<div style="margin-top: 10px;"></div>', unsafe_allow_html=True)
                col_c4, col_c5 = st.columns(2)
                with col_c4:
                    st.markdown(f"""
                    <div style="background: rgba(22, 27, 34, 0.85); backdrop-filter: blur(14px); border: 1px solid rgba(168, 85, 247, 0.35); border-left: 4px solid #a855f7; border-radius: 12px; padding: 16px 18px; box-shadow: 0 4px 16px rgba(0,0,0,0.3); height: 100%;">
                        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px;">
                            <div style="font-weight: 700; font-size: 15px; color: #ffffff;">💎 Massima Diversificazione (MDP)</div>
                            <span class="argus-command-pill" style="border-color: rgba(168, 85, 247, 0.5); color: #a855f7; font-size: 10.5px; font-weight: 700;">CHOUEIFATY</span>
                        </div>
                        <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 8px; text-align: center;">
                            <div style="background: rgba(255,255,255,0.03); padding: 8px 4px; border-radius: 8px;">
                                <div style="font-size: 10px; color: #8b949e; font-weight: 600;">DIVERSIFICATION RATIO</div>
                                <div style="font-size: 16px; font-weight: 800; color: #a855f7;">{mdp_dr:.3f}</div>
                            </div>
                            <div style="background: rgba(255,255,255,0.03); padding: 8px 4px; border-radius: 8px;">
                                <div style="font-size: 10px; color: #8b949e; font-weight: 600;">VOLATILITÀ STIMATA</div>
                                <div style="font-size: 16px; font-weight: 800; color: #58a6ff;">{mdp_v:.2f}%</div>
                            </div>
                        </div>
                    </div>
                    """, unsafe_allow_html=True)
                with col_c5:
                    st.markdown(f"""
                    <div style="background: rgba(22, 27, 34, 0.85); backdrop-filter: blur(14px); border: 1px solid rgba(239, 68, 68, 0.35); border-left: 4px solid #ef4444; border-radius: 12px; padding: 16px 18px; box-shadow: 0 4px 16px rgba(0,0,0,0.3); height: 100%;">
                        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px;">
                            <div style="font-weight: 700; font-size: 15px; color: #ffffff;">🛡️ Minimo CVaR (Expected Shortfall)</div>
                            <span class="argus-command-pill" style="border-color: rgba(239, 68, 68, 0.5); color: #ef4444; font-size: 10.5px; font-weight: 700;">ROCKAFELLAR LP</span>
                        </div>
                        <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 8px; text-align: center;">
                            <div style="background: rgba(255,255,255,0.03); padding: 8px 4px; border-radius: 8px;">
                                <div style="font-size: 10px; color: #8b949e; font-weight: 600;">CVaR 95% ANNUO</div>
                                <div style="font-size: 16px; font-weight: 800; color: #ef4444;">{mcvar_ann:.2f}%</div>
                            </div>
                            <div style="background: rgba(255,255,255,0.03); padding: 8px 4px; border-radius: 8px;">
                                <div style="font-size: 10px; color: #8b949e; font-weight: 600;">CVaR GIORNALIERO</div>
                                <div style="font-size: 16px; font-weight: 800; color: #f97316;">{mcvar_d:.2f}%</div>
                            </div>
                        </div>
                    </div>
                    """, unsafe_allow_html=True)

        # ── SUPER-RIBILANCIATORE & SIMULATORE TATTICO UNIFICATO ───────────────────────
        st.divider()
        col_sb_h1, col_sb_h2 = st.columns([3.5, 1.2])
        with col_sb_h1:
            st.markdown("#### 🧮 Super-Ribilanciatore & Simulatore Tattico Unificato")
            st.caption("Piattaforma unificata di ribilanciamento: allinea il portafoglio a una strategia quantitativa ottima (Max Sharpe, Minima Volatilità, Equal Risk, HRP, Equi-peso) oppure simula variazioni manuali di Pesi (%), Quote (N) e Controvalore (€). Calcola in tempo reale le metriche di rischio e genera la distinta esecutiva degli ordini broker con export CSV.")
        with col_sb_h2:
            st.markdown('<div style="margin-top: 6px;"></div>', unsafe_allow_html=True)
            glossary_modal("ℹ️ Guida al Super-Ribilanciatore", """
<div style="font-size: 13.5px; line-height: 1.5; color: #c9d1d9;">
<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,153,0,0.25); border-radius: 10px; padding: 14px; margin-bottom: 8px;">
  <div style="color: #ff9900; font-size: 15px; font-weight: 700; margin-bottom: 6px;">🧮 Motore di Ribilanciamento & Execution Ticket</div>
  <div style="margin-bottom: 6px;"><b>📌 Cosa fa:</b> Calcola il differenziale esatto tra la composizione attuale del portafoglio e il profilo bersaglio desiderato, generando una distinta completa di ordini di acquisto e vendita.</div>
  <div style="margin-bottom: 6px;"><b>📐 Strategie di Riferimento:</b><br>
    • <b>🎯 Max Sharpe (Ledoit-Wolf):</b> Massimizza l'efficienza rendimento/rischio.<br>
    • <b>🛡️ Minima Volatilità:</b> Minimizza la varianza complessiva del portafoglio.<br>
    • <b>🧬 Equal Risk Contribution (ERC):</b> Parità di rischio pura (1/N di volatilità).<br>
    • <b>🌳 Hierarchical Risk Parity (HRP):</b> Allocazione gerarchica ad albero.<br>
    • <b>⚖️ Equi-peso (1/N):</b> Equi-ponderazione del capitale.
  </div>
  <div><b>💡 Iniezione Cassa & Quote Intere:</b> Permette di simulare l'effetto di nuova liquidità iniettata o prelevata e di arrotondare gli ordini alle quote intere negoziabili sul mercato.</div>
</div>
</div>
""", button_label="💡 Come funziona?")

        tickers_in_opt = opt.get("tickers", [])
        if tickers_in_opt and not pos.empty:
            def _to_weight_map(raw_weights, tickers):
                if isinstance(raw_weights, dict):
                    return raw_weights
                if isinstance(raw_weights, (list, tuple, np.ndarray)) and len(raw_weights) == len(tickers):
                    return {t: float(w) for t, w in zip(tickers, raw_weights)}
                return {t: 1.0 / len(tickers) for t in tickers}

            cur_w_map = _to_weight_map(opt.get("current", {}).get("weights"), tickers_in_opt)
            ms_w_map = _to_weight_map(opt.get("max_sharpe", {}).get("weights"), tickers_in_opt)
            mv_w_map = _to_weight_map(opt.get("min_vol", {}).get("weights"), tickers_in_opt)
            mdp_w_map = _to_weight_map(opt.get("mdp", {}).get("weights"), tickers_in_opt)
            mcvar_w_map = _to_weight_map(opt.get("min_cvar", {}).get("weights"), tickers_in_opt)

            # Mappa prezzi e quote attuali
            price_map = {}
            qty_map = {}
            val_map = {}
            for _, r in pos.iterrows():
                tk = str(r.get("ticker", ""))
                lp = float(r.get("last_price", 0.0) or 0.0)
                qn = float(r.get("qty_net", 0.0) or 0.0)
                cv = float(r.get("current_value", 0.0) or (qn * lp if lp > 0 else 0.0))
                price_map[tk] = lp if lp > 0 else 100.0
                qty_map[tk] = qn
                val_map[tk] = cv

            for t in tickers_in_opt:
                if t not in price_map: price_map[t] = 100.0
                if t not in qty_map: qty_map[t] = 10.0
                if t not in val_map: val_map[t] = qty_map[t] * price_map[t]

            tot_cur_val = sum(qty_map.get(t, 0.0) * price_map.get(t, 100.0) for t in tickers_in_opt)

            col_ctrl_s1, col_ctrl_s2, col_ctrl_s3 = st.columns([1.8, 1.1, 0.9], vertical_alignment="center")
            with col_ctrl_s1:
                sbx_mode = st.radio(
                    "Modalità di Regolazione:",
                    ["🔢 Variazione Quote (Vendi / Compra N Azioni)", "📊 Pesi Percentuali (%)", "💶 Importo Monetario (€)"],
                    horizontal=True,
                    key="sbx_simulation_mode"
                )
            with col_ctrl_s2:
                cash_injection = st.number_input(
                    "Iniezione Cassa (€):",
                    value=0.0, step=500.0, format="%.2f",
                    key="sbx_cash_injection_val",
                    help="Inserisci un valore positivo per nuova liquidità o negativo per disinvestimento."
                )
            with col_ctrl_s3:
                int_shares_opt = st.checkbox(
                    "Quote Intere (Broker)",
                    value=True,
                    key="sbx_int_shares_flag_val",
                    help="Arrotonda le quote operative all'intero più vicino."
                )

            # Helper per applicare pesi bersaglio
            def apply_target_strategy_weights(w_dict):
                target_tot = max(0.0, tot_cur_val + cash_injection)
                for t in tickers_in_opt:
                    raw_w = float(w_dict.get(t, 0.0))
                    w = 0.0 if abs(raw_w) < 1e-5 else raw_w
                    w_pct = round(w * 100.0, 2)
                    val = w * target_tot
                    unit_px = float(price_map.get(t, 100.0))
                    q = (val / unit_px) if unit_px > 0 else 0.0
                    if int_shares_opt:
                        q = float(round(q))
                        val = q * unit_px
                    st.session_state[f"sbx_q_{t}"] = q
                    st.session_state[f"sbx_m_{t}"] = round(val, 2)
                    st.session_state[f"sbx_w_{t}"] = w_pct
                st.session_state["sbx_edit_key_qty"] = str(uuid.uuid4())[:8]
                st.session_state["sbx_edit_key_m"] = str(uuid.uuid4())[:8]
                st.session_state["sbx_edit_key_w"] = str(uuid.uuid4())[:8]
                st.rerun()

            st.markdown('<div style="font-size:12px; font-weight:700; color:#8b949e; margin: 8px 0 4px 0;">🎯 PRESET STRATEGICI & AZIONI RAPIDE:</div>', unsafe_allow_html=True)
            col_p1, col_p2, col_p3, col_p4, col_p5 = st.columns(5)
            with col_p1:
                if st.button("⭐ Attuale", key="btn_pre_cur", use_container_width=True, help="Ripristina posizioni attuali"):
                    apply_target_strategy_weights(cur_w_map)
            with col_p2:
                if st.button("🏆 Max Sharpe", key="btn_pre_ms", use_container_width=True, help="Massima efficienza Markowitz"):
                    apply_target_strategy_weights(ms_w_map)
            with col_p3:
                if st.button("🛡️ Min Vol", key="btn_pre_mv", use_container_width=True, help="Minima varianza Markowitz"):
                    apply_target_strategy_weights(mv_w_map)
            with col_p4:
                if st.button("🧬 Equal Risk", key="btn_pre_erc", use_container_width=True, help="Parità di rischio ERC"):
                    df_ret_temp = results.get("returns", pd.DataFrame())
                    erc_res_t = compute_equal_risk_contribution_portfolio(df_ret_temp[tickers_in_opt] if not df_ret_temp.empty and all(t in df_ret_temp.columns for t in tickers_in_opt) else None)
                    apply_target_strategy_weights(erc_res_t.get("weights", {t: 1.0/len(tickers_in_opt) for t in tickers_in_opt}))
            with col_p5:
                if st.button("🌳 HRP Tree", key="btn_pre_hrp", use_container_width=True, help="Hierarchical Risk Parity"):
                    df_ret_temp = results.get("returns", pd.DataFrame())
                    hrp_res_t = compute_hrp_portfolio(df_ret_temp[tickers_in_opt] if not df_ret_temp.empty and all(t in df_ret_temp.columns for t in tickers_in_opt) else None)
                    hrp_w_dict = hrp_res_t.get("weights", {t: 1.0/len(tickers_in_opt) for t in tickers_in_opt}) if hrp_res_t else {t: 1.0/len(tickers_in_opt) for t in tickers_in_opt}
                    apply_target_strategy_weights(hrp_w_dict)

            col_p6, col_p7, col_p8, col_p9 = st.columns(4)
            with col_p6:
                if st.button("💎 Max Div (MDP)", key="btn_pre_mdp", use_container_width=True, help="Massima diversificazione Choueifaty"):
                    apply_target_strategy_weights(mdp_w_map)
            with col_p7:
                if st.button("🛡️ Min-CVaR (LP)", key="btn_pre_mcvar", use_container_width=True, help="Minimizzazione Expected Shortfall"):
                    apply_target_strategy_weights(mcvar_w_map)
            with col_p8:
                if st.button("⚖️ Equi-peso", key="btn_pre_eq", use_container_width=True, help="1/N capitale"):
                    apply_target_strategy_weights({t: 1.0 / len(tickers_in_opt) for t in tickers_in_opt})
            with col_p9:
                if st.button("🧹 Azzera (0)", key="btn_pre_zero", use_container_width=True, help="Azzera tutto"):
                    apply_target_strategy_weights(dict.fromkeys(tickers_in_opt, 0.0))

            st.divider()

            sim_weights = {}
            sim_qtys = {}
            sim_vals = {}

            if sbx_mode == "🔢 Variazione Quote (Vendi / Compra N Azioni)":
                edit_key = st.session_state.get("sbx_edit_key_qty", "default")
                editor_state = st.session_state.get(f"data_editor_qty_{edit_key}", {})
                if isinstance(editor_state, dict) and "edited_rows" in editor_state:
                    for row_idx_str, edits in editor_state["edited_rows"].items():
                        try:
                            r_idx = int(row_idx_str)
                            if 0 <= r_idx < len(tickers_in_opt) and "sim_qty" in edits:
                                tk = tickers_in_opt[r_idx]
                                st.session_state[f"sbx_q_{tk}"] = float(edits["sim_qty"])
                        except (ValueError, TypeError):
                            pass

                st.markdown('<div style="font-size:12.5px; font-weight:700; color:#ff9900; margin: 12px 0 6px 0;">📋 TABELLA DI REBALANCING OPERATIVO (MODIFICA LE QUOTE NELLA COLONNA "NUOVE QUOTE"):</div>', unsafe_allow_html=True)
                
                rows_data = []
                for t in tickers_in_opt:
                    cur_q = float(qty_map.get(t, 0.0))
                    cur_px = float(price_map.get(t, 100.0))
                    val_q = float(st.session_state.get(f"sbx_q_{t}", cur_q))
                    cur_v = cur_q * cur_px
                    sim_v = val_q * cur_px
                    delta_q = val_q - cur_q
                    delta_v = delta_q * cur_px
                    if delta_q > 0:
                        act = f"🔵 COMPRA +{delta_q:,.1f} (Costa € {delta_v:,.2f})"
                    elif delta_q < 0:
                        act = f"🟢 VENDI {abs(delta_q):,.1f} (Libera € {abs(delta_v):,.2f})"
                    else:
                        act = "⚪ Invariato"
                    
                    rows_data.append({
                        "ticker": t,
                        "price": cur_px,
                        "current_qty": cur_q,
                        "current_value": cur_v,
                        "sim_qty": val_q,
                        "sim_value": sim_v,
                        "delta_qty": delta_q,
                        "action": act
                    })
                
                df_editor_qty = pd.DataFrame(rows_data)
                
                edited_df = st.data_editor(
                    df_editor_qty,
                    hide_index=True,
                    use_container_width=True,
                    disabled=["ticker", "price", "current_qty", "current_value", "sim_value", "delta_qty", "action"],
                    column_config={
                        "ticker": st.column_config.TextColumn("Ticker", width="small"),
                        "price": st.column_config.NumberColumn("Prezzo (€)", format="€ %,.2f"),
                        "current_qty": st.column_config.NumberColumn("Quote Attuali", format="%,.1f"),
                        "current_value": st.column_config.NumberColumn("Valore Attuale", format="€ %,.2f"),
                        "sim_qty": st.column_config.NumberColumn("🎯 Nuove Quote (Modifica)", format="%,.1f", min_value=0.0, step=1.0, required=True),
                        "sim_value": st.column_config.NumberColumn("Valore Target", format="€ %,.2f"),
                        "delta_qty": st.column_config.NumberColumn("Δ Quote", format="%+,.1f"),
                        "action": st.column_config.TextColumn("Azione Operativa", width="medium")
                    },
                    key=f"data_editor_qty_{edit_key}"
                )

                for _, r in edited_df.iterrows():
                    tk = str(r["ticker"])
                    sq = float(r["sim_qty"])
                    st.session_state[f"sbx_q_{tk}"] = sq
                    sim_qtys[tk] = sq
                    cur_px = float(price_map.get(tk, 100.0))
                    sim_vals[tk] = sq * cur_px

                tot_sim_val = sum(sim_vals.values())
                if tot_sim_val > 0:
                    norm_sim_weights = {t: sim_vals[t] / tot_sim_val for t in tickers_in_opt}
                else:
                    norm_sim_weights = {t: 1.0 / len(tickers_in_opt) for t in tickers_in_opt}

            elif sbx_mode == "💶 Importo Monetario (€)":
                edit_key_m = st.session_state.get("sbx_edit_key_m", "default")
                editor_state_m = st.session_state.get(f"data_editor_m_{edit_key_m}", {})
                if isinstance(editor_state_m, dict) and "edited_rows" in editor_state_m:
                    for row_idx_str, edits in editor_state_m["edited_rows"].items():
                        try:
                            r_idx = int(row_idx_str)
                            if 0 <= r_idx < len(tickers_in_opt) and "sim_value" in edits:
                                tk = tickers_in_opt[r_idx]
                                st.session_state[f"sbx_m_{tk}"] = float(edits["sim_value"])
                        except (ValueError, TypeError):
                            pass

                st.markdown('<div style="font-size:12.5px; font-weight:700; color:#ff9900; margin: 12px 0 6px 0;">📋 TABELLA OPERATIVA MONETARIA (MODIFICA IL CONTROVALORE NELLA COLONNA "NUOVO VALORE"):</div>', unsafe_allow_html=True)
                
                rows_data_m = []
                for t in tickers_in_opt:
                    cur_v = float(val_map.get(t, 0.0))
                    cur_px = float(price_map.get(t, 100.0))
                    val_m = float(st.session_state.get(f"sbx_m_{t}", cur_v))
                    delta_v = val_m - cur_v
                    res_q = (val_m / cur_px) if cur_px > 0 else 0.0
                    if int_shares_opt:
                        res_q = float(round(res_q))
                    if delta_v > 0:
                        act = f"🔵 INIETTA +€ {delta_v:,.2f}"
                    elif delta_v < 0:
                        act = f"🟢 DISINVESTI -€ {abs(delta_v):,.2f}"
                    else:
                        act = "⚪ Invariato"

                    rows_data_m.append({
                        "ticker": t,
                        "price": cur_px,
                        "current_value": cur_v,
                        "sim_value": val_m,
                        "sim_qty": res_q,
                        "delta_val": delta_v,
                        "action": act
                    })
                
                df_editor_m = pd.DataFrame(rows_data_m)
                
                edited_df_m = st.data_editor(
                    df_editor_m,
                    hide_index=True,
                    use_container_width=True,
                    disabled=["ticker", "price", "current_value", "sim_qty", "delta_val", "action"],
                    column_config={
                        "ticker": st.column_config.TextColumn("Ticker", width="small"),
                        "price": st.column_config.NumberColumn("Prezzo (€)", format="€ %,.2f"),
                        "current_value": st.column_config.NumberColumn("Valore Attuale", format="€ %,.2f"),
                        "sim_value": st.column_config.NumberColumn("🎯 Nuovo Valore (€) (Modifica)", format="€ %,.2f", min_value=0.0, step=250.0, required=True),
                        "sim_qty": st.column_config.NumberColumn("Quote Stimate", format="%,.1f"),
                        "delta_val": st.column_config.NumberColumn("Δ Capitale", format="€ %+,.2f"),
                        "action": st.column_config.TextColumn("Azione Operativa", width="medium")
                    },
                    key=f"data_editor_m_{edit_key_m}"
                )

                for _, r in edited_df_m.iterrows():
                    tk = str(r["ticker"])
                    sm = float(r["sim_value"])
                    st.session_state[f"sbx_m_{tk}"] = sm
                    sim_vals[tk] = sm
                    cur_px = float(price_map.get(tk, 100.0))
                    res_q = (sm / cur_px) if cur_px > 0 else 0.0
                    sim_qtys[tk] = float(round(res_q)) if int_shares_opt else res_q

                tot_sim_val = sum(sim_vals.values())
                if tot_sim_val > 0:
                    norm_sim_weights = {t: sim_vals[t] / tot_sim_val for t in tickers_in_opt}
                else:
                    norm_sim_weights = {t: 1.0 / len(tickers_in_opt) for t in tickers_in_opt}

            else:  # Pesi Percentuali (%)
                edit_key_w = st.session_state.get("sbx_edit_key_w", "default")
                editor_state_w = st.session_state.get(f"data_editor_w_{edit_key_w}", {})
                if isinstance(editor_state_w, dict) and "edited_rows" in editor_state_w:
                    for row_idx_str, edits in editor_state_w["edited_rows"].items():
                        try:
                            r_idx = int(row_idx_str)
                            if 0 <= r_idx < len(tickers_in_opt) and "sim_weight_pct" in edits:
                                tk = tickers_in_opt[r_idx]
                                st.session_state[f"sbx_w_{tk}"] = float(edits["sim_weight_pct"])
                        except (ValueError, TypeError):
                            pass

                st.markdown('<div style="font-size:12.5px; font-weight:700; color:#ff9900; margin: 12px 0 6px 0;">📋 TABELLA DI ALLOCAZIONE PESI (MODIFICA I PESI NELLA COLONNA "NUOVO PESO (%)"):</div>', unsafe_allow_html=True)
                
                target_tot_ref = max(0.0, tot_cur_val + cash_injection)
                rows_data_w = []
                for t in tickers_in_opt:
                    cur_w = float(cur_w_map.get(t, 1.0 / len(tickers_in_opt)) * 100.0)
                    cur_px = float(price_map.get(t, 100.0))
                    val_w = float(st.session_state.get(f"sbx_w_{t}", cur_w))
                    delta_w = val_w - cur_w
                    est_val = (val_w / 100.0) * target_tot_ref
                    est_q = (est_val / cur_px) if cur_px > 0 else 0.0
                    if int_shares_opt:
                        est_q = float(round(est_q))

                    rows_data_w.append({
                        "ticker": t,
                        "price": cur_px,
                        "cur_weight_pct": round(cur_w, 2),
                        "sim_weight_pct": round(val_w, 2),
                        "sim_value": est_val,
                        "sim_qty": est_q,
                        "delta_pct": delta_w
                    })
                
                df_editor_w = pd.DataFrame(rows_data_w)
                
                edited_df_w = st.data_editor(
                    df_editor_w,
                    hide_index=True,
                    use_container_width=True,
                    disabled=["ticker", "price", "cur_weight_pct", "sim_value", "sim_qty", "delta_pct"],
                    column_config={
                        "ticker": st.column_config.TextColumn("Ticker", width="small"),
                        "price": st.column_config.NumberColumn("Prezzo (€)", format="€ %,.2f"),
                        "cur_weight_pct": st.column_config.NumberColumn("Peso Attuale", format="%.2f%%"),
                        "sim_weight_pct": st.column_config.NumberColumn("🎯 Nuovo Peso (Modifica)", format="%.2f%%", min_value=0.0, max_value=100.0, step=0.5, required=True),
                        "sim_value": st.column_config.NumberColumn("Valore Target", format="€ %,.2f"),
                        "sim_qty": st.column_config.NumberColumn("Quote Target", format="%,.1f"),
                        "delta_pct": st.column_config.NumberColumn("Δ Peso %", format="%+,.2f%%")
                    },
                    key=f"data_editor_w_{edit_key_w}"
                )

                tot_raw_w = 0.0
                for _, r in edited_df_w.iterrows():
                    tk = str(r["ticker"])
                    sw = float(r["sim_weight_pct"])
                    st.session_state[f"sbx_w_{tk}"] = sw
                    sim_weights[tk] = sw
                    tot_raw_w += sw

                if tot_raw_w > 0:
                    norm_sim_weights = {t: w / tot_raw_w for t, w in sim_weights.items()}
                else:
                    norm_sim_weights = {t: 1.0 / len(tickers_in_opt) for t in tickers_in_opt}
                
                tot_sim_val = max(0.0, tot_cur_val + cash_injection)
                for t in tickers_in_opt:
                    sim_vals[t] = norm_sim_weights[t] * tot_sim_val
                    unit_px = float(price_map.get(t, 100.0))
                    q = (sim_vals[t] / unit_px) if unit_px > 0 else 0.0
                    sim_qtys[t] = float(round(q)) if int_shares_opt else q

                w_color = "#4ade80" if abs(tot_raw_w - 100.0) < 0.1 else "#facc15"
                st.caption(f"Somma Pesi Assegnati: <b style='color:{w_color};'>{tot_raw_w:.1f}%</b> {'(Normalizzati automaticamente a 100%)' if abs(tot_raw_w - 100.0) >= 0.1 else '✅'}", unsafe_allow_html=True)

            df_ret_sim = results.get("returns", pd.DataFrame())
            if df_ret_sim.empty or not all(t in df_ret_sim.columns for t in tickers_in_opt):
                df_pr = results.get("df_prices", pd.DataFrame())
                if not df_pr.empty and "ticker" in df_pr.columns:
                    piv = df_pr.pivot(index="price_date", columns="ticker", values="close")
                    df_ret_sim = piv[[t for t in tickers_in_opt if t in piv.columns]].pct_change().dropna()

            valid_ts = [t for t in tickers_in_opt if t in df_ret_sim.columns]
            if len(valid_ts) >= 2:
                mu_vec = df_ret_sim[valid_ts].mean().values * 252.0
                cov_mat = df_ret_sim[valid_ts].cov().values * 252.0
                
                w_sim_arr = np.array([norm_sim_weights.get(t, 0.0) for t in valid_ts])
                w_cur_arr = np.array([cur_w_map.get(t, 0.0) for t in valid_ts])
                
                ret_sim = float(np.dot(w_sim_arr, mu_vec)) * 100.0
                vol_sim = float(np.sqrt(np.dot(w_sim_arr.T, np.dot(cov_mat, w_sim_arr)))) * 100.0
                sharpe_sim = float((ret_sim - 2.75) / max(0.001, vol_sim))
                var_sim = float(1.645 * (vol_sim / np.sqrt(252)))

                ret_cur = float(np.dot(w_cur_arr, mu_vec)) * 100.0
                vol_cur = float(np.sqrt(np.dot(w_cur_arr.T, np.dot(cov_mat, w_cur_arr)))) * 100.0
                sharpe_cur = float((ret_cur - 2.75) / max(0.001, vol_cur))
                var_cur = float(1.645 * (vol_cur / np.sqrt(252)))

                d_ret = ret_sim - ret_cur
                d_vol = vol_sim - vol_cur
                d_var = var_sim - var_cur
                d_sharpe = sharpe_sim - sharpe_cur

                # Calcolo totale acquisti e vendite per la distinta broker
                tot_buy_amt = sum((sim_qtys[t] - qty_map.get(t, 0.0)) * price_map.get(t, 100.0) for t in valid_ts if sim_qtys.get(t, 0.0) > qty_map.get(t, 0.0))
                tot_sell_amt = sum((qty_map.get(t, 0.0) - sim_qtys[t]) * price_map.get(t, 100.0) for t in valid_ts if sim_qtys.get(t, 0.0) < qty_map.get(t, 0.0))

                # ── DASHBOARD FLUSSI FINANZIARI & RISCHIO ────────────────────
                st.markdown('<div style="margin-top: 15px;"></div>', unsafe_allow_html=True)
                col_fl1, col_fl2, col_fl3, col_fl4 = st.columns(4)
                with col_fl1:
                    metric_card("Patrimonio Target", f"€ {tot_sim_val:,.2f}".replace(",", "."), delta=f"Attuale: € {tot_cur_val:,.2f}".replace(",", "."), positive=True, help_text="Valore complessivo stimato del portafoglio post-ribilanciamento.")
                with col_fl2:
                    metric_card("Totale Acquisti", f"€ {tot_buy_amt:,.2f}".replace(",", "."), delta="Liquidità Richiesta", positive=True, help_text="Controvalore degli acquisti necessari per raggiungere il target.")
                with col_fl3:
                    metric_card("Totale Vendite", f"€ {tot_sell_amt:,.2f}".replace(",", "."), delta="Liquidità Liberata", positive=True, help_text="Controvalore delle vendite generate dal ribilanciamento.")
                with col_fl4:
                    cf_net_disp = tot_sell_amt - tot_buy_amt
                    cf_txt = f"+€ {cf_net_disp:,.2f}".replace(",", ".") if cf_net_disp >= 0 else f"-€ {abs(cf_net_disp):,.2f}".replace(",", ".")
                    metric_card("Flusso di Cassa Netto", cf_txt, delta="Liquidità Netta Generata" if cf_net_disp >= 0 else "Capitale Aggiuntivo", positive=(cf_net_disp >= 0), help_text="Differenza tra vendite e acquisti.")

                st.markdown('<div style="margin-top: 10px;"></div>', unsafe_allow_html=True)
                c_sb1, c_sb2, c_sb3, c_sb4 = st.columns(4)
                with c_sb1:
                    metric_card("Rendimento Atteso", f"{ret_sim:.2f}%", delta=f"{d_ret:+.2f}% vs Attuale", positive=(d_ret >= 0), help_text="Rendimento annuo atteso.")
                with c_sb2:
                    metric_card("Volatilità Annua", f"{vol_sim:.2f}%", delta=f"{d_vol:+.2f}% vs Attuale", positive=(d_vol <= 0), help_text="Volatilità annua stimata.")
                with c_sb3:
                    metric_card("VaR 95% Giornaliero", f"{var_sim:.2f}%", delta=f"{d_var:+.2f}% vs Attuale", positive=(d_var <= 0), help_text="Value at Risk 95% giornaliero.")
                with c_sb4:
                    metric_card("Sharpe Ratio Simulato", f"{sharpe_sim:.2f}", delta=f"{d_sharpe:+.2f} vs Attuale", positive=(d_sharpe >= 0), help_text="Indice di Sharpe atteso.")

                df_compare_w = pd.DataFrame({
                    "Ticker": valid_ts,
                    "Peso Attuale (%)": [cur_w_map.get(t, 0.0) * 100.0 for t in valid_ts],
                    "Peso Target (%)": [norm_sim_weights[t] * 100.0 for t in valid_ts]
                })

                fig_sbx = go.Figure()
                fig_sbx.add_trace(go.Bar(
                    x=df_compare_w["Ticker"],
                    y=df_compare_w["Peso Attuale (%)"],
                    name="Allocazione Attuale (%)",
                    marker=dict(color="#64748b", line=dict(color="rgba(255,255,255,0.1)", width=1)),
                    hovertemplate="<b>%{x}</b><br>Allocazione Attuale: <b>%{y:.2f}%</b><extra></extra>"
                ))
                fig_sbx.add_trace(go.Bar(
                    x=df_compare_w["Ticker"],
                    y=df_compare_w["Peso Target (%)"],
                    name="Allocazione Target / Ribilanciata (%)",
                    marker=dict(color="#ff9900", line=dict(color="rgba(255,153,0,0.4)", width=1)),
                    hovertemplate="<b>%{x}</b><br>Allocazione Target: <b>%{y:.2f}%</b><extra></extra>"
                ))
                fig_sbx.update_layout(
                    barmode="group",
                    height=340,
                    template="plotly_dark",
                    paper_bgcolor="rgba(0,0,0,0)",
                    plot_bgcolor="rgba(0,0,0,0)",
                    margin=dict(l=20, r=20, t=35, b=30),
                    legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="center", x=0.5, font=dict(size=11.5)),
                    xaxis=dict(title=None, tickangle=-45, tickfont=dict(size=11, family="monospace")),
                    yaxis=dict(title="Peso %", gridcolor="rgba(255,255,255,0.06)", zerolinecolor="rgba(255,255,255,0.12)")
                )
                apply_plotly_theme(fig_sbx)
                st.plotly_chart(fig_sbx, use_container_width=True)

                # ── DISTINTA ORDINI ESECUTIVI PER IL BROKER ──────────────────
                st.markdown("##### 📋 Distinta Ordini Esecutivi di Borsa (Broker Order Book)")
                table_rows = []
                for t in valid_ts:
                    cq = float(qty_map.get(t, 0.0))
                    sq = float(sim_qtys.get(t, 0.0))
                    asset_px = float(price_map.get(t, 100.0))
                    cv = cq * asset_px
                    sv = sq * asset_px
                    dq = sq - cq
                    dv = sv - cv
                    cw = cur_w_map.get(t, 0.0) * 100.0
                    sw = norm_sim_weights.get(t, 0.0) * 100.0

                    if dq < -1e-4:
                        action = f"SELL {abs(dq):,.1f} quote"
                    elif dq > 1e-4:
                        action = f"BUY +{dq:,.1f} quote"
                    else:
                        action = "HOLD MANTIENI"

                    table_rows.append({
                        "Ticker": t,
                        "Azione Tattica": action,
                        "Prezzo (€)": asset_px,
                        "Quote Attuali": cq,
                        "Quote Target": sq,
                        "Quote Operative (Δ)": dq,
                        "Valore Attuale (€)": cv,
                        "Valore Target (€)": sv,
                        "Controvalore Ordine (€)": dv,
                        "Peso Attuale %": cw,
                        "Peso Target %": sw
                    })

                df_orders_exec = pd.DataFrame(table_rows)

                col_ord_f1, col_ord_f2, col_ord_f3 = st.columns([2.0, 1.3, 0.9], vertical_alignment="bottom")
                with col_ord_f1:
                    search_ord = st.text_input("🔍 Cerca Titolo:", placeholder="Filtra per Ticker (es. GOOGL, BABA, MSFT)...", key="search_unified_rebal")
                with col_ord_f2:
                    filter_ord_act = st.selectbox("🏷️ Direzione Ordine:", ["Tutti gli Ordini", "🟢 Solo ACQUISTO (BUY)", "🔴 Solo VENDITA (SELL)", "⚪ Solo MANTIENI (HOLD)"], key="filter_unified_rebal")

                df_orders_disp = df_orders_exec.copy()
                if search_ord:
                    df_orders_disp = df_orders_disp[df_orders_disp["Ticker"].astype(str).str.contains(search_ord.strip(), case=False, na=False)]
                if filter_ord_act == "🟢 Solo ACQUISTO (BUY)":
                    df_orders_disp = df_orders_disp[df_orders_disp["Azione Tattica"].astype(str).str.contains("BUY", case=False, na=False)]
                elif filter_ord_act == "🔴 Solo VENDITA (SELL)":
                    df_orders_disp = df_orders_disp[df_orders_disp["Azione Tattica"].astype(str).str.contains("SELL", case=False, na=False)]
                elif filter_ord_act == "⚪ Solo MANTIENI (HOLD)":
                    df_orders_disp = df_orders_disp[df_orders_disp["Azione Tattica"].astype(str).str.contains("HOLD|MANTIENI", case=False, na=False)]

                with col_ord_f3:
                    render_export_toolbar(
                        df_orders_disp,
                        file_prefix="distinta_ordini_ribilanciamento",
                        key_suffix="mq_orders",
                        table_title="Distinta Ordini Ribilanciamento"
                    )

                if df_orders_disp.empty:
                    st.info("ℹ️ Nessun ordine corrisponde ai filtri selezionati.")
                else:
                    def highlight_broker_action(val):
                        if "BUY" in str(val):
                            return "color: #3fb950; font-weight: bold;"
                        elif "SELL" in str(val):
                            return "color: #f85149; font-weight: bold;"
                        return "color: #8b949e;"

                    rebal_unified_cfg = {
                        "Ticker": st.column_config.TextColumn("Ticker", width="small"),
                        "Azione Tattica": st.column_config.TextColumn("Azione Operativa", width="medium"),
                        "Prezzo (€)": st.column_config.NumberColumn("Prezzo Spot (€)", format="€ %,.2f"),
                        "Quote Attuali": st.column_config.NumberColumn("Quote Attuali", format="%,.1f"),
                        "Quote Target": st.column_config.NumberColumn("Quote Target", format="%,.1f"),
                        "Quote Operative (Δ)": st.column_config.NumberColumn("Quote Operative (Δ)", format="%+,.1f"),
                        "Controvalore Ordine (€)": st.column_config.NumberColumn("Controvalore Ordine (€)", format="€ %+,.2f"),
                        "Peso Attuale %": st.column_config.ProgressColumn("Peso Attuale %", format="%.2f%%", min_value=0.0, max_value=100.0),
                        "Peso Target %": st.column_config.ProgressColumn("Peso Target %", format="%.2f%%", min_value=0.0, max_value=100.0),
                    }
                    st.dataframe(
                        df_orders_disp.style.map(highlight_broker_action, subset=["Azione Tattica"]).format({
                            "Prezzo (€)": "€ {:,.2f}",
                            "Quote Attuali": "{:,.1f}",
                            "Quote Target": "{:,.1f}",
                            "Quote Operative (Δ)": "{:+,.1f}",
                            "Valore Attuale (€)": "€ {:,.2f}",
                            "Valore Target (€)": "€ {:,.2f}",
                            "Controvalore Ordine (€)": "€ {:+,.2f}",
                            "Peso Attuale %": "{:.2f}%",
                            "Peso Target %": "{:.2f}%"
                        }),
                        column_config=rebal_unified_cfg,
                        use_container_width=True,
                        hide_index=True
                    )

        st.divider()
        col_head_hrp1, col_head_hrp2 = st.columns([3.2, 1.1])
        with col_head_hrp1:
            st.markdown("#### 🧬 Hierarchical Risk Parity (HRP - Marcos López de Prado)")
            st.caption("Allocazione robusta basata su Machine Learning & Clustering Gerarchico ad Albero (Tree Clustering & Recursive Bisection) senza inversione di matrice.")
        with col_head_hrp2:
            st.markdown('<div style="margin-top: 6px;"></div>', unsafe_allow_html=True)
            glossary_modal("ℹ️ Guida all'Hierarchical Risk Parity (HRP)", """
<div style="font-size: 13.5px; line-height: 1.45;">

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px; margin-bottom: 8px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">📌 Cos'è l'Hierarchical Risk Parity (HRP)</div>
  <div>Un algoritmo quantitativo di allocazione sviluppato da Marcos López de Prado (2016) che sfrutta la teoria dei grafi e il machine learning non supervisionato per superare l'instabilità dell'inversione di matrice (&Sigma;<sup>&minus;1</sup>) di Markowitz.</div>
</div>

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px; margin-bottom: 8px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">📐 Il Processo in 3 Fasi Matematiche</div>
  <div style="background: rgba(255,153,0,0.08); border-left: 3px solid #ff9900; padding: 6px 10px; border-radius: 6px; margin: 5px 0; color: #ffb74d; font-size: 12px; line-height: 1.45;">
    1. <b>Tree Clustering:</b> Calcola la distanza di correlazione <b>D<sub>i,j</sub> = &radic;[ (1 &minus; &rho;<sub>i,j</sub>) / 2 ]</b> e costruisce il dendrogramma gerarchico.<br>
    2. <b>Quasi-Diagonalization:</b> Riordina la matrice affinché gli asset simili e correlati siano contigui.<br>
    3. <b>Recursive Bisection:</b> Alloca il capitale bipartendo ricorsivamente i cluster in modo inversamente proporzionale alla loro varianza aggregata.
  </div>
</div>

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px; margin-bottom: 8px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">🎯 A cosa serve</div>
  <div>Garantisce una diversificazione gerarchica genuina ed evita l'iper-concentrazione su singoli asset quando la matrice di covarianza presenta collinearità elevata o campioni ridotti.</div>
</div>

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px; margin-bottom: 8px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">⚙️ Calcolo in ARGUS</div>
  <div>Il modulo <code>core/risk_engine.py</code> calcola la matrice delle distanze informative e genera il dendrogramma dei legami gerarchici con i pesi di allocazione paritaria ottimali.</div>
</div>

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">🔍 Come leggerlo</div>
  <div>Confronta i pesi calcolati da HRP con l'allocazione attuale: gli scostamenti evidenziano cluster di titoli con sovraesposizione di rischio non compensata.</div>
</div>

</div>
""", button_label="💡 Come funziona l'HRP?")

        df_returns_hrp = results.get("returns", pd.DataFrame())
        if df_returns_hrp.empty or df_returns_hrp.shape[1] < 2:
            df_pr = results.get("df_prices", pd.DataFrame())
            if not df_pr.empty and "ticker" in df_pr.columns and "close" in df_pr.columns:
                piv = df_pr.pivot(index="price_date", columns="ticker", values="close").sort_index()
                df_returns_hrp = piv.pct_change().dropna(how="all")

        # Filtro per isolare SOLO i titoli ATTIVAMENTE DETENUTI (qty_net > 0) ed escludere posizioni chiuse e tassi FX (es. DKKEUR=X)
        if not df_returns_hrp.empty and not pos.empty:
            active_mask = (pos["qty_net"] > 1e-6) if "qty_net" in pos.columns else pd.Series(True, index=pos.index)
            port_tickers = [t for t in pos[active_mask]["ticker"].dropna().unique() if not str(t).endswith("=X")]
            valid_cols = [c for c in df_returns_hrp.columns if c in port_tickers]
            if len(valid_cols) >= 2:
                df_returns_hrp = df_returns_hrp[valid_cols]

        # Sanitizzazione outlier estremi nei rendimenti giornalieri (es. split non rettificati o anomalie decimali)
        if not df_returns_hrp.empty:
            df_returns_hrp = df_returns_hrp.replace([np.inf, -np.inf], np.nan).clip(lower=-0.50, upper=1.0)

        if not df_returns_hrp.empty and df_returns_hrp.shape[1] >= 2:
            hrp_res = compute_hrp_portfolio(df_returns_hrp)
            if hrp_res:
                col_hrp1, col_hrp2 = st.columns([1.5, 1])
                with col_hrp1:
                    df_hrp_w = hrp_res.get("df_weights", pd.DataFrame()).sort_values("hrp_weight_pct", ascending=False)
                    fig_hrp = px.bar(
                        df_hrp_w, x="ticker", y="hrp_weight_pct",
                        labels={"ticker": "Asset in Portafoglio", "hrp_weight_pct": "Allocazione Ottima HRP %"},
                        title="Allocazione Ottima Hierarchical Risk Parity (HRP)",
                        color="hrp_weight_pct", color_continuous_scale="Viridis",
                        template="plotly_dark", height=340
                    )
                    fig_hrp.update_layout(
                        paper_bgcolor="rgba(0,0,0,0)",
                        plot_bgcolor="rgba(0,0,0,0)",
                        margin=dict(l=10, r=10, t=40, b=10)
                    )
                    st.plotly_chart(fig_hrp, use_container_width=True)

                with col_hrp2:
                    st.markdown(f"""
                    * **Rendimento Atteso HRP**: <span style='color:#00e676; font-weight:bold;'>{hrp_res['expected_return_pct']:.2f}%</span>
                    * **Volatilità Annua HRP**: <span style='color:#ffab40; font-weight:bold;'>{hrp_res['volatility_annual_pct']:.2f}%</span>
                    * **Sharpe Ratio HRP**: <span style='color:#00f3ff; font-weight:bold;'>{hrp_res['sharpe_ratio']:.2f}</span>
                    """, unsafe_allow_html=True)
                    
                    df_hrp_display = df_hrp_w.rename(columns={
                        "ticker": "Asset / Titolo",
                        "hrp_weight": "Peso Frazionario",
                        "hrp_weight_pct": "Allocazione Ottima HRP %"
                    })
                    hrp_cfg = {
                        "Asset / Titolo": st.column_config.TextColumn("Asset / Titolo", width="medium"),
                        "Allocazione Ottima HRP %": st.column_config.ProgressColumn("Allocazione Ottima HRP %", format="%.2f%%", min_value=0.0, max_value=100.0),
                        "Peso Frazionario": st.column_config.NumberColumn("Peso Frazionario", format="%.4f")
                    }
                    render_table_with_export(
                        df=df_hrp_display,
                        table_title="Pesi Ottimali HRP",
                        file_prefix="pesi_ottimali_hrp",
                        key_suffix="mq_hrp",
                        column_config=hrp_cfg,
                        hide_index=True,
                        height=240
                    )
        # ── SEZIONE ERC (EQUAL RISK CONTRIBUTION) ──
        st.divider()
        col_erc_t1, col_erc_t2 = st.columns([3.2, 1.1])
        with col_erc_t1:
            st.markdown("##### ⚖️ Equal Risk Contribution (ERC / Parità di Rischio Pura)")
            st.caption("Allocazione dove ogni singolo asset contribuisce esattamente per la stessa quota (1/N) alla volatilità totale di portafoglio.")
        with col_erc_t2:
            st.markdown('<div style="margin-top: 6px;"></div>', unsafe_allow_html=True)
            render_info_modal(
                title="Come Funziona Equal Risk Contribution (ERC)",
                content="""
<div style="font-size: 13.5px; line-height: 1.5; color: #c9d1d9;">

<div style="background: rgba(255, 153, 0, 0.08); border-left: 3px solid #ff9900; padding: 10px 14px; border-radius: 4px; margin-bottom: 12px;">
  <b style="color: #ff9900;">🎯 Differenza tra 1/N ed Equal Risk Contribution</b><br>
  Un portafoglio equipesato in capitale (1/N) non è equipesato in rischio: un titolo molto volatile (es. Tech o Crypto) dominerà l'80% delle oscillazioni totali.
</div>

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px; margin-bottom: 8px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">📐 Formulazione Matematica</div>
  <div>ARGUS risolve il problema di ottimizzazione non lineare (SLSQP):</div>
  <div style="background: rgba(0,0,0,0.3); padding: 6px 10px; border-radius: 4px; font-family: monospace; margin: 4px 0; color: #79c0ff;">
    min<sub>w</sub> &sum;<sub>i,j</sub> ( RC<sub>i</sub> &minus; RC<sub>j</sub> )<sup>2</sup> &nbsp;&nbsp;s.t.&nbsp;&nbsp; &sum; w<sub>i</sub> = 1, w<sub>i</sub> &ge; 0
  </div>
  <div>dove il contributo marginale al rischio è <b>RC<sub>i</sub> = w<sub>i</sub> &middot; (&Sigma;w)<sub>i</sub> / &sigma;<sub>p</sub> = &sigma;<sub>p</sub> / N</b>.</div>
</div>

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">🔍 Vantaggi Istituzionali</div>
  <div>Evita la concentrazione nei titoli più volatili e non richiede la stima dei rendimenti attesi futuri &mu; (che è notoriamente rumorosa), massimizzando la stabilità e la diversificazione nei mercati avversi.</div>
</div>

</div>
""",
                button_label="📖 Metodologia Equal Risk (ERC)"
            )

        erc_res = compute_equal_risk_contribution_portfolio(df_returns_hrp)
        if erc_res and erc_res.get("weights"):
            col_erc1, col_erc2 = st.columns([1.5, 1])
            with col_erc1:
                df_erc_w = pd.DataFrame([
                    {"ticker": t, "erc_weight_pct": round(w * 100.0, 2), "risk_contrib_pct": erc_res.get("risk_contributions_pct", {}).get(t, 0.0)}
                    for t, w in erc_res["weights"].items()
                ]).sort_values("erc_weight_pct", ascending=False)

                fig_erc = px.bar(
                    df_erc_w, x="ticker", y="erc_weight_pct",
                    labels={"ticker": "Asset in Portafoglio", "erc_weight_pct": "Peso ERC %"},
                    title="Pesi Ottimali Equal Risk Contribution (ERC)",
                    color="erc_weight_pct", color_continuous_scale="Teal",
                    template="plotly_dark", height=330
                )
                fig_erc.update_layout(paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)", margin=dict(l=10, r=10, t=40, b=10))
                apply_plotly_theme(fig_erc)
                st.plotly_chart(fig_erc, use_container_width=True)

            with col_erc2:
                st.markdown(f"""
                * **Rendimento Atteso ERC**: <span style='color:#00e676; font-weight:bold;'>{erc_res['expected_return']*100:.2f}%</span>
                * **Volatilità Annua ERC**: <span style='color:#ffab40; font-weight:bold;'>{erc_res['volatility']*100:.2f}%</span>
                * **Sharpe Ratio ERC**: <span style='color:#00f3ff; font-weight:bold;'>{erc_res['sharpe_ratio']:.2f}</span>
                """, unsafe_allow_html=True)

                df_erc_disp = df_erc_w.rename(columns={
                    "ticker": "Asset",
                    "erc_weight_pct": "Peso ERC (%)",
                    "risk_contrib_pct": "Contributo al Rischio (%)"
                })
                erc_cfg = {
                    "Asset": st.column_config.TextColumn("Asset", width="medium"),
                    "Peso ERC (%)": st.column_config.ProgressColumn("Peso ERC (%)", format="%.2f%%", min_value=0.0, max_value=100.0),
                    "Contributo al Rischio (%)": st.column_config.ProgressColumn("Contributo al Rischio (%)", format="%.2f%%", min_value=0.0, max_value=100.0)
                }
                render_table_with_export(
                    df=df_erc_disp,
                    table_title="Pesi Ottimali ERC",
                    file_prefix="pesi_ottimali_erc",
                    key_suffix="mq_erc",
                    column_config=erc_cfg,
                    hide_index=True,
                    height=230
                )

        # ── SEZIONE MICHAUD RESAMPLED EFFICIENT FRONTIER ──
        if not df_returns_hrp.empty and df_returns_hrp.shape[1] >= 2:
            st.divider()
            col_mch_t1, col_mch_t2 = st.columns([3.2, 1.1])
            with col_mch_t1:
                st.markdown("##### 🔬 Frontiera Efficiente Ricampionata di Michaud (1998 — Resampling Bootstrap)")
                st.caption("Superamento dell'instabilità e dell'errore di stima di Markowitz tramite simulazione Monte Carlo di N universi alternativi e averaging dei pesi ottimali.")
            with col_mch_t2:
                st.markdown('<div style="margin-top: 6px;"></div>', unsafe_allow_html=True)
                render_info_modal(
                    title="Come Funziona la Frontiera di Michaud (REF)",
                    content="""
<div style="font-size: 13.5px; line-height: 1.5; color: #c9d1d9;">
<div style="background: rgba(56, 189, 248, 0.08); border-left: 3px solid #38bdf8; padding: 10px 14px; border-radius: 4px; margin-bottom: 12px;">
    <b>Il Paradosso dell'Error Maximizer di Markowitz:</b><br>
    L'ottimizzazione classica media-varianza presuppone che i rendimenti medi &mu; e la matrice di covarianza &Sigma; storici siano noti con certezza assoluta. In realtà, sono stime affette da elevato errore campionario. Markowitz sovra-alloca sistematicamente verso i titoli con stime sovrastimate di rendimento o sottostimate di rischio, producendo portafogli a coltello (corner solutions) fragili out-of-sample.
</div>
<b>La Metodologia di Richard Michaud (1998):</b><br>
1. <b>Simulazione Bootstrap:</b> Genera centinaia di serie storiche sintetiche campionando dalla distribuzione empirica.<br>
2. <b>Risoluzione di N Frontiere:</b> Risolve l'ottimizzazione convessa per ciascun universo simulato per K livelli di rischio/rendimento.<br>
3. <b>Rank Averaging:</b> Media i vettori dei pesi &oline;w<sub>k</sub> = (1/B) &sum; w<sub>k</sub><sup>(b)</sup> per ciascun rango di portafoglio.<br>
4. <b>Vantaggi Quantitativi:</b> Elimina i portafogli d'angolo, aumenta la diversificazione effettiva (minore HHI) e genera curve di frontiera stabili e replicabili.
</div>
                    """,
                    button_label="💡 Spiegazione Michaud REF",
                    key_suffix="michaud_ref_modal"
                )

            with st.expander("⚙️ Parametri & Calcolo Frontiera Ricampionata", expanded=False):
                c_m1, c_m2 = st.columns(2)
                with c_m1:
                    mch_sims = st.slider("Numero di Campioni Bootstrap (B)", min_value=20, max_value=200, value=60, step=20, key="mch_sims_slider")
                with c_m2:
                    mch_pts = st.slider("Punti della Frontiera (K)", min_value=10, max_value=30, value=20, step=5, key="mch_pts_slider")

            from core.michaud_resampling import compute_michaud_resampled_frontier
            try:
                mch_res = compute_michaud_resampled_frontier(
                    df_returns_hrp,
                    n_samples=mch_sims if "mch_sims" in locals() else 60,
                    n_frontier_points=mch_pts if "mch_pts" in locals() else 20,
                    seed=42,
                    risk_free_rate=0.03
                )

                col_mc_plot, col_mc_stats = st.columns([1.6, 1])
                with col_mc_plot:
                    fig_mch = go.Figure()
                    # Curva Classica Markowitz
                    fig_mch.add_trace(go.Scatter(
                        x=mch_res["classic_vols_pct"],
                        y=mch_res["classic_returns_pct"],
                        mode="lines",
                        line=dict(color="rgba(148, 163, 184, 0.6)", width=2, dash="dash"),
                        name="Markowitz Classico"
                    ))
                    # Curva Michaud Resampled
                    fig_mch.add_trace(go.Scatter(
                        x=mch_res["resampled_vols_pct"],
                        y=mch_res["resampled_returns_pct"],
                        mode="lines+markers",
                        line=dict(color="#38bdf8", width=3),
                        marker=dict(size=5, color="#0284c7"),
                        name="Michaud Resampled"
                    ))
                    # Punto Max Sharpe Michaud
                    msr = mch_res["resampled_max_sharpe"]
                    fig_mch.add_trace(go.Scatter(
                        x=[msr["volatility_annual_pct"]],
                        y=[msr["expected_return_pct"]],
                        mode="markers",
                        marker=dict(symbol="star", size=14, color="#f59e0b", line=dict(color="#ffffff", width=1.5)),
                        name=f"Max Sharpe ({msr['sharpe_ratio']:.2f})"
                    ))
                    # Punto Min Variance Michaud
                    gmv = mch_res["resampled_min_var"]
                    fig_mch.add_trace(go.Scatter(
                        x=[gmv["volatility_annual_pct"]],
                        y=[gmv["expected_return_pct"]],
                        mode="markers",
                        marker=dict(symbol="diamond", size=11, color="#10b981", line=dict(color="#ffffff", width=1.5)),
                        name=f"Min Varianza ({gmv['volatility_annual_pct']:.1f}%)"
                    ))
                    fig_mch.update_layout(
                        title="Frontiera Efficiente: Michaud Resampled vs Markowitz",
                        xaxis_title="Volatilità Annualizzata (%)",
                        yaxis_title="Rendimento Atteso Annuo (%)",
                        template="plotly_dark",
                        paper_bgcolor="rgba(0,0,0,0)",
                        plot_bgcolor="rgba(0,0,0,0)",
                        height=360,
                        margin=dict(l=10, r=10, t=40, b=10),
                        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
                    )
                    apply_plotly_theme(fig_mch)
                    st.plotly_chart(fig_mch, use_container_width=True)

                with col_mc_stats:
                    st.markdown(f"""
                    * **Sharpe Ratio Max (Michaud)**: <span style='color:#38bdf8; font-weight:bold;'>{msr['sharpe_ratio']:.2f}</span>
                    * **Rendimento Atteso**: <span style='color:#00e676; font-weight:bold;'>{msr['expected_return_pct']:.2f}%</span>
                    * **Volatilità Annua**: <span style='color:#ffab40; font-weight:bold;'>{msr['volatility_annual_pct']:.2f}%</span>
                    * **Costituenti Effettivi (N<sub>eff</sub>)**: <span style='color:#bc8cff; font-weight:bold;'>{msr['effective_constituents']:.1f}</span>
                    * **Guadagno di Diversificazione**: <span style='color:#10b981; font-weight:bold;'>+{mch_res['diversification_gain_pct']:.1f}%</span>
                    """, unsafe_allow_html=True)

                    df_comp = mch_res["df_comparison"].rename(columns={
                        "Asset": "Asset",
                        "Michaud Resampled %": "Michaud %",
                        "Markowitz Classic %": "Markowitz %"
                    })
                    st.dataframe(
                        df_comp,
                        column_config={
                            "Asset": st.column_config.TextColumn("Asset", width="small"),
                            "Michaud %": st.column_config.ProgressColumn("Michaud REF %", format="%.2f%%", min_value=0.0, max_value=100.0),
                            "Markowitz %": st.column_config.ProgressColumn("Markowitz %", format="%.2f%%", min_value=0.0, max_value=100.0),
                        },
                        use_container_width=True,
                        hide_index=True,
                        height=220
                    )
            except Exception as exc:
                st.info(f"Ottimizzazione Michaud in elaborazione o non applicabile: {exc}")

        # ── BACKTESTING ESTRATTO (HRP / MARKOWITZ / EQUI-PESO) ────────
        bt_data = opt.get("backtest", {})
        if bt_data:
            st.divider()
            st.markdown("#### ⏳ Backtesting Storico: Portafoglio vs Markowitz vs HRP vs S&P 500")
            st.caption("Verifica la performance out-of-sample storicizzata dei modelli di allocazione rispetto al mercato.")
            
            glossary_modal("ℹ️ Cos'è l'Hierarchical Risk Parity (HRP)?", """
<div style="font-size: 13.5px; line-height: 1.45;">
L'<b>Hierarchical Risk Parity (HRP)</b> è un algoritmo quantitativo sviluppato da Marcos López de Prado che supera i limiti dell'ottimizzazione classica di Markowitz sfruttando il <b>clustering gerarchico e la bisezione ricorsiva</b>. Produce pesi out-of-sample solidi senza invertire matrici di covarianza.
</div>
            """, button_label="💡 Cos'è l'Hierarchical Risk Parity?")
            
            df_bt = pd.DataFrame(bt_data.get("equity_curves", {}))
            if not df_bt.empty and "date" in df_bt.columns:
                df_bt["date"] = pd.to_datetime(df_bt["date"])
                
                fig_bt = px.line(
                    df_bt, x="date", y=[c for c in df_bt.columns if c != "date"],
                    labels={"value": "Valore Indiciato (Base 100)", "date": "Data", "variable": "Strategia"},
                    title="Confronto Curve di Equity Storiche (Base 100)",
                    color_discrete_sequence=["#58a6ff", "#00e676", "#ff9900", "#bc8cff"],
                    template="plotly_dark", height=420
                )
                fig_bt.update_traces(
                    line=dict(width=2.2),
                    hovertemplate="<b>Data: %{x|%d %b %Y}</b><br>%{fullData.name}: %{y:.2f}<extra></extra>"
                )
                fig_bt.update_layout(
                    paper_bgcolor="rgba(0,0,0,0)",
                    plot_bgcolor="rgba(0,0,0,0)",
                    legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1, title=None),
                    yaxis=dict(gridcolor="rgba(255,255,255,0.06)"),
                    xaxis=dict(gridcolor="rgba(255,255,255,0.06)")
                )
                apply_plotly_theme(fig_bt)
                st.plotly_chart(fig_bt, use_container_width=True)

    else:
        st.info("Dati di ottimizzazione di Markowitz non disponibili.")

# ── TAB 2: AI REINFORCEMENT LEARNING ASSET ALLOCATION ───────────
elif active_quant_tab == "🤖 AI Reinforcement Learning":
    if not has_portfolio:
        st.warning("⚠️ Carica prima un portafoglio per addestrare l'Agente AI di Reinforcement Learning.")
    else:
        st.markdown("### 🤖 Asset Allocation con Reinforcement Learning (RL Policy Sandbox)")
        render_institutional_info_box(
            title="AI Deep Reinforcement Learning & Permutation-Equivariant Policy Gradient",
            badge="ARTIFICIAL INTELLIGENCE • DEEP RL • POLICY GRADIENT",
            summary_html="Addestramento di agenti neurali continui (Permutation-Equivariant Policy Gradient) formulati come Processo Decisionale di Markov (MDP) per l'adattamento dinamico dei pesi sui regimi macro e la massimizzazione del reward risk-adjusted.",
            math_html="Ottimizzazione policy: <code>∇_θ J(θ) = E_{τ ~ π_θ} [ Σ_t ∇_θ log π_θ(a_t | s_t) · R_t ] + λ_H ∇_θ H(π_θ)</code><br>Stato $s_t \\in \\mathbb{R}^{3N}$ (Sharpe rolling, momentum e downside volatility), Azione $a_t \\in \\Delta^{N-1}$ via Softmax equivariante e ottimizzatore <b>Adam</b> con gradient clipping.",
            chart_guide_html="• <b>Reward Curve:</b> traccia la convergenza della funzione obiettivo (Sharpe, Sortino o Min-Vol) attraverso gli episodi di addestramento.<br>• <b>Allocazione Dinamica:</b> visualizza le transizioni temporali dei pesi in risposta alle variazioni di volatilità e trend.",
            regulatory_html="• <b>AI Act (Regolamento UE 2024/1689):</b> tracciabilità e spiegabilità degli algoritmi decisionali autonomi per investimenti ad alto impatto.<br>• <b>Model Risk Governance (SR 11-7):</b> validazione empirica out-of-sample per prevenire l'overfitting su serie storiche rumorose.",
            accent_color="#a855f7",
        )

        df_returns_rl = results.get("returns", pd.DataFrame())
        if active_tickers_set:
            valid_cols = [c for c in df_returns_rl.columns if c in active_tickers_set]
            if len(valid_cols) >= 2:
                df_returns_rl = df_returns_rl[valid_cols]

        if df_returns_rl.empty or len(df_returns_rl.columns) < 2:
            st.info("Dati di serie storiche insufficienti per l'addestramento del modello di Reinforcement Learning.")
        else:
            # Control Bar di Configurazione dell'Agente
            col_cfg1, col_cfg2, col_cfg3, col_cfg4, col_cfg5 = st.columns([1.1, 1.4, 1.1, 1.1, 1.1])
            with col_cfg1:
                episodes_in = st.slider("Episodi Addestramento", min_value=10, max_value=60, value=30, step=5, key="rl_episodes_slider")
            with col_cfg2:
                reward_choice = st.selectbox(
                    "Obiettivo Reward",
                    options=[
                        "Massimizzazione Sortino (Penalità Downside)",
                        "Massimizzazione Sharpe Ratio",
                        "Minima Volatilità & Low Turnover"
                    ],
                    key="rl_reward_select"
                )
                reward_key = "sortino" if "Sortino" in reward_choice else ("sharpe" if "Sharpe" in reward_choice else "min_vol")
            with col_cfg3:
                rebal_choice = st.selectbox(
                    "Ribilanciamento",
                    options=[
                        "Mensile (~21 gg)",
                        "Bi-settimanale (~10 gg)",
                        "Settimanale (~5 gg)",
                        "Trimestrale (~63 gg)",
                        "Giornaliero (Alta Freq.)",
                    ],
                    index=0,
                    key="rl_rebal_select"
                )
                rebal_map = {
                    "Mensile (~21 gg)": 21,
                    "Bi-settimanale (~10 gg)": 10,
                    "Settimanale (~5 gg)": 5,
                    "Trimestrale (~63 gg)": 63,
                    "Giornaliero (Alta Freq.)": 1,
                }
                rebal_days = rebal_map[rebal_choice]
            with col_cfg4:
                lookback_w = st.slider("Lookback (gg)", min_value=15, max_value=50, value=25, step=5, key="rl_window_slider")
            with col_cfg5:
                turnover_pen = st.slider("Costo Turnover (%)", min_value=0.0, max_value=0.5, value=0.10, step=0.05, format="%.2f%%", key="rl_turnover_slider") / 100.0

            col_btn1, col_btn2 = st.columns([1.5, 3.5])
            with col_btn1:
                run_rl_btn = st.button("⚡ Avvia Addestramento Agente RL", type="primary", use_container_width=True, key="btn_train_rl")

            # Training Execution / Session State Cache (Attivazione su richiesta tramite pulsante)
            if run_rl_btn:
                with st.spinner("🤖 Addestramento della Policy Neurale in corso con simulazione ad episodi..."):
                    rl_res = train_and_evaluate_rl_portfolio(
                        df_returns=df_returns_rl,
                        episodes=episodes_in,
                        window_size=lookback_w,
                        reward_type=reward_key,
                        turnover_penalty=turnover_pen,
                        rebalance_days=rebal_days,
                    )
                    st.session_state["rl_portfolio_results"] = rl_res
                    if rl_res and rl_res.get("has_data"):
                        st.toast("✅ Addestramento agente RL completato!", icon="🤖")

            rl_res = st.session_state.get("rl_portfolio_results")

            if rl_res is None:
                st.markdown("<div style='height: 8px;'></div>", unsafe_allow_html=True)
                st.info("💡 Configura i parametri sopra e clicca su **⚡ Avvia Addestramento Agente RL** per avviare la simulazione e confrontare l'agente con la strategia equiponderata (1/N).")
            elif rl_res and not rl_res.get("has_data"):
                st.warning("⚠️ Dati storici insufficienti o non validi per addestrare l'agente neurale.")
            elif rl_res and rl_res.get("has_data"):
                rl_stats = rl_res["rl_stats"]
                ew_stats = rl_res["ew_stats"]

                st.markdown("<div style='height: 10px;'></div>", unsafe_allow_html=True)

                # ── KPI SCORECARD ROW ──
                col_k1, col_k2, col_k3, col_k4, col_k5, col_k6 = st.columns(6)
                with col_k1:
                    diff_ret = rl_stats['total_return_pct'] - ew_stats['total_return_pct']
                    metric_card(
                        "Rendimento Totale RL",
                        f"{rl_stats['total_return_pct']:.2f}%",
                        f"{diff_ret:+.2f}% vs 1/N ({ew_stats['total_return_pct']:.1f}%)",
                        is_positive=(diff_ret >= 0),
                    )
                with col_k2:
                    diff_cagr = rl_stats['cagr_pct'] - ew_stats['cagr_pct']
                    metric_card(
                        "CAGR Annualizzato",
                        f"{rl_stats['cagr_pct']:.2f}%",
                        f"{diff_cagr:+.2f}% vs 1/N ({ew_stats['cagr_pct']:.2f}%)",
                        is_positive=(diff_cagr >= 0),
                    )
                with col_k3:
                    diff_vol = rl_stats['volatility_pct'] - ew_stats['volatility_pct']
                    # Volatilità più bassa è preferibile (differenziale negativo è positivo)
                    metric_card(
                        "Volatilità Ann.",
                        f"{rl_stats['volatility_pct']:.2f}%",
                        f"{diff_vol:+.2f}% vs 1/N ({ew_stats['volatility_pct']:.2f}%)",
                        is_positive=(diff_vol <= 0),
                    )
                with col_k4:
                    diff_sh = rl_stats['sharpe_ratio'] - ew_stats['sharpe_ratio']
                    metric_card(
                        "Sharpe Ratio",
                        f"{rl_stats['sharpe_ratio']:.2f}",
                        f"{diff_sh:+.2f} vs 1/N ({ew_stats['sharpe_ratio']:.2f})",
                        is_positive=(diff_sh >= 0),
                    )
                with col_k5:
                    diff_so = rl_stats['sortino_ratio'] - ew_stats['sortino_ratio']
                    metric_card(
                        "Sortino Ratio",
                        f"{rl_stats['sortino_ratio']:.2f}",
                        f"{diff_so:+.2f} vs 1/N ({ew_stats['sortino_ratio']:.2f})",
                        is_positive=(diff_so >= 0),
                    )
                with col_k6:
                    diff_dd = rl_stats['max_drawdown_pct'] - ew_stats['max_drawdown_pct']
                    # Max DD meno profondo (es. -40% > -50% => diff > 0) è preferibile
                    metric_card(
                        "Max Drawdown",
                        f"{rl_stats['max_drawdown_pct']:.2f}%",
                        f"{diff_dd:+.2f}% vs 1/N ({ew_stats['max_drawdown_pct']:.2f}%)",
                        is_positive=(diff_dd >= 0),
                    )

                st.markdown("<div style='height: 14px;'></div>", unsafe_allow_html=True)

                # ── CHARTS ROW: Learning Curve & Backtest Equity Curve ──
                col_ch1, col_ch2 = st.columns([1.1, 1.6])
                with col_ch1:
                    st.markdown("##### 📈 Curva di Apprendimento dell'Agente (Reward Convergence)")
                    df_lc = rl_res["learning_curve"]
                    fig_lc = go.Figure()
                    fig_lc.add_trace(go.Scatter(
                        x=df_lc["episode"],
                        y=df_lc["cumulative_reward"],
                        mode="lines+markers",
                        name="Reward Totale Episodio",
                        line=dict(color="#58a6ff", width=2.5),
                        marker=dict(size=5, color="#58a6ff"),
                        hovertemplate="<b>Episodio %{x}</b><br>Reward Cumulato: %{y:.1f}<extra></extra>"
                    ))
                    fig_lc.update_layout(
                        template="plotly_dark",
                        paper_bgcolor="rgba(0,0,0,0)",
                        plot_bgcolor="rgba(13,17,23,0.7)",
                        height=320,
                        margin=dict(l=20, r=20, t=30, b=20),
                        xaxis=dict(title="Episodio di Training", gridcolor="rgba(255,255,255,0.06)"),
                        yaxis=dict(title="Reward Cumulato", gridcolor="rgba(255,255,255,0.06)"),
                        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
                    )
                    apply_plotly_theme(fig_lc)
                    st.plotly_chart(fig_lc, use_container_width=True)

                with col_ch2:
                    st.markdown("##### 🚀 Equity Curve: Agente AI RL vs Equipesato (Base 100)")
                    df_bt = rl_res["backtest_df"]
                    fig_bt = go.Figure()
                    fig_bt.add_trace(go.Scatter(
                        x=df_bt["date"],
                        y=df_bt["rl_equity_curve"],
                        mode="lines",
                        name="RL Policy Agent (Adattivo)",
                        line=dict(color="#3fb950", width=3.0),
                        hovertemplate="<b>RL Agent</b>: %{y:.2f}<extra></extra>"
                    ))
                    fig_bt.add_trace(go.Scatter(
                        x=df_bt["date"],
                        y=df_bt["ew_equity_curve"],
                        mode="lines",
                        name="Benchmark Equipesato (1/N)",
                        line=dict(color="#8b949e", width=2.0, dash="dash"),
                        hovertemplate="<b>1/N Benchmark</b>: %{y:.2f}<extra></extra>"
                    ))
                    fig_bt.update_layout(
                        template="plotly_dark",
                        paper_bgcolor="rgba(0,0,0,0)",
                        plot_bgcolor="rgba(13,17,23,0.7)",
                        height=320,
                        margin=dict(l=20, r=20, t=30, b=20),
                        xaxis=dict(title="Data", gridcolor="rgba(255,255,255,0.06)"),
                        yaxis=dict(title="Valore Portafoglio (Base 100)", gridcolor="rgba(255,255,255,0.06)"),
                        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
                    )
                    apply_plotly_theme(fig_bt)
                    st.plotly_chart(fig_bt, use_container_width=True)

                # ── CHART 3: DYNAMIC ASSET ALLOCATION OVER TIME (STACKED AREA) ──
                st.markdown("##### 🧬 Evoluzione dell'Allocazione Dinamica nel Tempo (AI Policy Weights)")
                df_w = rl_res["weights_history"]
                if not df_w.empty:
                    tickers_list = rl_res["tickers"]
                    fig_area = go.Figure()
                    for tk in tickers_list:
                        if tk in df_w.columns:
                            fig_area.add_trace(go.Scatter(
                                x=df_w["date"],
                                y=df_w[tk] * 100.0,
                                mode="lines",
                                stackgroup="one",
                                name=tk,
                                hovertemplate=f"<b>{tk}</b>: %{{y:.1f}}%<extra></extra>"
                            ))
                    fig_area.update_layout(
                        template="plotly_dark",
                        paper_bgcolor="rgba(0,0,0,0)",
                        plot_bgcolor="rgba(13,17,23,0.7)",
                        height=300,
                        margin=dict(l=20, r=20, t=25, b=20),
                        xaxis=dict(title="Data di Valutazione", gridcolor="rgba(255,255,255,0.06)"),
                        yaxis=dict(title="Allocazione (%)", range=[0, 100], gridcolor="rgba(255,255,255,0.06)"),
                        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
                    )
                    apply_plotly_theme(fig_area)
                    st.plotly_chart(fig_area, use_container_width=True)

                # Costruisci confronto con pesi attuali con rilevamento ticker robusto
                target_rows = []
                tot_val = float(pos["current_value"].sum()) if ("current_value" in pos.columns and pos["current_value"].sum() > 0) else 100_000.0
                tk_col = next((c for c in ["ticker", "Ticker", "symbol", "Symbol", "Asset"] if c in pos.columns), None)

                for tk in rl_res["tickers"]:
                    w_rl = rl_res["final_weights"].get(tk, 0.0) * 100.0
                    cur_row = pos[pos[tk_col] == tk] if (tk_col and not pos.empty) else pd.DataFrame()
                    cur_w = (float(cur_row["current_value"].iloc[0]) / tot_val * 100.0) if (not cur_row.empty and "current_value" in cur_row.columns) else (100.0 / len(rl_res["tickers"]))
                    delta_w = w_rl - cur_w
                    
                    target_rows.append({
                        "Ticker": tk,
                        "Peso Attuale (%)": round(cur_w, 2),
                        "Peso RL Target (%)": round(w_rl, 2),
                        "Variazione Tattica (Δ)": round(delta_w, 2),
                        "Azione Suggerita": "🟢 Incrementa" if delta_w > 1.0 else ("🔴 Riduci" if delta_w < -1.0 else "⚪ Mantieni")
                    })

                df_target_comp = pd.DataFrame(target_rows)
                rl_cfg = {
                    "Ticker": st.column_config.TextColumn("Ticker"),
                    "Peso Attuale (%)": st.column_config.NumberColumn("Peso Attuale", format="%.2f%%"),
                    "Peso RL Target (%)": st.column_config.NumberColumn("Peso Target RL", format="%.2f%%"),
                    "Variazione Tattica (Δ)": st.column_config.NumberColumn("Variazione (Δ)", format="%+.2f%%"),
                    "Azione Suggerita": st.column_config.TextColumn("Raccomandazione AI")
                }
                render_table_with_export(
                    df=df_target_comp,
                    table_title="Pesi Target Raccomandati dall'Agente RL",
                    file_prefix="pesi_target_rl_agent",
                    key_suffix="mq_rl_weights",
                    column_config=rl_cfg,
                    hide_index=True
                )

# ── TAB 3: TAIL COPULA & KELLY SIZING ────────────────────────────
elif active_quant_tab == "🧬 Tail Copula & Kelly":
    if not has_portfolio:
        st.warning("⚠️ Carica prima un portafoglio per calcolare le Copule di Coda e il dimensionamento di Kelly.")
    else:
        st.markdown("### 🧬 Modelli di Dipendenza di Coda (Tail Copula) & Kelly Criterion")
        render_institutional_info_box(
            title="Dipendenza di Coda Asimmetrica (Tail Copulas) & Optimal Kelly Sizing",
            badge="EXTREME RISK • CLAYTON/GUMBEL • HALF-KELLY",
            summary_html="Quantificazione non lineare del rischio di crash congiunto asimmetrico tramite copule archimedee (Clayton e Gumbel) per rilevare il contagio sistemico, combinata con il dimensionamento matematico di capitale frazionario (Half-Kelly).",
            math_html="Lower Tail Dependence (Clayton): <code>λ_L = lim_{q→0^+} P(U_j ≤ q | U_i ≤ q) = 2^{-1/θ}</code><br>Kelly Criterion continuo: <code>f^* = (μ - r_f) / σ²</code> | Half-Kelly discreto: <code>f^*_{half} = 0.5 · [p(b + 1) - 1] / b</code> con win-rate $p$ e payoff ratio $b$.",
            chart_guide_html="• <b>Heatmap Dipendenza di Coda:</b> celle con $\\lambda_L \\ge 0.30$ segnalano breakdown della diversificazione in caso di crolli.<br>• <b>Half-Kelly Sizing:</b> garantisce il 75% del tasso di crescita geometrico asintotico riducendo la volatilità e il rischio di rovina del 50%.",
            regulatory_html="• <b>Basilea III / FRTB Expected Shortfall:</b> cattura il rischio di code pesanti non gaussiane e crolli simultanei non riflessi dalla covarianza lineare.<br>• <b>Money Management Istituzionale:</b> imposizione di capping stringenti per evitare sovradimensionamento e drawdown irreversibili.",
            accent_color="#ec4899",
        )

        df_returns_all = results.get("returns", pd.DataFrame())
        if df_returns_all.empty or not isinstance(df_returns_all, pd.DataFrame) or df_returns_all.shape[1] < 2:
            df_pr_t = results.get("df_prices", pd.DataFrame())
            if not df_pr_t.empty and "ticker" in df_pr_t.columns:
                piv_t = df_pr_t.pivot(index="price_date", columns="ticker", values="close")
                df_returns_all = piv_t.pct_change().dropna()

        pos = results.get("positions", pd.DataFrame())
        # Filtro per isolare SOLO le posizioni attive attualmente in portafoglio
        if not df_returns_all.empty and not pos.empty:
            active_mask = (pos["qty_net"] > 1e-6) if "qty_net" in pos.columns else pd.Series(True, index=pos.index)
            active_tickers_list = [t for t in pos[active_mask]["ticker"].dropna().unique() if not str(t).endswith("=X")]
            common_active = [c for c in df_returns_all.columns if c in active_tickers_list]
            if len(common_active) >= 2:
                df_returns_all = df_returns_all[common_active]

        # ── SEZIONE 1: TAIL COPULA MATRIX ──
        section("1. 🧬 Matrice di Dipendenza di Coda Asimmetrica (Tail Copulas)")
        st.caption("Quantifica la dipendenza non lineare e la probabilità di shock simultaneo sulle code di distribuzione.")

        col_cop_q, col_cop_k1, col_cop_k2, col_cop_k3 = st.columns([1.4, 1, 1, 1])
        with col_cop_q:
            q_thresh = st.slider(
                "Soglia Percentile di Coda (q):",
                min_value=0.01,
                max_value=0.15,
                value=0.05,
                step=0.01,
                help="q=0.05 analizza il 5% delle giornate di mercato peggiori (Tail Risk al 95%)."
            )
        
        copula_res = compute_tail_copula_matrix(df_returns_all, quantile_threshold=q_thresh)
        mean_tl = copula_res.get('mean_tail_dependence', 0.0)
        df_l = copula_res.get("lambda_lower_df", pd.DataFrame())
        df_u = copula_res.get("lambda_upper_df", pd.DataFrame())
        df_asym = copula_res.get("asymmetry_df", pd.DataFrame())
        contagion = copula_res.get("contagion_pairs", [])
        
        if not df_u.empty:
            upper_vals = df_u.values[np.triu_indices_from(df_u.values, k=1)]
            mean_tu = float(np.mean(upper_vals)) if len(upper_vals) > 0 else 0.0
        else:
            mean_tu = 0.0

        with col_cop_k1:
            metric_card(
                "Dipendenza Coda Inferiore (λ_L)",
                f"{mean_tl:.3f}",
                delta="Rischio Crash Congiunto",
                positive=(mean_tl < 0.20),
                help_text="Media della probabilità di crash congiunto tra tutte le coppie di asset durante shock ribassisti."
            )
        with col_cop_k2:
            metric_card(
                "Dipendenza Coda Superiore (λ_U)",
                f"{mean_tu:.3f}",
                delta="Co-Boom Rialzista",
                positive=True,
                help_text="Media della probabilità di rally congiunto tra tutte le coppie di asset durante fasi di espansione."
            )
        with col_cop_k3:
            metric_card(
                "Coppie ad Alto Contagio (λ_L ≥ 0.30)",
                f"{len(contagion)}",
                delta="Breakdown Diversificazione" if len(contagion) > 0 else "Nessun Alert Critico",
                positive=(len(contagion) == 0),
                help_text="Numero di coppie di asset che perdono la diversificazione durante i crolli di mercato."
            )

        st.markdown('<div style="margin-top: 12px;"></div>', unsafe_allow_html=True)
        tab_cl, tab_cu, tab_asym = st.tabs([
            "🔻 Lower Tail Dependence (λ_L - Rischio Crash)",
            "🔺 Upper Tail Dependence (λ_U - Co-Boom)",
            "⚖️ Matrice Asimmetria di Coda (λ_L - λ_U)"
        ])
        
        n_assets = len(df_l) if not df_l.empty else 0
        show_matrix_text = (n_assets <= 12)
        
        with tab_cl:
            if not df_l.empty:
                fig_cl = px.imshow(
                    df_l,
                    color_continuous_scale=[[0.0, "#0f172a"], [0.4, "#d97706"], [1.0, "#ef4444"]],
                    zmin=0.0, zmax=1.0,
                    text_auto=".2f" if show_matrix_text else False,
                    labels={"x": "Asset", "y": "Asset", "color": "λ_L"}
                )
                fig_cl.update_traces(
                    hovertemplate="<b>Coppia: %{x} ↔ %{y}</b><br>🔻 Lower Tail Copula (λ_L): <b>%{z:.3f}</b><br><i>Probabilità di crash simultaneo nei sell-off</i><extra></extra>"
                )
                fig_cl.update_layout(
                    height=480, paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                    margin=dict(l=10, r=10, t=20, b=10),
                    xaxis=dict(tickangle=-45, tickfont=dict(size=11, family="monospace")),
                    yaxis=dict(tickfont=dict(size=11, family="monospace"))
                )
                apply_plotly_theme(fig_cl)
                st.plotly_chart(fig_cl, use_container_width=True)

        with tab_cu:
            if not df_u.empty:
                fig_cu = px.imshow(
                    df_u,
                    color_continuous_scale=[[0.0, "#0f172a"], [0.4, "#0284c7"], [1.0, "#22c55e"]],
                    zmin=0.0, zmax=1.0,
                    text_auto=".2f" if show_matrix_text else False,
                    labels={"x": "Asset", "y": "Asset", "color": "λ_U"}
                )
                fig_cu.update_traces(
                    hovertemplate="<b>Coppia: %{x} ↔ %{y}</b><br>🔺 Upper Tail Copula (λ_U): <b>%{z:.3f}</b><br><i>Probabilità di co-boom rialzista simultaneo</i><extra></extra>"
                )
                fig_cu.update_layout(
                    height=480, paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                    margin=dict(l=10, r=10, t=20, b=10),
                    xaxis=dict(tickangle=-45, tickfont=dict(size=11, family="monospace")),
                    yaxis=dict(tickfont=dict(size=11, family="monospace"))
                )
                apply_plotly_theme(fig_cu)
                st.plotly_chart(fig_cu, use_container_width=True)

        with tab_asym:
            if not df_asym.empty:
                fig_asym = px.imshow(
                    df_asym,
                    color_continuous_scale=[[0.0, "#22c55e"], [0.5, "#0f172a"], [1.0, "#ef4444"]],
                    zmin=-0.5, zmax=0.5,
                    text_auto=".2f" if show_matrix_text else False,
                    labels={"x": "Asset", "y": "Asset", "color": "Δ (λ_L - λ_U)"}
                )
                fig_asym.update_traces(
                    hovertemplate="<b>Coppia: %{x} ↔ %{y}</b><br>⚖️ Asimmetria Coda: <b>%{z:+.3f}</b><br><i>Valori positivi indicano maggiore rischio di crash congiunto rispetto ai rally</i><extra></extra>"
                )
                fig_asym.update_layout(
                    height=480, paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                    margin=dict(l=10, r=10, t=20, b=10),
                    xaxis=dict(tickangle=-45, tickfont=dict(size=11, family="monospace")),
                    yaxis=dict(tickfont=dict(size=11, family="monospace"))
                )
                apply_plotly_theme(fig_asym)
                st.plotly_chart(fig_asym, use_container_width=True)

        # Tabella Coppie a Rischio Contagio & Indice di Rottura della Diversificazione
        contagion = copula_res.get("contagion_pairs", [])
        if contagion:
            st.caption("Queste coppie mostrano un picco di correlazione durante i crolli di mercato (*'In a crisis, all correlations go to 1'*), azzerando l'effetto protettivo della diversificazione.")
            
            df_cont = pd.DataFrame(contagion).rename(columns={
                "pair": "Coppia Asset", "lambda_lower": "Lower Tail (λ_L)",
                "lambda_upper": "Upper Tail (λ_U)", "asymmetry": "Asimmetria di Coda", "risk_level": "Livello Rischio"
            })

            cont_cfg = {
                "Coppia Asset": st.column_config.TextColumn("Coppia Asset", width="medium"),
                "Lower Tail (λ_L)": st.column_config.ProgressColumn("Lower Tail (λ_L)", format="%.3f", min_value=0.0, max_value=1.0),
                "Upper Tail (λ_U)": st.column_config.ProgressColumn("Upper Tail (λ_U)", format="%.3f", min_value=0.0, max_value=1.0),
                "Asimmetria di Coda": st.column_config.NumberColumn("Asimmetria (λ_L - λ_U)", format="%+.3f"),
                "Livello Rischio": st.column_config.TextColumn("Livello Rischio", width="small")
            }
            render_table_with_export(
                df=df_cont,
                table_title="Alert Coppie ad Alto Contagio di Coda (λ_L ≥ 0.30)",
                file_prefix="coppie_contagio_tail_risk",
                key_suffix="mq_contagion",
                column_config=cont_cfg,
                hide_index=True
            )

        st.divider()

        # ── SEZIONE 2: KELLY CRITERION SIZING ──
        st.markdown('<div style="margin-top: 25px;"></div>', unsafe_allow_html=True)
        section("2. 🎯 Ottimizzazione dei Pesi con Criterio di Kelly (Half-Kelly)")
        st.caption("Confronto tra pesi effettivi di portafoglio e allocazione ottimale Half-Kelly per la massimizzazione del tasso di crescita del capitale.")

        col_k_rf, col_k_info = st.columns([2, 4])
        with col_k_rf:
            rf_rate = st.slider("Tasso Risk-Free Annuo (Rf %):", 0.0, 6.0, 2.0, 0.5) / 100.0
        
        # Mappa pesi attuali solo posizioni attive
        pos_df = results.get("positions", pd.DataFrame())
        cur_w_k = {}
        if not pos_df.empty and "ticker" in pos_df.columns:
            active_pos = pos_df[pos_df["qty_net"] > 1e-6] if "qty_net" in pos_df.columns else pos_df
            w_col = "weight_pct" if "weight_pct" in active_pos.columns else ("weight" if "weight" in active_pos.columns else None)
            if w_col:
                cur_w_k = dict(zip(active_pos["ticker"], active_pos[w_col] / (100.0 if w_col == "weight_pct" else 1.0)))

        df_kelly = compute_kelly_criterion_sizing(df_returns_all, current_weights=cur_w_k, risk_free_rate=rf_rate)
        
        if not df_kelly.empty:
            col_k_f1, col_k_f2, col_k_f3 = st.columns([2.0, 1.3, 0.9], vertical_alignment="bottom")
            with col_k_f1:
                search_k = st.text_input("🔍 Cerca Ticker:", placeholder="Filtra per Ticker (es. AAPL, BTC, ETH, GOOGL)...", key="search_kelly_ticker")
            with col_k_f2:
                filter_k_diag = st.selectbox("🏷️ Diagnostica Allocazione:", ["Tutti gli Stati", "🔴 Sovra-Allocati", "🟢 Sotto-Allocati", "⚪ Equilibrati", "⛔ Zero Edge"], key="filter_kelly_diag")

            df_k_filt = df_kelly.copy()
            if search_k:
                df_k_filt = df_k_filt[df_k_filt["Ticker"].astype(str).str.contains(search_k.strip(), case=False, na=False)]
            if filter_k_diag == "🔴 Sovra-Allocati":
                df_k_filt = df_k_filt[df_k_filt["Stato Allocazione"].astype(str).str.contains("Sovra", case=False, na=False)]
            elif filter_k_diag == "🟢 Sotto-Allocati":
                df_k_filt = df_k_filt[df_k_filt["Stato Allocazione"].astype(str).str.contains("Sotto", case=False, na=False)]
            elif filter_k_diag == "⚪ Equilibrati":
                df_k_filt = df_k_filt[df_k_filt["Stato Allocazione"].astype(str).str.contains("Equilibrat", case=False, na=False)]
            elif filter_k_diag == "⛔ Zero Edge":
                df_k_filt = df_k_filt[df_k_filt["Stato Allocazione"].astype(str).str.contains("Nessun|Zero", case=False, na=False)]

            with col_k_f3:
                render_export_toolbar(
                    df_k_filt,
                    file_prefix="kelly_criterion_sizing",
                    key_suffix="mq_kelly",
                    table_title="Kelly Criterion Sizing"
                )

            if df_k_filt.empty:
                st.info("ℹ️ Nessun asset corrisponde ai criteri di filtro selezionati.")
            else:
                # Tabella Interattiva con Sorting su ogni colonna e Column Config
                df_k_interactive = pd.DataFrame({
                    "Ticker": df_k_filt["Ticker"],
                    "Rendimento Annuo (%)": [float(str(w).replace("%", "").replace("+", "")) for w in df_k_filt["Rendimento Annuo"]],
                    "Volatilità Annua (%)": [float(str(w).replace("%", "").replace("+", "")) for w in df_k_filt["Volatilità Annua"]],
                    "Win Rate (%)": [float(str(w).replace("%", "").replace("+", "")) for w in df_k_filt["Win Rate"]],
                    "Win/Loss (B)": df_k_filt["Win/Loss Ratio"],
                    "Peso Attuale (%)": [float(str(w).replace("%", "").replace("+", "")) for w in df_k_filt["Peso Attuale"]],
                    "Target Kelly (%)": [float(str(w).replace("%", "").replace("+", "")) for w in df_k_filt["Half-Kelly (Target)"]],
                    "Leva Full Kelly (%)": [float(str(w).replace("%", "").replace("+", "")) for w in df_k_filt["Full Kelly"]],
                    "Diagnostica": df_k_filt["Stato Allocazione"]
                })

                kelly_cfg = {
                    "Ticker": st.column_config.TextColumn("Ticker", width="small"),
                    "Rendimento Annuo (%)": st.column_config.NumberColumn("Rendimento Annuo", format="%+.2f%%"),
                    "Volatilità Annua (%)": st.column_config.NumberColumn("Volatilità Annua", format="%.2f%%"),
                    "Win Rate (%)": st.column_config.ProgressColumn("Win Rate", format="%.1f%%", min_value=0.0, max_value=100.0),
                    "Win/Loss (B)": st.column_config.TextColumn("Payoff (B)", width="small"),
                    "Peso Attuale (%)": st.column_config.NumberColumn("Peso Attuale", format="%.2f%%"),
                    "Target Kelly (%)": st.column_config.ProgressColumn("Target Kelly", format="%.2f%%", min_value=0.0, max_value=100.0),
                    "Leva Full Kelly (%)": st.column_config.NumberColumn("Leva Full Kelly", format="%.2f%%"),
                    "Diagnostica": st.column_config.TextColumn("Diagnostica Allocazione", width="medium")
                }

                st.dataframe(
                    df_k_interactive,
                    column_config=kelly_cfg,
                    use_container_width=True,
                    hide_index=True
                )

                # Grafico a barre comparative: Peso Attuale vs Half-Kelly Target
                df_k_plot = pd.DataFrame({
                    "Ticker": df_k_filt["Ticker"],
                    "Peso Attuale (%)": [float(str(w).replace("%", "").replace("+", "")) for w in df_k_filt["Peso Attuale"]],
                    "Half-Kelly Target (%)": [float(str(w).replace("%", "").replace("+", "")) for w in df_k_filt["Half-Kelly (Target)"]]
                })

                fig_k_bar = go.Figure()
                fig_k_bar.add_trace(go.Bar(
                    x=df_k_plot["Ticker"],
                    y=df_k_plot["Peso Attuale (%)"],
                    name="⭐ Peso Attuale",
                    marker=dict(color="#58a6ff", line=dict(color="rgba(255,255,255,0.1)", width=1)),
                    hovertemplate="<b>%{x}</b><br>Peso Attuale: <b>%{y:.2f}%</b><extra></extra>"
                ))
                fig_k_bar.add_trace(go.Bar(
                    x=df_k_plot["Ticker"],
                    y=df_k_plot["Half-Kelly Target (%)"],
                    name="🎯 Target Kelly Normalizzato",
                    marker=dict(color="#ff9900", line=dict(color="rgba(255,153,0,0.4)", width=1)),
                    hovertemplate="<b>%{x}</b><br>Target Kelly: <b>%{y:.2f}%</b><extra></extra>"
                ))
                fig_k_bar.update_layout(
                    template="plotly_dark",
                    paper_bgcolor="rgba(0,0,0,0)",
                    plot_bgcolor="rgba(0,0,0,0)",
                    barmode="group",
                    height=340,
                    margin=dict(l=10, r=10, t=30, b=30),
                    yaxis=dict(title="Allocazione (%)", showgrid=True, gridcolor="rgba(255,255,255,0.06)"),
                    xaxis=dict(title=None, tickangle=-45, tickfont=dict(size=11, family="monospace")),
                    legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="center", x=0.5, font=dict(size=11.5))
                )
                apply_plotly_theme(fig_k_bar)
                st.plotly_chart(fig_k_bar, use_container_width=True)

        # ── SEZIONE 3: SIMULATORE INTERATTIVO DI TRADE SIZING (KELLY) ─
        st.markdown("<div style='margin-top: 20px;'></div>", unsafe_allow_html=True)
        st.markdown("#### ⚖️ Simulatore Interattivo Trade Sizing (Kelly Criterion)")
        st.caption("Calcola il dimensionamento matematico ideale di una nuova posizione (o strategia) per massimizzare la crescita geometrica del capitale a zero rischio di rovina statistica.")

        from core.advanced_quant import compute_interactive_trade_kelly
        from core.closed_trades import compute_closed_trades_journal

        # Pre-popola con statistiche reali del Graveyard se disponibili
        gy_stats = compute_closed_trades_journal(
            df_tx=results.get("df_tx"),
            df_prices=results.get("df_prices"),
            df_positions=results.get("positions"),
            is_sandbox=bool(results.get("is_sandbox"))
        )
        real_wr = gy_stats.get("win_rate_pct", 55.0) if gy_stats.get("has_closed_trades") else 55.0
        real_pr = gy_stats.get("payoff_ratio", 1.8) if gy_stats.get("has_closed_trades") else 1.8

        with st.expander("⚙️ Parametri della Nuova Idea di Trading", expanded=True):
            col_k_in1, col_k_in2, col_k_in3, col_k_in4 = st.columns(4)
            with col_k_in1:
                k_win_rate = st.slider("Probabilità di Successo (Win Rate %):", 10.0, 90.0, float(real_wr), 1.0, help="Percentuale storica o stimata di trade vincenti.")
            with col_k_in2:
                k_payoff = st.slider("Payoff Ratio (Avg Win / Avg Loss):", 0.5, 5.0, float(real_pr), 0.1, help="Rapporto tra profitto medio su trade vincenti e perdita media su trade perdenti.")
            with col_k_in3:
                k_capital = st.number_input("Capitale di Riferimento Portafoglio (€):", min_value=1000.0, value=100000.0, step=5000.0)
            with col_k_in4:
                k_sl = st.slider("Stop-Loss Previsto (% sull'asset):", 1.0, 25.0, 5.0, 0.5, help="Distanza percentuale del livello di stop loss dal prezzo di ingresso.")

        k_res = compute_interactive_trade_kelly(k_win_rate, k_payoff, k_capital, k_sl)

        col_kr1, col_kr2, col_kr3, col_kr4 = st.columns(4)
        with col_kr1:
            metric_card("🎯 Half-Kelly (Consigliato)", f"{k_res['half_kelly_pct']:.2f}%", f"Rischio: € {k_res['risk_half_eur']:,.2f}", True)
        with col_kr2:
            metric_card("🔥 Full Kelly (Massima Leva)", f"{k_res['full_kelly_pct']:.2f}%", f"Rischio: € {k_res['risk_full_eur']:,.2f}", False)
        with col_kr3:
            metric_card("🛡️ Quarter-Kelly (Prudente)", f"{k_res['quarter_kelly_pct']:.2f}%", f"Rischio: € {k_res['risk_quarter_eur']:,.2f}", True)
        with col_kr4:
            metric_card("📦 Nozionale Suggerito (Half-K)", f"€ {k_res['pos_size_half_eur']:,.2f}", f"Con Stop al {k_sl:.1f}%", True)

        st.info(f"💡 **Edge Matematico della Strategia:** **{k_res['edge_pct']:+.2f}%** | **Tasso di Crescita Geometrico Teorico:** **{k_res['expected_growth_rate']:+.3f}% per operazione** | Profilo di Rischio Drawdown: **{k_res['drawdown_risk']}**")

# ── TAB 3: SIMULAZIONI STOCASTICHE ────────────────────────────
elif active_quant_tab == "🎲 Monte Carlo & Merton":
    st.markdown("### 🎲 Simulatore Stocastico Monte Carlo Multivariato & Salti di Merton")
    render_institutional_info_box(
        title="Simulatore Stocastico Monte Carlo Multivariato & Jump-Diffusion di Merton",
        badge="STOCHASTIC SIMULATION • 10K SCENARIOS • MERTON JUMP",
        summary_html="Generatore vettoriale ad alte prestazioni (10.000 iterazioni) per proiettare l'evoluzione congiunta del portafoglio tramite Decomposizione di Cholesky, code pesanti (Student-t) e componente a salti discreti di Poisson (Merton 1976).",
        math_html="Dinamica Jump-Diffusion di Merton: <code>dS_t / S_t = (μ - λ k) dt + σ dW_t + (J - 1) dq_t</code><br>con $W_t$ Browniano correlato via Cholesky $\\Sigma = L L^T$, $q_t$ processo di Poisson con intensità di salto $\\lambda$, e $\\ln(J) \\sim \\mathcal{N}(\\mu_J, \\sigma_J^2)$.",
        chart_guide_html="• <b>Fascio Traiettorie & Mediana:</b> visualizza il cono di confidenza (5°, 25°, 50°, 75°, 95° percentile) del controvalore atteso.<br>• <b>Probabilità di Perdita (%):</b> quota di scenari che si attestano al di sotto del capitale iniziale investito.",
        regulatory_html="• <b>Basilea III Stressed VaR / Expected Shortfall:</b> proiezione di scenari congiunti estremi per verificare la tenuta dei requisiti di capitale di vigilanza.<br>• <b>PRIIPs Methodology:</b> simulazione di scenari Favorevole, Moderato, Sfavorevole e di Stress conforme agli standard tecnici RTS UE.",
        accent_color="#3b82f6",
    )

    try:
        from core.risk_engine import run_advanced_monte_carlo_simulation
    except ImportError:
        import importlib

        import core.risk_engine
        importlib.reload(core.risk_engine)
        from core.risk_engine import run_advanced_monte_carlo_simulation

    if not has_portfolio or results is None:
        st.warning("⚠️ Carica prima un portafoglio nella Control Room per eseguire le simulazioni Monte Carlo & Merton.")
    else:
        with st.expander("⚙️ Pannello di Controllo Scenario Monte Carlo & Regimi di Stress", expanded=True):
            mc_c1, mc_c2, mc_c3, mc_c4 = st.columns(4)
            with mc_c1:
                horizon_opt = st.selectbox(
                    "Orizzonte Temporale Proiettato:",
                    options=[63, 126, 252, 504, 756],
                    index=2,
                    format_func=lambda x: {63: "3 Mesi (63 gg)", 126: "6 Mesi (126 gg)", 252: "1 Anno (252 gg)", 504: "2 Anni (504 gg)", 756: "3 Anni (756 gg)"}[x]
                )
            with mc_c2:
                vol_mult = st.slider("Moltiplicatore Volatilità (Stress):", 0.50, 2.50, 1.00, 0.25, help="1.0x = Condizioni Normali; 1.5x - 2.0x = Regime di Alta Volatilità / Crisi")
            with mc_c3:
                drift_shift = st.slider("Aggiustamento Trend / Drift Anno (%):", -20.0, 20.0, 0.0, 1.0, help="Shift % sul rendimento atteso anno")
            with mc_c4:
                dist_type = st.radio("Distribuzione Shock:", ["Gaussiana (Normale)", "Student-t (Code Grasse)"], horizontal=True)
                dist_key = "student_t" if "Student-t" in dist_type else "gaussian"

        # Esecuzione della Simulazione Monte Carlo con caching di sessione
        mc_cache_key = f"mc_adv_{horizon_opt}_{vol_mult}_{drift_shift}_{dist_key}_{results.get('run_id', '')}"
        if mc_cache_key in st.session_state:
            mc_adv = st.session_state[mc_cache_key]
        else:
            mc_adv = run_advanced_monte_carlo_simulation(
                results_dict=results,
                horizon_days=horizon_opt,
                volatility_multiplier=vol_mult,
                drift_shift_pct=drift_shift,
                distribution_type=dist_key,
                n_simulations=3000
            )
            st.session_state[mc_cache_key] = mc_adv

        if mc_adv:
            # Head KPI Cards
            mk1, mk2, mk3, mk4, mk5 = st.columns(5)
            with mk1:
                metric_card(
                    "Valore Iniziale",
                    fmt_eur_it(mc_adv['initial_portfolio_value']),
                    "Capitale Base",
                    True,
                    help_text="Valore attuale complessivo del portafoglio utilizzato come base di simulazione."
                )
            with mk2:
                metric_card(
                    "Mediana Attesa (1Y)",
                    fmt_eur_it(mc_adv['expected_value_median']),
                    f"Rendimento: {mc_adv['expected_return_median_pct']:+.2f}%",
                    mc_adv['expected_return_median_pct'] >= 0,
                    help_text="Valore mediano del portafoglio al termine dell'orizzonte temporale."
                )
            with mk3:
                metric_card(
                    "VaR 95% (Rischio)",
                    fmt_eur_it(mc_adv['var_95_val_eur']),
                    f"Perdita Max: -{mc_adv['var_95_pct']:.2f}%",
                    False,
                    help_text="Perdita massima stimata al 95% di confidenza statistica."
                )
            with mk4:
                metric_card(
                    "CVaR 95% (Shortfall)",
                    fmt_eur_it(mc_adv['cvar_95_val_eur']),
                    f"Perdita Media: -{mc_adv['cvar_95_pct']:.2f}%",
                    False,
                    help_text="Expected Shortfall: perdita media attesa qualora si verifichi uno shock oltre il VaR 95%."
                )
            with mk5:
                metric_card(
                    "Probabilità Profitto",
                    f"{mc_adv['prob_profit_pct']:.1f}%",
                    "3.000 Simulazioni",
                    mc_adv['prob_profit_pct'] >= 50.0,
                    help_text="Frazione di percorsi stocastici che registrano un valore finale superiore al capitale iniziale."
                )

            st.divider()

            # Grafico a Nastro (Ribbon & Path Generator Chart)
            st.markdown("#### 📈 Proiezione Stocastica delle Traiettorie nel Tempo (Fan / Ribbon Chart)")
            st.caption(f"Fascio stocastico di 3.000 traiettorie simulate su orizzonte di **{horizon_opt} giorni** ({dist_type}) con intervalli di confidenza percentili (P01 – P99).")
            
            t_days = mc_adv["time_axis"]
            fig_fan = go.Figure()

            # 80 sample paths traslucidi per evidenziare il fascio esteso
            sample_paths = mc_adv["sample_paths"]
            for s_idx in range(sample_paths.shape[1]):
                fig_fan.add_trace(go.Scatter(
                    x=t_days, y=sample_paths[:, s_idx],
                    mode="lines",
                    line=dict(color="rgba(72, 149, 239, 0.07)", width=1),
                    showlegend=False,
                    hoverinfo="skip"
                ))

            # Fasce a nastro (Ribbon Fills)
            fig_fan.add_trace(go.Scatter(
                x=t_days, y=mc_adv["p99_path"], mode="lines", name="P99 (Scenario Ultra-Rialzista)",
                line=dict(color="rgba(0, 255, 153, 0.6)", width=1.5, dash="dot"),
                hovertemplate="<b>P99 (Scenario Ultra-Rialzista)</b><br>Giorno: %{x}<br>Valore: <b>€ %{y:,.2f}</b><extra></extra>"
            ))
            fig_fan.add_trace(go.Scatter(
                x=t_days, y=mc_adv["p75_path"], mode="lines", name="P75 (Scenario Positivo)",
                line=dict(color="rgba(0, 204, 255, 0.5)", width=1), fill="tonexty", fillcolor="rgba(0, 255, 153, 0.05)",
                hovertemplate="<b>P75 (Scenario Positivo)</b><br>Giorno: %{x}<br>Valore: <b>€ %{y:,.2f}</b><extra></extra>"
            ))
            fig_fan.add_trace(go.Scatter(
                x=t_days, y=mc_adv["p50_path"], mode="lines", name="P50 (Mediana Attesa)",
                line=dict(color="#00ff99", width=3),
                hovertemplate="<b>P50 (Mediana Attesa)</b><br>Giorno: %{x}<br>Valore: <b>€ %{y:,.2f}</b><extra></extra>"
            ))
            fig_fan.add_trace(go.Scatter(
                x=t_days, y=mc_adv["p25_path"], mode="lines", name="P25 (Scenario Conservativo)",
                line=dict(color="rgba(255, 204, 0, 0.5)", width=1), fill="tonexty", fillcolor="rgba(255, 204, 0, 0.05)",
                hovertemplate="<b>P25 (Scenario Conservativo)</b><br>Giorno: %{x}<br>Valore: <b>€ %{y:,.2f}</b><extra></extra>"
            ))
            fig_fan.add_trace(go.Scatter(
                x=t_days, y=mc_adv["p05_path"], mode="lines", name="P05 (VaR 95%)",
                line=dict(color="#ff9900", width=2, dash="dash"),
                hovertemplate="<b>P05 (VaR 95%)</b><br>Giorno: %{x}<br>Valore: <b>€ %{y:,.2f}</b><extra></extra>"
            ))
            fig_fan.add_trace(go.Scatter(
                x=t_days, y=mc_adv["p01_path"], mode="lines", name="P01 (Worst Case / VaR 99%)",
                line=dict(color="#ff3333", width=2.5, dash="dash"),
                hovertemplate="<b>P01 (Worst Case / VaR 99%)</b><br>Giorno: %{x}<br>Valore: <b>€ %{y:,.2f}</b><extra></extra>"
            ))

            fig_fan.update_layout(
                xaxis_title="Giorni di Contrattazione (Trading Days)",
                yaxis_title="Valore stimato di Portafoglio (€)",
                template="plotly_dark",
                height=480,
                margin=dict(t=50, b=40, l=55, r=25),
                paper_bgcolor="rgba(0,0,0,0)",
                plot_bgcolor="rgba(0,0,0,0)",
                legend=dict(
                    orientation="h",
                    yanchor="bottom",
                    y=1.02,
                    xanchor="left",
                    x=0.0,
                    bgcolor="rgba(22, 27, 34, 0.85)",
                    bordercolor="rgba(255, 255, 255, 0.12)",
                    borderwidth=1,
                    font=dict(size=11, color="#ffffff")
                )
            )
            apply_plotly_theme(fig_fan)
            st.plotly_chart(fig_fan, use_container_width=True, config={"displayModeBar": "hover", "displaylogo": False})

            # ── RIGA 1: ISTOGRAMMA DEL VALORE FINALE & SOGLIE DI RISCHIO ───
            st.markdown("#### 📊 Istogramma del Valore Finale & Soglie di Rischio (VaR / CVaR)")
            st.caption("Distribuzione di frequenza empirica del capitale stimato a fine orizzonte con indicazione del capitale iniziale, della mediana attesa e dei livelli di VaR 95% e CVaR 95%.")
            
            final_vals = mc_adv["final_values"]
            fig_hist_mc = go.Figure()
            
            fig_hist_mc.add_trace(go.Histogram(
                x=final_vals, nbinsx=55, name="Valore Finale",
                marker=dict(
                    color="rgba(0, 243, 255, 0.45)",
                    line=dict(color="#00f3ff", width=0.8)
                ),
                hovertemplate="<b>Capitale Finale: € %{x:,.0f}</b><br>Frequenza: %{y} simulazioni<extra></extra>"
            ))

            init_v = mc_adv["initial_portfolio_value"]
            med_v = mc_adv["expected_value_median"]
            var95_v = init_v - mc_adv["var_95_val_eur"]
            cvar95_v = init_v - mc_adv["cvar_95_val_eur"]

            fig_hist_mc.add_vline(
                x=cvar95_v, line_dash="dot", line_color="#ff3333", line_width=2,
                annotation_text=f"<b>CVaR 95%</b>: {fmt_eur_it(cvar95_v)}", 
                annotation_position="top left",
                annotation=dict(bgcolor="rgba(22, 27, 34, 0.90)", bordercolor="#ff3333", borderwidth=1, borderpad=4, font=dict(color="#ff5252", size=11))
            )
            fig_hist_mc.add_vline(
                x=var95_v, line_dash="dash", line_color="#ff9900", line_width=2,
                annotation_text=f"<b>VaR 95%</b>: {fmt_eur_it(var95_v)}", 
                annotation_position="top left",
                annotation=dict(bgcolor="rgba(22, 27, 34, 0.90)", bordercolor="#ff9900", borderwidth=1, borderpad=4, font=dict(color="#ffab40", size=11), yshift=-35)
            )
            fig_hist_mc.add_vline(
                x=init_v, line_dash="dash", line_color="#ffffff", line_width=1.8,
                annotation_text=f"<b>Capitale Iniziale</b>: {fmt_eur_it(init_v)}", 
                annotation_position="top right",
                annotation=dict(bgcolor="rgba(22, 27, 34, 0.90)", bordercolor="rgba(255, 255, 255, 0.35)", borderwidth=1, borderpad=4, font=dict(color="#ffffff", size=11))
            )
            fig_hist_mc.add_vline(
                x=med_v, line_dash="solid", line_color="#00ff99", line_width=2.2,
                annotation_text=f"<b>Mediana Attesa</b>: {fmt_eur_it(med_v)}", 
                annotation_position="top right",
                annotation=dict(bgcolor="rgba(22, 27, 34, 0.90)", bordercolor="#00ff99", borderwidth=1, borderpad=4, font=dict(color="#00e676", size=11), yshift=-35)
            )

            fig_hist_mc.update_layout(
                xaxis_title="Valore Finale Stimato di Portafoglio (€)",
                yaxis_title="Frequenza Simulazioni",
                template="plotly_dark", height=415,
                margin=dict(t=45, b=40, l=55, r=25),
                paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)"
            )
            apply_plotly_theme(fig_hist_mc)
            st.plotly_chart(fig_hist_mc, use_container_width=True, config={"displayModeBar": "hover", "displaylogo": False})

            st.markdown("<div style='margin-top: 15px;'></div>", unsafe_allow_html=True)

            # ── RIGA 2: MATRICE DELLE PROBABILITÀ & RISK PROFILE ───────────
            st.caption("Valutazione quantitativa delle probabilità di successo e degli scenari di stress drawdown su 3.000 path simulati.")
            
            df_odds = pd.DataFrame([
                {"Scenario Stocastico": "🟢 Probabilità di Profitto", "Probabilità / Valore": f"{mc_adv['prob_profit_pct']:.1f}%", "Condizione": "Rendimento Finale > 0%"},
                {"Scenario Stocastico": "🚀 Target Moderato (≥ +10%)", "Probabilità / Valore": f"{mc_adv['prob_gain_10_pct']:.1f}%", "Condizione": "Guadagno Finale ≥ +10%"},
                {"Scenario Stocastico": "🔥 Target Rialzista (≥ +20%)", "Probabilità / Valore": f"{mc_adv['prob_gain_20_pct']:.1f}%", "Condizione": "Guadagno Finale ≥ +20%"},
                {"Scenario Stocastico": "⚠️ Rischio Ribasso (≤ -10%)", "Probabilità / Valore": f"{mc_adv['prob_loss_10_pct']:.1f}%", "Condizione": "Perdita Finale ≤ -10%"},
                {"Scenario Stocastico": "🔴 Rischio Crollo (≤ -20%)", "Probabilità / Valore": f"{mc_adv['prob_loss_20_pct']:.1f}%", "Condizione": "Perdita Finale ≤ -20%"},
                {"Scenario Stocastico": "📉 Max Drawdown Simulato Medio", "Probabilità / Valore": f"{mc_adv['avg_max_drawdown_pct']:.2f}%", "Condizione": "Perdita massima media registrata lungo il path"},
                {"Scenario Stocastico": "💥 Max Drawdown Simulato Worst 1%", "Probabilità / Valore": f"{mc_adv['p99_max_drawdown_pct']:.2f}%", "Condizione": "Peggior drawdown nell'1% dei percorsi estremi"}
            ])

            odds_cfg = {
                "Scenario Stocastico": st.column_config.TextColumn("Scenario Stocastico", width="medium"),
                "Probabilità / Valore": st.column_config.TextColumn("Probabilità / Valore", width="small"),
                "Condizione": st.column_config.TextColumn("Condizione di Verifica", width="large")
            }
            render_table_with_export(
                df=df_odds,
                table_title="Matrice delle Probabilità & Risk Profile",
                file_prefix="monte_carlo_odds_matrix",
                key_suffix="mq_mc_odds",
                column_config=odds_cfg,
                hide_index=True
            )

        else:
            st.info("Simulazione Monte Carlo non disponibile per gli asset selezionati.")

        st.divider()

        col_km_h1, col_km_h2 = st.columns([3.2, 1.1])
        with col_km_h1:
            st.markdown("#### 🧬 K-Means Clustering: Segmentazione Asset per Profilo di Rischio & Rendimento")
            st.caption("Algoritmo di machine learning non supervisionato che raggruppa gli asset di portafoglio in cluster omogenei in base al tradeoff tra Volatilità Annua e CAGR.")
        with col_km_h2:
            st.markdown('<div style="margin-top: 6px;"></div>', unsafe_allow_html=True)
            glossary_modal("💡 Guida al K-Means Clustering", r"""
<div style="font-size: 13.5px; line-height: 1.5; color: #c9d1d9;">
  <div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,153,0,0.25); border-radius: 10px; padding: 14px; margin-bottom: 8px;">
    <div style="color: #ff9900; font-size: 15px; font-weight: 700; margin-bottom: 8px;">🧬 K-Means Clustering degli Asset</div>
    <div style="margin-bottom: 8px;"><b>📌 Cos'è:</b> Algoritmo di Machine Learning non supervisionato che partiziona gli $N$ asset del portafoglio in $k$ cluster omogenei, minimizzando la varianza interna a ciascun gruppo (Within-Cluster Sum of Squares).</div>
    <div style="margin-bottom: 8px;"><b>📐 Come si calcola:</b>
      <div style="background: rgba(255,153,0,0.08); border-left: 3px solid #ff9900; padding: 6px 10px; border-radius: 6px; margin: 4px 0; color: #ffb74d; font-family: monospace; font-size: 12.5px;">
        argmin_S &Sigma;_{i=1}^k &Sigma;_{x \in S_i} || x - &mu;_i ||^2 &nbsp;|&nbsp; Features: [Volatilità Annua, CAGR]
      </div>
    </div>
    <div style="margin-bottom: 8px;"><b>🎯 A cosa serve:</b> Identificare categorie funzionali di rischio (Core difensivi, Motori di crescita, Outlier volatili) evitando di trattare tutti i titoli azionari o obbligazionari come un blocco monolitico.</div>
    <div style="margin-bottom: 8px;"><b>⚙️ Come viene calcolato da ARGUS:</b> Estrazione della volatilità storica annualizzata (252 gg) e del CAGR per ciascun asset attivo, standardizzazione delle feature e applicazione di k-means (k=2..3 con metodo Elbow/Silhouette).</div>
    <div><b>🔍 Come leggerlo:</b><br>
      • 🟢 <b>Cluster 1 (Core / Bassa Volatilità):</b> Asset stabilizzatori con moderata oscillazione.<br>
      • 🟡 <b>Cluster 2 (Crescita / Rendimento):</b> Titoli ad alto CAGR e profilo di rischio equilibrato.<br>
      • 🔴 <b>Cluster 3 (Alta Volatilità / Outlier):</b> Asset speculativi o fortemente oscillanti da monitorare.
    </div>
  </div>
</div>
""", button_label="💡 Come funziona K-Means?")

        # Fallback computazionale dinamico se clusters non è presente o è vuoto
        if not clusters or len(clusters) == 0:
            df_returns_all = results.get("df_returns", pd.DataFrame())
            df_prices_all = results.get("df_prices", pd.DataFrame())
            pos_active = results.get("positions", pd.DataFrame())
            
            # 1. Prova di calcolo da df_returns usando SOLO asset attivi
            if isinstance(df_returns_all, pd.DataFrame) and not df_returns_all.empty:
                candidate_tickers = list(active_tickers_set) if active_tickers_set else [t for t in df_returns_all.columns if not str(t).endswith("=X")]
                common_t = [t for t in candidate_tickers if t in df_returns_all.columns and not str(t).endswith("=X")]
                if len(common_t) >= 2:
                    v_rets = df_returns_all[common_t].replace([np.inf, -np.inf], np.nan).dropna(how="all")
                    v_rets = v_rets.clip(lower=-0.75, upper=2.0)
                    vol_s = (v_rets.std() * np.sqrt(252)).clip(0.001, 3.0)
                    mean_r = v_rets.mean().clip(lower=-0.05, upper=0.05)
                    cagr_s = ((1 + mean_r) ** 252 - 1).clip(-0.90, 5.0)
                    f_df = pd.DataFrame({'volatility': vol_s, 'cagr': cagr_s})
                    f_df = f_df.replace([np.inf, -np.inf], np.nan).dropna()
                    f_df = f_df[np.isfinite(f_df).all(axis=1)]
                    f_df.index.name = "ticker"
                    if len(f_df) >= 2:
                        try:
                            from sklearn.cluster import KMeans
                            X = f_df[['volatility', 'cagr']].values
                            std_X = X.std(axis=0)
                            std_X[std_X == 0] = 1.0
                            X_scaled = (X - X.mean(axis=0)) / std_X
                            n_c = min(3, len(f_df))
                            km = KMeans(n_clusters=n_c, random_state=42, n_init=10)
                            f_df['cluster'] = km.fit_predict(X_scaled)
                            clusters = f_df.reset_index().to_dict(orient="records")
                        except Exception:
                            clusters = []
            
            # 2. Prova di calcolo da df_prices se df_returns era vuoto
            if (not clusters or len(clusters) == 0) and isinstance(df_prices_all, pd.DataFrame) and not df_prices_all.empty and "ticker" in df_prices_all.columns and "close" in df_prices_all.columns:
                cand_p = df_prices_all[df_prices_all["ticker"].isin(active_tickers_set)] if active_tickers_set else df_prices_all
                p_piv = cand_p.pivot_table(index="price_date", columns="ticker", values="close").pct_change()
                p_piv = p_piv.replace([np.inf, -np.inf], np.nan).dropna(how="all").clip(lower=-0.75, upper=2.0)
                p_piv = p_piv[[c for c in p_piv.columns if not str(c).endswith("=X") and (not active_tickers_set or c in active_tickers_set)]]
                if not p_piv.empty and len(p_piv.columns) >= 2:
                    vol_s = (p_piv.std() * np.sqrt(252)).clip(0.001, 3.0)
                    mean_p = p_piv.mean().clip(lower=-0.05, upper=0.05)
                    cagr_s = ((1 + mean_p) ** 252 - 1).clip(-0.90, 5.0)
                    f_df = pd.DataFrame({'volatility': vol_s, 'cagr': cagr_s})
                    f_df = f_df.replace([np.inf, -np.inf], np.nan).dropna()
                    f_df = f_df[np.isfinite(f_df).all(axis=1)]
                    f_df.index.name = "ticker"
                    if len(f_df) >= 2:
                        try:
                            from sklearn.cluster import KMeans
                            X = f_df[['volatility', 'cagr']].values
                            std_X = X.std(axis=0)
                            std_X[std_X == 0] = 1.0
                            X_scaled = (X - X.mean(axis=0)) / std_X
                            n_c = min(3, len(f_df))
                            km = KMeans(n_clusters=n_c, random_state=42, n_init=10)
                            f_df['cluster'] = km.fit_predict(X_scaled)
                            clusters = f_df.reset_index().to_dict(orient="records")
                        except Exception:
                            clusters = []

        if clusters and len(clusters) > 0:
            df_cl = pd.DataFrame(clusters)
            if "ticker" not in df_cl.columns and "index" in df_cl.columns:
                df_cl = df_cl.rename(columns={"index": "ticker"})
            elif "ticker" not in df_cl.columns:
                df_cl["ticker"] = [f"Asset {i+1}" for i in range(len(df_cl))]

            # Filtra rigorosamente solo asset aperti
            if active_tickers_set:
                df_cl = df_cl[df_cl["ticker"].isin(active_tickers_set)]
            df_cl = df_cl[~df_cl["ticker"].astype(str).str.endswith("=X")]

            # Sanitizzazione preventiva valori
            df_cl = df_cl.replace([np.inf, -np.inf], np.nan).dropna(subset=["volatility", "cagr"])
            df_cl["volatility"] = pd.to_numeric(df_cl["volatility"], errors="coerce").fillna(0.0)
            df_cl["cagr"] = pd.to_numeric(df_cl["cagr"], errors="coerce").fillna(0.0)

            # Rilevamento scala percentuale basato sulla mediana dei valori (robusto contro outlier)
            is_decimal = float(df_cl["volatility"].median()) < 2.0
            if is_decimal:
                df_cl["volatility"] = df_cl["volatility"] * 100.0
                df_cl["cagr"] = df_cl["cagr"] * 100.0

            df_cl["volatility"] = df_cl["volatility"].clip(lower=0.1, upper=250.0)
            df_cl["cagr"] = df_cl["cagr"].clip(lower=-99.0, upper=500.0)

            # Dynamic meaningful cluster naming based on average volatility
            stats = df_cl.groupby("cluster")[["volatility", "cagr"]].mean()
            sorted_c = stats.sort_values("volatility").index.tolist()
            
            label_map = {}
            for i, cid in enumerate(sorted_c):
                if i == 0:
                    label_map[cid] = "🛡️ Cluster 1: Bassa Volatilità / Core"
                elif i == len(sorted_c) - 1 and len(sorted_c) > 1:
                    label_map[cid] = f"⚡ Cluster {i+1}: Alta Volatilità / Outlier"
                else:
                    label_map[cid] = f"🚀 Cluster {i+1}: Crescita / Moderato"

            df_cl["cluster_label"] = df_cl["cluster"].map(label_map)
            df_cl = df_cl.sort_values(by=["volatility", "cagr"]).reset_index(drop=True)

            # Smart label offsetting to eliminate overlapping text for nearby points
            pos_options = ["top center", "bottom right", "top right", "bottom left", "top left"]
            df_cl["text_pos"] = [pos_options[i % len(pos_options)] for i in range(len(df_cl))]

            fig_cl = go.Figure()
            colors = ["#58a6ff", "#00e676", "#ff9900", "#f85149", "#bc8cff", "#00f3ff"]

            for idx, cl_name in enumerate(df_cl["cluster_label"].unique()):
                sub = df_cl[df_cl["cluster_label"] == cl_name]
                fig_cl.add_trace(go.Scatter(
                    x=sub["volatility"],
                    y=sub["cagr"],
                    mode="markers+text",
                    name=cl_name,
                    text=sub["ticker"],
                    textposition=sub["text_pos"].tolist(),
                    marker=dict(
                        size=14,
                        color=colors[idx % len(colors)],
                        line=dict(width=1.5, color="#ffffff")
                    ),
                    textfont=dict(size=11, color="#e6edf3"),
                    hovertemplate="<b>%{text}</b><br>" + cl_name + "<br>Volatilità Annua: <b>%{x:.2f}%</b><br>CAGR: <b>%{y:.2f}%</b><extra></extra>"
                ))

            # Quadrant reference lines (Medians)
            med_v = float(df_cl["volatility"].median())
            med_r = float(df_cl["cagr"].median())
            fig_cl.add_vline(x=med_v, line_dash="dot", line_color="rgba(255,255,255,0.18)", line_width=1)
            fig_cl.add_hline(y=med_r, line_dash="dot", line_color="rgba(255,255,255,0.18)", line_width=1)

            fig_cl.update_layout(
                xaxis_title="Volatilità Annua % (Rischio)",
                yaxis_title="CAGR % (Rendimento Composto Annuo)",
                template="plotly_dark",
                height=450,
                margin=dict(t=50, b=40, l=55, r=25),
                paper_bgcolor="rgba(0,0,0,0)",
                plot_bgcolor="rgba(0,0,0,0)",
                legend=dict(
                    orientation="h",
                    yanchor="bottom",
                    y=1.02,
                    xanchor="left",
                    x=0.0,
                    bgcolor="rgba(22, 27, 34, 0.85)",
                    bordercolor="rgba(255, 255, 255, 0.12)",
                    borderwidth=1,
                    font=dict(size=11, color="#ffffff")
                )
            )
            apply_plotly_theme(fig_cl)
            st.plotly_chart(fig_cl, use_container_width=True, config={"displayModeBar": "hover", "displaylogo": False})

            # Tabella Interattiva Dettaglio Cluster
            df_cl_table = pd.DataFrame({
                "Ticker": df_cl["ticker"].astype(str),
                "Segmento Cluster": df_cl["cluster_label"].astype(str),
                "Volatilità Annua %": df_cl["volatility"].astype(float),
                "CAGR %": df_cl["cagr"].astype(float),
                "Sharpe Implicito": ((df_cl["cagr"] - 2.75) / df_cl["volatility"].replace(0, np.nan)).fillna(0.0).round(2)
            })

            search_cl = st.text_input("🔍 Cerca Ticker nei Cluster:", placeholder="Filtra per Ticker...", key="search_km_cluster")
            df_cl_filt = df_cl_table.copy()
            if search_cl:
                df_cl_filt = df_cl_filt[df_cl_filt["Ticker"].str.contains(search_cl.strip(), case=False, na=False)]

            cl_col_config = {
                "Ticker": st.column_config.TextColumn("Ticker", width="small"),
                "Segmento Cluster": st.column_config.TextColumn("Segmento Cluster", width="medium"),
                "Volatilità Annua %": st.column_config.NumberColumn("Volatilità Annua %", format="%.2f%%"),
                "CAGR %": st.column_config.NumberColumn("CAGR %", format="%+.2f%%"),
                "Sharpe Implicito": st.column_config.NumberColumn("Sharpe Implicito", format="%.2f")
            }
            render_table_with_export(
                df=df_cl_filt,
                table_title="Dettaglio Asset per Cluster di Rischio",
                file_prefix="asset_clusters_kmeans",
                key_suffix="mq_kmeans",
                column_config=cl_col_config,
                hide_index=True
            )
        else:
            st.info("ℹ️ Il modello K-Means Clustering richiede almeno 2 asset attivi con serie storica dei prezzi per calcolare la segmentazione del profilo rischio/rendimento.")

        st.divider()
        col_head_mer1, col_head_mer2 = st.columns([3.2, 1.1])
        with col_head_mer1:
            st.markdown("#### ⚡ Simulatore Jump-Diffusion di Merton (Shock Stocastici & Tail Risk)")
            st.caption("Modellizzazione stocastica avanzata non-gaussiana che integra salti di Poisson (Crash Shock) per misurare perdite catastrofiche di coda (Fat Tails).")
        with col_head_mer2:
            st.markdown('<div style="margin-top: 6px;"></div>', unsafe_allow_html=True)
            glossary_modal("⚡ Guida al Modello Merton Jump-Diffusion", """
<div style="font-size: 13.5px; line-height: 1.45;">

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px; margin-bottom: 8px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">📌 Cos'è il Processo Jump-Diffusion di Merton (1976)</div>
  <div>Un'estensione del moto browniano geometrico sviluppata dal premio Nobel Robert C. Merton che combina una dinamica continua di diffusione con salti discontinui discreti governati da un processo di Poisson.</div>
</div>

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px; margin-bottom: 8px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">📐 Equazione Differenziale Stocastica (SDE)</div>
  <div style="background: rgba(255,153,0,0.08); border-left: 3px solid #ff9900; padding: 6px 10px; border-radius: 6px; margin: 5px 0; color: #ffb74d; font-size: 12.5px; text-align: center;">
    <b>dS<sub>t</sub></b> = &mu; S<sub>t</sub> dt + &sigma; S<sub>t</sub> dW<sub>t</sub> + (e<sup>Y<sub>t</sub></sup> &minus; 1) S<sub>t</sub> dN<sub>t</sub>
  </div>
  <div>
    • <b>&lambda;:</b> Frequenza media annua di arrivo dei salti (Processo di Poisson <i>N<sub>t</sub></i>)<br>
    • <b>&mu;<sub>J</sub>, &sigma;<sub>J</sub>:</b> Media e deviazione standard logaritmica dell'ampiezza dello shock (<i>Y<sub>t</sub> ~ N(&mu;<sub>J</sub>, &sigma;<sub>J</sub><sup>2</sup>)</i>)
  </div>
</div>

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px; margin-bottom: 8px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">🎯 A cosa serve</div>
  <div>Modellizzare i crash istantanei (Flash Crash, eventi geopolitici, default bancari improvvisi) che i modelli gaussiani standard non possono fisicamente generare.</div>
</div>

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px; margin-bottom: 8px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">⚙️ Calcolo in ARGUS</div>
  <div>Il modulo <code>core/risk_engine.py</code> calibra i salti sui rendimenti storici e calcola la discrepanza percentuale tra il VaR normale e il VaR sotto processo di Merton.</div>
</div>

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">🔍 Come leggerlo</div>
  <div>Se il VaR Merton è significativamente più severo del VaR normale, il portafoglio è esposto a grave rischio di salto asimmetrico e richiede strategie di tail hedging.</div>
</div>

</div>
""", button_label="💡 Come funziona Merton Jump-Diffusion?")

        with st.expander("⚙️ Configurazione Parametri Merton Jump Shocks", expanded=False):
            col_mj1, col_mj2, col_mj3 = st.columns(3)
            with col_mj1:
                lambda_in = st.slider("Frequenza Salto Poisson (salti/anno):", 0.1, 5.0, 1.5, 0.1, help="Numero medio di shock improvvisi attesi all'anno")
            with col_mj2:
                mu_j_in = st.slider("Dimensione Media Salto (%)", -30.0, 5.0, -8.0, 1.0, help="Shock medio in % (valori negativi = crolli)") / 100.0
            with col_mj3:
                sigma_j_in = st.slider("Volatilità Salto (%)", 1.0, 20.0, 5.0, 1.0) / 100.0

        from core.risk_engine import compute_merton_jump_diffusion_simulation
        sr_p_merton = results.get("portfolio_return", pd.Series(dtype=float)) if results else pd.Series(dtype=float)
        merton_res = compute_merton_jump_diffusion_simulation(
            sr_portfolio=sr_p_merton,
            n_sims=500,
            time_horizon_days=horizon_opt,
            lambda_j=lambda_in,
            mu_j=mu_j_in,
            sigma_j=sigma_j_in,
            initial_value=mc_adv['initial_portfolio_value'] if mc_adv else 100000.0
        )

        cmj1, cmj2, cmj3, cmj4 = st.columns(4)
        with cmj1:
            metric_card("VaR 99% Gaussiano", f"{merton_res['var_99_gauss_pct']:.2f}%", "Benchmark Normale", True)
        with cmj2:
            merton_diff = merton_res['var_99_jump_pct'] - merton_res['var_99_gauss_pct']
            metric_card("VaR 99% Merton Jump", f"{merton_res['var_99_jump_pct']:.2f}%", f"{merton_diff:+.2f}% vs Gauss", False)
        with cmj3:
            metric_card("CVaR 99% Shortfall", f"{merton_res['cvar_99_jump_pct']:.2f}%", "Coda Estrema Fat Tail", False)
        with cmj4:
            metric_card("Frequenza Salti", f"{merton_res['mean_jumps_per_year']:.1f} / anno", "Processo di Poisson", True)

        st.markdown("<div style='margin-top: 10px;'></div>", unsafe_allow_html=True)
        st.markdown("##### 📈 Traiettorie Stocastiche Merton Jump-Diffusion")
        st.caption(f"Fascio stocastico simulato con Poisson Jump Shocks (λ = {lambda_in} salti/anno, ampiezza media shock μ_J = {mu_j_in*100:.1f}%, σ_J = {sigma_j_in*100:.1f}%).")

        m_days = merton_res["days"]
        fig_merton = go.Figure()
        fig_merton.add_trace(go.Scatter(
            x=m_days, y=merton_res["p95"], mode="lines", name="P95 Scenario Rialzista",
            line=dict(color="rgba(0,255,153,0.6)", width=1.2),
            hovertemplate="<b>P95 (Scenario Rialzista)</b><br>Giorno: <b>%{x}</b><br>Valore: <b>€ %{y:,.2f}</b><extra></extra>"
        ))
        fig_merton.add_trace(go.Scatter(
            x=m_days, y=merton_res["p75"], mode="lines", name="P75 Scenario Positivo",
            line=dict(color="rgba(0,204,255,0.5)", width=1), fill="tonexty", fillcolor="rgba(0,255,153,0.05)",
            hovertemplate="<b>P75 (Scenario Positivo)</b><br>Giorno: <b>%{x}</b><br>Valore: <b>€ %{y:,.2f}</b><extra></extra>"
        ))
        fig_merton.add_trace(go.Scatter(
            x=m_days, y=merton_res["p50"], mode="lines", name="P50 Mediana Jump-Diffusion",
            line=dict(color="#00f3ff", width=2.5),
            hovertemplate="<b>P50 (Mediana Jump-Diffusion)</b><br>Giorno: <b>%{x}</b><br>Valore: <b>€ %{y:,.2f}</b><extra></extra>"
        ))
        fig_merton.add_trace(go.Scatter(
            x=m_days, y=merton_res["p25"], mode="lines", name="P25 Scenario Conservativo",
            line=dict(color="rgba(255,204,0,0.5)", width=1), fill="tonexty", fillcolor="rgba(255,204,0,0.05)",
            hovertemplate="<b>P25 (Scenario Conservativo)</b><br>Giorno: <b>%{x}</b><br>Valore: <b>€ %{y:,.2f}</b><extra></extra>"
        ))
        fig_merton.add_trace(go.Scatter(
            x=m_days, y=merton_res["p5"], mode="lines", name="P05 Tail Crash Zone",
            line=dict(color="#ff3333", width=2, dash="dash"),
            hovertemplate="<b>P05 (Tail Crash Zone)</b><br>Giorno: <b>%{x}</b><br>Valore: <b>€ %{y:,.2f}</b><extra></extra>"
        ))

        fig_merton.update_layout(
            xaxis_title="Giorni di Contrattazione (Trading Days)",
            yaxis_title="Valore Portafoglio (€)",
            template="plotly_dark",
            height=450,
            margin=dict(t=50, b=40, l=55, r=25),
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            legend=dict(
                orientation="h",
                yanchor="bottom",
                y=1.02,
                xanchor="left",
                x=0.0,
                bgcolor="rgba(22, 27, 34, 0.85)",
                bordercolor="rgba(255, 255, 255, 0.12)",
                borderwidth=1,
                font=dict(size=11, color="#ffffff")
            )
        )
        apply_plotly_theme(fig_merton)
        st.plotly_chart(fig_merton, use_container_width=True, config={"displayModeBar": "hover", "displaylogo": False})

# ── TAB 4: HEDGING TATTICO & TAIL RISK ────────────────────────
elif active_quant_tab == "🛡️ Hedging & Opzioni":
    st.markdown("#### 🛡️ Simulatore di Copertura & Hedging Tattico (Beta-Neutral & Black-Scholes Options)")
    render_institutional_info_box(
        title="Tactical Beta-Neutral Hedging, Black-Scholes (1973) Greeks & Volatility Skew",
        badge="TACTICAL HEDGING • GREEKS • VOLATILITY SKEW",
        summary_html="Dimensionamento esatto delle coperture di portafoglio: calcolo delle quote per ETF inversi e micro-futures per immunizzare il Beta di mercato, pricing analitico di opzioni europee (Black-Scholes-Merton), decomposizione dei 5 Greci (Δ, Γ, Θ, Vega, ρ) e calibrazione dello Skew di volatilità reale.",
        math_html="Numero contratti/quote di copertura: <code>N_{hedge} = - (β_{target} - β_p) · V_p / (β_{inst} · P_{inst})</code><br>Pricing Black-Scholes: <code>C = S e^{-q T} N(d_1) - K e^{-r T} N(d_2)</code> | <code>P = K e^{-r T} N(-d_2) - S e^{-q T} N(-d_1)</code><br>con $d_1 = [\\ln(S/K) + (r - q + 0.5 σ²)T] / (σ \\sqrt{T})$ e $d_2 = d_1 - σ \\sqrt{T}$.",
        chart_guide_html="• <b>Beta Attuale vs Target:</b> calcola l'investimento monetario protettivo per azzerare la reattività sistemica (Beta-Neutral).<br>• <b>Profilo Payoff & Vol Skew:</b> evidenzia l'effetto asimmetrico OTM Put/Call e il costo del decadimento temporale (Theta bleed).",
        regulatory_html="• <b>IFRS 9 Hedge Accounting:</b> documentazione formale dell'efficacia prospettica e retrospettiva della copertura (intervallo 80-125%).<br>• <b>EMIR & Clearing Mandates:</b> gestione del rischio di base (basis risk) tra lo strumento derivato quotato o ETF inverso e il paniere di portafoglio sottostante.",
        accent_color="#06b6d4",
    )

    if not has_portfolio or results is None:
        st.warning("⚠️ Carica prima un portafoglio nella Control Room per calcolare le coperture di Hedging Tattico.")
    else:
        from core.hedging import HEDGE_INSTRUMENTS, compute_beta_neutral_hedge

        col_hd1, col_hd2 = st.columns(2)
        with col_hd1:
            target_beta_input = st.slider(
                "Target Beta Desiderato:",
                min_value=-0.50, max_value=1.50, value=0.00, step=0.10,
                help="Imposta 0.00 per renderti immune ai movimenti del mercato generale (Beta-Neutral)."
            )
        with col_hd2:
            hedge_inst_input = st.selectbox(
                "Strumento di Copertura:",
                options=list(HEDGE_INSTRUMENTS.keys()),
                format_func=lambda k: f"{k} - {HEDGE_INSTRUMENTS[k]['name']} ({HEDGE_INSTRUMENTS[k]['underlying']})"
            )

        hedge_res = compute_beta_neutral_hedge(results, target_beta=target_beta_input, hedge_ticker=hedge_inst_input)

        col_hm1, col_hm2, col_hm3, col_hm4 = st.columns(4)
        with col_hm1:
            metric_card(
                "Beta Attuale Portafoglio",
                f"{hedge_res['current_beta']:.2f}",
                delta=f"Target: {target_beta_input:.2f}",
                positive=True,
                help_text="Sensibilità complessiva del portafoglio alle oscillazioni del mercato benchmark."
            )
        with col_hm2:
            val_eur_str = f"€ {hedge_res['hedge_value_eur']:,.2f}".replace(",", ".")
            metric_card(
                "Valore Copertura",
                val_eur_str,
                delta="Controvalore Reale",
                positive=True,
                help_text="Controvalore finanziario totale dello strumento short necessario per azzerare il Beta."
            )
        with col_hm3:
            metric_card(
                f"Quote {hedge_inst_input}",
                f"{hedge_res['hedge_shares']} quote",
                delta=f"Prezzo: € {hedge_res['instrument_price']:.2f}".replace(",", "."),
                positive=True,
                help_text="Numero esatto di quote/azioni dello strumento di copertura da acquistare a mercato."
            )
        with col_hm4:
            tail_eur_str = f"€ {hedge_res['tail_risk_var99_eur']:,.2f}".replace(",", ".")
            metric_card(
                "Protezione Tail Risk (99%)",
                tail_eur_str,
                delta="Scudo anti-crash",
                positive=True,
                help_text="Perdita massima stimata al 99% coperta dal posizionamento di hedging."
            )

        st.info(f"""
        💡 **Indicazione Operativa di Copertura**:
        Per portare il Beta di portafoglio da **{hedge_res['current_beta']:.2f}** a **{target_beta_input:.2f}**, acquista **{hedge_res['hedge_shares']} quote** dello strumento **{hedge_res['instrument_name']} ({hedge_inst_input})** ad un prezzo indicativo di **€ {hedge_res['instrument_price']:.2f}** per un investimento protettivo di **€ {hedge_res['hedge_value_eur']:,.2f}**.
        """)

        st.divider()
        col_head_bs1, col_head_bs2 = st.columns([3.5, 1.0])
        with col_head_bs1:
            st.markdown("#### 🛡️ Copertura Delta-Hedging & Volatility Skew (Black-Scholes 1973)")
            st.caption("Dimensionamento matematico dei contratti Put per immunizzare il Beta di portafoglio, calcolo analitico dei 5 Greci ($\\Delta, \\Gamma, \\Theta, \\text{Vega}, \\rho$) e calibrazione dello Skew reale.")
        with col_head_bs2:
            st.markdown('<div style="margin-top: 6px;"></div>', unsafe_allow_html=True)
            glossary_modal("💡 Guida a Black-Scholes, Greci & Skew", """
<div style="font-size: 13.5px; line-height: 1.45;">

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px; margin-bottom: 8px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">📌 1. Modello di Black-Scholes-Merton (1973) & Greci</div>
  <div>
    • <b>Delta (&Delta;):</b> Sensibilità del premio al sottostante (Hedge Ratio)<br>
    • <b>Gamma (&Gamma;):</b> Curvatura e derivata seconda del prezzo rispetto allo Spot<br>
    • <b>Theta (&Theta;):</b> Decadimento temporale giornaliero (<i>Time Decay</i>)<br>
    • <b>Vega:</b> Sensibilità all'1% di variazione della volatilità implicita (&sigma;)<br>
    • <b>Rho (&rho;):</b> Reattività alle variazioni dei tassi d'interesse
  </div>
</div>

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px; margin-bottom: 8px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">📐 2. Volatility Smile & Skew Reale</div>
  <div>Black-Scholes assume volatilità costante. Nella realtà, le Put OTM incorporano un premio di crash risk (&sigma;<sub>IV</sub> più elevata). ARGUS calibra la curva di Skew reale &sigma;(m) = a + b&middot;m + c&middot;m<sup>2</sup> per un pricing rigoroso dei contratti.</div>
</div>

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">🎯 3. Dimensionamento Contratti Put</div>
  <div><code>Contratti = (Valore Portafoglio &times; &beta; &times; Copertura %) / (Spot &times; 100 &times; |&Delta;|)</code></div>
</div>

</div>
""", button_label="💡 Come funziona Black-Scholes & Greci?")

        col_opt_in1, col_opt_in2, col_opt_in3, col_opt_in4 = st.columns(4)
        with col_opt_in1:
            bm_spot_in = st.number_input("Prezzo Spot Benchmark (SPY/SPX $):", value=550.0, step=10.0)
        with col_opt_in2:
            iv_in = st.slider("Volatilità Base ATM (%):", 10.0, 60.0, 18.0, 1.0) / 100.0
        with col_opt_in3:
            target_hedge_pct = st.slider("Copertura Portafoglio (%):", 25.0, 100.0, 100.0, 25.0)
        with col_opt_in4:
            expiry_m_in = st.selectbox("Scadenza Opzioni:", [1.0, 3.0, 6.0, 12.0], index=1, format_func=lambda x: f"{int(x)} Mesi")

        use_skew = st.toggle("⚡ Calibrazione Volatility Skew & Smile Reale", value=True, help="Applica la pendenza dello Skew per strike OTM (le Put OTM costano di più per il premio al crash risk)")

        port_val_tot = float(pos["current_value"].sum()) if (isinstance(pos, pd.DataFrame) and not pos.empty and "current_value" in pos.columns) else 100000.0
        port_b = float(results.get("metrics", {}).get("market_risk", {}).get("beta", 1.10) or 1.10) if results else 1.10

        bs_hedge = compute_portfolio_delta_hedge(
            portfolio_value=port_val_tot,
            portfolio_beta=port_b,
            benchmark_spot=bm_spot_in,
            target_hedge_pct=target_hedge_pct,
            strike_otm_pct=5.0,
            expiry_months=expiry_m_in,
            implied_vol=iv_in,
            use_skew_calibration=use_skew
        )

        col_bs1, col_bs2, col_bs3, col_bs4 = st.columns(4)
        with col_bs1:
            metric_card(
                "Contratti Put Necessari",
                f"{bs_hedge['contracts_needed']} Contratti",
                delta=f"Strike ${bs_hedge['strike_price']:.1f} (5% OTM)",
                positive=True,
                help_text=f"Numero di contratti di opzione Put 5% OTM necessari per sterilizzare il Beta al {target_hedge_pct:.0f}% del portafoglio."
            )
        with col_bs2:
            skew_diff = bs_hedge['put_price'] - bs_hedge['flat_put_price']
            metric_card(
                "Premio Put (Per Azione)",
                f"${bs_hedge['put_price']:.2f}",
                delta=f"+${skew_diff:.2f} Skew Prem." if use_skew else "IV Piatta ATM",
                positive=(not use_skew or skew_diff <= 0),
                help_text="Costo unitario del premio dell'opzione Put per singola azione del sottostante."
            )
        with col_bs3:
            cost_usd_str = f"${bs_hedge['total_hedge_cost']:,.2f}".replace(",", ".")
            metric_card(
                "Costo Totale Copertura",
                cost_usd_str,
                delta=f"{bs_hedge['cost_pct_of_portfolio']:.2f}% del Portafoglio",
                positive=(bs_hedge['cost_pct_of_portfolio'] < 5.0),
                help_text="Esborso finanziario totale per l'acquisto di tutti i contratti Put di copertura."
            )
        with col_bs4:
            metric_card(
                f"IV Effettiva ({bs_hedge['effective_iv_pct']:.1f}%)",
                f"Δ: {bs_hedge['put_delta']:.3f}",
                delta=f"Vega: {bs_hedge['put_vega']:.2f} | Γ: {bs_hedge['put_gamma']:.4f}",
                positive=True,
                help_text="Greci di Black-Scholes: Delta (Δ), Vega (sensibilità all'1% di IV) e Gamma (Γ, curvatura)."
            )

        # Superficie e Smile Plotly
        surf_model = build_volatility_surface(spot=bm_spot_in, base_atm_iv=iv_in)
        
        st.markdown('<div style="margin-top: 15px;"></div>', unsafe_allow_html=True)
        tab_opt_2d, tab_opt_3d = st.tabs([
            "📉 Curva Volatility Smile & Skew (2D)",
            "🌐 Superficie di Volatilità Implicita 3D (Term Structure x Moneyness)"
        ])
        
        with tab_opt_2d:
            fig_smile = go.Figure()
            exp_key = f"{int(expiry_m_in)}M"
            smile_fit = surf_model["smile_models"].get(exp_key, list(surf_model["smile_models"].values())[0])
            k_range = np.linspace(bm_spot_in * 0.75, bm_spot_in * 1.25, 60)
            iv_curve = [smile_fit["eval_func"](k) * 100.0 for k in k_range]
            
            fig_smile.add_trace(go.Scatter(
                x=k_range,
                y=iv_curve,
                mode="lines",
                name=f"Skew Calibrato ({int(expiry_m_in)} Mesi)",
                line=dict(color="#00f3ff", width=2.8),
                hovertemplate="<b>Strike: $%{x:.1f}</b><br>IV Calibrata: <b>%{y:.2f}%</b><extra></extra>"
            ))
            
            # Strike di Copertura Put
            fig_smile.add_trace(go.Scatter(
                x=[bs_hedge["strike_price"]],
                y=[bs_hedge["effective_iv_pct"]],
                mode="markers+text",
                name="Strike Put Hedging (5% OTM)",
                text=["Put Strike"],
                textposition="top left",
                textfont=dict(color="#f87171", size=11),
                marker=dict(color="#ef4444", size=12, symbol="diamond", line=dict(color="#ffffff", width=1.5)),
                hovertemplate="<b>Strike Put Hedging: $%{x:.1f}</b><br>IV Skew Effettiva: <b>%{y:.2f}%</b><extra></extra>"
            ))
            
            # Strike Spot ATM
            fig_smile.add_trace(go.Scatter(
                x=[bm_spot_in],
                y=[iv_in * 100.0],
                mode="markers+text",
                name=f"Spot ATM (${bm_spot_in:.0f})",
                text=["Spot ATM"],
                textposition="top right",
                textfont=dict(color="#ffb74d", size=11),
                marker=dict(color="#ff9900", size=11, symbol="circle", line=dict(color="#ffffff", width=1.5)),
                hovertemplate="<b>Spot Benchmark: $%{x:.1f}</b><br>IV Base ATM: <b>%{y:.2f}%</b><extra></extra>"
            ))
            
            fig_smile.update_layout(
                height=380,
                margin=dict(l=15, r=15, t=30, b=20),
                legend=dict(
                    orientation="h",
                    yanchor="bottom",
                    y=1.02,
                    xanchor="center",
                    x=0.5,
                    font=dict(size=11.5)
                ),
                paper_bgcolor="rgba(0,0,0,0)",
                plot_bgcolor="rgba(0,0,0,0)",
                xaxis=dict(title="Strike Price ($)", showgrid=True, gridcolor="rgba(255,255,255,0.06)", tickfont=dict(family="monospace")),
                yaxis=dict(title="Volatilità Implicita (%)", showgrid=True, gridcolor="rgba(255,255,255,0.06)", tickfont=dict(family="monospace"))
            )
            apply_plotly_theme(fig_smile)
            st.plotly_chart(fig_smile, use_container_width=True)

        with tab_opt_3d:
            matrix_z = surf_model["matrix_iv"].values
            strikes_x = surf_model["matrix_iv"].columns.values
            expiries_y = surf_model["matrix_iv"].index.values
            
            fig_surf3d = go.Figure(data=[go.Surface(
                z=matrix_z,
                x=strikes_x,
                y=expiries_y,
                colorscale="Viridis",
                colorbar=dict(
                    title=dict(text="IV (%)", font=dict(color="#ffffff", size=12)),
                    tickfont=dict(color="#cbd5e1", size=10),
                    len=0.75,
                    thickness=16
                ),
                hovertemplate="<b>Strike: $%{x:.1f}</b><br>Scadenza: %{y} Mesi<br>Volatilità Implicita: <b>%{z:.2f}%</b><extra></extra>"
            )])
            fig_surf3d.update_layout(
                height=480,
                margin=dict(l=10, r=10, t=20, b=20),
                paper_bgcolor="rgba(0,0,0,0)",
                scene=dict(
                    xaxis=dict(title="Strike ($)", gridcolor="rgba(255,255,255,0.08)", tickfont=dict(family="monospace")),
                    yaxis=dict(title="Scadenza (Mesi)", gridcolor="rgba(255,255,255,0.08)", tickfont=dict(family="monospace")),
                    zaxis=dict(title="IV (%)", gridcolor="rgba(255,255,255,0.08)", tickfont=dict(family="monospace")),
                    camera=dict(eye=dict(x=-1.65, y=-1.65, z=1.25))
                )
            )
            apply_plotly_theme(fig_surf3d)
            st.plotly_chart(fig_surf3d, use_container_width=True)

        st.markdown("##### 💵 Strategia Covered Call Yield Enhancer sui Titoli in Portafoglio")
        st.caption("Simula la vendita sistematica di opzioni Call Out-of-The-Money (+5% Strike) a 30 giorni per monetizzare la volatilità implicita ed estrarre rendimento addizionale (*Yield Enhancement*).")
        
        df_ret_hedging = results.get("returns", pd.DataFrame()) if results else pd.DataFrame()
        if (df_ret_hedging.empty or not isinstance(df_ret_hedging, pd.DataFrame) or df_ret_hedging.shape[1] < 2) and results:
            df_pr_h = results.get("df_prices", pd.DataFrame())
            if not df_pr_h.empty and "ticker" in df_pr_h.columns and "price_date" in df_pr_h.columns:
                piv_h = df_pr_h.pivot(index="price_date", columns="ticker", values="close")
                df_ret_hedging = piv_h.pct_change().dropna(how="all")

        vol_map_pos = (df_ret_hedging.std() * np.sqrt(252.0)).to_dict() if (isinstance(df_ret_hedging, pd.DataFrame) and not df_ret_hedging.empty) else {}
        pos_active_cc = pos[(pos["qty_net"] > 1e-6) & (pos["current_value"] > 0)] if (isinstance(pos, pd.DataFrame) and not pos.empty and "qty_net" in pos.columns and "current_value" in pos.columns) else pos
        df_cov_call = compute_covered_call_yield_enhancement(
            pos_active_cc,
            otm_pct=5.0,
            implied_vol=iv_in,
            use_skew_calibration=use_skew,
            vol_map=vol_map_pos
        ) if isinstance(pos_active_cc, pd.DataFrame) and not pos_active_cc.empty else pd.DataFrame()

        if not df_cov_call.empty:
            col_cc_f1, col_cc_f2, col_cc_f3 = st.columns([2.0, 1.3, 0.9], vertical_alignment="bottom")
            with col_cc_f1:
                search_cc = st.text_input("🔍 Cerca Ticker:", placeholder="Digita ticker per filtrare (es. BTC, GOOGL, AMZN)...", key="search_cov_call")
            with col_cc_f2:
                filter_cc_type = st.selectbox("🏷️ Filtro Lotti:", ["Tutti gli Asset", "🟢 Solo Lotti Standard (≥100 quote)", "⚪ Solo Frazionari (<100 quote)"], key="filter_cov_call_type")

            df_cov_filtered = df_cov_call.copy()
            if search_cc:
                df_cov_filtered = df_cov_filtered[df_cov_filtered["ticker"].astype(str).str.contains(search_cc.strip(), case=False, na=False)]
            if filter_cc_type == "🟢 Solo Lotti Standard (≥100 quote)":
                df_cov_filtered = df_cov_filtered[df_cov_filtered["contratti_eseguibili"] > 0]
            elif filter_cc_type == "⚪ Solo Frazionari (<100 quote)":
                df_cov_filtered = df_cov_filtered[df_cov_filtered["contratti_eseguibili"] == 0]

            if df_cov_filtered.empty:
                st.info("ℹ️ Nessuna posizione trovata corrispondente ai criteri di ricerca.")
            else:
                df_cov_show = pd.DataFrame({
                    "Ticker": df_cov_filtered["ticker"],
                    "Quote Posizione": df_cov_filtered["quantita_totale"],
                    "Prezzo Spot (€)": df_cov_filtered["prezzo_spot"],
                    "Strike Call (+5%)": df_cov_filtered["strike_call_otm"],
                    "IV Specifica (%)": df_cov_filtered["iv_effettiva_pct"],
                    "Premio / Azione (€)": df_cov_filtered["premio_per_azione"],
                    "Incasso Mensile (€)": df_cov_filtered["incasso_premio_totale"],
                    "Extra Yield Annuo (%)": df_cov_filtered["extra_rendimento_annuo_pct"],
                    "Lotti Opzioni": df_cov_filtered.apply(
                        lambda r: f"🟢 {int(r['contratti_eseguibili'])} Contratti ({int(r['contratti_eseguibili']*100)} quote)"
                        if r['contratti_eseguibili'] > 0
                        else f"⚪ Frazionario ({r['quantita_totale']:g}/100)",
                        axis=1
                    )
                })

                with col_cc_f3:
                    render_export_toolbar(
                        df_cov_show,
                        file_prefix="strategia_covered_call",
                        key_suffix="mq_cov_call",
                        table_title="Strategia Covered Call"
                    )

                cov_cfg = {
                    "Ticker": st.column_config.TextColumn("Ticker", width="small"),
                    "Quote Posizione": st.column_config.NumberColumn("Quote Posizione", format="%.2f"),
                    "Prezzo Spot (€)": st.column_config.NumberColumn("Prezzo Spot (€)", format="€ %.2f"),
                    "Strike Call (+5%)": st.column_config.NumberColumn("Strike OTM (+5%)", format="€ %.2f"),
                    "IV Specifica (%)": st.column_config.ProgressColumn("IV Specifica", format="%.1f%%", min_value=0.0, max_value=100.0),
                    "Premio / Azione (€)": st.column_config.NumberColumn("Premio / Azione", format="€ %.2f"),
                    "Incasso Mensile (€)": st.column_config.NumberColumn("Incasso Stimato", format="€ %.2f"),
                    "Extra Yield Annuo (%)": st.column_config.NumberColumn("Extra Yield Annuo", format="+%.2f%%"),
                    "Lotti Opzioni": st.column_config.TextColumn("Lotti Opzioni (x100)", width="medium")
                }

                st.dataframe(
                    df_cov_show,
                    column_config=cov_cfg,
                    use_container_width=True,
                    hide_index=True
                )

        st.divider()

        # ── MULTI-LEG OPTIONS STRATEGY WORKBENCH & PAYOFF ────────────
        st.markdown("##### 📈 Multi-Leg Options Strategy Workbench & Payoff Desk")
        st.caption("Costruttore interattivo di strategie su derivati multi-gamba (Iron Condor, Protective Collar, Spreads, Straddle) con analisi delle Greche aggregate e profilo di PnL a scadenza e anticipato.")

        from core.options_workbench import build_options_strategy_payoff, get_options_strategy_presets

        col_w1, col_w2, col_w3, col_w4 = st.columns(4)
        with col_w1:
            strat_choice = st.selectbox("Seleziona Struttura Opzioni:", get_options_strategy_presets(), index=1)
        with col_w2:
            spot_input = st.number_input("Prezzo Sottostante (€):", min_value=1.0, value=float(bm_spot_in), step=5.0)
        with col_w3:
            iv_opt_in = st.slider("Volatilità Implicita IV (%):", 5.0, 80.0, float(iv_in * 100.0), 1.0) / 100.0
        with col_w4:
            dte_input = st.slider("Giorni a Scadenza (DTE):", 7, 180, 45, 5)

        opt_bench_res = build_options_strategy_payoff(
            strategy_name=strat_choice,
            underlying_price=spot_input,
            strike_offset_pct=5.0,
            iv=iv_opt_in,
            days_to_exp=dte_input,
            contracts=1
        )
        grk = opt_bench_res["greeks"]

        ow1, ow2, ow3, ow4 = st.columns(4)
        with ow1:
            metric_card("Costo Netto / Incasso", f"€ {abs(opt_bench_res['net_debit_credit_eur']):,.2f}", delta="Net Credit 🟢" if opt_bench_res["is_credit_strategy"] else "Net Debit 🔴", delta_color="normal")
        with ow2:
            metric_card("Max Profit Atteso", f"€ {opt_bench_res['max_profit_eur']:,.2f}", delta="Guadagno Massimo", delta_color="normal")
        with ow3:
            metric_card("Max Loss Rischio", f"€ {opt_bench_res['max_loss_eur']:,.2f}", delta="Perdita Massima", delta_color="inverse")
        with ow4:
            metric_card("Greche di Portafoglio", f"Δ {grk['net_delta']:+.2f} | Γ {grk['net_gamma']:+.3f}", delta=f"Θ {grk['net_theta_per_day']:+.2f}€/g | V {grk['net_vega_per_pct']:+.2f}€/%", delta_color="normal")

        st.write("")

        col_pf_chart, col_pf_legs = st.columns([3, 2])
        with col_pf_chart:
            st.markdown("###### 📊 Profilo di Payoff (Scadenza vs Mid-Term)")
            df_pay = opt_bench_res["payoff_df"]
            fig_payoff = go.Figure()
            fig_payoff.add_trace(go.Scatter(
                x=df_pay["spot_price"],
                y=df_pay["pnl_expiry_eur"],
                mode="lines",
                name="PnL a Scadenza (T=0)",
                line=dict(color="#10b981", width=3)
            ))
            fig_payoff.add_trace(go.Scatter(
                x=df_pay["spot_price"],
                y=df_pay["pnl_mid_term_eur"],
                mode="lines",
                name=f"PnL Anticipato ({dte_input//2} gg)",
                line=dict(color="#6366f1", width=1.8, dash="dash")
            ))
            fig_payoff.add_hline(y=0.0, line_dash="dot", line_color="rgba(255,255,255,0.3)", line_width=1)
            fig_payoff.update_layout(
                xaxis_title="Prezzo Sottostante (€)",
                yaxis_title="Profit / Loss (€)",
                height=300,
                margin=dict(t=15, l=10, r=10, b=10),
                legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
            )
            apply_plotly_theme(fig_payoff)
            st.plotly_chart(fig_payoff, use_container_width=True, config={'displayModeBar': False})

        with col_pf_legs:
            st.markdown("###### 🧩 Gambe della Struttura")
            st.dataframe(
                pd.DataFrame(opt_bench_res["legs"]).rename(columns={
                    "leg_type": "Tipo",
                    "action": "Azione",
                    "strike_eur": "Strike (€)",
                    "premium_unit_eur": "Premio Unit (€)",
                    "delta": "Delta",
                    "gamma": "Gamma",
                    "theta": "Theta",
                    "vega": "Vega"
                }),
                use_container_width=True,
                hide_index=True
            )

# ── TAB 5: ATTRIBUZIONE BRINSON & FATTORI MULTI-FATTORIALI ────────
elif active_quant_tab == "🎯 Attribuzione & Fattori":
    st.markdown("#### 🎯 Attribuzione della Performance & Modelli Multi-Fattoriali (Brinson-Fachler)")
    render_institutional_info_box(
        title="Performance Attribution Brinson-Fachler & Regressione Multi-Fattoriale",
        badge="ALPHA ATTRIBUTION • BRINSON-FACHLER • MULTI-FACTOR",
        summary_html="Decomposizione formale dell'extra-rendimento di portafoglio rispetto al benchmark nei tre pilastri canonici di Brinson-Fachler: Allocation Effect (scelta settoriale), Selection Effect (scelta titoli) e Interaction Effect, integrata con modelli fattoriali empirici.",
        math_html="Modello di Brinson-Fachler:<br><code>Allocation = Σ_i (w_i^p - w_i^b) · (R_i^b - R_tot^b)</code><br><code>Selection = Σ_i w_i^b · (R_i^p - R_i^b)</code> | <code>Interaction = Σ_i (w_i^p - w_i^b) · (R_i^p - R_i^b)</code><br>Extra-rendimento totale: <code>R_p - R_b = Allocation + Selection + Interaction</code>.",
        chart_guide_html="• <b>Barre di Attribuzione per Settore:</b> identifica se l'Alpha deriva dall'overweight/underweight di specifici settori o dalla bravura nel selezionare i singoli titoli.<br>• <b>Tabelle di Dettaglio:</b> quantificano in punti base i contributi marginali di ogni singola posizione.",
        regulatory_html="• <b>GIPS (Global Investment Performance Standards):</b> conformità ai requisiti CFA Institute per il reporting oggettivo delle performance e la spiegazione delle fonti di valore aggiunto.<br>• <b>Governance del Fondo:</b> verifica dell'aderenza del gestore al mandato d'investimento e al benchmark dichiarato.",
        accent_color="#10b981",
    )

    if not has_portfolio or results is None:
        st.warning("⚠️ Carica prima un portafoglio nella Control Room per visualizzare l'attribuzione di performance e i fattori Barra.")
    else:
        from core.attribution import compute_brinson_attribution

        attr_res = compute_brinson_attribution(results)
        attr_summary = attr_res.get("summary", {})
        attr_df = attr_res.get("attribution_df", pd.DataFrame())
        if not attr_df.empty:
            st.markdown("**Scomposizione per Settore (Allocation vs Selection vs Interaction)**")
            fig_attr = px.bar(
                attr_df, x="sector", y=["allocation_effect_pct", "selection_effect_pct", "interaction_effect_pct"],
                barmode="group",
                color_discrete_sequence=["#58a6ff", "#3fb950", "#bc8cff"],
                labels={
                    "value": "Impatto %", "sector": "Settore GICS", "variable": "Fattore Attribuzione",
                    "allocation_effect_pct": "Allocation Effect",
                    "selection_effect_pct": "Selection Effect",
                    "interaction_effect_pct": "Interaction Effect"
                },
                template="plotly_dark", height=430
            )
            new_names = {
                "allocation_effect_pct": "Allocation Effect",
                "selection_effect_pct": "Selection Effect",
                "interaction_effect_pct": "Interaction Effect"
            }
            fig_attr.for_each_trace(lambda t: t.update(name=new_names.get(t.name, t.name)))
            fig_attr.update_traces(
                hovertemplate="<b>Settore: %{x}</b><br>%{fullData.name}: <b>%{y:.2f}%</b><extra></extra>"
            )
            fig_attr.update_layout(
                xaxis_title="Settore GICS",
                yaxis_title="Impatto su Extra-Rendimento %",
                margin=dict(t=50, b=40, l=55, r=25),
                legend=dict(
                    orientation="h",
                    yanchor="bottom",
                    y=1.02,
                    xanchor="left",
                    x=0.0,
                    bgcolor="rgba(22, 27, 34, 0.85)",
                    bordercolor="rgba(255, 255, 255, 0.12)",
                    borderwidth=1,
                    font=dict(size=11, color="#ffffff")
                ),
                paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)"
            )
            apply_plotly_theme(fig_attr)
            st.plotly_chart(fig_attr, use_container_width=True, config={"displayModeBar": "hover", "displaylogo": False})
        else:
            st.info("Dati di settore insufficienti per calcolare l'attribuzione Brinson-Fachler.")

        st.divider()

        from core.risk_engine import compute_black_litterman_optimization, compute_carhart_4factor_exposures

        sr_p = results.get("portfolio_return", pd.Series(dtype=float)) if results else pd.Series(dtype=float)

        # ── RIGA 1: OTTIMIZZAZIONE BLACK-LITTERMAN ────────────────
        st.markdown("#### 🏛️ Ottimizzazione Black-Litterman (Equilibrio Implicito & Pesi)")
        st.caption("Stima i rendimenti attesi di equilibrio inverso (Reverse Optimization) a partire dalla matrice di covarianza e dai pesi correnti di portafoglio.")

        cov_df = None
        if opt and "cov_matrix" in opt and isinstance(opt["cov_matrix"], pd.DataFrame) and not opt["cov_matrix"].empty:
            cov_df = opt["cov_matrix"]
        else:
            df_returns_all = results.get("returns", pd.DataFrame()) if results else pd.DataFrame()
            if isinstance(df_returns_all, pd.DataFrame) and not df_returns_all.empty:
                active_tickers = []
                if isinstance(pos, pd.DataFrame) and not pos.empty and "qty_net" in pos.columns and "ticker" in pos.columns:
                    active_tickers = pos[pos["qty_net"] > 0]["ticker"].tolist()
                common = [t for t in active_tickers if t in df_returns_all.columns]
                if len(common) >= 1:
                    cov_df = df_returns_all[common].cov() * 252

        if cov_df is not None and not cov_df.empty:
            mkt_w = None
            if isinstance(pos, pd.DataFrame) and not pos.empty and "weight_pct" in pos.columns and "ticker" in pos.columns:
                active_pos = pos[pos["qty_net"] > 1e-6] if "qty_net" in pos.columns else pos
                mkt_w = active_pos.set_index("ticker")["weight_pct"] / 100.0
            else:
                mkt_w = pd.Series(1.0 / len(cov_df), index=cov_df.index)
            
            # Opzionale: Input interattivo delle Views dell'Investitore
            custom_views = {}
            with st.expander("🎯 Personalizza Views dell'Investitore (Opzionale)", expanded=False):
                st.caption("Inserisci le tue aspettative soggettive di rendimento su specifici titoli per osservare come il modello Black-Litterman aggiorna i rendimenti attesi a posteriori e ricalibra i pesi ottimali.")
                col_v1, col_v2 = st.columns([2, 2])
                with col_v1:
                    view_asset = st.selectbox("Seleziona Titolo per la View:", options=list(cov_df.index), key="bl_view_asset")
                with col_v2:
                    view_return_pct = st.number_input(f"Rendimento Atteso Annuo per {view_asset} (%):", min_value=-50.0, max_value=150.0, value=15.0, step=1.0, key="bl_view_return")
                
                enable_view = st.checkbox("Applica questa View soggettiva al Modello", value=False, key="bl_enable_view")
                if enable_view and view_asset:
                    custom_views[view_asset] = view_return_pct / 100.0

            bl_res = compute_black_litterman_optimization(cov_df, mkt_w, views_dict=custom_views if custom_views else None)
            if bl_res:
                df_bl = pd.DataFrame({
                    "Ticker": cov_df.index,
                    "Equilibrium Return %": bl_res["implied_equilibrium_returns"].values * 100,
                    "BL Return %": bl_res["black_litterman_returns"].values * 100,
                    "BL Weight %": bl_res["black_litterman_weights"].values * 100
                })
                # ── RIGA 1: GRAFICI INTERATTIVI AD ALTA DENSITÀ (TREEMAP & BARRE RAGGRUPPATE) ──
                tab_bl_tm, tab_bl_bar = st.tabs([
                    "🗺️ Mappa di Allocazione Ottimale (Treemap)",
                    "📊 Confronto Pesi (Peso Attuale vs Target Black-Litterman)"
                ])

                with tab_bl_tm:
                    fig_bl_tm = px.treemap(
                        df_bl,
                        path=[px.Constant("Allocazione Black-Litterman"), "Ticker"],
                        values="BL Weight %",
                        color="BL Return %",
                        custom_data=["BL Return %"],
                        color_continuous_scale=[[0.0, "#0f172a"], [0.5, "#1e3a8a"], [1.0, "#38bdf8"]],
                        labels={"BL Weight %": "Peso Target %", "BL Return %": "Rendimento BL %"}
                    )
                    fig_bl_tm.update_traces(
                        textinfo="label+value",
                        texttemplate="<b>%{label}</b><br>%{value:.2f}%<br><span style='font-size:10.5px;'>Ret: %{customdata[0]:.2f}%</span>",
                        hovertemplate="<b>Asset: %{label}</b><br>🎯 Peso Target BL: <b>%{value:.2f}%</b><br>📈 Rendimento Atteso: <b>%{customdata[0]:.2f}%</b><extra></extra>"
                    )
                    fig_bl_tm.update_layout(
                        height=310,
                        margin=dict(t=25, b=15, l=10, r=10),
                        paper_bgcolor="rgba(0,0,0,0)",
                        plot_bgcolor="rgba(0,0,0,0)"
                    )
                    apply_plotly_theme(fig_bl_tm)
                    st.plotly_chart(fig_bl_tm, use_container_width=True)

                with tab_bl_bar:
                    cur_w_map = (mkt_w * 100.0).to_dict() if isinstance(mkt_w, pd.Series) else {}
                    df_bl_comp = df_bl.copy()
                    df_bl_comp["Peso Attuale %"] = df_bl_comp["Ticker"].map(cur_w_map).fillna(0.0)

                    fig_bl_bar = go.Figure()
                    fig_bl_bar.add_trace(go.Bar(
                        x=df_bl_comp["Ticker"],
                        y=df_bl_comp["Peso Attuale %"],
                        name="⭐ Peso Attuale",
                        marker=dict(color="#58a6ff", line=dict(color="rgba(255,255,255,0.1)", width=1)),
                        hovertemplate="<b>%{x}</b><br>Peso Attuale: <b>%{y:.2f}%</b><extra></extra>"
                    ))
                    fig_bl_bar.add_trace(go.Bar(
                        x=df_bl_comp["Ticker"],
                        y=df_bl_comp["BL Weight %"],
                        name="🎯 Target Black-Litterman",
                        marker=dict(color="#ff9900", line=dict(color="rgba(255,153,0,0.4)", width=1)),
                        hovertemplate="<b>%{x}</b><br>Target BL: <b>%{y:.2f}%</b><extra></extra>"
                    ))
                    fig_bl_bar.update_layout(
                        height=310,
                        barmode="group",
                        margin=dict(t=20, b=35, l=40, r=15),
                        paper_bgcolor="rgba(0,0,0,0)",
                        plot_bgcolor="rgba(0,0,0,0)",
                        xaxis=dict(tickangle=-45, tickfont=dict(size=10.5, family="monospace")),
                        yaxis=dict(title="Allocazione %", ticksuffix="%", showgrid=True, gridcolor="rgba(255,255,255,0.06)"),
                        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="center", x=0.5, font=dict(size=11))
                    )
                    apply_plotly_theme(fig_bl_bar)
                    st.plotly_chart(fig_bl_bar, use_container_width=True)

                # ── RIGA 2: TABELLA INTERATTIVA AD ALTEZZA COMPATTA CON FILTRI ───────
                search_bl = st.text_input("🔍 Cerca Ticker nella Tabella Black-Litterman:", placeholder="Filtra per Ticker (es. GOOGL, BTC, ETH)...", key="search_bl_ticker")
                df_bl_filt = df_bl.copy()
                if search_bl:
                    df_bl_filt = df_bl_filt[df_bl_filt["Ticker"].astype(str).str.contains(search_bl.strip(), case=False, na=False)]

                bl_cfg = {
                    "Ticker": st.column_config.TextColumn("Ticker", width="small"),
                    "Equilibrium Return %": st.column_config.NumberColumn("Equilibrium Return", format="%.2f%%"),
                    "BL Return %": st.column_config.NumberColumn("BL Return", format="%.2f%%"),
                    "BL Weight %": st.column_config.ProgressColumn("BL Target Weight", format="%.2f%%", min_value=0.0, max_value=100.0)
                }
                render_table_with_export(
                    df=df_bl_filt,
                    table_title="Pesi Black-Litterman",
                    file_prefix="black_litterman_weights",
                    key_suffix="mq_bl_weights",
                    column_config=bl_cfg,
                    hide_index=True,
                    height=280
                )
            else:
                st.info("Dati di covarianza insufficienti per Black-Litterman.")
        else:
            st.info("Matrice di covarianza non disponibile. Assicurati di aver calcolato i rendimenti per le posizioni attive.")

        st.divider()

        # ── RIGA 2: ANALISI FATTORIALE KENNETH FRENCH & CARHART ────
        col_c_head1, col_c_head2 = st.columns([3.5, 1.2])
        with col_c_head1:
            st.markdown("#### 🧠 Analisi Fattoriale Kenneth French (Fama-French 5-Factor & Momentum)")
            st.caption("Regressione econometrica multivariata OLS su serie storiche ufficiali di Dartmouth: isolamento dell'Alpha puro di gestione, attribuzione del rendimento e significatività statistica (t-stat & p-value).")
        with col_c_head2:
            st.markdown('<div style="margin-top: 6px;"></div>', unsafe_allow_html=True)
            render_fama_french_modal(button_label="ℹ️ Teoria Fama-French & Formule", use_popover=False)

        from core.factor_library import compute_fama_french_factor_model

        st.markdown('<div style="margin-top: 10px;"></div>', unsafe_allow_html=True)
        ff_model_sel = render_segmented_tabs([
            "🏛️ Fama-French 5-Factor + Momentum",
            "📊 Carhart 4-Factor (Mkt, SMB, HML, MOM)",
            "📐 Fama-French 3-Factor (Mkt, SMB, HML)"
        ], key="ff_model_selector_tab")

        if "5-Factor" in ff_model_sel:
            m_code = "5_factor_mom"
        elif "Carhart" in ff_model_sel:
            m_code = "4_factor"
        else:
            m_code = "3_factor"

        ff_res = compute_fama_french_factor_model(sr_p, model_type=m_code)
        df_ff_factors = ff_res.get("df_factors", pd.DataFrame())

        # KPI Cards Dinamiche e Bilanciate
        alpha_ann = ff_res.get("alpha_annualized", 0.0)
        alpha_t = ff_res.get("alpha_t_stat", 0.0)
        r2_val = ff_res.get("r_squared", 0.0)
        adj_r2 = ff_res.get("adj_r_squared", 0.0)

        # Mappatura rapida dei beta
        betas_by_name = {}
        if not df_ff_factors.empty:
            for _, r in df_ff_factors.iterrows():
                betas_by_name[r["factor"]] = r["beta"]

        b_mkt = betas_by_name.get("Mkt-RF", 1.0)
        b_smb = betas_by_name.get("SMB", 0.0)
        b_hml = betas_by_name.get("HML", 0.0)
        b_rmw = betas_by_name.get("RMW")
        b_cma = betas_by_name.get("CMA")
        b_mom = betas_by_name.get("MOM")

        # Riga 1: Alpha, Mercato, Size, Value
        col_kpi1, col_kpi2, col_kpi3, col_kpi4 = st.columns(4)
        with col_kpi1:
            metric_card(
                "Alpha Puro (α)",
                f"{alpha_ann*100:+.2f}%",
                f"t = {alpha_t:+.2f} ({'Significativo' if abs(alpha_t)>=1.96 else 'Non Sig.'})",
                alpha_ann >= 0
            )
        with col_kpi2:
            metric_card(
                "Beta Mkt-RF",
                f"{b_mkt:+.2f}",
                "Esposizione Sistemica",
                b_mkt >= 0
            )
        with col_kpi3:
            metric_card(
                "Beta Size (SMB)",
                f"{b_smb:+.2f}",
                "Small Cap Tilt" if b_smb > 0 else "Large Cap Tilt",
                b_smb >= 0
            )
        with col_kpi4:
            metric_card(
                "Beta Value (HML)",
                f"{b_hml:+.2f}",
                "Value Tilt" if b_hml > 0 else "Growth Tilt",
                b_hml >= 0
            )

        # Riga 2: Fattori Aggiuntivi & Bontà del Modello
        if b_rmw is not None and b_cma is not None:
            st.markdown('<div style="margin-top: 10px;"></div>', unsafe_allow_html=True)
            col_kpi5, col_kpi6, col_kpi7, col_kpi8 = st.columns(4)
            with col_kpi5:
                metric_card(
                    "Beta Profit (RMW)",
                    f"{b_rmw:+.2f}",
                    "Alta Redditività" if b_rmw > 0 else "Margini Deboli",
                    b_rmw >= 0
                )
            with col_kpi6:
                metric_card(
                    "Beta Inv (CMA)",
                    f"{b_cma:+.2f}",
                    "Capex Conservativo" if b_cma > 0 else "Capex Aggressivo",
                    b_cma >= 0
                )
            with col_kpi7:
                b_m_val = b_mom if b_mom is not None else 0.0
                metric_card(
                    "Beta Momentum (MOM)",
                    f"{b_m_val:+.2f}",
                    "Trend Winner" if b_m_val > 0 else "Trend Loser",
                    b_m_val >= 0
                )
            with col_kpi8:
                metric_card(
                    "Bontà Modello (R²)",
                    f"{r2_val*100:.1f}%",
                    f"Adj R²: {adj_r2*100:.1f}%",
                    True
                )
        elif b_mom is not None:
            st.markdown('<div style="margin-top: 10px;"></div>', unsafe_allow_html=True)
            col_kpi5, col_kpi6 = st.columns(2)
            with col_kpi5:
                metric_card(
                    "Beta Momentum (MOM)",
                    f"{b_mom:+.2f}",
                    "Trend Winner (12M)" if b_mom > 0 else "Trend Loser (12M)",
                    b_mom >= 0
                )
            with col_kpi6:
                metric_card(
                    "Bontà Modello (R²)",
                    f"{r2_val*100:.1f}%",
                    f"Adj R²: {adj_r2*100:.1f}%",
                    True
                )
        else:
            st.markdown('<div style="margin-top: 10px;"></div>', unsafe_allow_html=True)
            col_kpi5, _ = st.columns([1, 3])
            with col_kpi5:
                metric_card(
                    "Bontà Modello (R²)",
                    f"{r2_val*100:.1f}%",
                    f"Adj R²: {adj_r2*100:.1f}%",
                    True
                )

        # Grafici e Attribuzione
        st.markdown("<div style='margin-top: 15px;'></div>", unsafe_allow_html=True)
        col_ff_g1, col_ff_g2 = st.columns([1.6, 1.1])

        with col_ff_g1:
            st.markdown("##### 🌊 Factor Return Attribution (% Rendimento Annuo Spiegato)")
            attrib = ff_res.get("factor_attribution", {})
            if attrib:
                df_attr = pd.DataFrame([
                    {"Fattore": k, "Contributo %": v * 100.0} for k, v in attrib.items()
                ])
                colors_attr = ["#3fb950" if val >= 0 else "#f85149" for val in df_attr["Contributo %"]]

                fig_attr = go.Figure(go.Bar(
                    x=df_attr["Fattore"],
                    y=df_attr["Contributo %"],
                    marker_color=colors_attr,
                    text=df_attr["Contributo %"].apply(lambda x: f"{x:+.2f}%"),
                    textposition="outside",
                    hovertemplate="<b>%{x}</b><br>Contributo al Rendimento: <b>%{text}</b><extra></extra>"
                ))
                fig_attr.update_layout(
                    template="plotly_dark",
                    height=290,
                    margin=dict(l=10, r=10, t=20, b=20),
                    paper_bgcolor="rgba(0,0,0,0)",
                    plot_bgcolor="rgba(0,0,0,0)",
                    yaxis=dict(title="Contributo Annuo %", showgrid=True, gridcolor="rgba(255,255,255,0.06)"),
                    xaxis=dict(title="")
                )
                apply_plotly_theme(fig_attr)
                st.plotly_chart(fig_attr, use_container_width=True, config={"displayModeBar": "hover", "displaylogo": False})

        with col_ff_g2:
            st.markdown("##### 🍩 Decomposizione Varianza del Rischio")
            sys_ff_pct = ff_res.get("systematic_risk_pct", 85.0)
            spec_ff_pct = ff_res.get("specific_risk_pct", 15.0)

            fig_pie_ff = go.Figure(data=[go.Pie(
                labels=["Rischio Sistemico (Fattori)", "Rischio Specifico (Alpha/Idiosincratico)"],
                values=[sys_ff_pct, spec_ff_pct],
                hole=0.6,
                marker=dict(colors=["#58a6ff", "#f59e0b"], line=dict(color="#0d1117", width=2)),
                hovertemplate="<b>%{label}</b><br>Quota Varianza: <b>%{percent}</b><extra></extra>"
            )])
            fig_pie_ff.update_layout(
                template="plotly_dark",
                height=230,
                margin=dict(l=10, r=10, t=10, b=10),
                paper_bgcolor="rgba(0,0,0,0)",
                plot_bgcolor="rgba(0,0,0,0)",
                showlegend=True,
                legend=dict(orientation="h", y=-0.1)
            )
            apply_plotly_theme(fig_pie_ff)
            st.plotly_chart(fig_pie_ff, use_container_width=True, config={"displayModeBar": "hover", "displaylogo": False})
            st.caption(f"Bontà di Adattamento OLS: **R² = {r2_val*100:.1f}%** | **Adj R² = {ff_res.get('adj_r_squared', 0.0)*100:.1f}%**")

        # Tabella Econometrica dei Parametri
        if not df_ff_factors.empty:
            df_ff_show = df_ff_factors.rename(columns={
                "factor": "Fattore di Rischio",
                "beta": "Coefficiente Beta (β)",
                "std_err": "Errore Standard",
                "t_stat": "Statistica t",
                "p_value": "p-value",
                "ci_95": "Intervallo Confidenza 95%",
                "is_significant": "Significatività (95%)",
                "annual_return_contrib_pct": "Contributo Rendimento Annuo (%)"
            })
            df_ff_show["Significatività (95%)"] = df_ff_show["Significatività (95%)"].apply(
                lambda x: "🟢 Significativo (|t| ≥ 1.96)" if x else "⚪ Non Significativo"
            )
            ff_cfg = {
                "Fattore di Rischio": st.column_config.TextColumn("Fattore di Rischio", width="medium"),
                "Coefficiente Beta (β)": st.column_config.NumberColumn("Beta (β)", format="%+.4f"),
                "Errore Standard": st.column_config.NumberColumn("Std Error", format="%.4f"),
                "Statistica t": st.column_config.NumberColumn("Statistica t", format="%+.2f"),
                "p-value": st.column_config.NumberColumn("p-value", format="%.4f"),
                "Intervallo Confidenza 95%": st.column_config.TextColumn("CI 95%", width="medium"),
                "Significatività (95%)": st.column_config.TextColumn("Significatività (95%)", width="medium"),
                "Contributo Rendimento Annuo (%)": st.column_config.NumberColumn("Contributo Rend. Annuo", format="%+.2f%%")
            }
            render_table_with_export(
                df=df_ff_show,
                table_title="Tabella Econometrica di Regressione OLS & Test di Ipotesi",
                file_prefix="fama_french_factor_regression",
                key_suffix="mq_fama_french",
                column_config=ff_cfg,
                hide_index=True
            )

        # Grafico Rolling Factor Exposures (se presente)
        df_roll_b = ff_res.get("rolling_betas", pd.DataFrame())
        if not df_roll_b.empty:
            st.markdown("##### 📈 Evoluzione Dinamica delle Esposizioni Fattoriali (Rolling OLS 60 Giorni)")
            st.caption("Traccia nel tempo come cambiano i Beta di rischio sistemico e di stile del portafoglio (evidenziando cambi di regime o drift stilistici).")
            
            all_factors = [c for c in df_roll_b.columns if c != "Alpha (Ann)"]
            col_rf1, col_rf2 = st.columns([3.2, 1.0], vertical_alignment="bottom")
            with col_rf1:
                selected_factors = st.multiselect(
                    "🔍 Filtra Fattori da visualizzare nel Grafico:",
                    options=all_factors,
                    default=all_factors,
                    key="rolling_factors_filter"
                )
            with col_rf2:
                render_export_toolbar(
                    df_roll_b.reset_index() if isinstance(df_roll_b.index, pd.DatetimeIndex) else df_roll_b,
                    file_prefix="rolling_factor_betas_60d",
                    key_suffix="mq_roll_betas",
                    table_title="Rolling Factor Betas 60D"
                )

            factors_to_show = selected_factors if selected_factors else all_factors

            color_map = {
                "Mkt-RF": "#58a6ff",
                "SMB": "#f59e0b",
                "HML": "#3fb950",
                "RMW": "#bc8cff",
                "CMA": "#f43f5e",
                "MOM": "#00f3ff"
            }

            df_plot_r = df_roll_b.reset_index()
            fig_roll = go.Figure()

            # Linea neutra y=0
            fig_roll.add_hline(
                y=0.0,
                line_dash="dash",
                line_color="rgba(255, 255, 255, 0.25)",
                line_width=1.2,
                annotation_text="Neutrale (β = 0.0)",
                annotation_position="bottom right",
                annotation_font=dict(size=10, color="#8b949e")
            )

            for f_name in factors_to_show:
                if f_name in df_plot_r.columns:
                    fig_roll.add_trace(go.Scatter(
                        x=df_plot_r["Date"],
                        y=df_plot_r[f_name],
                        mode="lines",
                        name=f_name,
                        line=dict(color=color_map.get(f_name, "#58a6ff"), width=2),
                        hovertemplate=f"<b>{f_name}</b>: %{{y:+.3f}}<extra></extra>"
                    ))

            fig_roll.update_layout(
                template="plotly_dark",
                height=350,
                hovermode="x unified",
                margin=dict(l=10, r=15, t=25, b=20),
                paper_bgcolor="rgba(0,0,0,0)",
                plot_bgcolor="rgba(0,0,0,0)",
                xaxis=dict(
                    title=None,
                    showgrid=True,
                    gridcolor="rgba(255,255,255,0.06)",
                    rangeselector=dict(
                        buttons=[
                            dict(count=6, label="6M", step="month", stepmode="backward"),
                            dict(count=1, label="1A", step="year", stepmode="backward"),
                            dict(count=3, label="3A", step="year", stepmode="backward"),
                            dict(step="all", label="Tutto")
                        ],
                        bgcolor="rgba(22, 27, 34, 0.9)",
                        font=dict(color="#ffffff", size=10.5),
                        activecolor="#ff9900"
                    )
                ),
                yaxis=dict(
                    title="Beta Rolling (60G)",
                    showgrid=True,
                    gridcolor="rgba(255,255,255,0.06)",
                    tickformat="+.2f"
                ),
                legend=dict(
                    orientation="h",
                    yanchor="bottom",
                    y=1.04,
                    xanchor="center",
                    x=0.5,
                    font=dict(size=11, family="monospace")
                )
            )
            apply_plotly_theme(fig_roll)
            st.plotly_chart(fig_roll, use_container_width=True, config={"displayModeBar": "hover", "displaylogo": False})

        st.divider()
        col_head_bar1, col_head_bar2 = st.columns([3.2, 1.1])
        with col_head_bar1:
            st.markdown("#### 🏛️ Modello Macro-Fattoriale MSCI Barra (5 Fattori Ortogonalizzati)")
            st.caption("Decomposizione avanzata ed ortogonale delle esposizioni fattoriali del portafoglio (Market, Size SMB, Value HML, Momentum WML, Term Premium).")
        with col_head_bar2:
            st.markdown('<div style="margin-top: 6px;"></div>', unsafe_allow_html=True)
            glossary_modal("ℹ️ Guida al Modello Fattoriale MSCI Barra & Forecast ML", """
<div style="font-size: 13.5px; line-height: 1.45;">

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px; margin-bottom: 8px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">📌 Cos'è il Modello Macro-Fattoriale MSCI Barra</div>
  <div>Lo standard quantitativo dell'industria per l'attribuzione del rischio istituzionale, che scompone la varianza totale del portafoglio in 5 macro-fattori ortogonalizzati e rischio specifico.</div>
</div>

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px; margin-bottom: 8px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">📐 I 5 Macro-Fattori Ortogonali</div>
  <div style="background: rgba(255,153,0,0.08); border-left: 3px solid #ff9900; padding: 6px 10px; border-radius: 6px; margin: 5px 0; color: #ffb74d; font-size: 12px; line-height: 1.45;">
    • <b>MKT (Equity Systematic):</b> Esposizione al mercato azionario globale<br>
    • <b>SMB (Small Minus Big):</b> Sensibilità al fattore dimensione d'impresa<br>
    • <b>HML (High Minus Low):</b> Esposizione a titoli Value vs Growth<br>
    • <b>WML (Winners Minus Losers):</b> Inerzia di Momentum a 12 mesi<br>
    • <b>TERM (Term Premium):</b> Sensibilità all'inclinazione della curva dei tassi sovrani
  </div>
</div>

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px; margin-bottom: 8px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">🎯 A cosa serve</div>
  <div>Separare la componente di rischio sistemico (spiegata dai fattori) dal rischio specifico non diversificato, stimando la vera abilità gestionale (&alpha; puro).</div>
</div>

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px; margin-bottom: 8px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">⚙️ Calcolo in ARGUS & Forecast ML</div>
  <div>ARGUS esegue la regressione ortogonale con calcolo delle t-stat al 95% e combina un modello Random Forest per prevedere la volatilità attesa sui successivi 30 giorni.</div>
</div>

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">🔍 Come leggerlo</div>
  <div>I fattori con <code>|t-stat| &ge; 1.96</code> sono statisticamente significativi; una quota di Rischio Specifico &gt; 40% indica una marcata esposizione a eventi societari idiosincratici.</div>
</div>

</div>
""", button_label="💡 Come funziona il Modello MSCI Barra?")

        from core.risk_engine import compute_msci_barra_multifactor_model
        barra_res = compute_msci_barra_multifactor_model(sr_p)

        betas_dict = barra_res.get("factor_betas", {})
        t_dict = barra_res.get("t_stats", {})

        factor_names_map = {
            "MKT": "Mercato (Equity Systematic)",
            "SMB": "Dimensione (Small Caps)",
            "HML": "Valore (High Book-to-Market)",
            "WML": "Inerzia (12M Momentum)",
            "TERM": "Macro Curva Tassi (Term Premium)"
        }

        df_barra = pd.DataFrame({
            "Fattore": list(betas_dict.keys()),
            "Nome Esteso": [factor_names_map.get(k, k) for k in betas_dict.keys()],
            "Beta Fattoriale": [betas_dict[k] for k in betas_dict.keys()],
            "Statistica t": [t_dict.get(k, 0.0) for k in betas_dict.keys()],
            "Significatività (95%)": ["🟢 Significativo" if abs(t_dict.get(k, 0.0)) >= 1.96 else "⚪ In Linea" for k in betas_dict.keys()]
        })

        col_bar1, col_bar2 = st.columns([1.5, 1])

        with col_bar1:
            colors = ["#3fb950" if b >= 0 else "#f85149" for b in df_barra["Beta Fattoriale"]]

            fig_barra = go.Figure(go.Bar(
                x=df_barra["Fattore"],
                y=df_barra["Beta Fattoriale"],
                marker_color=colors,
                text=df_barra["Beta Fattoriale"].apply(lambda b: f"{b:+.2f}"),
                textposition="outside",
                textfont=dict(size=12, color="white"),
                hovertemplate="<b>Fattore: %{x}</b><br>Beta Fattoriale: <b>%{text}</b><extra></extra>"
            ))

            fig_barra.update_layout(
                template="plotly_dark",
                height=350,
                margin=dict(l=10, r=10, t=20, b=30),
                paper_bgcolor="rgba(0,0,0,0)",
                plot_bgcolor="rgba(0,0,0,0)",
                yaxis=dict(title="Esposizione (Beta)", showgrid=True, gridcolor="rgba(255,255,255,0.06)"),
                xaxis=dict(title="Fattori Stile & Macro")
            )
            apply_plotly_theme(fig_barra)
            st.plotly_chart(fig_barra, use_container_width=True, config={"displayModeBar": "hover", "displaylogo": False})

        with col_bar2:
            st.markdown("##### 🍩 Decomposizione Varianza Rischio")
            sys_pct = barra_res.get("systematic_risk_pct", 88.0)
            spec_pct = barra_res.get("specific_risk_pct", 12.0)

            fig_pie = go.Figure(data=[go.Pie(
                labels=["Rischio Sistemico (Fattori)", "Rischio Specifico (Residuo)"],
                values=[sys_pct, spec_pct],
                hole=0.6,
                marker=dict(colors=["#58a6ff", "#bc8cff"], line=dict(color="#0d1117", width=2)),
                hovertemplate="<b>%{label}</b><br>Quota Varianza: <b>%{percent}</b><extra></extra>"
            )])
            fig_pie.update_layout(
                template="plotly_dark",
                height=260,
                margin=dict(l=10, r=10, t=10, b=10),
                paper_bgcolor="rgba(0,0,0,0)",
                plot_bgcolor="rgba(0,0,0,0)",
                showlegend=True,
                legend=dict(orientation="h", y=-0.1)
            )
            apply_plotly_theme(fig_pie)
            st.plotly_chart(fig_pie, use_container_width=True, config={"displayModeBar": "hover", "displaylogo": False})
            metric_card("Alpha Multi-Fattoriale (α)", f"{barra_res.get('alpha_annualized', 0.0)*100:+.2f}%", "MSCI Barra 5-Factor", True)

        st.markdown("<div style='margin-top: 15px;'></div>", unsafe_allow_html=True)
        barra_cfg = {
            "Fattore Barra": st.column_config.TextColumn("Fattore Barra", width="medium"),
            "Beta Fattoriale": st.column_config.NumberColumn("Beta Fattoriale", format="%+.3f"),
            "Statistica t": st.column_config.NumberColumn("Statistica t", format="%+.2f"),
            "Significatività (95%)": st.column_config.TextColumn("Significatività (95%)", width="medium")
        }
        render_table_with_export(
            df=df_barra,
            table_title="Tabella di Dettaglio dei Fattori MSCI Barra",
            file_prefix="msci_barra_factors",
            key_suffix="mq_msci_barra",
            column_config=barra_cfg,
            hide_index=True
        )

        st.divider()
        st.markdown("##### 🤖 Forecast Volatilità a 30 Giorni (Machine Learning Ensemble)")
        from core.financial_analysis import predict_ml_distress_and_volatility
        df_p_ml = st.session_state.get("df_prices")
        ml_res = predict_ml_distress_and_volatility(df_prices=df_p_ml)

        col_ml1, col_ml2 = st.columns([1, 2.5])
        with col_ml1:
            metric_card("Volatilità Predetta 30G", f"{ml_res['predicted_volatility_30d_pct']:.2f}%", "Random Forest Regressor", True)
        with col_ml2:
            st.markdown(f"**Verdetto ML:** {ml_res['verdict']}")
            st.caption("Stima avanzata della volatilità annualizzata a 30 giorni basata su Random Forest Regressor e indicatori tecnici di mercato.")

        # ── SEZIONE FACTOR QUINTILES BACKTESTING ────────────────────────
        st.divider()
        col_fq_h1, col_fq_h2 = st.columns([3.2, 1.1])
        with col_fq_h1:
            st.markdown("#### 🔬 Backtesting di Strategie Multi-Fattoriali (Analisi a 5 Quintili)")
            st.caption("Simulatore di ordinamento periodico su fattori istituzionali (QMJ, Low-Beta BAB, Gross Profitability, Momentum, Deep Value) con scomposizione in 5 quantili e calcolo dello Spread Long-Short (Q1 - Q5).")
        with col_fq_h2:
            st.markdown('<div style="margin-top: 6px;"></div>', unsafe_allow_html=True)
            glossary_modal("ℹ️ Guida al Backtesting Fattoriale a Quintili", """
<div style="font-size: 13.5px; line-height: 1.45;">

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px; margin-bottom: 8px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">📌 Metodologia a Quintili di Fama-French & AQR</div>
  <div>A ogni intervallo di ribilanciamento (mensile o trimestrale), tutti i titoli dell'universo vengono ordinati in base al punteggio del fattore prescelto e divisi in 5 panieri equi-ponderati:
  <ul style="margin: 4px 0 0 16px; padding: 0;">
    <li><b>Q1 (Top 20%):</b> Massima esposizione al fattore positivo (es. Alta Qualità, Basso Beta, Alto Momentum).</li>
    <li><b>Q2, Q3, Q4:</b> Quintili intermedi di transizione.</li>
    <li><b>Q5 (Bottom 20%):</b> Titoli speculativi o ad esposizione avversa (Junk, High Beta, Neglect).</li>
  </ul>
  </div>
</div>

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px; margin-bottom: 8px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">📐 Spread Long-Short & Test di Monotonicità</div>
  <div style="background: #0d1117; border: 1px solid #30363d; border-radius: 6px; padding: 8px 12px; margin: 6px 0; font-family: monospace; color: #e6edf3;">
    <b>Spread Long-Short:</b> R<sub>L/S</sub> = R<sub>Q1</sub> - R<sub>Q5</sub><br>
    <b>Monotonicità di Spearman:</b> Correlazione di rango tra Quintile (1..5) e Rendimento Annuo (Ideale = +1.0).
  </div>
</div>

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">🔍 Interpretazione Istituzionale</div>
  <div>Un fattore è statisticamente robusto e sfruttabile quando genera uno <b>Spread Long-Short positivo e persistente</b> e una curva di rendimento <b>strettamente decrescente</b> da Q1 a Q5 (nessun incrocio di stile).</div>
</div>

</div>
""", button_label="💡 Come funziona il Backtest a Quintili")

        from core.factor_library import FACTOR_PRESET_DEFINITIONS, run_factor_quintile_backtest
        
        col_fq_c1, col_fq_c2, col_fq_c3 = st.columns([2.0, 1.2, 1.2])
        with col_fq_c1:
            fact_choice = st.selectbox(
                "Seleziona Strategia Fattoriale da Testare:",
                list(FACTOR_PRESET_DEFINITIONS.keys()),
                format_func=lambda k: FACTOR_PRESET_DEFINITIONS[k]["name"],
                index=0,
                key="sel_factor_quintile_strategy"
            )
        with col_fq_c2:
            rebal_choice = st.radio("Frequenza Ribilanciamento:", ["Mensile (M)", "Trimestrale (Q)"], horizontal=True, key="sel_fq_rebal")
            rebal_code = "Q" if "Trimestrale" in rebal_choice else "M"
        with col_fq_c3:
            lb_choice = st.slider("Lookback Calcolo Score (Giorni):", min_value=30, max_value=252, value=126, step=21, key="sel_fq_lookback")

        st.caption(f"ℹ️ **Razionale Accademico:** {FACTOR_PRESET_DEFINITIONS[fact_choice]['rationale']}")

        # Esecuzione del Backtest a Quintili
        df_rets_port = results.get("returns", pd.DataFrame()) if results else pd.DataFrame()
        if not isinstance(df_rets_port, pd.DataFrame) or df_rets_port.empty:
            df_pr = results.get("df_prices", pd.DataFrame()) if results else pd.DataFrame()
            if isinstance(df_pr, pd.DataFrame) and not df_pr.empty and "price_date" in df_pr.columns:
                df_rets_port = df_pr.pivot(index="price_date", columns="ticker", values="close").pct_change().dropna(how="all")

        fq_res = run_factor_quintile_backtest(
            df_returns=df_rets_port,
            factor_type=fact_choice,
            rebalance_freq=rebal_code,
            lookback_window=lb_choice
        )

        if fq_res.get("valid", False):
            # KPI Cards
            col_k1, col_k2, col_k3, col_k4 = st.columns(4)
            with col_k1:
                metric_card("Spread Long-Short (Q1 - Q5)", f"{fq_res['spread_cagr']:+.2f}%", "Extra-rendimento annuo fattore", fq_res['spread_cagr'] > 0)
            with col_k2:
                q1_row = fq_res["metrics_df"][fq_res["metrics_df"]["Quintile"].str.contains("Q1")]
                q1_sharpe = q1_row["Sharpe Ratio"].iloc[0] if not q1_row.empty else 0.0
                metric_card("Sharpe Ratio Q1 (Top 20%)", f"{q1_sharpe:.2f}", "Efficienza paniere alta qualità", q1_sharpe >= 0.7)
            with col_k3:
                q1_ir = q1_row["Information Ratio vs Univ"].iloc[0] if not q1_row.empty else 0.0
                metric_card("Information Ratio Q1 vs Univ", f"{q1_ir:.2f}", "Consistenza rispetto al benchmark", q1_ir >= 0.5)
            with col_k4:
                metric_card("Monotonicità di Spearman", f"{fq_res['monotonicity_score']:+.2f}", fq_res["monotonicity_verdict"].split("(")[0].strip(), fq_res["monotonicity_score"] >= 0.4)

            # Grafico Curve Cumulative dei 5 Quintili + Spread Long-Short
            col_g1, col_g2 = st.columns([2.2, 1.1])
            with col_g1:
                st.markdown("##### 📈 Curve di Crescita Patrimoniale dei 5 Quintili (Base 100)")
                df_cum_q = fq_res["cumulative_df"].reset_index()
                date_col_name = df_cum_q.columns[0]
                
                fig_fq = go.Figure()
                q_colors = {
                    "Q1": "#3fb950",
                    "Q2": "#58a6ff",
                    "Q3": "#d2a8ff",
                    "Q4": "#f59e0b",
                    "Q5": "#f85149",
                    "Long_Short_Spread": "#ff9900",
                    "Equal_Weight_Univ": "#8b949e"
                }
                q_labels = {
                    "Q1": "Q1 (Top 20% · High Factor)",
                    "Q2": "Q2 (Quintile 2)",
                    "Q3": "Q3 (Mediano)",
                    "Q4": "Q4 (Quintile 4)",
                    "Q5": "Q5 (Bottom 20% · Junk)",
                    "Long_Short_Spread": "⚡ Spread Long-Short (Q1 - Q5)",
                    "Equal_Weight_Univ": "🌐 Universo Equi-Ponderato"
                }

                for col_k in ["Q1", "Q2", "Q3", "Q4", "Q5", "Equal_Weight_Univ", "Long_Short_Spread"]:
                    if col_k in df_cum_q.columns:
                        is_main = col_k in ["Q1", "Q5", "Long_Short_Spread"]
                        fig_fq.add_trace(go.Scatter(
                            x=df_cum_q[date_col_name],
                            y=df_cum_q[col_k],
                            mode="lines",
                            name=q_labels.get(col_k, col_k),
                            line=dict(
                                color=q_colors.get(col_k, "#ffffff"),
                                width=3.0 if is_main else 1.5,
                                dash="solid" if col_k != "Equal_Weight_Univ" else "dash"
                            ),
                            hovertemplate=f"<b>{q_labels.get(col_k, col_k)}</b>: %{{y:.1f}}<extra></extra>"
                        ))

                fig_fq.update_layout(
                    template="plotly_dark",
                    paper_bgcolor="rgba(0,0,0,0)",
                    plot_bgcolor="rgba(13,17,23,0.7)",
                    margin=dict(l=15, r=15, t=25, b=15),
                    height=360,
                    xaxis=dict(gridcolor="rgba(255,255,255,0.06)"),
                    yaxis=dict(title="Valore Portafoglio (Base 100)", gridcolor="rgba(255,255,255,0.06)"),
                    legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
                )
                apply_plotly_theme(fig_fq)
                st.plotly_chart(fig_fq, use_container_width=True, config={"displayModeBar": "hover", "displaylogo": False})

            with col_g2:
                st.markdown("##### 📊 Rendimento Annuo per Quintile")
                df_bar_q = fq_res["metrics_df"][fq_res["metrics_df"]["Quintile"].str.startswith("Q")].copy()
                fig_bar_q = px.bar(
                    df_bar_q,
                    x="Quintile",
                    y="Rendimento Annuo CAGR %",
                    color="Rendimento Annuo CAGR %",
                    color_continuous_scale=["#f85149", "#58a6ff", "#3fb950"],
                    template="plotly_dark",
                    height=360
                )
                fig_bar_q.update_layout(
                    paper_bgcolor="rgba(0,0,0,0)",
                    plot_bgcolor="rgba(0,0,0,0)",
                    margin=dict(l=10, r=10, t=25, b=10),
                    xaxis=dict(title=None, tickangle=-25),
                    coloraxis_showscale=False
                )
                fig_bar_q.update_traces(hovertemplate="<b>%{x}</b><br>CAGR: <b>%{y:+.2f}%</b><extra></extra>")
                apply_plotly_theme(fig_bar_q)
                st.plotly_chart(fig_bar_q, use_container_width=True, config={"displayModeBar": False})

            # Tabella Dettagliata Analytics per Quintile
            fq_cfg = {
                "Quintile": st.column_config.TextColumn("Paniere Quintile", width="medium"),
                "Rendimento Annuo CAGR %": st.column_config.NumberColumn("CAGR Ann %", format="%+.2f%%"),
                "Volatilità Annua %": st.column_config.NumberColumn("Volatilità %", format="%.2f%%"),
                "Sharpe Ratio": st.column_config.NumberColumn("Sharpe Ratio", format="%.2f"),
                "Max Drawdown %": st.column_config.NumberColumn("Max Drawdown", format="%.2f%%"),
                "Win Rate Mensile %": st.column_config.NumberColumn("Win Rate Mensile", format="%.1f%%"),
                "Information Ratio vs Univ": st.column_config.NumberColumn("Information Ratio", format="%.2f")
            }
            render_table_with_export(
                df=fq_res["metrics_df"],
                table_title="Tabella Comparativa di Performance e Rischio per Quintile",
                file_prefix=f"factor_quintile_{fact_choice.lower()}",
                key_suffix="mq_factor_quintiles",
                column_config=fq_cfg,
                hide_index=True
            )
        else:
            st.info(fq_res.get("message", "Dati non sufficienti per calcolare il backtest a quintili."))

        st.divider()

        # ── SEZIONE MSCI BARRA ASSET-LEVEL FACTOR RISK DECOMPOSITION (GEM3/USE4) ──
        st.markdown("### 🏛️ Decomposizione del Rischio Multi-Fattoriale MSCI Barra (GEM3/USE4)")
        st.caption("Standard Tier-1 (BlackRock Aladdin / MSCI Barra): scomposizione analitica della matrice di covarianza &Sigma; = X F X<sup>T</sup> + &Delta; tra Rischio Sistemico Fattoriale e Rischio Idiosincratico Residuo, con Marginal Risk Contribution (MCTR) e Percent Risk Contribution (PCTR) conformi al Teorema di Eulero.")

        from core.msci_barra_risk_engine import (
            GICS_SECTORS,
            STYLE_FACTORS,
            AssetFactorProfile,
            BarraMultiAssetRiskEngine,
        )

        barra_eng = BarraMultiAssetRiskEngine()
        barra_profiles = []

        if not pos.empty and "ticker" in pos.columns:
            sub_pos = pos.copy()
            if "qty_net" in sub_pos.columns:
                sub_pos = sub_pos[sub_pos["qty_net"] > 1e-6]
            tot_val = sub_pos["current_value"].sum() if "current_value" in sub_pos.columns and sub_pos["current_value"].sum() > 0 else 1.0

            for _, row_a in sub_pos.iterrows():
                tk = str(row_a["ticker"])
                if tk.endswith("=X"):
                    continue
                c_val = float(row_a.get("current_value", 10000.0))
                w_a = c_val / tot_val if tot_val > 0 else 1.0 / len(sub_pos)
                name_a = str(row_a.get("name", tk))
                barra_profiles.append(
                    barra_eng.estimate_default_exposures_for_ticker(tk, name=name_a, weight=w_a, current_value=c_val)
                )

        if len(barra_profiles) < 2:
            barra_profiles = [
                barra_eng.estimate_default_exposures_for_ticker("CSPX.MI", name="iShares Core S&P 500", weight=0.40, current_value=40000.0),
                barra_eng.estimate_default_exposures_for_ticker("MEUD.PA", name="Amundi Stoxx Europe 600", weight=0.25, current_value=25000.0),
                barra_eng.estimate_default_exposures_for_ticker("BTP-10Y", name="BTP Benchmark 10Y", weight=0.20, current_value=20000.0),
                barra_eng.estimate_default_exposures_for_ticker("XOM", name="ExxonMobil Energy", weight=0.10, current_value=10000.0),
                barra_eng.estimate_default_exposures_for_ticker("JNJ", name="Johnson & Johnson", weight=0.05, current_value=5000.0)
            ]

        barra_res = barra_eng.decompose_portfolio_factor_risk(barra_profiles)

        bm1, bm2, bm3, bm4 = st.columns(4)
        with bm1:
            metric_card("Volatilità Totale Annua", f"{barra_res['volatility_total_annual']*100:.2f}%", delta="Rischio Complessivo", delta_color="normal")
        with bm2:
            metric_card("Rischio Fattoriale Sistemico", f"{barra_res['volatility_factor_annual']*100:.2f}%", delta=f"{barra_res['factor_risk_contribution_pct']:.1f}% della Varianza", delta_color="normal")
        with bm3:
            metric_card("Rischio Specifico / Idiosincratico", f"{barra_res['volatility_specific_annual']*100:.2f}%", delta=f"{barra_res['specific_risk_contribution_pct']:.1f}% della Varianza", delta_color="normal")
        with bm4:
            metric_card("Verifica Somma Eulero", f"{barra_res['euler_sum_pctr']:.1f}%", delta="&Sigma; PCTR = 100.0% Exact", delta_color="normal")

        st.markdown("<div style='margin-top: 12px;'></div>", unsafe_allow_html=True)

        c_radar, c_bar = st.columns([1.1, 1.25])
        with c_radar:
            st.markdown("##### 🕸️ Active Factor Tilts vs Benchmark (Radar)")
            # Radar chart of style & macro factor bets
            tilts = barra_res["active_style_tilts"]
            r_factors = list(tilts.keys())
            r_vals = [tilts[f] for f in r_factors]
            # Close radar loop
            r_factors_loop = r_factors + [r_factors[0]]
            r_vals_loop = r_vals + [r_vals[0]]

            fig_radar = go.Figure()
            fig_radar.add_trace(go.Scatterpolar(
                r=r_vals_loop,
                theta=r_factors_loop,
                fill='toself',
                name='Portafoglio Attuale',
                line=dict(color='#38bdf8', width=2),
                fillcolor='rgba(56, 189, 248, 0.25)'
            ))
            fig_radar.add_trace(go.Scatterpolar(
                r=[0.0] * len(r_factors_loop),
                theta=r_factors_loop,
                name='Benchmark Neutro (MSCI World)',
                line=dict(color='#8b949e', width=1, dash='dash')
            ))
            fig_radar.update_layout(
                polar=dict(
                    radialaxis=dict(visible=True, range=[-1.5, 2.5], gridcolor='rgba(255,255,255,0.1)'),
                    angularaxis=dict(gridcolor='rgba(255,255,255,0.1)')
                ),
                template="plotly_dark",
                height=350,
                margin=dict(l=30, r=30, t=30, b=30),
                paper_bgcolor="rgba(0,0,0,0)",
                legend=dict(orientation="h", yanchor="bottom", y=-0.15, xanchor="center", x=0.5)
            )
            apply_plotly_theme(fig_radar)
            st.plotly_chart(fig_radar, use_container_width=True)

        with c_bar:
            st.markdown("##### 📊 Scomposizione Rischio per Fattore (Factor PCTR %)")
            df_f = barra_res["factor_attribution_df"].head(10).copy()
            fig_f_bar = go.Figure(go.Bar(
                x=df_f["factor_pctr"],
                y=df_f["factor_name"],
                orientation='h',
                marker=dict(
                    color=df_f["factor_pctr"].apply(lambda v: '#34d399' if v >= 0 else '#f87171')
                ),
                text=df_f["factor_pctr"].apply(lambda v: f"{v:+.1f}%"),
                textposition='outside'
            ))
            fig_f_bar.update_layout(
                template="plotly_dark",
                height=350,
                margin=dict(l=20, r=40, t=20, b=20),
                paper_bgcolor="rgba(0,0,0,0)",
                plot_bgcolor="rgba(0,0,0,0)",
                xaxis=dict(title="% Contributo al Rischio Totale (PCTR)", gridcolor="rgba(255,255,255,0.06)"),
                yaxis=dict(autorange="reversed")
            )
            apply_plotly_theme(fig_f_bar)
            st.plotly_chart(fig_f_bar, use_container_width=True)

        st.markdown("##### 📋 Contributo di Rischio Marginale (MCTR) e Percentuale (PCTR) per Posizione")
        df_a_disp = barra_res["asset_risk_df"].copy()
        st.dataframe(
            df_a_disp.rename(columns={
                "ticker": "Ticker",
                "asset_name": "Strumento",
                "weight_pct": "Peso (%)",
                "mctr": "MCTR",
                "pctr_total": "PCTR Totale (%)",
                "pctr_factor": "PCTR Fattoriale (%)",
                "pctr_specific": "PCTR Specifico (%)",
                "specific_vol_annual": "Vol Idiosincratica"
            }).style.format({
                "Peso (%)": "{:.2f}%",
                "MCTR": "{:.4f}",
                "PCTR Totale (%)": "{:.2f}%",
                "PCTR Fattoriale (%)": "{:.2f}%",
                "PCTR Specifico (%)": "{:.2f}%",
                "Vol Idiosincratica": "{:.2%}"
            }),
            use_container_width=True,
            hide_index=True
        )

# ── TAB 6: FIXED INCOME, YTM & Z-SPREAD (YAS) ──────────────────────
elif active_quant_tab == "🏛️ Fixed Income & Z-Spread":
    st.markdown("#### 🏛️ Fixed Income Istituzionale & Z-Spread Cockpit (Bloomberg YAS Style)")
    render_institutional_info_box(
        title="Fixed Income Pricing, Curva Zero-Coupon, Z-Spread & Default Implicito",
        badge="FIXED INCOME • YAS • Z-SPREAD • CDS HAZARD",
        summary_html="Valutazione obbligazionaria di classe Bloomberg YAS: Yield to Maturity (YTM), Duration Modificata, Convessità, DV01/PVBP, bootstrapping della curva zero-coupon sovrana, calcolo dello Z-Spread e stima dell'intensità di default (Hazard Rate).",
        math_html="Pricing Z-Spread su curva spot $z(t_i)$: <code>P = Σ_{i=1}^n C_i / [1 + z(t_i) + Z]^{t_i} + M / [1 + z(t_n) + Z]^{t_n}</code><br>Sensibilità di prezzo: <code>ΔP/P ≈ - D_{mod} · Δy + 0.5 · C · (Δy)²</code> | <code>DV01 = P · D_{mod} · 0.0001</code>.<br>Hazard Rate implicita: <code>λ ≈ S_{CDS} / (1 - R)</code> con Recovery Rate $R$.",
        chart_guide_html="• <b>Z-Spread vs Benchmark:</b> misura il puro premio al rischio creditizio e di liquidità scorporato dalla forma della curva dei tassi.<br>• <b>Probabilità di Default Cumulata:</b> proietta la curva $Q(0, t) = 1 - e^{-λ t}$ a 1Y, 5Y, 10Y, 30Y.",
        regulatory_html="• <b>Basilea III Requisiti di Capitale per Rischio Tassi nel Banking Book (IRRBB):</b> monitoraggio delle sensibilità DV01 ed effetto convessità su grandi movimenti di curva.<br>• <b>Valutazione Fair Value IFRS 13 / Mark-to-Model:</b> calibrazione oggettiva dei flussi di cassa scontati su tassi zero-coupon privi di rischio.",
        accent_color="#eab308",
    )

    st.markdown("<div style='margin-top: 10px;'></div>", unsafe_allow_html=True)

    # Selezione Titolo Benchmark o Custom
    preset_keys = ["IT10Y", "DE10Y", "US10Y", "CORP_ENI", "CUSTOM"]
    preset_names = [
        "🇮🇹 BTP Decennale 4.00% (Italia)",
        "🇩🇪 Bund Decennale 2.50% (Germania)",
        "🇺🇸 US 10-Year Treasury 4.25% (USA)",
        "🏢 ENI SpA Sustainability 3.875% (Corporate)",
        "✏️ Obbligazione Personalizzata (Custom)"
    ]
    
    col_sel1, col_sel2 = st.columns([2.5, 1.5])
    with col_sel1:
        selected_idx = st.selectbox(
            "Seleziona Strumento Obbligazionario Benchmark o Personalizzato:",
            options=range(len(preset_names)),
            format_func=lambda i: preset_names[i],
            index=0,
            key="fi_preset_choice"
        )
    
    preset_choice = preset_keys[selected_idx]
    
    # Parametri iniziali
    if preset_choice != "CUSTOM":
        p_data = INSTITUTIONAL_BOND_PRESETS[preset_choice]
        def_face = float(p_data.get("face_value", 100.0))
        def_coupon = float(p_data["coupon_rate"] * 100.0)
        def_mat = float(p_data["maturity_years"])
        def_price = float(p_data["market_price"])
        def_freq = int(p_data["coupon_freq"])
        def_cds = float(p_data.get("cds_5y_bps", 80.0))
        curr_symbol = "€" if p_data.get("currency") == "EUR" else "$"
    else:
        def_face = 100.0
        def_coupon = 4.50
        def_mat = 7.0
        def_price = 99.50
        def_freq = 2
        def_cds = 110.0
        curr_symbol = "€"

    # Input interattivi
    with st.expander("⚙️ Parametri Finanziari dell'Obbligazione", expanded=True):
        col_inp1, col_inp2, col_inp3, col_inp4, col_inp5, col_inp6 = st.columns(6)
        with col_inp1:
            inp_face = st.number_input("Valore Nominale", min_value=1.0, value=def_face, step=10.0, key="fi_face_val")
        with col_inp2:
            inp_coupon = st.number_input("Tasso Cedolare (%)", min_value=0.0, max_value=25.0, value=def_coupon, step=0.10, key="fi_coupon_val")
        with col_inp3:
            inp_mat = st.number_input("Scadenza (Anni)", min_value=0.1, max_value=50.0, value=def_mat, step=0.5, key="fi_mat_val")
        with col_inp4:
            inp_price = st.number_input("Prezzo di Mercato", min_value=1.0, max_value=300.0, value=def_price, step=0.25, key="fi_price_val")
        with col_inp5:
            inp_freq = st.selectbox("Frequenza Cedola", options=[1, 2, 4], format_func=lambda x: "Annuale (1x)" if x==1 else ("Semestrale (2x)" if x==2 else "Trimestrale (4x)"), index=(0 if def_freq==1 else (1 if def_freq==2 else 2)), key="fi_freq_val")
        with col_inp6:
            inp_cds = st.number_input("Spread CDS 5Y (bps)", min_value=0.0, max_value=2000.0, value=def_cds, step=5.0, key="fi_cds_val")

    # Calcolo metriche
    coupon_dec = inp_coupon / 100.0
    bond_res = compute_bond_analytics(
        face_value=inp_face,
        coupon_rate=coupon_dec,
        maturity_years=inp_mat,
        market_price=inp_price,
        coupon_frequency=inp_freq
    )
    z_spread_bps = compute_z_spread(
        face_value=inp_face,
        coupon_rate=coupon_dec,
        maturity_years=inp_mat,
        market_price=inp_price,
        spot_curve_fn_or_params=None,
        coupon_frequency=inp_freq
    )
    cds_res = compute_cds_implied_default_probability(
        cds_spread_bps=inp_cds,
        recovery_rate=0.40
    )

    # 4 Executive KPI Cards
    st.markdown("<div style='margin-top: 15px;'></div>", unsafe_allow_html=True)
    col_kpi1, col_kpi2, col_kpi3, col_kpi4 = st.columns(4)
    with col_kpi1:
        metric_card(
            "Yield to Maturity (YTM)",
            f"{bond_res['ytm_pct']:.3f}%",
            f"Cedola Corrente: {bond_res['current_yield_pct']:.2f}%",
            True
        )
    with col_kpi2:
        metric_card(
            "Modified Duration",
            f"{bond_res['modified_duration']:.2f}x",
            f"Macaulay Duration: {bond_res['macaulay_duration_years']:.2f} Anni",
            True
        )
    with col_kpi3:
        metric_card(
            "Convexity (Convessità)",
            f"{bond_res['convexity']:.2f}",
            f"DV01 / PVBP: {curr_symbol} {bond_res['dv01']:.4f} / bp",
            True
        )
    with col_kpi4:
        metric_card(
            "Z-Spread & Hazard Rate",
            f"{z_spread_bps:+.1f} bps",
            f"Hazard Rate CDS: {cds_res['implied_hazard_rate_pct']:.2f}%/anno",
            True
        )

    st.markdown("<div style='margin-top: 20px;'></div>", unsafe_allow_html=True)

    # Simulatore Interattivo Shock di Rendimento & Price-Yield Curve
    col_plot1, col_plot2 = st.columns([1.8, 1.2])
    with col_plot1:
        st.markdown("##### 📈 Curva Prezzo-Rendimento & Guadagno di Convessità")
        st.caption("Confronto tra Curva di Prezzo Esatta, Approssimazione di 1° Ordine (Sola Duration) e di 2° Ordine (Duration + Convessità).")
        
        # Genera punti per la curva continua
        ytm_center = bond_res['ytm_pct'] / 100.0
        y_shifts = np.linspace(-0.03, 0.03, 60)
        y_points = (ytm_center + y_shifts) * 100.0
        exact_prices = [compute_bond_price_from_ytm(inp_face, coupon_dec, inp_mat, ytm_center + dy, inp_freq) for dy in y_shifts]
        
        # Taylor 1 (Duration) e Taylor 2 (Duration + Convexity)
        taylor_1_prices = [inp_price * (1.0 - bond_res['modified_duration'] * dy) for dy in y_shifts]
        taylor_2_prices = [inp_price * (1.0 - bond_res['modified_duration'] * dy + 0.5 * bond_res['convexity'] * (dy**2)) for dy in y_shifts]

        fig_py = go.Figure()
        fig_py.add_trace(go.Scatter(
            x=y_points, y=exact_prices,
            mode='lines', name='Prezzo Esatto P(y)',
            line=dict(color='#ff9900', width=3.5)
        ))
        fig_py.add_trace(go.Scatter(
            x=y_points, y=taylor_2_prices,
            mode='lines', name='Taylor 2° Ordine (Duration + Convexity)',
            line=dict(color='#00c853', width=2, dash='dash')
        ))
        fig_py.add_trace(go.Scatter(
            x=y_points, y=taylor_1_prices,
            mode='lines', name='Taylor 1° Ordine (Solo Duration)',
            line=dict(color='#f85149', width=1.5, dash='dot')
        ))
        # Punto di prezzo corrente
        fig_py.add_trace(go.Scatter(
            x=[bond_res['ytm_pct']], y=[inp_price],
            mode='markers+text', name='Prezzo Attuale',
            marker=dict(color='#ffffff', size=10, symbol='diamond'),
            text=[f"YTM {bond_res['ytm_pct']:.2f}%"], textposition='top center'
        ))

        fig_py.update_layout(
            template='plotly_dark',
            paper_bgcolor='rgba(0,0,0,0)',
            plot_bgcolor='rgba(13,17,23,0.7)',
            margin=dict(l=20, r=20, t=30, b=20),
            height=360,
            xaxis=dict(title="Yield to Maturity (%)", gridcolor='rgba(255,255,255,0.06)'),
            yaxis=dict(title=f"Prezzo Obbligazione ({curr_symbol})", gridcolor='rgba(255,255,255,0.06)'),
            legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
        )
        st.plotly_chart(fig_py, use_container_width=True, config={"displayModeBar": "hover", "displaylogo": False})

    with col_plot2:
        df_cds = cds_res["default_probability_curve"]
        col_cds_h1, col_cds_h2 = st.columns([2.0, 1.2], vertical_alignment="center")
        with col_cds_h1:
            st.markdown("##### 🛡️ Curva Default Implicita (CDS)")
        with col_cds_h2:
            render_export_toolbar(
                df_cds,
                file_prefix=f"cds_default_curve_{preset_choice.lower()}",
                key_suffix="mq_cds_curve",
                table_title="Curva Default Implicita (CDS)"
            )
        st.caption(f"Term structure cumulativa di default basata sullo spread CDS di **{inp_cds:.0f} bps** (Recovery: 40%).")
        
        fig_cds = go.Figure()
        fig_cds.add_trace(go.Scatter(
            x=df_cds["tenor_years"], y=df_cds["cumulative_default_prob_pct"],
            mode='lines+markers', name='Probabilità di Default Cumulativa (%)',
            line=dict(color='#f85149', width=3),
            fill='tozeroy', fillcolor='rgba(248,81,73,0.12)',
            marker=dict(size=7, color='#f85149')
        ))
        fig_cds.update_layout(
            template='plotly_dark',
            paper_bgcolor='rgba(0,0,0,0)',
            plot_bgcolor='rgba(13,17,23,0.7)',
            margin=dict(l=20, r=20, t=30, b=20),
            height=360,
            xaxis=dict(title="Scadenza (Anni)", gridcolor='rgba(255,255,255,0.06)'),
            yaxis=dict(title="Probabilità Cumulativa Default (%)", gridcolor='rgba(255,255,255,0.06)'),
            showlegend=False
        )
        st.plotly_chart(fig_cds, use_container_width=True, config={"displayModeBar": "hover", "displaylogo": False})

    # Tabella di Sensibilità a Shock di Rendimento
    st.markdown("<div style='margin-top: 15px;'></div>", unsafe_allow_html=True)
    df_sens = bond_res["sensitivity_table"].copy()
    sens_cfg = {
        "shift_bps": st.column_config.NumberColumn("Shock Tasso", format="%+d bps"),
        "new_ytm_pct": st.column_config.NumberColumn("Nuovo YTM", format="%.3f%%"),
        "exact_price": st.column_config.NumberColumn(f"Prezzo Esatto ({curr_symbol})", format="%.2f"),
        "pct_change_exact": st.column_config.NumberColumn("Var % Prezzo Esatta", format="%+.2f%%"),
        "pct_change_duration_only": st.column_config.NumberColumn("Stima Solo Duration", format="%+.2f%%"),
        "pct_change_duration_plus_convexity": st.column_config.NumberColumn("Stima Duration + Convexity", format="%+.2f%%"),
        "convexity_gain_pct": st.column_config.NumberColumn("Vantaggio Convessità", format="%+.2f%%")
    }
    render_table_with_export(
        df=df_sens,
        table_title="Matrice di Sensibilità Istituzionale a Shock di Tasso",
        file_prefix=f"bond_sensitivity_{preset_choice.lower()}",
        key_suffix="mq_bond_sens",
        column_config=sens_cfg,
        hide_index=True
    )

# ── TAB 8: MACHINE LEARNING HMM REGIMES ──────────────────────
elif active_quant_tab == "⚡ Machine Learning HMM Regimes":
    st.markdown("#### ⚡ Machine Learning Hidden Markov Models (HMM) & Regime Detection")
    st.caption("Classificazione probabilistica non supervisionata della serie dei rendimenti in 3 stati latenti (Low-Vol Bull, Range-Bound Drift, High-Vol Crisis) e calcolo della matrice di transizione.")

    render_institutional_info_box(
        title="Hidden Markov Models (HMM) & Regime Detection Non-Supervisionato (Hamilton 1989)",
        badge="MACHINE LEARNING • MARKOV SWITCHING",
        summary_html=(
            "Classificazione probabilistica non supervisionata della serie storica dei rendimenti in 3 stati latenti "
            "<b>(Low-Vol Bull, Range-Bound Drift, High-Vol Crisis)</b> con stima della matrice di transizione Markoviana "
            "e calcolo analitico della durata attesa di permanenza nel regime."
        ),
        math_html=(
            "Probabilità di transizione $p_{ij} = P(S_t = j \\mid S_{t-1} = i)$ stimate via algoritmo di <b>Baum-Welch (EM)</b>:<br>"
            "<code>L(θ) = Σ_S P(Y, S | θ)  |  Durata media attesa E[D_i] = 1 / (1 - p_ii)</code><br>"
            "Rendimento e varianza condizionati: <code>Y_t | (S_t = k) ~ N(μ_k, σ²_k)</code>"
        ),
        chart_guide_html=(
            "• <b>Profilo Statistico dei Regimi</b>: indica rendimento annuo, volatilità e Sharpe ratio associati a ciascuno stato latente.<br>"
            "• <b>Matrice di Transizione (%)</b>: la diagonale principale $(p_{ii})$ quantifica la persistenza e stabilità del regime."
        ),
        regulatory_html=(
            "• <b>Pillar 2 Supervisory Stress Testing</b>: identificazione tempestiva delle transizioni verso regimi di crisi ad alta volatilità.<br>"
            "• <b>Tactical Asset Allocation</b>: adeguamento dinamico dei pesi di portafoglio in funzione della probabilità di transizione a $T+1$."
        ),
        accent_color="#8b5cf6",
    )

    from core.hmm_regime_engine import compute_hmm_market_regime_detection

    sr_port_ret = results.get("portfolio_return") if results else None
    hmm_res = compute_hmm_market_regime_detection(sr_returns=sr_port_ret)
    rec = hmm_res["tactical_recommendation"]

    hk1, hk2, hk3, hk4 = st.columns(4)
    with hk1:
        metric_card("Regime Attuale Stimato", hmm_res["current_regime_name"], delta="Stato Latente Attivo", delta_color="normal")
    with hk2:
        metric_card("Persistenza del Regime", f"{hmm_res['regime_persistence_pct']:.1f}%", delta="Probabilità di Permanenza", delta_color="normal")
    with hk3:
        metric_card("Durata Attesa Residua", f"~{hmm_res['expected_remaining_duration_days']} gg", delta="Trading Days", delta_color="normal")
    with hk4:
        metric_card("Allocazione Consigliata", rec["allocation"][:24], delta="Overlay Tattico ML", delta_color="normal")

    st.write("")

    col_hmm_l, col_hmm_r = st.columns([3, 2])
    with col_hmm_l:
        st.markdown("##### 📊 Profilo Statistico dei 3 Regimi Latenti")
        st.dataframe(
            hmm_res["state_profiles_df"][["state_name", "frequency_pct", "annualized_return_pct", "annualized_volatility_pct", "sharpe_ratio", "persistence_prob_pct", "expected_duration_days"]].rename(columns={
                "state_name": "Regime di Mercato",
                "frequency_pct": "Frequenza Storica (%)",
                "annualized_return_pct": "Rendimento Annuo (%)",
                "annualized_volatility_pct": "Volatilità Annua (%)",
                "sharpe_ratio": "Sharpe Ratio",
                "persistence_prob_pct": "Persistenza (%)",
                "expected_duration_days": "Durata Media (gg)"
            }),
            use_container_width=True,
            hide_index=True
        )

    with col_hmm_r:
        st.markdown("##### 🔄 Matrice di Transizione di Stato (%)")
        st.dataframe(
            hmm_res["transition_matrix_pct_df"],
            use_container_width=True
        )


# ── TAB 9: TAX-AWARE REBALANCER & EXECUTION ──────────────────
elif active_quant_tab == "⚖️ Tax-Aware Rebalancer & Execution":
    st.markdown("#### ⚖️ Ribilanciatore Tax-Aware, Matrice di Attrito & Zero-Tax PAC")
    st.caption("Ottimizzazione dell'esecuzione degli ordini con frizioni reali (commissioni broker, bid-ask spread, imposte capital gain 26%/12.5% e compensazione minusvalenze) oppure ribilanciamento asintotico a zero imposte tramite nuovi versamenti.")

    render_institutional_info_box(
        title="Ribilanciatore Tax-Aware, Matrice d'Attrito & Zero-Tax PAC Asintotico",
        badge="TAX & EXECUTION • FRICTION MATRIX",
        summary_html=(
            "Ottimizzazione convessa dell'esecuzione con frizioni reali: commissioni fisse e variabili broker, "
            "bid-ask spread di mercato, imposte sul capital gain (aliquote 26% e 12.5% per titoli di Stato white-list) "
            "e compensazione FIFO delle minusvalenze pregresse nello zainetto fiscale quadriennale."
        ),
        math_html=(
            "Funzione obiettivo quadratica con penalizzazione d'attrito e imposte:<br>"
            "<code>min_w  (w - w_target)' Σ (w - w_target) + λ_tax · TaxDue(w, w_0) + λ_cost · FrictionCost(w - w_0)</code><br>"
            "Zero-Tax PAC Flow: <code>ΔC_i = max(0, w_target,i · (V_0 + C_new) - V_0,i)</code> [solo acquisti, zero plusvalenze realizzate]"
        ),
        chart_guide_html=(
            "• <b>Confronto Ribilanciamento Standard vs Tax-Aware</b>: evidenzia il risparmio fiscale netto e il turnover ottimizzato.<br>"
            "• <b>Zainetto Fiscale & Minusvalenze</b>: monitora il credito d'imposta utilizzabile e la scadenza quadriennale."
        ),
        regulatory_html=(
            "• <b>TUIR Art. 67-68 (Regime Fiscale Italiano)</b>: compensazione minusvalenze con plusvalenze di natura diversa.<br>"
            "• <b>MIFID II Best Execution</b>: minimizzazione dei costi totali di transazione e dell'impatto sul NAV del cliente."
        ),
        accent_color="#10b981",
    )

    from core.tax_aware_rebalancer import FrictionConfig, TaxAwarePortfolioRebalancer

    # Recupera posizioni attuali
    if has_portfolio and opt and opt.get("tickers"):
        cur_tks = opt["tickers"]
        cur_v = float(opt.get("portfolio_val", 100000.0))
        cur_weights_list = opt.get("weights", [1.0 / len(cur_tks)] * len(cur_tks))
        df_cur_pos = pd.DataFrame({
            "ticker": cur_tks,
            "market_value": [cur_v * w for w in cur_weights_list]
        })
    else:
        cur_tks = ["SWDA.MI", "EIMI.MI", "XEON.DE", "BTP-10Y", "GLD"]
        cur_v = 150000.0
        df_cur_pos = pd.DataFrame([
            {"ticker": "SWDA.MI", "market_value": 90000.0},
            {"ticker": "EIMI.MI", "market_value": 15000.0},
            {"ticker": "XEON.DE", "market_value": 30000.0},
            {"ticker": "BTP-10Y", "market_value": 10000.0},
            {"ticker": "GLD", "market_value": 5000.0}
        ])

    col_reb_cfg1, col_reb_cfg2, col_reb_cfg3 = st.columns(3)
    with col_reb_cfg1:
        f_comm = st.number_input("Commissione Fissa Broker (€)", min_value=0.0, value=2.95, step=0.5, key="f_comm_in")
        pct_comm = st.number_input("Commissione Variabile (%)", min_value=0.0, value=0.19, step=0.01, key="pct_comm_in") / 100.0
    with col_reb_cfg2:
        spread_bps = st.number_input("Bid-Ask Spread Medio (bps)", min_value=0, value=10, step=2, key="spread_bps_in") / 10000.0
        minus_val = st.number_input("Minusvalenze Pregresse (€)", min_value=0.0, value=1500.0, step=250.0, key="minus_val_in")
    with col_reb_cfg3:
        pac_val = st.number_input("Versamento Mensile PAC (€)", min_value=100.0, value=1200.0, step=100.0, key="pac_val_in")
        target_preset = st.selectbox("Preset Allocazione Target:", ["Bilanciato 60/40 Equity/Bond", "Aggressive Growth 80/20", "Ray Dalio All-Weather", "Equal Weight 1/N"], key="reb_preset_sel")

    # Target weights map
    if target_preset == "Aggressive Growth 80/20":
        target_w_map = {"SWDA.MI": 0.65, "EIMI.MI": 0.15, "XEON.DE": 0.05, "BTP-10Y": 0.10, "GLD": 0.05}
    elif target_preset == "Ray Dalio All-Weather":
        target_w_map = {"SWDA.MI": 0.30, "EIMI.MI": 0.00, "XEON.DE": 0.15, "BTP-10Y": 0.40, "GLD": 0.15}
    elif target_preset == "Equal Weight 1/N":
        n_t = len(df_cur_pos["ticker"].tolist())
        target_w_map = dict.fromkeys(df_cur_pos["ticker"].tolist(), 1.0 / n_t)
    else:  # Bilanciato 60/40
        target_w_map = {"SWDA.MI": 0.50, "EIMI.MI": 0.10, "XEON.DE": 0.10, "BTP-10Y": 0.25, "GLD": 0.05}

    f_config = FrictionConfig(
        fixed_commission_eur=f_comm,
        pct_commission=pct_comm,
        bid_ask_spread_pct=spread_bps,
        capital_gain_tax_rate=0.26,
        gov_bond_tax_rate=0.125
    )

    full_reb = TaxAwarePortfolioRebalancer.compute_full_rebalance_plan(
        df_cur_pos, target_w_map, cur_v, existing_minusvalenze=minus_val, config=f_config
    )
    zero_tax_reb = TaxAwarePortfolioRebalancer.compute_zero_tax_cashflow_rebalance(
        df_cur_pos, target_w_map, cur_v, monthly_inflow_eur=pac_val
    )

    st.write("")
    tab_full_reb, tab_zero_tax = st.tabs([
        "⚡ 1. Full Rebalance Immediato (Trade Execution List)",
        "🌱 2. Cashflow Rebalance a Impatto Fiscale Zero (PAC)"
    ])

    with tab_full_reb:
        rk1, rk2, rk3, rk4 = st.columns(4)
        with rk1:
            metric_card("Turnover Lordo", fmt_eur(full_reb["gross_turnover_eur"]), delta=f"{full_reb['gross_turnover_pct']:.1f}% del Portafoglio", delta_color="normal")
        with rk2:
            metric_card("Commissioni Totali", fmt_eur(full_reb["total_commissions_eur"]), delta=f"Spread: {fmt_eur(full_reb['total_spread_cost_eur'])}", delta_color="normal")
        with rk3:
            metric_card("Imposta Capital Gain", fmt_eur(full_reb["estimated_tax_eur"]), delta=f"Minus residue: {fmt_eur(full_reb['remaining_minusvalenze_eur'])}", delta_color="normal" if full_reb["estimated_tax_eur"] == 0 else "inverse")
        with rk4:
            metric_card("Costo Frizione Totale", fmt_eur(full_reb["total_friction_drag_eur"]), delta="Impatto su Performance", delta_color="inverse")

        st.write("")
        df_exec = full_reb["trade_execution_list_df"]
        if not df_exec.empty:
            render_table_with_export(
                df=df_exec,
                table_title="Trade Execution List (Distinta Ordini Pronta per il Broker)",
                file_prefix="trade_execution_list",
                key_suffix="mq_trade_exec",
                hide_index=True
            )
        else:
            st.success("✅ Portafoglio già perfettamente allineato ai pesi target!")

    with tab_zero_tax:
        zk1, zk2, zk3, zk4 = st.columns(4)
        with zk1:
            metric_card("Tempo Stimato di Allineamento", f"~{zero_tax_reb['months_to_full_alignment']} Mesi", delta="Con PAC di " + fmt_eur(pac_val) + "/m", delta_color="normal")
        with zk2:
            metric_card("Tasse Evitate (Capital Gain)", fmt_eur(zero_tax_reb["tax_saved_eur"]), delta="Zero Ritenute Subite", delta_color="normal")
        with zk3:
            metric_card("Risparmio Commissioni Vendita", fmt_eur(zero_tax_reb["turnover_savings_eur"]), delta="Zero Turnover Vendita", delta_color="normal")
        with zk4:
            metric_card("Efficienza Fiscale", "100.0%", delta="Tax-Free Rebalance", delta_color="normal")

        st.write("")
        st.markdown("##### 🎯 Piano di Allocazione Mensile PAC (Zero Vendite)")
        st.dataframe(
            zero_tax_reb["cashflow_plan_df"],
            use_container_width=True,
            hide_index=True
        )





# ── TAB: WALK-FORWARD MULTI-STRATEGY ROLLING OOS ENGINE ────────────
elif active_quant_tab == "🔄 Walk-Forward Backtesting (WFO)":
    st.markdown("#### 🔄 Walk-Forward Multi-Strategy Rolling Out-of-Sample Engine")
    st.caption("Esecuzione di backtesting rolling con finestre di training (In-Sample) e finestre di test (Out-of-Sample) con frizioni di ribilanciamento.")

    render_institutional_info_box(
        title="Walk-Forward Optimization (WFO), Out-of-Sample Efficiency & PBO",
        badge="MODEL VALIDATION • PURGED WALK-FORWARD",
        summary_html=(
            "Validazione quantitativa non retrospettiva con finestre rolling Out-of-Sample per prevenire l'overfitting. "
            "Calcolo della <b>Walk-Forward Efficiency (WFE) di Pardo (2008)</b> e della <b>Probability of Backtest Overfitting (PBO)</b> "
            "di Bailey & López de Prado (2014)."
        ),
        math_html=(
            "Efficienza Out-of-Sample e Combinatorially Symmetric CV (CSCV):<br>"
            "<code>WFE = Sharpe_OOS / Sharpe_IS ≥ 65%  |  PBO = P(Sharpe_OOS ≤ Median(Sharpe_IS))</code><br>"
            "Purged & Embargoed folds per eliminare il look-ahead bias e la correlazione seriale dei residui."
        ),
        chart_guide_html=(
            "• <b>Equity Line In-Sample vs Out-of-Sample</b>: verifica che le performance non degradino bruscamente fuori campione.<br>"
            "• <b>Distribuzione Overfitting PBO</b>: valori superiori al 30% segnalano data-mining bias e instabilità parametrica."
        ),
        regulatory_html=(
            "• <b>Fed SR 11-7 / OCC 2011-12</b>: requisiti stringenti di validazione indipendente dei modelli e test fuori campione.<br>"
            "• <b>EBA Guidelines on Internal Models</b>: backtesting continuo e monitoraggio del decadimento prestazionale."
        ),
        accent_color="#06b6d4",
    )

    returns_df = results.get("returns_df") if isinstance(results, dict) else None
    if returns_df is None or (isinstance(returns_df, pd.DataFrame) and returns_df.empty):
        tickers = (
            list(pos["ticker"].dropna().unique())
            if isinstance(pos, pd.DataFrame) and not pos.empty and "ticker" in pos.columns
            else ["SPY", "QQQ", "TLT", "GLD"]
        )
        if len(tickers) < 2:
            tickers = ["SPY", "QQQ", "TLT", "GLD"]
        np.random.seed(42)
        dates = pd.date_range(end=datetime.now(), periods=500, freq="B")
        synth_data = {t: np.random.normal(0.0004, 0.012, len(dates)) for t in tickers}
        returns_df = pd.DataFrame(synth_data, index=dates)

    if not has_portfolio and (returns_df is None or returns_df.empty):
        st.warning("⚠️ Carica prima un portafoglio nella Control Room con serie storiche per eseguire il Walk-Forward Backtesting.")
    else:
        from core.walk_forward_engine import run_walk_forward_backtest

        wfo_c1, wfo_c2, wfo_c3 = st.columns(3)
        with wfo_c1:
            wfo_strat = st.selectbox(
                "Strategia Quantitativa:",
                options=["equal_weight", "hrp", "erc", "max_sharpe"],
                format_func=lambda x: {
                    "equal_weight": "1/N Equal Weight (Naive Benchmark)",
                    "hrp": "Hierarchical Risk Parity (HRP)",
                    "erc": "Equal Risk Contribution (ERC Spinu)",
                    "max_sharpe": "Maximum Sharpe Ratio (Ledoit-Wolf)",
                }.get(x, x),
            )
            wfo_train = st.slider("Finestra di Training (In-Sample Giorni):", min_value=63, max_value=504, value=252, step=21)
        with wfo_c2:
            wfo_test = st.slider("Finestra di Test (Out-of-Sample Giorni):", min_value=21, max_value=126, value=63, step=21)
            wfo_reb_cost = st.slider("Costo Commissionale Ribilanciamento (bps):", min_value=0.0, max_value=50.0, value=10.0, step=2.5)
        with wfo_c3:
            wfo_slip = st.slider("Slippage d'Esecuzione (bps):", min_value=0.0, max_value=30.0, value=5.0, step=2.5)
            wfo_bid_ask = st.slider("Bid-Ask Spread Drag (bps):", min_value=0.0, max_value=30.0, value=5.0, step=2.5)

        if st.button("🚀 Esegui Walk-Forward Backtesting", key="btn_run_wfo", use_container_width=True, type="primary"):
            with st.spinner("Esecuzione backtest rolling multi-finestra..."):
                try:
                    wfo_res = run_walk_forward_backtest(
                        returns_df=returns_df,
                        strategy_name=wfo_strat,
                        train_window_days=wfo_train,
                        test_window_days=wfo_test,
                        rebalance_cost_bps=wfo_reb_cost,
                        slippage_bps=wfo_slip,
                        bid_ask_bps=wfo_bid_ask,
                    )
                    st.session_state["wfo_last_result"] = wfo_res
                except Exception as exc:
                    st.error(f"Errore durante l'esecuzione del Walk-Forward: {exc}")

        if "wfo_last_result" in st.session_state:
            res_wfo = st.session_state["wfo_last_result"]
            st.markdown("##### 📈 Risultati Rolling Out-of-Sample")
            st.dataframe(res_wfo["summary_table"], use_container_width=True, hide_index=True)

            cum_df = res_wfo["cumulative_returns"]
            if not cum_df.empty:
                fig_cum = px.line(cum_df, title="Curve Rendimento Cumulativo OOS vs Buy & Hold (Netto Frizioni)")
                fig_cum = apply_plotly_theme(fig_cum)
                st.plotly_chart(fig_cum, use_container_width=True)

            dd_df = res_wfo["drawdown_series"]
            if not dd_df.empty:
                fig_dd = px.area(dd_df * 100.0, title="Profilo di Drawdown OOS (%)")
                fig_dd = apply_plotly_theme(fig_dd)
                st.plotly_chart(fig_dd, use_container_width=True)

# ── TAB: BARRA STRUCTURAL MULTI-FACTOR RISK MODEL ───────────────────
elif active_quant_tab == "🏛️ Barra Structural Multi-Factor Risk":
    st.markdown("#### 🏛️ Barra-Style Structural Multi-Asset Risk Model (MSCI GEM3/USE4)")
    st.caption("Decomposizione formale: $\\boldsymbol{\\Sigma} = \\mathbf{X}\\boldsymbol{\\Sigma}_F\\mathbf{X}^T + \\boldsymbol{\\Delta}_\\epsilon$ con attribuzione Euleriana MCTR/PCTR.")

    render_institutional_info_box(
        title="Barra-Style Structural Multi-Asset Risk Model (MSCI GEM3/USE4) & Euler PCTR",
        badge="FACTOR RISK • BARRA STRUCTURAL",
        summary_html=(
            "Decomposizione formale della covarianza di portafoglio "
            "$\\boldsymbol{\\Sigma} = \\mathbf{X}\\boldsymbol{\\Sigma}_F\\mathbf{X}^T + \\boldsymbol{\\Delta}_\\epsilon$ "
            "in fattori sistemici di Stile (Value, Momentum, Quality, Low Vol, Size) e Macro "
            "con attribuzione Euleriana esatta al 100% (Marginal & Percentage Contribution to Risk)."
        ),
        math_html=(
            "Attribuzione Euleriana del Rischio (Teorema di Eulero per funzioni omogenee di grado 1):<br>"
            "<code>σ_p = w' Σ w / σ_p = Σ_i w_i · MCTR_i  |  PCTR_i = (w_i · MCTR_i) / σ_p  ⇒  Σ_i PCTR_i = 100%</code><br>"
            "Fattoriale: <code>FactorRisk = w' X Σ_F X' w  |  SpecificRisk = w' Δ_ε w</code>"
        ),
        chart_guide_html=(
            "• <b>Ripartizione Rischio Sistemico vs Idiosincratico</b>: identifica quanta varianza è spiegata dai fattori di mercato e quanto dal rischio specifico.<br>"
            "• <b>Factor Loadings & Attribuzione</b>: mostra quali fattori guidano la volatilità del portafoglio."
        ),
        regulatory_html=(
            "• <b>BCBS 365 (FRTB-SBA)</b>: decomposizione dei fattori di rischio per la sensibilità Delta, Vega e Curvature.<br>"
            "• <b>Active Risk Budgeting</b>: allocazione del tracking error e monitoraggio dei limiti di esposizione fattoriale."
        ),
        accent_color="#3b82f6",
    )

    from core.barra_risk_model import compute_barra_structural_risk

    b_ret_df = results.get("returns_df") if isinstance(results, dict) else None
    if b_ret_df is None or (isinstance(b_ret_df, pd.DataFrame) and b_ret_df.empty):
        tickers = ["AAPL", "MSFT", "BTP-10Y", "XOM", "JNJ"]
        np.random.seed(42)
        dates = pd.date_range(end=datetime.now(), periods=500, freq="B")
        b_ret_df = pd.DataFrame({t: np.random.normal(0.0004, 0.012, len(dates)) for t in tickers}, index=dates)

    if st.button("🚀 Esegui Decomposizione Fattoriale Barra", key="btn_run_barra", type="primary", use_container_width=True):
        with st.spinner("Calibrazione factor loadings e covarianza strutturale..."):
            try:
                b_res = compute_barra_structural_risk(asset_returns=b_ret_df)
                st.session_state["barra_last_result"] = b_res
            except Exception as e:
                st.error(f"Errore durante l'esecuzione del modello Barra: {e}")

    if "barra_last_result" in st.session_state:
        res_b = st.session_state["barra_last_result"]
        bk1, bk2, bk3, bk4 = st.columns(4)
        with bk1:
            metric_card("Volatilita Totale", f"{res_b['volatility_total_annual']*100:.2f}%", delta="Annualizzata 252d", delta_color="normal")
        with bk2:
            metric_card("Rischio Sistemico (Fattoriale)", f"{res_b['factor_risk_contribution_pct']:.1f}%", delta=f"Vol: {res_b['volatility_factor_annual']*100:.2f}%", delta_color="normal")
        with bk3:
            metric_card("Rischio Idiosincratico", f"{res_b['specific_risk_contribution_pct']:.1f}%", delta=f"Vol: {res_b['volatility_specific_annual']*100:.2f}%", delta_color="normal")
        with bk4:
            metric_card("Euler Sum PCTR", f"{res_b['euler_sum_pctr']:.2f}%", delta="Verifica Eulero (100%)", delta_color="normal")

        st.markdown("##### 🧩 Decomposizione del Rischio per Fattore di Stile & Macro")
        fact_df = pd.DataFrame(res_b["factor_attribution"]).T.reset_index().rename(columns={"index": "Fattore"})
        st.dataframe(fact_df, use_container_width=True, hide_index=True)


# ── TAB: DCC-GARCH & VINE COPULA DYNAMIC TAIL RISK ──────────────────
elif active_quant_tab == "🌊 DCC-GARCH & Vine Copula":
    st.markdown("#### 🌊 DCC-GARCH Dynamic Correlation & Vine Copula Tail Risk")
    st.caption("Modellazione tempo-variante $R_t$ (Engle 2002) e dipendenza asimmetrica di coda tramite Regular Vine Copula.")

    render_institutional_info_box(
        title="DCC-GARCH Dynamic Conditional Correlation (Engle 2002) & Vine Copula Extreme Risk",
        badge="DYNAMIC VOLATILITY • ASYMMETRIC COPULA",
        summary_html=(
            "Modellazione tempo-variante della matrice di correlazione condizionata $R_t$ secondo la metodologia "
            "di Robert Engle (premio Nobel 2003) combinata con Regular Vine Copula per catturare la dipendenza asimmetrica "
            "di coda estrema (Crash Dependence)."
        ),
        math_html=(
            "Dinamica della quasi-correlazione $Q_t$ e standardizzazione $R_t$:<br>"
            "<code>Q_t = (1 - α - β) Q_bar + α (ε_{t-1} ε'_{t-1}) + β Q_{t-1}  |  R_t = diag(Q_t)^{-1/2} Q_t diag(Q_t)^{-1/2}</code><br>"
            "Copula C-Vine / D-Vine: decomposizione della densità congiunta in alberi di copule bivariate condizionate $c_{ij|D}$."
        ),
        chart_guide_html=(
            "• <b>DCC Alpha & Beta</b>: $\\alpha$ misura la sensibilità agli shock improvvisi, $\\beta$ la persistenza della correlazione ($\alpha + \beta < 1$).<br>"
            "• <b>Dynamic VaR/CVaR T+1</b>: incorpora il clustering della volatilità rispetto alle metriche statiche."
        ),
        regulatory_html=(
            "• <b>Basilea IV Stressed Expected Shortfall</b>: cattura l'incremento di correlazione sistemica durante le fasi di stress estremo.<br>"
            "• <b>Tail Risk Hedging</b>: dimensionamento delle coperture asimmetriche su opzioni e swap."
        ),
        accent_color="#ec4899",
    )

    from core.dcc_garch_engine import compute_dcc_garch_extreme_risk

    d_ret_df = results.get("returns_df") if isinstance(results, dict) else None
    if d_ret_df is None or (isinstance(d_ret_df, pd.DataFrame) and d_ret_df.empty):
        tickers = ["SPY", "QQQ", "TLT", "GLD"]
        np.random.seed(42)
        dates = pd.date_range(end=datetime.now(), periods=500, freq="B")
        d_ret_df = pd.DataFrame({t: np.random.normal(0.0004, 0.012, len(dates)) for t in tickers}, index=dates)

    if st.button("🚀 Calibra DCC-GARCH & Simula Vine Copula", key="btn_run_dcc", type="primary", use_container_width=True):
        with st.spinner("Calibrazione GARCH(1,1) multivariata e ottimizzazione DCC..."):
            try:
                d_res = compute_dcc_garch_extreme_risk(returns_df=d_ret_df, n_mc_sims=3000)
                st.session_state["dcc_last_result"] = d_res
            except Exception as e:
                st.error(f"Errore durante l'esecuzione DCC-GARCH: {e}")

    if "dcc_last_result" in st.session_state:
        res_d = st.session_state["dcc_last_result"]
        dk1, dk2, dk3, dk4 = st.columns(4)
        with dk1:
            metric_card("DCC Alpha (Shock)", f"{res_d['dcc_alpha']:.4f}", delta=f"Beta: {res_d['dcc_beta']:.4f}", delta_color="normal")
        with dk2:
            metric_card("Persistenza Dinamica", f"{res_d['persistence']:.4f}", delta="< 1.0 Stazionario", delta_color="normal")
        with dk3:
            metric_card("Dynamic VaR 99% (T+1)", f"{res_d['dynamic_var_99_t1']*100:.2f}%", delta=f"Static Normal: {res_d['static_normal_var_99']*100:.2f}%", delta_color="inverse")
        with dk4:
            metric_card("Dynamic CVaR 99% (T+1)", f"{res_d['dynamic_cvar_99_t1']*100:.2f}%", delta=f"Lower Tail Dep: {res_d['tail_dependence_lower']:.2f}", delta_color="inverse")

        st.markdown("##### 🌐 Matrice di Correlazione Prevista (T+1)")
        st.dataframe(pd.DataFrame(res_d["forecast_correlation_t1"]), use_container_width=True)


# ── TAB: SABR & LOCAL VOLATILITY SURFACE 3D ─────────────────────────
elif active_quant_tab == "🔮 SABR & Local Volatility Surface 3D":
    st.markdown("#### 🔮 SABR Volatility Smile Calibration & Dupire Local Volatility Surface (3D)")
    st.caption("Modellazione stocastica della volatilità secondo Hagan et al. (2002) e inversione PDE di Dupire (1994) $\\sigma_{\\text{loc}}(K, T)$.")

    from core.sabr_local_vol_engine import compute_sabr_and_local_vol_surface
    from core.ux_institutional_hub import render_institutional_info_box

    render_institutional_info_box(
        title="SABR Volatility Smile (Hagan 2002) & Dupire Local Volatility PDE (1994)",
        badge="VOLATILITY DESK • SABR / DUPIRE",
        summary_html=(
            "Il modello <b>SABR (Stochastic Alpha Beta Rho)</b> modella congiuntamente la dinamica del prezzo forward $dF_t = \\alpha_t F_t^\\beta dW_1$ "
            "e della volatilità stocastica $d\\alpha_t = \\nu \\alpha_t dW_2$, mentre l'inversione PDE di <b>Dupire (1994)</b> ricava l'unica funzione deterministica "
            "$\\sigma_{\\text{loc}}(K, T)$ coerente con tutti i prezzi delle opzioni europee quotate."
        ),
        math_html=(
            "Espansione asintotica di Hagan et al. (2002) e formula di Dupire:<br>"
            "<code>σ_loc²(K, T) = [ ∂C/∂T + (r - q) K ∂C/∂K + q C ] / [ ½ K² ∂²C/∂K² ]</code><br>"
            "I 4 parametri $(\\alpha, \\beta, \\rho, \\nu)$ controllano rispettivamente il livello ATM, il backbone di elasticità CEV, "
            "lo skew direzionale (correlazione spot-vol) e la curvatura delle ali (vol-of-vol)."
        ),
        chart_guide_html=(
            "• <b>Superficie 3D Dupire Local Vol</b>: mostra la volatilità istantanea locale $\\sigma_{\\text{loc}}(K, T)$ utilizzabile nei pricing engine Monte Carlo per opzioni esotiche path-dependent.<br>"
            "• <b>Griglia Tabellare SABR vs Dupire</b>: confronta la volatilità implicita Black-Scholes (media integrata lungo il percorso) con la volatilità locale puntuale."
        ),
        regulatory_html=(
            "• <b>Exotic Desk & Barrier Options</b>: la volatilità locale di Dupire è lo standard di mercato per il pricing coerente di Barrier Options, Autocallable e Cliquet.<br>"
            "• <b>IPV & Prudent Valuation (EBA RTS)</b>: calibrazione inter-strike priva di arbitraggio statico per la verifica indipendente dei prezzi (Independent Price Verification)."
        ),
    )

    c_sb1, c_sb2, c_sb3 = st.columns(3)
    with c_sb1:
        f0_in = st.number_input("Prezzo Forward / Spot ($F_0$):", min_value=1.0, value=100.0, step=5.0, key="sabr_f0_in")
        asset_type = st.selectbox("Asset Class Underlying:", ["Equity / Index (Beta = 0.70)", "Fixed Income / Rates (Beta = 0.50)", "FX / Normal (Beta = 1.00)"], key="sabr_asset_sel")
        beta_val = 0.70 if "Equity" in asset_type else (0.50 if "Rates" in asset_type else 1.00)
    with c_sb2:
        atm_vol_pct = st.slider("Volatilità ATM Iniziale (%):", min_value=5.0, max_value=80.0, value=20.0, step=1.0, key="sabr_atm_vol_in")
        skew_preset = st.select_slider("Skew / Asimmetria di Coda (Correlation $\\rho$):", options=[-0.75, -0.50, -0.25, 0.0, 0.25, 0.50], value=-0.25, key="sabr_rho_slider")
    with c_sb3:
        vol_of_vol = st.slider("Volatilità della Volatilità ($\\nu$):", min_value=0.10, max_value=1.50, value=0.45, step=0.05, key="sabr_nu_slider")
        maturities_preset = st.multiselect("Scadenze Opzioni (Anni):", [0.25, 0.50, 1.00, 2.00, 3.00, 5.00], default=[0.25, 0.50, 1.00, 2.00], key="sabr_mat_multi")

    if not maturities_preset:
        maturities_preset = [0.25, 0.50, 1.00, 2.00]

    if st.button("🚀 Calibra SABR & Calcola Superficie Dupire 3D", key="btn_run_sabr", type="primary", use_container_width=True):
        with st.spinner("Calibrazione parametri SABR ed inversione PDE Dupire..."):
            try:
                strikes_arr = [round(f0_in * mult, 2) for mult in [0.70, 0.80, 0.90, 0.95, 1.0, 1.05, 1.10, 1.20, 1.30]]
                market_vols_matrix = []
                for T in maturities_preset:
                    row = []
                    for K in strikes_arr:
                        log_m = np.log(K / f0_in)
                        vol_k = (atm_vol_pct / 100.0) + skew_preset * 0.15 * log_m + vol_of_vol * 0.10 * (log_m ** 2) / np.sqrt(T)
                        row.append(max(0.04, vol_k))
                    market_vols_matrix.append(row)

                sabr_res = compute_sabr_and_local_vol_surface(
                    f0=f0_in,
                    strikes=strikes_arr,
                    maturities=maturities_preset,
                    market_vols=market_vols_matrix,
                    beta=beta_val,
                )
                st.session_state["sabr_last_result"] = sabr_res
            except Exception as e:
                st.error(f"Errore durante il calcolo SABR/Dupire: {e}")

    if "sabr_last_result" in st.session_state:
        s_res = st.session_state["sabr_last_result"]
        calib = s_res["calibrated_sabr_parameters"]
        sk1, sk2, sk3, sk4 = st.columns(4)
        with sk1:
            metric_card("SABR Alpha (Vol Iniziale)", f"{calib['alpha']:.4f}", delta="Livello ATM", delta_color="normal")
        with sk2:
            metric_card("SABR Rho (Correlazione Skew)", f"{calib['rho']:.4f}", delta="Inclinazione Smile", delta_color="normal")
        with sk3:
            metric_card("SABR Nu (Vol of Vol)", f"{calib['nu']:.4f}", delta="Curvatura Convexity", delta_color="normal")
        with sk4:
            metric_card("SABR Beta (Elasticità)", f"{calib['beta']:.2f}", delta=asset_type.split()[0], delta_color="normal")

        st.markdown("##### 🌐 Superficie di Volatilità Locale di Dupire $\\sigma_{\\text{loc}}(K, T)$ [3D Mesh]")
        loc_df = pd.DataFrame(s_res["local_vol_surface_pct"])

        z_data = loc_df.values
        x_strikes = [float(c.replace("K_", "")) for c in loc_df.columns]
        y_maturities = [float(idx.replace("T_", "").replace("y", "")) for idx in loc_df.index]

        fig_3d = go.Figure(data=[go.Surface(
            z=z_data,
            x=x_strikes,
            y=y_maturities,
            colorscale="Viridis",
            colorbar=dict(title="Local Vol (%)")
        )])
        fig_3d.update_layout(
            title="Superficie 3D Dupire Local Volatility σ_loc(K, T)",
            scene=dict(
                xaxis_title="Strike (K)",
                yaxis_title="Maturity (Anni T)",
                zaxis_title="Local Vol (%)"
            ),
            margin=dict(l=10, r=10, b=10, t=40),
            height=550,
        )
        st.plotly_chart(fig_3d, use_container_width=True)

        st.markdown("##### 📊 Griglia Tabellare: Volatilità Implicita SABR vs Volatilità Locale")
        tab_v_sabr, tab_v_loc = st.tabs(["🔮 Implied Vol SABR (%)", "🌊 Local Vol Dupire (%)"])
        with tab_v_sabr:
            st.dataframe(pd.DataFrame(s_res["implied_vol_surface_pct"]), use_container_width=True)
        with tab_v_loc:
            st.dataframe(loc_df, use_container_width=True)



# ── TAB: HESTON FFT STOCHASTIC VOLATILITY ─────────────────────────────
elif active_quant_tab == "⚡ Heston FFT Stochastic Volatility":
    st.markdown("#### ⚡ Heston (1993) Stochastic Volatility & Carr-Madan (1999) FFT Calibration")
    st.caption("Prezzatura Fourier ad alte prestazioni per opzioni europee, test di positività varianza di Feller e calibrazione L-BFGS-B.")

    from core.heston_fft_engine import compute_heston_surface_and_calibration
    from core.ux_institutional_hub import render_institutional_info_box

    render_institutional_info_box(
        title="Heston (1993) Stochastic Volatility & Carr-Madan (1999) Fast Fourier Transform",
        badge="FOURIER PRICING • HESTON FFT",
        summary_html=(
            "Il modello di <b>Heston (1993)</b> descrive la varianza istantanea $v_t$ tramite un processo CIR mean-reverting "
            "$dv_t = \\kappa(\\theta - v_t)dt + \\sigma_v \\sqrt{v_t}dW_2$, prezzando intere catene di opzioni in millisecondi tramite "
            "l'inversione <b>Fast Fourier Transform (Carr-Madan 1999)</b> della funzione caratteristica chiusa."
        ),
        math_html=(
            "Condizione di stretta positività di Feller e formula di Carr-Madan:<br>"
            "<code>2 κ θ &gt; σ_v²  (Condizione di Feller: v_t &gt; 0 q.c.)</code><br>"
            "<code>C(k) = (e^(-α k) / π) ∫_0^∞ Re[ e^(-i u k) ψ_T(u) ] du</code><br>"
            "dove $\\psi_T(u)$ è la trasformata di Fourier smorzata espressa tramite la funzione caratteristica analitica di Heston."
        ),
        chart_guide_html=(
            "• <b>Condizione di Feller</b>: se soddisfatta ($2\\kappa\\theta > \\sigma_v^2$), il processo di varianza non tocca mai lo zero.<br>"
            "• <b>Superficie 3D Heston IV</b>: mostra come $\\rho < 0$ generi lo skew negativo equity e $\\sigma_v$ controlli la convessità (kurtosi) a breve e medio termine."
        ),
        regulatory_html=(
            "• <b>Forward-Starting & Cliquet Options</b>: contrariamente a Dupire Local Vol, Heston preserva la dinamica stocastica dello smile forward.<br>"
            "• <b>Model Risk Audit</b>: calibrazione L-BFGS-B regolarizzata per evitare l'instabilità numerica del ramo complesso del logaritmo (Albrecher et al. 2007)."
        ),
    )

    h_col1, h_col2, h_col3 = st.columns(3)
    with h_col1:
        h_s0 = st.number_input("Prezzo Spot S0:", min_value=1.0, value=100.0, step=5.0, key="heston_s0")
        h_r = st.number_input("Tasso Risk-Free (r):", min_value=0.0, max_value=0.20, value=0.03, step=0.005, key="heston_r")
        h_q = st.number_input("Dividend Yield (q):", min_value=0.0, max_value=0.15, value=0.015, step=0.005, key="heston_q")
    with h_col2:
        h_v0 = st.slider("Varianza Iniziale v0 (vol ~20%):", min_value=0.01, max_value=0.25, value=0.04, step=0.01, key="heston_v0")
        h_kappa = st.slider("Velocità Mean Reversion (κ):", min_value=0.2, max_value=8.0, value=2.0, step=0.2, key="heston_kappa")
        h_theta = st.slider("Varianza a Lungo Termine (θ):", min_value=0.01, max_value=0.25, value=0.04, step=0.01, key="heston_theta")
    with h_col3:
        h_sigma_v = st.slider("Volatilità della Varianza (σ_v):", min_value=0.05, max_value=1.0, value=0.30, step=0.05, key="heston_sigmav")
        h_rho = st.slider("Correlazione Prezzo-Varianza (ρ):", min_value=-0.95, max_value=0.0, value=-0.65, step=0.05, key="heston_rho")

    # Live Feller Check metric
    feller_denom = 2.0 * h_kappa * h_theta
    feller_stat = (h_sigma_v ** 2) / feller_denom if feller_denom > 0 else 999.0
    feller_pass = h_sigma_v ** 2 < feller_denom

    f_col1, f_col2, f_col3 = st.columns(3)
    with f_col1:
        metric_card("Condizione di Feller (2κθ > σ_v²)", "Soddisfatta ✅" if feller_pass else "Violata ❌", delta=f"Ratio: {feller_stat:.3f}", positive=feller_pass)
    with f_col2:
        metric_card("2κθ (Drift Variational)", f"{feller_denom:.4f}", delta="Mean Reversion Barrier", positive=True)
    with f_col3:
        metric_card("σ_v² (Diffusion Variance)", f"{(h_sigma_v**2):.4f}", delta="Vol-of-Vol Dispersion", positive=True)

    if st.button("🚀 Calcola Superficie Carr-Madan FFT & Calibra", key="btn_run_heston", type="primary", use_container_width=True):
        with st.spinner("Esecuzione trasformata veloce di Fourier (Carr-Madan 1999)..."):
            custom_p = {"v0": h_v0, "kappa": h_kappa, "theta": h_theta, "sigma_v": h_sigma_v, "rho": h_rho}
            heston_res = compute_heston_surface_and_calibration(
                s0=h_s0, r=h_r, q=h_q, custom_params=custom_p
            )
            st.session_state["heston_last_result"] = heston_res

    if "heston_last_result" in st.session_state:
        h_data = st.session_state["heston_last_result"]
        surf = h_data["volatility_surface"]

        st.markdown("##### 📈 Superficie di Volatilità Implicita Heston 3D Mesh")
        mat_arr = surf["maturities"]
        k_arr = surf["strikes"]
        iv_matrix = np.array(surf["iv_matrix"]) * 100.0

        fig_h3d = go.Figure(data=[go.Surface(
            z=iv_matrix,
            x=k_arr,
            y=mat_arr,
            colorscale="Plasma",
            colorbar=dict(title="Implied Vol (%)")
        )])
        fig_h3d.update_layout(
            title="Heston Analytical Implied Volatility Surface σ_imp(K, T)",
            scene=dict(
                xaxis_title="Strike (K)",
                yaxis_title="Scadenza T (Anni)",
                zaxis_title="Implied Vol (%)"
            ),
            margin=dict(l=10, r=10, b=10, t=40),
            height=500,
        )
        st.plotly_chart(fig_h3d, use_container_width=True)

        st.markdown("##### 📋 Tabella Quotazioni Prezzi & Volatilità Implicita")
        pts_df = pd.DataFrame(surf["surface_points"])
        pts_df["implied_vol_pct"] = (pts_df["implied_vol"] * 100.0).round(2)
        st.dataframe(pts_df[["maturity_years", "strike", "moneyness", "call_price", "implied_vol_pct"]], use_container_width=True)


# ── TAB: BAYESIAN BLACK-LITTERMAN OPTIMIZATION ───────────────────────
elif active_quant_tab == "⚖️ Bayesian Black-Litterman Optimization":
    st.markdown("#### ⚖️ Bayesian Black-Litterman Model with Idzorek Confidence Weighting")
    st.caption("Pesi di equilibrio di mercato (reverse optimization), integrazione di view soggettive e matrice Omega calibrata empiricamente.")

    from core.black_litterman_engine import compute_black_litterman_allocation
    from core.ux_institutional_hub import render_institutional_info_box

    render_institutional_info_box(
        title="Bayesian Black-Litterman Allocation & Idzorek (2005) Confidence Calibration",
        badge="ASSET ALLOCATION • BLACK-LITTERMAN",
        summary_html=(
            "Il modello <b>Black-Litterman (1992)</b> supera l'instabilità estrema dell'ottimizzazione media-varianza classica di Markowitz "
            "combinando tramite aggiornamento Bayesiano i <b>rendimenti impliciti di equilibrio CAPM ($\\Pi = \\lambda \\Sigma w_{\\text{mkt}}$)</b> "
            "con le view soggettive (assolute o relative) del Comitato Investimenti calibrate secondo <b>Idzorek (2005)</b>."
        ),
        math_html=(
            "Vettore dei rendimenti attesi a posteriori $\\mu_{\\text{BL}}$ e covarianza posterior $\\Sigma_{\\text{BL}}$:<br>"
            "<code>Π = λ Σ w_mkt  |  μ_BL = [ (τΣ)^(-1) + P^T Ω^(-1) P ]^(-1) [ (τΣ)^(-1) Π + P^T Ω^(-1) Q ]</code><br>"
            "La matrice diagonale d'incertezza delle view $\\Omega$ viene calibrata direttamente dal livello percentuale di confidenza $c_k \\in (0, 1)$ espresso dal gestore."
        ),
        chart_guide_html=(
            "• <b>Confronto Allocazioni</b>: evidenzia gli scostamenti attivi (Active Tilt) del portafoglio ottimo rispetto ai pesi di capitalizzazione del benchmark.<br>"
            "• <b>Information Ratio & Tracking Error</b>: misura l'efficienza dell'extrarendimento generato dalle view attive per unità di rischio relativo assunto."
        ),
        regulatory_html=(
            "• <b>Strategic & Tactical Asset Allocation (SAA / TAA)</b>: evita portafogli concentrati o corner solutions non investibili.<br>"
            "• <b>Investment Committee Governance</b>: separa in modo trasparente e verificabile il consenso neutrale di mercato dalle scommesse attive del gestore."
        ),
    )

    bl_c1, bl_c2, bl_c3 = st.columns(3)
    with bl_c1:
        bl_aversion = st.slider("Avversione al Rischio (λ):", min_value=1.0, max_value=8.0, value=3.0, step=0.5, key="bl_lambda")
    with bl_c2:
        bl_tau = st.slider("Incertezza del Prior (τ):", min_value=0.01, max_value=0.20, value=0.05, step=0.01, key="bl_tau")
    with bl_c3:
        bl_max_w = st.slider("Peso Massimo per Asset (%):", min_value=20, max_value=60, value=40, step=5, key="bl_maxw") / 100.0

    st.markdown("##### 👁️ Configurazione View Soggettive dell'Investitore")
    v_col1, v_col2 = st.columns(2)
    with v_col1:
        st.info("📌 **View 1 (Assoluta)**: US Equities sovraperformerà con rendimento annuo target:")
        v1_ret = st.number_input("Rendimento Atteso US Equities (%):", min_value=1.0, max_value=25.0, value=9.5, step=0.5, key="v1_ret") / 100.0
        v1_conf = st.slider("Livello di Confidenza View 1 (Idzorek %):", min_value=10, max_value=95, value=70, step=5, key="v1_conf") / 100.0
    with v_col2:
        st.info("📌 **View 2 (Relativa)**: EM Equities sovraperformerà EU Equities con spread annuo di:")
        v2_ret = st.number_input("Spread EM vs EU (%):", min_value=0.5, max_value=10.0, value=3.0, step=0.5, key="v2_ret") / 100.0
        v2_conf = st.slider("Livello di Confidenza View 2 (Idzorek %):", min_value=10, max_value=95, value=65, step=5, key="v2_conf") / 100.0

    if st.button("🚀 Esegui Ottimizzazione Black-Litterman", key="btn_run_bl", type="primary", use_container_width=True):
        with st.spinner("Calcolo rendimenti di equilibrio, aggiornamento Bayesiano e SLSQP..."):
            custom_views = [
                {"view_type": "absolute", "assets": ["US_Equities"], "weights": [1.0], "expected_return": v1_ret, "confidence": v1_conf},
                {"view_type": "relative", "assets": ["EM_Equities", "EU_Equities"], "weights": [1.0, -1.0], "expected_return": v2_ret, "confidence": v2_conf}
            ]
            bl_res = compute_black_litterman_allocation(
                risk_aversion=bl_aversion,
                tau=bl_tau,
                max_weight=bl_max_w,
                views_data=custom_views,
            )
            st.session_state["bl_last_result"] = bl_res

    if "bl_last_result" in st.session_state:
        b_res = st.session_state["bl_last_result"]
        metrics = b_res["portfolio_metrics"]

        bm1, bm2, bm3, bm4 = st.columns(4)
        with bm1:
            metric_card("Rendimento Atteso Ptf", f"{metrics['portfolio_expected_return']*100:.2f}%", delta=f"Benchmark: {metrics['benchmark_expected_return']*100:.2f}%", positive=metrics['portfolio_expected_return'] >= metrics['benchmark_expected_return'])
        with bm2:
            metric_card("Volatilità Posterior", f"{metrics['portfolio_volatility']*100:.2f}%", delta=f"Benchmark: {metrics['benchmark_volatility']*100:.2f}%", positive=metrics['portfolio_volatility'] <= metrics['benchmark_volatility'])
        with bm3:
            metric_card("Sharpe Ratio Ptf", f"{metrics['portfolio_sharpe']:.2f}", delta=f"BM: {metrics['benchmark_sharpe']:.2f}", positive=metrics['portfolio_sharpe'] >= metrics['benchmark_sharpe'])
        with bm4:
            metric_card("Information Ratio", f"{metrics['information_ratio']:.2f}", delta=f"Tracking Error: {metrics['tracking_error']*100:.2f}%", positive=metrics['information_ratio'] > 0)

        st.markdown("##### ⚖️ Confronto Allocazioni: Portafoglio Ottimo vs Benchmark di Mercato")
        sum_df = pd.DataFrame(b_res["summary_table"])

        fig_bl = go.Figure()
        fig_bl.add_trace(go.Bar(
            name="Market Benchmark (%)",
            x=sum_df["asset"],
            y=sum_df["market_weight_pct"],
            marker_color="#94a3b8"
        ))
        fig_bl.add_trace(go.Bar(
            name="Black-Litterman Optimal (%)",
            x=sum_df["asset"],
            y=sum_df["optimal_weight_pct"],
            marker_color="#6366f1"
        ))
        fig_bl.update_layout(
            barmode="group",
            title="Allocazione di Portafoglio Black-Litterman con Tilt Attivi",
            xaxis_title="Classe di Attivo",
            yaxis_title="Peso (%)",
            height=400,
            margin=dict(l=10, r=10, b=10, t=40)
        )
        st.plotly_chart(fig_bl, use_container_width=True)

        st.markdown("##### 📋 Tabella Dettagliata Rendimenti & Tilt Attivi")
        st.dataframe(sum_df, use_container_width=True)


# ── TAB: MULTI-CURVE OIS DISCOUNTING & DUAL-CURVE IRS ───────────────────────
elif active_quant_tab == "📈 Multi-Curve OIS & Dual-Curve IRS":
    st.markdown("#### 📈 Post-LIBOR Multi-Curve OIS Discounting (€STR / SOFR) & Dual-Curve Bootstrapping")
    st.caption("Bootstrapping disaccoppiato della curva di sconto OIS risk-free (€STR / SOFR) e della curva forward Ibor (Euribor 6M / Term SOFR), interpolazione Pchip sui log-discount factors, pricing IRS dual-curve e Tenor Basis Swap.")
    render_institutional_info_box(
        title="Architettura Multi-Curve Post-LIBOR: OIS Discounting (€STR / SOFR) & Dual-Curve IRS",
        badge="OIS DISCOUNTING • DUAL-CURVE • TENOR BASIS",
        summary="Separazione rigorosa tra la curva di attualizzazione collateralizzata OIS (€STR/SOFR) e la curva di proiezione dei flussi variabili (Euribor 6M / Term SOFR).",
        math_foundation="Dalla crisi del 2008 e dalla riforma dei benchmark IBOR, il valore attuale di un Interest Rate Swap collateralizzato CSA si calcola scontando con fattori $D_{\\text{OIS}}(0, T_i)$ estratti da €STR/SOFR e proiettando i tassi forward $F_{6M}(T_{i-1}, T_i)$ su una curva separata tramite interpolazione monotona Pchip sui log-discount factors.",
        kpi_guide="• <b>Par Swap Rate Dual-Curve</b>: tasso fisso che azzera l'NPV multi-curva.<br>• <b>DV01 (€/bp)</b>: variazione di valore per +1 bp parallelo.<br>• <b>Fair Tenor Basis (6M vs 3M)</b>: premio di liquidità e credito interbancario tra scadenze 6M e 3M.",
        operational_impact="Standard obbligatorio per le banche soggette a vigilanza BCE/Fed, clearing house (LCH SwapClear, Eurex Clearing) e valutazione mark-to-market IFRS 13 dei derivati su tassi.",
        accent_color="#10b981",
    )

    from core.multicurve_engine import compute_multicurve_bootstrapping

    _live_nav_q = max(1_000.0, round(float(live_bind.get("total_nav_eur", 64_233.0)), 2)) if live_bind.get("autobind_enabled") else 10_000_000.0
    mc_c1, mc_c2, mc_c3, mc_c4 = st.columns(4)
    with mc_c1:
        mc_ccy = st.selectbox("Valuta di Riferimento:", ["EUR", "USD"], index=0, key="mc_ccy_sel")
    with mc_c2:
        mc_notional = st.number_input("Nozionale IRS (€/$):", min_value=1_000.0, value=float(_live_nav_q), step=10_000.0, key="mc_notional_in")
    with mc_c3:
        mc_fixed = st.slider("Tasso Fisso IRS (%):", min_value=0.50, max_value=6.50, value=3.10, step=0.05, key="mc_fixed_in") / 100.0
    with mc_c4:
        mc_mat = st.slider("Scadenza IRS (Anni):", min_value=1.0, max_value=30.0, value=5.0, step=1.0, key="mc_mat_in")

    mc_res = compute_multicurve_bootstrapping(
        currency=mc_ccy,
        notional=mc_notional,
        irs_fixed_rate=mc_fixed,
        irs_maturity_years=mc_mat,
    )
    irs_info = mc_res["irs_valuation"]
    tbs_info = mc_res["basis_swap_valuation"]

    m_k1, m_k2, m_k3, m_k4 = st.columns(4)
    with m_k1:
        metric_card("Par Swap Rate (Dual-Curve)", f"{float(irs_info['par_swap_rate_pct']):.3f}%", delta=f"Adj Multi-Curve: {fmt_eur(float(irs_info['multicurve_valuation_adjustment_eur']))}", positive=True)
    with m_k2:
        metric_card("NPV Swap (Multi-Curve)", fmt_eur(float(irs_info["multicurve_npv_eur"])), delta=f"DV01: {fmt_eur(float(irs_info['dv01_eur']))}", positive=float(irs_info["multicurve_npv_eur"]) >= 0)
    with m_k3:
        metric_card("PV Gamba Variabile vs Fissa", fmt_eur(float(irs_info["pv_floating_leg_eur"])), delta=f"Fixed PV: {fmt_eur(float(irs_info['pv_fixed_leg_eur']))}", positive=True)
    with m_k4:
        metric_card("Fair Tenor Basis (6M vs 3M)", f"{float(tbs_info['fair_basis_spread_3m_vs_6m_bps']):.2f} bps", delta=f"NPV Basis: {fmt_eur(float(tbs_info['basis_swap_npv_eur']))}", positive=True)

    ois_df = pd.DataFrame(mc_res["ois_curve_nodes"])
    f6_df = pd.DataFrame(mc_res["forward_6m_nodes"])
    fig_mc = go.Figure()
    fig_mc.add_trace(go.Scatter(x=ois_df["tenor_years"], y=ois_df["zero_rate_pct"], mode="lines+markers", name="OIS Zero Rate (€STR/SOFR %)", line=dict(color="#10b981", width=2.5)))
    fig_mc.add_trace(go.Scatter(x=f6_df["tenor_years"], y=f6_df["zero_rate_pct"], mode="lines+markers", name="Forward 6M Zero Rate (%)", line=dict(color="#3b82f6", width=2.5)))
    fig_mc.update_layout(
        title="Struttura per Scadenza Multi-Curve: OIS Discount vs Forward Projection 6M",
        xaxis_title="Scadenza (Anni)",
        yaxis=dict(title="Tasso Zero-Coupon (%)"),
        height=400,
        margin=dict(l=10, r=10, b=10, t=40),
    )
    style_institutional_chart(fig_mc, title="Struttura per Scadenza Multi-Curve: OIS Discount vs Forward Projection 6M", height=400)
    st.plotly_chart(fig_mc, use_container_width=True)
    render_scenario_delta_comparator(
        scenario_key="multicurve_irs",
        scenario_title="Multi-Curve OIS & Dual-Curve IRS",
        current_metrics={
            "Par Swap Rate (%)": float(irs_info["par_swap_rate_pct"]),
            "NPV Multi-Curve (€)": float(irs_info["multicurve_npv_eur"]),
            "DV01 (€/bp)": float(irs_info["dv01_eur"]),
            "Tenor Basis 6M/3M (bps)": float(tbs_info["fair_basis_spread_3m_vs_6m_bps"]),
        },
        higher_is_better_map={"Par Swap Rate (%)": True, "NPV Multi-Curve (€)": True, "DV01 (€/bp)": False, "Tenor Basis 6M/3M (bps)": False},
    )
    st.dataframe(ois_df, use_container_width=True, hide_index=True)
    render_sr117_audit_drawer(
        engine_name="Multi-Curve OIS Discounting & Dual-Curve IRS Engine",
        latex_formulas=[
            r"\text{NPV}_{\text{IRS}} = N \sum_{i=1}^M \tau_i F_{6M}(T_{i-1}, T_i) D_{\text{OIS}}(0, T_i) - N K \sum_{j=1}^N \alpha_j D_{\text{OIS}}(0, T_j)",
            r"S_{\text{par}} = \frac{\sum_{i=1}^M \tau_i F_{6M}(T_{i-1}, T_i) D_{\text{OIS}}(0, T_i)}{\sum_{j=1}^N \alpha_j D_{\text{OIS}}(0, T_j)}",
        ],
        inputs_dict={"currency": mc_ccy, "notional": mc_notional, "fixed_rate": mc_fixed, "maturity_years": mc_mat},
        outputs_dict={"par_swap_rate_pct": irs_info["par_swap_rate_pct"], "multicurve_npv_eur": irs_info["multicurve_npv_eur"], "dv01_eur": irs_info["dv01_eur"]},
        regulatory_refs=["Ametrano & Bianchetti (2013)", "ISDA IBOR Fallbacks Protocol", "ECB €STR / Fed SOFR Standards"],
    )


# ── TAB: HULL-WHITE SHORT RATE & BERMUDAN SWAPTIONS ─────────────────────────
elif active_quant_tab == "🔔 Hull-White Bermudan Swaptions":
    st.markdown("#### 🔔 1-Factor Gaussian Hull-White Short Rate & Longstaff-Schwartz Bermudan Swaptions")
    st.caption("Simulazione esatta del tasso breve dr_t = [θ(t) - a r_t]dt + σ dW_t e induzione all'indietro LSMC per la valutazione dell'Early Exercise Premium su Swaption Bermudiane e Callable Bonds.")
    render_institutional_info_box(
        title="Modello 1-Fattore di Hull-White (1990) & Bermudan Swaptions via Longstaff-Schwartz (LSMC)",
        badge="HULL-WHITE 1F • LSMC BACKWARD INDUCTION • CALLABLE BONDS",
        summary="Calibrazione esatta alla struttura a termine iniziale dei tassi e valutazione dell'opzionalità di esercizio anticipato su date discrete (Bermudan).",
        math_foundation="Il tasso breve $dr_t = [\\theta(t) - a r_t]dt + \\sigma dW_t$ ammette prezzi obbligazionari zero-coupon analitici affini $P(t,T) = A(t,T)e^{-B(t,T)r_t}$. L'algoritmo di Longstaff-Schwartz stima il valore di continuazione tramite regressione polinomiale trasversale ad ogni data di esercizio $T_m$, determinando la frontiera ottima di esercizio.",
        kpi_guide="• <b>Bermudan Swaption PV</b>: valore totale dell'opzione con facoltà di esercizio multi-data.<br>• <b>Early Exercise Premium (EEP)</b>: extravalore rispetto alla swaption europea co-terminale.<br>• <b>Callable Bond PV</b>: prezzo dell'obbligazione al netto dell'opzione di rimborso anticipato dell'emittente.",
        operational_impact="Utilizzato dalle tesorerie bancarie e dai desk ALM per prezzare e coprire mutui rinegoziabili, emissioni obbligazionarie Callable/Puttable e portafogli di swaption esotiche.",
        accent_color="#3b82f6",
    )

    from core.hull_white_engine import compute_hull_white_swaptions

    _live_nav_hw = max(1_000.0, round(float(live_bind.get("total_nav_eur", 64_233.0)), 2)) if live_bind.get("autobind_enabled") else 10_000_000.0
    hw_c1, hw_c2, hw_c3, hw_c4 = st.columns(4)
    with hw_c1:
        hw_strike = st.slider("Strike Rate Swaption (%):", min_value=0.5, max_value=6.0, value=3.0, step=0.1, key="hw_strike_in") / 100.0
        hw_r0 = st.slider("Short Rate Iniziale r0 (%):", min_value=0.5, max_value=6.0, value=3.0, step=0.1, key="hw_r0_in") / 100.0
    with hw_c2:
        hw_a = st.slider("Mean Reversion Speed (a):", min_value=0.01, max_value=0.30, value=0.05, step=0.01, key="hw_a_in")
        hw_sigma = st.slider("Volatilità Short Rate σ (bps):", min_value=20, max_value=250, value=100, step=10, key="hw_sigma_in") / 10000.0
    with hw_c3:
        hw_mat = st.selectbox("Maturity Sottostante (Anni):", [3.0, 5.0, 7.0, 10.0], index=1, key="hw_mat_sel")
        hw_payer = st.selectbox("Tipo Swaption:", ["Payer (diritto a pagare fisso)", "Receiver (diritto a ricevere fisso)"], index=0, key="hw_type_sel")
    with hw_c4:
        hw_notional = st.number_input("Nozionale Swaption (€):", min_value=1_000.0, value=float(_live_nav_hw), step=10_000.0, key="hw_notional_in")
        hw_paths = st.select_slider("Percorsi LSMC Monte Carlo:", options=[1000, 2000, 3000, 5000], value=2000, key="hw_paths_sel")

    hw_res = compute_hull_white_swaptions(
        notional=float(hw_notional),
        strike_rate=hw_strike,
        swap_maturity_years=float(hw_mat),
        is_payer=hw_payer.startswith("Payer"),
        mean_reversion_a=hw_a,
        short_rate_vol_sigma=hw_sigma,
        initial_short_rate=hw_r0,
        n_paths=int(hw_paths),
    )

    hk1, hk2, hk3, hk4 = st.columns(4)
    with hk1:
        metric_card("Prezzo Bermudan Swaption (LSMC)", fmt_eur(float(hw_res["bermudan_swaption_pv_eur"])), delta=f"{float(hw_res['bermudan_price_bps']):.1f} bps del nozionale", positive=True)
    with hk2:
        metric_card("Benchmark Europea Co-Terminale", fmt_eur(float(hw_res["european_swaption_pv_eur"])), delta="Jamshidian / Analytical", positive=True)
    with hk3:
        metric_card("Early Exercise Premium (EEP)", fmt_eur(float(hw_res["early_exercise_premium_eur"])), delta="Valore Flessibilità Bermudiana", positive=True)
    with hk4:
        metric_card("Prezzo Callable Bond", fmt_eur(float(hw_res["callable_bond_pv_eur"])), delta=f"Option: -{fmt_eur(float(hw_res['embedded_call_option_eur']))}", positive=True)

    render_scenario_delta_comparator(
        scenario_key="hull_white_bermudan",
        scenario_title="Hull-White 1F Bermudan Swaption",
        current_metrics={
            "Bermudan Swaption PV (€)": float(hw_res["bermudan_swaption_pv_eur"]),
            "European Swaption PV (€)": float(hw_res["european_swaption_pv_eur"]),
            "Early Exercise Premium (€)": float(hw_res["early_exercise_premium_eur"]),
            "Callable Bond PV (€)": float(hw_res["callable_bond_pv_eur"]),
        },
    )
    ex_df = pd.DataFrame(hw_res["exercise_schedule"])
    st.dataframe(ex_df, use_container_width=True, hide_index=True)
    render_sr117_audit_drawer(
        engine_name="Hull-White 1F Short Rate & LSMC Bermudan Swaption Engine",
        latex_formulas=[
            r"dr_t = [\theta(t) - a\,r_t]\,dt + \sigma\,dW_t, \quad B(t,T) = \frac{1 - e^{-a(T-t)}}{a}",
            r"V_m(r_{T_m}) = \max\!\left(\text{Payoff}_m(r_{T_m}),\; \mathbb{E}\!\left[e^{-\int_{T_m}^{T_{m+1}} r_s ds} V_{m+1} \mid r_{T_m}\right]\right)",
        ],
        inputs_dict={"notional": hw_notional, "strike": hw_strike, "a": hw_a, "sigma": hw_sigma, "paths": hw_paths},
        outputs_dict={"bermudan_pv_eur": hw_res["bermudan_swaption_pv_eur"], "eep_eur": hw_res["early_exercise_premium_eur"]},
        regulatory_refs=["Hull & White (1990)", "Longstaff & Schwartz (2001)", "Fed SR 11-7 Model Validation"],
    )


# ── TAB: ROUGH VOLATILITY (rBERGOMI) & SVI ARBITRAGE-FREE SURFACE ──────────
elif active_quant_tab == "🌊 Rough Volatility (rBergomi) & SVI Surface":
    st.markdown("#### 🌊 Rough Volatility (Rough Bergomi $H \\approx 0.10$) & Gatheral SVI Arbitrage-Free Surface")
    st.caption(r"Parametrizzazione SVI di Gatheral con test di non-arbitraggio Butterfly di Durrleman $g(k) \ge 0$ e legge di potenza dello skew ATM a breve termine $\mathcal{O}(T^{H - 1/2})$.")
    render_institutional_info_box(
        title="Rough Volatility (rBergomi H ≈ 0.10) & Superficie SVI Arbitrage-Free di Gatheral",
        badge="ROUGH BERGOMI • GATHERAL SVI • DURRLEMAN g(k) ≥ 0",
        summary="Modellazione frazionaria della volatilità con memoria corta (Hurst H ≈ 0.10) e verifica rigorosa di assenza di arbitraggio Butterfly e Calendar.",
        math_foundation="I dati empirici ad alta frequenza mostrano che la log-volatilità segue un Moto Browniano Frazionario con $H \\approx 0.10$, generando uno skew ATM esplosivo per scadenze brevi $\\mathcal{S}(T) \\propto T^{H-1/2}$. La parametrizzazione SVI $w(k) = a + b(\\rho(k-m) + \\sqrt{(k-m)^2 + \\sigma^2})$ è priva di arbitraggio statico se la densità di Durrleman $g(k) \\ge 0$ per ogni log-moneyness $k$.",
        kpi_guide="• <b>Hurst H & Fractal Dim D = 2 - H</b>: rugosità della traiettoria di volatilità.<br>• <b>Durrleman Min g(k) ≥ 0</b>: certifica che la densità neutrale al rischio $p(K)$ è strettamente positiva.<br>• <b>ATM Skew 1M vs 12M</b>: legge di potenza dello skew sulle scadenze corte.",
        operational_impact="Evita il mispricing sistematico delle opzioni settimanali/mensili (0DTE / 1M) tipico dei modelli di volatilità stocastica markoviani classici (Heston/SABR).",
        accent_color="#06b6d4",
    )

    from core.rough_vol_svi_engine import compute_rough_vol_svi_surface
    from core.ux_institutional_hub import apply_macro_shock_to_inputs, render_bento_kpi_card, render_sr117_audit_drawer
    from core.ux_quant_canvas import build_svi_3d_surface_and_density_chart

    _default_svi_sig = round(float(np.clip(float(live_bind.get("annual_volatility", 0.2625)), 0.05, 0.40)), 2) if live_bind.get("autobind_enabled") else 0.14
    rv_c1, rv_c2, rv_c3 = st.columns(3)
    with rv_c1:
        rv_h = st.slider("Esponente di Hurst Rough Bergomi (H):", min_value=0.04, max_value=0.35, value=0.10, step=0.01, key="rv_h_in")
        rv_rho = st.slider("Correlazione Spot-Vol SVI (ρ):", min_value=-0.95, max_value=0.20, value=-0.62, step=0.02, key="rv_rho_in")
    with rv_c2:
        rv_b = st.slider("Pendenza Ali SVI (b):", min_value=0.05, max_value=0.40, value=0.185, step=0.01, key="rv_b_in")
        rv_sig = st.slider("Curvatura ATM SVI (σ):", min_value=0.05, max_value=0.40, value=float(_default_svi_sig), step=0.01, key="rv_sig_in")
    with rv_c3:
        rv_eta = st.slider("Vol-of-Vol Rough Bergomi (η):", min_value=0.50, max_value=3.50, value=1.85, step=0.05, key="rv_eta_in")

    shocked_rv = apply_macro_shock_to_inputs({"annual_vol": rv_sig})
    eff_sig = float(shocked_rv["annual_vol"])
    prov_tag = "GLOBAL SHOCK OVERRIDE" if shocked_rv.get("macro_shock_active") else "LIVE PORTFOLIO BOUND"

    rv_res = compute_rough_vol_svi_surface(hurst_h=rv_h, svi_b=rv_b, svi_rho=rv_rho, svi_sigma=eff_sig, eta_vol_of_vol=rv_eta)

    rk1, rk2, rk3, rk4 = st.columns(4)
    with rk1:
        render_bento_kpi_card(
            "Hurst H & Fractal Dim.",
            f"H = {rv_res['hurst_exponent_h']:.2f}",
            f"Fractal D = {rv_res['fractal_dimension_d']:.2f}",
            provenance=prov_tag,
            sparkline_values=[0.22, 0.16, 0.12, 0.10, float(rv_res["hurst_exponent_h"])],
            accent_color="#06b6d4",
        )
    with rk2:
        render_bento_kpi_card(
            "Durrleman Butterfly Min g(k)",
            f"{rv_res['min_durrleman_density_g']:.4f}",
            "Arbitrage-Free ✅" if rv_res["butterfly_arbitrage_free"] else "Arbitrage ⚠️",
            provenance=prov_tag,
            limit_utilization_pct=max(5.0, min(95.0, (1.0 - float(rv_res["min_durrleman_density_g"])) * 55.0)),
            accent_color="#10b981" if rv_res["butterfly_arbitrage_free"] else "#ef4444",
        )
    with rk3:
        render_bento_kpi_card(
            "ATM Skew 1M (rBergomi)",
            f"{rv_res['short_end_skew_1m']:.3f}",
            f"Power-Law T^({rv_res['skew_power_law_exponent']:+.2f})",
            provenance=prov_tag,
            sparkline_values=[abs(float(r["rough_bergomi_atm_skew"])) for r in rv_res["surface_term_structure"]],
            accent_color="#3b82f6",
        )
    with rk4:
        render_bento_kpi_card(
            "ATM Skew 12M (1 Anno)",
            f"{rv_res['one_year_skew_12m']:.3f}",
            "Calendar Free ✅" if rv_res["calendar_spread_arbitrage_free"] else "Warning ⚠️",
            provenance=prov_tag,
            accent_color="#f59e0b",
        )

    fig_3d_svi, fig_dens_svi = build_svi_3d_surface_and_density_chart(
        {"calibrated_params": {"a": 0.015, "b": rv_b, "rho": rv_rho, "m": 0.01, "sigma": eff_sig}, "maturity_years": 0.25},
        {"hurst_h": rv_h},
    )
    ch_col1, ch_col2 = st.columns(2)
    with ch_col1:
        st.plotly_chart(fig_3d_svi, use_container_width=True)
    with ch_col2:
        st.plotly_chart(fig_dens_svi, use_container_width=True)

    svi_df = pd.DataFrame(rv_res["surface_term_structure"])
    fig_rv = go.Figure()
    fig_rv.add_trace(go.Scatter(x=svi_df["tenor_label"], y=svi_df["rough_bergomi_atm_skew"].abs(), mode="lines+markers", name="|ATM Skew| Rough Bergomi (Power-Law)", line=dict(color="#06b6d4", width=3)))
    fig_rv.add_trace(go.Scatter(x=svi_df["tenor_label"], y=svi_df["classical_markov_skew"].abs(), mode="lines+markers", name="|ATM Skew| Heston Classico", line=dict(color="#94a3b8", width=2, dash="dash")))
    style_institutional_chart(fig_rv, title="Confronto Term Structure ATM Volatility Skew: Rough Bergomi vs Modello Markoviano Classico", height=360)
    st.plotly_chart(fig_rv, use_container_width=True)
    st.dataframe(svi_df, use_container_width=True, hide_index=True)
    render_sr117_audit_drawer(
        engine_name="Rough Bergomi & Gatheral SVI Surface Engine",
        latex_formulas=[
            r"w(k) = a + b\left(\rho(k-m) + \sqrt{(k-m)^2 + \sigma^2}\right)",
            r"g(k) = \left(1 - \frac{k w'(k)}{2w(k)}\right)^2 - \frac{(w'(k))^2}{4}\left(\frac{1}{w(k)} + \frac{1}{4}\right) + \frac{w''(k)}{2} \ge 0",
            r"\mathcal{S}_{\text{ATM}}(T) = \left.\frac{\partial \sigma_{\text{BS}}(k,T)}{\partial k}\right|_{k=0} \propto T^{H - 1/2}",
        ],
        inputs_dict={"hurst_h": rv_h, "svi_b": rv_b, "svi_rho": rv_rho, "svi_sigma": eff_sig, "eta": rv_eta},
        outputs_dict={"min_g_k": rv_res["min_durrleman_density_g"], "short_end_skew_1m": rv_res["short_end_skew_1m"]},
        regulatory_refs=["Gatheral & Jacquier (2014)", "Bayer, Friz & Gatheral (2016)", "Fed SR 11-7"],
    )


# ── TAB: SINGLE-NAME CDS & SYNTHETIC CREDIT INDEX TRANCHES (iTRAXX/CDX) ────
elif active_quant_tab == "💳 Single-Name CDS & iTraxx/CDX CDO Tranches":
    st.markdown("#### 💳 ISDA Single-Name CDS Bootstrapping & Synthetic CDO Tranches (iTraxx / CDX 1F Gaussian Copula)")
    st.caption(r"Bootstrapping delle intensità di default $\lambda(t)$ e probabilità di sopravvivenza $Q(0, t)$, ISDA Upfront, CS01 e prezzatura 1-Factor Gaussian Copula / Base Correlation delle tranche sintetiche.")

    from core.cds_tranche_engine import compute_cds_and_tranche_pricing
    from core.ux_institutional_hub import (
        apply_macro_shock_to_inputs,
        render_bento_kpi_card,
        render_institutional_info_box,
        render_sr117_audit_drawer,
    )
    from core.ux_quant_canvas import build_cds_bootstrap_and_tranche_chart

    render_institutional_info_box(
        title="ISDA Standard CDS Hazard-Rate Bootstrapping & 1-Factor Gaussian Copula CDO Tranches",
        badge="CREDIT DERIVATIVES • ISDA / COPULA",
        summary_html=(
            "Il motore effettua lo stripping esatto della curva delle probabilità di sopravvivenza $Q(0, t) = \\exp(-\\int_0^t \\lambda(u)du)$ "
            "dai par spread di mercato (convenzione <b>ISDA Big Bang / Standard Model</b> con cedola fissa 100/500 bps) e prezza le tranche sintetiche "
            "<b>iTraxx Europe / CDX IG</b> tramite il modello <b>Large Homogeneous Portfolio (LHP) 1-Factor Gaussian Copula (Li 2000 / Vasicek)</b>."
        ),
        math_html=(
            "Uguaglianza tra Premium Leg e Protection Leg ed Expected Tranche Loss $[K_1, K_2]$:<br>"
            "<code>Upfront = (S_par - C_std) · RPV01(0, T)  |  Q(0, t_k) = exp(- Σ_j λ_j Δt_j)</code><br>"
            "<code>p(M) = Φ( (Φ⁻¹(PD) - √ρ M) / √(1 - ρ) )  ⇒  EL_[K1,K2] = E_M[ min(max(L(M)-K1, 0), K2-K1) ] / (K2 - K1)</code>"
        ),
        chart_guide_html=(
            "• <b>Pannello Sinistro (Curva Survival $Q(0,t)$ & Hazard Rate $\\lambda_t$)</b>: mostra la probabilità cumulativa di sopravvivenza e l'intensità marginale di default.<br>"
            "• <b>Pannello Destro (Tranche Loss & Spread per Attachment Point)</b>: illustra come la tranche Equity [0%-3%] assorba le prime perdite idiosincratiche mentre la Senior [12%-22%] sia esposta alla correlazione sistemica $\\rho$."
        ),
        regulatory_html=(
            "• <b>FRTB CSR (Credit Spread Risk) & DRC (Default Risk Charge)</b>: CS01 e Jump-to-Default (JTD) alimentano i requisiti patrimoniali Basilea IV per il Trading Book.<br>"
            "• <b>CVA Hedging Desk</b>: i CDS Single-Name e gli indici iTraxx sono gli strumenti primari per la copertura dinamica del Credit Valuation Adjustment."
        ),
    )

    _default_cds_ent = f"{live_bind.get('top_ticker', 'ENI.MI')} ({live_bind.get('portfolio_name', 'Portafoglio Attivo')})" if live_bind.get("autobind_enabled") else "Intesa Sanpaolo S.p.A. (Senior)"
    _default_cds_not = max(1_000.0, round(float(live_bind.get("total_nav_eur", 64_233.0)), 2)) if live_bind.get("autobind_enabled") else 10_000_000.0
    cd_c1, cd_c2, cd_c3 = st.columns(3)
    with cd_c1:
        cd_ent = st.text_input("Reference Entity / Indice:", value=_default_cds_ent, key="cd_ent_in")
        cd_not = st.number_input("Nozionale CDS / Tranche (€):", min_value=1_000.0, value=float(_default_cds_not), step=10_000.0, key="cd_not_in")
    with cd_c2:
        cd_spr = st.slider("Par Spread CDS 5 Anni (bps):", min_value=15.0, max_value=550.0, value=96.0, step=5.0, key="cd_spr_in")
        cd_rec = st.slider("Recovery Rate Atteso R (%):", min_value=10.0, max_value=70.0, value=40.0, step=5.0, key="cd_rec_in") / 100.0
    with cd_c3:
        cd_rho = st.slider("Correlazione Sistemica Gaussian Copula (ρ):", min_value=0.10, max_value=0.75, value=0.32, step=0.02, key="cd_rho_in")

    shocked_cd = apply_macro_shock_to_inputs({"index_spread_bps": cd_spr})
    eff_cd_spr = float(shocked_cd["index_spread_bps"])
    cd_prov = "GLOBAL SHOCK OVERRIDE" if shocked_cd.get("macro_shock_active") else "LIVE CREDIT CURVE"

    cd_res = compute_cds_and_tranche_pricing(
        reference_entity=cd_ent,
        notional_eur=cd_not,
        recovery_rate=cd_rec,
        five_year_spread_bps=eff_cd_spr,
        copula_correlation_rho=cd_rho,
    )

    ck1, ck2, ck3, ck4 = st.columns(4)
    with ck1:
        render_bento_kpi_card(
            "ISDA Upfront (vs 100bps)",
            fmt_eur(cd_res["isda_upfront_eur"]),
            f"{cd_res['isda_upfront_pct']:+.2f}% Notional",
            provenance=cd_prov,
            sparkline_values=[
                float(n.get("survival_probability_pct", float(n.get("survival_prob_q", 1.0)) * 100.0))
                for n in cd_res.get("survival_curve_nodes", [])
            ],
            accent_color="#3b82f6",
        )
    with ck2:
        render_bento_kpi_card(
            "CS01 (Credit Spread 01)",
            fmt_eur(cd_res["cs01_eur_per_bp"]),
            f"Risky PV01: {cd_res['risky_pv01_5y']:.3f}",
            provenance=cd_prov,
            accent_color="#10b981",
        )
    with ck3:
        render_bento_kpi_card(
            "Jump-to-Default (JTD Net)",
            fmt_eur(cd_res["jump_to_default_jtd_eur"]),
            f"Recovery: {cd_res['recovery_rate_pct']:.0f}%",
            provenance=cd_prov,
            limit_utilization_pct=min(100.0, float(cd_res["jump_to_default_jtd_eur"]) / max(cd_not, 1.0) * 100.0),
            accent_color="#ef4444",
        )
    with ck4:
        eq_tr = cd_res["synthetic_cdo_tranches"][0]
        render_bento_kpi_card(
            "Equity Tranche [0-3%]",
            f"{eq_tr['fair_running_spread_bps']:,.0f} bps",
            f"Upfront: {eq_tr['upfront_vs_std_coupon_pct']:+.1f}% (vs 500 bps)",
            provenance=cd_prov,
            accent_color="#f59e0b",
        )

    fig_cds_curve, fig_cdo_tr = build_cds_bootstrap_and_tranche_chart(
        {
            "bootstrapped_curve": [
                {
                    "tenor_years": float(r.get("tenor_years", 1.0)),
                    "survival_prob_q": float(r.get("survival_prob_q", float(r.get("survival_probability_pct", 100.0)) / 100.0)),
                    "hazard_rate_lambda": float(r.get("hazard_rate_lambda", float(r.get("hazard_rate_bps", float(r.get("hazard_rate_pct", 1.0)) * 100.0)) / 10000.0)),
                }
                for r in cd_res.get("survival_curve_nodes", [])
            ]
        },
        {
            "tranches": [
                {
                    "tranche_name": str(r.get("tranche_name", "Tranche")),
                    "attach_pct": float(r.get("attachment_pct", r.get("attach_pct", float(str(r.get("attachment_detachment", "0-3")).split("-")[0].replace("%", ""))))),
                    "detach_pct": float(r.get("detachment_pct", r.get("detach_pct", float(str(r.get("attachment_detachment", "0-3")).split("-")[1].replace("%", ""))))),
                    "expected_loss_pct": float(r.get("expected_loss_pct", r.get("expected_tranche_loss_pct", 0.0))),
                    "fair_running_spread_bps": float(r.get("fair_running_spread_bps", 0.0)),
                }
                for r in cd_res.get("synthetic_cdo_tranches", [])
            ]
        },
    )
    cc1, cc2 = st.columns(2)
    with cc1:
        st.plotly_chart(fig_cds_curve, use_container_width=True)
    with cc2:
        st.plotly_chart(fig_cdo_tr, use_container_width=True)

    st.markdown("##### 📊 Prezzatura Tranche Sintetiche iTraxx / CDX (1-Factor Gaussian Copula & Base Correlation)")
    st.dataframe(pd.DataFrame(cd_res["synthetic_cdo_tranches"]), use_container_width=True, hide_index=True)
    st.markdown(r"##### 📈 Curva delle Probabilità di Sopravvivenza $Q(0, t)$ & Hazard Rates $\lambda(t)$")
    st.dataframe(pd.DataFrame(cd_res["survival_curve_nodes"]), use_container_width=True, hide_index=True)
    render_sr117_audit_drawer(
        engine_name="ISDA Single-Name CDS & 1F Gaussian Copula Tranche Engine",
        latex_formulas=[
            r"Q(0, t_i) = \exp\left(-\int_0^{t_i} \lambda(u)\,du\right), \quad \text{PV}_{\text{prot}} = (1 - R)\sum_{j=1}^M D(0, t_j)\,[Q(t_{j-1}) - Q(t_j)]",
            r"p(T \mid M) = \Phi\left(\frac{\Phi^{-1}(1 - Q(0,T)) - \sqrt{\rho}\,M}{\sqrt{1-\rho}}\right)",
        ],
        inputs_dict={"entity": cd_ent, "notional_eur": cd_not, "spread_5y_bps": eff_cd_spr, "recovery": cd_rec, "rho": cd_rho},
        outputs_dict={"isda_upfront_eur": cd_res["isda_upfront_eur"], "cs01_eur": cd_res["cs01_eur_per_bp"]},
        regulatory_refs=["ISDA CDS Standard Model", "Vasicek (2002) LHP", "Basel III CVA/IRC"],
    )
