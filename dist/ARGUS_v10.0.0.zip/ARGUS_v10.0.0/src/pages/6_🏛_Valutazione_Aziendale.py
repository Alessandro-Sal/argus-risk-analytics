import streamlit as st

st.set_page_config(page_title="Valutazione Aziendale | ARGUS", page_icon="🏛️", layout="wide")

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

import core.financial_analysis as financial_analysis
import core.metadata_resolver as metadata_resolver
import core.risk_engine as risk_engine
import core.sec_rag_engine as sec_rag_engine
import core.ui_utils as ui_utils
from core.financial_analysis import resolve_company_name
from core.forensic_accounting import compute_beneish_m_score, compute_sloan_accrual_ratio
from core.metadata_resolver import resolve_asset_metadata, resolve_asset_valuation_metrics
from core.ui_export_utils import render_table_with_export
from core.ui_utils import (
    apply_plotly_theme,
    ensure_risk_bundle_loaded,
    fmt_pct,
    format_display_portfolio_name,
    glossary_modal,
    inject_custom_css,
    metric_card,
    render_altman_zscore_modal,
    render_command_bar,
    render_institutional_telemetry_ribbon,
    render_sandbox_banner,
    render_sec_rag_modal,
    render_segmented_tabs,
    render_sr117_audit_drawer,
)
from core.workspace_manager import get_url_param, register_workspace_tab, set_url_params

inject_custom_css()

from core.sidebar import render_sidebar

render_sidebar()
render_command_bar()

url_ticker = get_url_param("ticker", None)
if url_ticker:
    register_workspace_tab(f"val_{url_ticker}", f"🏛️ {url_ticker}", "5_Valutazione_Aziendale", {"ticker": url_ticker})

# Gestione Portafoglio o Sandbox
results, has_real_portfolio = ensure_risk_bundle_loaded()
if not has_real_portfolio:
    render_sandbox_banner()
    pos = pd.DataFrame([
        {"ticker": "AAPL", "asset_name": "Apple Inc.", "name": "Apple Inc.", "asset_class": "Stock", "weight_pct": 20.0, "qty_net": 10, "current_value": 2200.0, "last_price": 220.0, "target_mean_price": 250.0, "peg_ratio": 2.1, "trailing_pe": 33.0, "forward_pe": 28.0, "price_to_book": 39.0, "dividend_yield": 0.005, "roe": 1.45},
        {"ticker": "MSFT", "asset_name": "Microsoft Corp.", "name": "Microsoft Corp.", "asset_class": "Stock", "weight_pct": 20.0, "qty_net": 10, "current_value": 4400.0, "last_price": 440.0, "target_mean_price": 500.0, "peg_ratio": 2.3, "trailing_pe": 35.0, "forward_pe": 30.0, "price_to_book": 12.0, "dividend_yield": 0.007, "roe": 0.38},
        {"ticker": "NVDA", "asset_name": "NVIDIA Corp.", "name": "NVIDIA Corp.", "asset_class": "Stock", "weight_pct": 20.0, "qty_net": 10, "current_value": 1250.0, "last_price": 125.0, "target_mean_price": 155.0, "peg_ratio": 1.1, "trailing_pe": 46.0, "forward_pe": 33.0, "price_to_book": 48.0, "dividend_yield": 0.001, "roe": 1.18},
        {"ticker": "RACE.MI", "asset_name": "Ferrari N.V.", "name": "Ferrari N.V.", "asset_class": "Stock", "weight_pct": 20.0, "qty_net": 10, "current_value": 4100.0, "last_price": 410.0, "target_mean_price": 460.0, "peg_ratio": 2.8, "trailing_pe": 49.0, "forward_pe": 42.0, "price_to_book": 19.0, "dividend_yield": 0.006, "roe": 0.42},
        {"ticker": "ENEL.MI", "asset_name": "Enel S.p.A.", "name": "Enel S.p.A.", "asset_class": "Stock", "weight_pct": 20.0, "qty_net": 100, "current_value": 710.0, "last_price": 7.10, "target_mean_price": 8.20, "peg_ratio": 1.4, "trailing_pe": 10.8, "forward_pe": 9.9, "price_to_book": 1.4, "dividend_yield": 0.063, "roe": 0.14}
    ])
    active_pos = pos.copy()
    port_metrics = {"cagr_pct": 16.5, "volatility_ann_pct": 17.8, "sharpe_ratio": 1.22, "max_drawdown_pct": -11.5}
else:
    pos = results.get("positions", pd.DataFrame())
    active_pos = pos[pos["qty_net"] > 0].copy() if not pos.empty and "qty_net" in pos.columns else (pos[pos["weight_pct"] > 0].copy() if not pos.empty and "weight_pct" in pos.columns else pos.copy())
    port_metrics = results.get("metrics", {})

render_institutional_telemetry_ribbon(
    page_badge="CORPORATE VALUATION & CREDIT",
    risk_data={"metrics": port_metrics, "positions": active_pos} if has_real_portfolio else None,
)

from core.financial_analysis import resolve_company_name

equity_pos = active_pos[active_pos["asset_class"].str.lower().isin(["equity", "azione", "stock", "azioni"])].copy() if "asset_class" in active_pos.columns else active_pos
if equity_pos.empty:
    equity_pos = active_pos

company_options = {}
for _, r in equity_pos.iterrows():
    tk = r["ticker"]
    raw_name = r.get("name", r.get("asset_name", tk))
    company_options[tk] = resolve_company_name(tk, raw_name)

col_head1, col_head2 = st.columns([3.4, 1.2], vertical_alignment="center")
with col_head1:
    st.title("🏛️ Valutazione Intrinseca & Fair Value")
    active_p_name = format_display_portfolio_name(st.session_state.get("portfolio_name"))
    if "run_id" in st.session_state:
        st.caption(f"Run ID: {st.session_state['run_id']} | Portafoglio: {active_p_name} • Analisi dei fondamentali societari, target price dei mercati (Consensus) e simulazioni di private equity (IRR & TVPI).")

with col_head2:
    glossary_modal("Cos'è la Valutazione Aziendale & Fair Value", """
<div style="font-size: 13.5px; line-height: 1.45;">

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px; margin-bottom: 8px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">📌 Cos'è la Valutazione Fondamentale</div>
  <div>La determinazione quantitativa del valore intrinseco (Fair Value) di un'impresa basata sulla generazione di cassa, bilanci certificati, multipli di mercato e stime di consenso degli analisti finanziari.</div>
</div>

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px; margin-bottom: 8px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">📐 I Modelli Integrati in ARGUS</div>
  <div style="background: rgba(255,153,0,0.08); border-left: 3px solid #ff9900; padding: 6px 10px; border-radius: 6px; margin: 5px 0; color: #ffb74d; font-size: 12px; line-height: 1.45;">
    • <b>Target Price Consensus:</b> Mediana degli analisti di Wall Street / Piazza Affari<br>
    • <b>PE Waterfall:</b> Flussi di cassa LP/GP, TVPI, DPI, RVPI e Carried Interest<br>
    • <b>Solvibilità & Fallimento:</b> Altman Z-Score a 5 indici e scomposizione DuPont del ROE<br>
    • <b>Contabilità Forense:</b> Beneish M-Score (frodi) e Sloan Accruals (qualità utili)<br>
    • <b>DCF Monte Carlo:</b> Attualizzazione flussi FCF a 1.000 iterazioni stocastiche
  </div>
</div>

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px; margin-bottom: 8px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">🎯 A cosa serve</div>
  <div>Verificare se i titoli in portafoglio sono prezzati a sconto (Margin of Safety di Graham-Dodd) o a premio rispetto alla loro capacità reale di generare cassa.</div>
</div>

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px; margin-bottom: 8px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">⚙️ Calcolo in ARGUS</div>
  <div>I moduli <code>core/financial_analysis.py</code> e <code>core/risk_engine.py</code> estraggono i bilanci ufficiali normalizzando le valute e proiettano scenari probabilistici.</div>
</div>

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">🔍 Come leggerlo</div>
  <div>Naviga tra le schede per esaminare la valutazione di consenso (Tab 1), il Private Equity (Tab 3), la solidità contabile (Tab 4) o la simulazione DCF (Tab 5).</div>
</div>

</div>
""", button_label="💡 Come funziona la Valutazione?")
    st.markdown('</div>', unsafe_allow_html=True)

st.markdown('<div style="margin-bottom: 8px;"></div>', unsafe_allow_html=True)


if active_pos.empty:
    st.info("Nessuna posizione aperta in portafoglio.")
    st.stop()

# Estrazione colonne e calcolo dell'Upside / Giudizio
fund_cols = ["ticker", "name", "asset_name", "asset_class", "weight_pct", "last_price", 
             "target_mean_price", "peg_ratio", "trailing_pe", "forward_pe", "price_to_book", "dividend_yield", "roe"]
df_fund = active_pos[[c for c in fund_cols if c in active_pos.columns]].copy()

if "name" not in df_fund.columns:
    if "asset_name" in active_pos.columns:
        df_fund["name"] = active_pos["asset_name"]
    else:
        df_fund["name"] = df_fund["ticker"]

# Pulizia numerica e inizializzazione colonne
for col in ["last_price", "target_mean_price", "peg_ratio", "trailing_pe", "forward_pe", "price_to_book", "dividend_yield", "roe"]:
    if col in df_fund.columns:
        df_fund[col] = pd.to_numeric(df_fund[col], errors='coerce')
    else:
        df_fund[col] = np.nan

@st.cache_data(ttl=86400, show_spinner=False)
def get_live_asset_valuation(tk_str: str) -> dict:
    try:
        import yfinance as yf
        t = yf.Ticker(tk_str)
        info = t.info
        if not info:
            return {}
        return {
            "target_mean_price": info.get("targetMeanPrice"),
            "trailing_pe": info.get("trailingPE"),
            "forward_pe": info.get("forwardPE"),
            "peg_ratio": info.get("pegRatio"),
            "price_to_book": info.get("priceToBook"),
            "dividend_yield": info.get("dividendYield"),
            "roe": info.get("returnOnEquity"),
            "currency": info.get("currency"),
        }
    except Exception:
        return {}

# Mappatura tassi di cambio (base EUR) dinamica da df_prices con fallback di mercato
fx_rates_map = {
    "EUR": 1.0,
    "USD": 0.8667,
    "DKK": 0.1338,
    "GBP": 1.1676,
    "GBp": 0.011676,
    "SEK": 0.088,
    "NOK": 0.086,
    "CHF": 1.06,
    "JPY": 0.0062,
    "CAD": 0.68,
}
if isinstance(results, dict) and "df_prices" in results:
    df_pr_fx = results["df_prices"]
    if isinstance(df_pr_fx, pd.DataFrame) and not df_pr_fx.empty and "ticker" in df_pr_fx.columns:
        for cur, pair in [("USD", "USDEUR=X"), ("DKK", "DKKEUR=X"), ("GBP", "GBPEUR=X"), ("CHF", "CHFEUR=X"), ("JPY", "JPYEUR=X"), ("SEK", "SEKEUR=X"), ("CAD", "CADEUR=X")]:
            sub_fx = df_pr_fx[df_pr_fx["ticker"] == pair]
            if not sub_fx.empty:
                try:
                    fx_rates_map[cur] = float(sub_fx.iloc[-1]["close"])
                except Exception:
                    pass

# Arricchimento automatico per asset noti privi di Target Price o multipli
for idx, row in df_fund.iterrows():
    tk = str(row.get("ticker", "")).strip().upper()
    known_val = resolve_asset_valuation_metrics(tk)
    if not known_val or "target_mean_price" not in known_val:
        live_val = get_live_asset_valuation(tk)
        if live_val:
            known_val = {**live_val, **(known_val or {})}

    if known_val:
        for metric_k, metric_v in known_val.items():
            if metric_k == "currency":
                df_fund.at[idx, "native_currency"] = metric_v
            elif metric_k in df_fund.columns and (pd.isna(df_fund.at[idx, metric_k]) or df_fund.at[idx, metric_k] is None):
                df_fund.at[idx, metric_k] = metric_v

# Normalizzazione automatica valuta per Target Price (conversione coerente in EUR)
def normalize_target_price(row):
    last = row.get("last_price")
    target = row.get("target_mean_price")
    ticker = str(row.get("ticker", "")).strip().upper()
    
    if pd.isna(last) or pd.isna(target) or last <= 0:
        return target
        
    curr = str(row.get("native_currency", "")).strip().upper()
    if not curr or curr in ["NAN", "NONE"]:
        if ticker.endswith((".MI", ".PA", ".AS", ".DE", ".MC")):
            curr = "EUR"
        elif ticker.endswith(".CO"):
            curr = "DKK"
        elif ticker.endswith(".ST"):
            curr = "SEK"
        elif ticker.endswith(".OL"):
            curr = "NOK"
        elif ticker.endswith(".SW"):
            curr = "CHF"
        elif ticker.endswith(".T"):
            curr = "JPY"
        elif ticker.endswith(".L"):
            curr = "GBP"
        else:
            curr = "USD"
            
    # Gestione pence britannici (GBp -> GBP)
    if ticker.endswith(".L") and target > 100:
        target = target / 100.0
        curr = "GBP"
        
    fx = fx_rates_map.get(curr, 1.0)
    return target * fx

df_fund["target_mean_price"] = df_fund.apply(normalize_target_price, axis=1)

# Logica di Valutazione (Verdetto)
def get_verdict(row):
    last = row.get("last_price")
    target = row.get("target_mean_price")
    peg = row.get("peg_ratio")
    
    if pd.isna(last) or pd.isna(target):
        return "⚪ N/A"
        
    upside = (target / last) - 1
    
    if pd.notna(peg) and peg > 2.5 and upside < 0.05:
        return "🔴 Sopravvalutata (PEG Alto)"
    
    if upside > 0.10:
        return "🟢 Sottovalutata"
    elif upside < -0.05:
        return "🔴 Sopravvalutata"
    else:
        return "🟡 Fair Value"

df_fund["Upside %"] = np.where(
    (df_fund["target_mean_price"].notna()) & (df_fund["last_price"].notna()) & (df_fund["last_price"] > 0),
    (df_fund["target_mean_price"] / df_fund["last_price"]) - 1,
    np.nan
)

df_fund["Verdetto"] = df_fund.apply(get_verdict, axis=1)
df_valued = df_fund[df_fund["Verdetto"] != "⚪ N/A"]

# ── SELETTORE MODULI DI VALUTAZIONE STILE BLOOMBERG TERMINAL ─────────
VALUATION_MODELS_CATALOG = {
    "🏛️ Fair Value & Consensus Analisti": {
        "title": "Stime di Fair Value, Target Price di Mercato & Consensus di Wall Street",
        "badge": "Target Price • Upside • Multipli",
        "badge_color": "#58a6ff",
        "category": "Consensus & Prezzo Obiettivo",
        "desc": "Confronto tra prezzi di mercato correnti, target price medio/mediano degli analisti, raccomandazioni (Buy/Hold/Sell) e stima del margine di sicurezza (Graham)."
    },
    "💼 Private Equity & Waterfall": {
        "title": "Modellazione Cash Flow Private Equity, Struttura Waterfall & Metriche Rendimento",
        "badge": "IRR • TVPI • DPI • Carry",
        "badge_color": "#ff9900",
        "category": "Private Markets & Fondi",
        "desc": "Simulazione distribuzioni LP/GP con hurdle rate, catch-up, carried interest e calcolo istantaneo delle metriche istituzionali (IRR, TVPI, DPI, RVPI)."
    },
    "📊 Bilanci & Solvibilità (Altman & DuPont)": {
        "title": "Analisi Fondamentale di Bilancio, Rischio Fallimento (Altman Z) & Scomposizione ROE",
        "badge": "Altman Z-Score • DuPont 3/5 • Beneish",
        "badge_color": "#3fb950",
        "category": "Salute Finanziaria & Bilanci",
        "desc": "Check-up patrimoniale completo: Probabilità di default Altman Z-Score a 5 coefficienti, scomposizione DuPont del ROE, qualità degli utili Sloan e Beneish M-Score."
    },
    "🧮 Valutazione Intrinseca DCF Monte Carlo": {
        "title": "Discounted Cash Flow (DCF) Stocastico & Simulazioni Monte Carlo su WACC e Growth",
        "badge": "DCF 1.000 Iterazioni • WACC • Terminal Value",
        "badge_color": "#a855f7",
        "category": "Valutazione Intrinseca",
        "desc": "Attualizzazione dei flussi di cassa operativi liberi (FCFF/FCFE) con simulazione Monte Carlo congiunta su WACC, tasso di crescita terminale (g) e sensitivity table."
    }
}

active_val_tab = render_segmented_tabs(
    options=VALUATION_MODELS_CATALOG,
    key="val_segmented_tab",
    select_label="Seleziona Modulo di Valutazione Aziendale:",
    show_banner=True,
)


# ── TAB 1: FAIR VALUE & CONSENSUS ANALISTI ─────────────────────
if active_val_tab == "🏛️ Fair Value & Consensus Analisti":
    if df_valued.empty:
        st.info("ℹ️ Nessun dato di Target Price o Consensus Analisti disponibile per gli asset attualmente caricati in portafoglio.")
    else:
        st.markdown("#### Riepilogo Giudizi di Mercato")
        col1, col2, col3 = st.columns(3)

        n_under = len(df_valued[df_valued["Verdetto"].str.contains("Sottovalutata")])
        n_fair  = len(df_valued[df_valued["Verdetto"].str.contains("Fair Value")])
        n_over  = len(df_valued[df_valued["Verdetto"].str.contains("Sopravvalutata")])

        with col1:
            metric_card(
                "Sottovalutate (Buy)",
                str(n_under),
                "Asset a sconto vs target price",
                True,
                help_text="<b>Cosa significa:</b> Azioni con Target Price a 12 mesi superiore di almeno il 10% al prezzo attuale con multipli equilibrati."
            )
        with col2:
            metric_card(
                "Fairly Valued (Hold)",
                str(n_fair),
                "Asset in linea col fair value",
                True,
                help_text="<b>Cosa significa:</b> Azioni scambiate in un intervallo di normalità tra -5% e +10% rispetto al prezzo obiettivo."
            )
        with col3:
            metric_card(
                "Sopravvalutate (Sell)",
                str(n_over),
                "Asset a premio vs target price",
                False,
                help_text="<b>Cosa significa:</b> Azioni con Upside negativo (< -5%) o con PEG Ratio superiore a 2.5 (premio eccessivo)."
            )

        st.divider()

        col_a, col_b = st.columns([2, 1])

        with col_a:
            df_display = df_valued[["ticker", "Verdetto", "last_price", "target_mean_price", "Upside %", "peg_ratio", "trailing_pe"]].copy()
            df_display.rename(columns={
                "ticker": "Asset",
                "last_price": "Prezzo Attuale",
                "target_mean_price": "Target Price (Analisti)",
                "peg_ratio": "PEG Ratio",
                "trailing_pe": "P/E Ratio"
            }, inplace=True)
            
            df_display["Prezzo Attuale"] = df_display["Prezzo Attuale"].apply(lambda x: f"€ {x:,.2f}" if pd.notna(x) else "N/A")
            df_display["Target Price (Analisti)"] = df_display["Target Price (Analisti)"].apply(lambda x: f"€ {x:,.2f}" if pd.notna(x) else "N/A")
            df_display["Upside %"] = df_display["Upside %"].apply(lambda x: f"{x*100:+.2f}%" if pd.notna(x) else "N/A")
            df_display["PEG Ratio"] = df_display["PEG Ratio"].apply(lambda x: f"{x:.2f}" if pd.notna(x) else "N/A")
            df_display["P/E Ratio"] = df_display["P/E Ratio"].apply(lambda x: f"{x:.2f}" if pd.notna(x) else "N/A")

            render_table_with_export(
                df_display,
                table_title="📋 Tabella Fair Value & Target Price",
                file_prefix="fair_value_target_price",
                key_suffix="fv_tp",
                height=400,
            )

        with col_b:
            glossary_modal("📚 Glossario Metriche di Valutazione", """
<div style="font-size: 13.5px; line-height: 1.45;">
<div style="margin-bottom: 6px;"><b>🎯 Target Price:</b><br>
Prezzo obiettivo a 12 mesi stimato dal consensus degli analisti istituzionali.</div>

<div style="margin-bottom: 6px;"><b>📈 Upside / Downside %:</b><br>
Distanza percentuale necessaria affinché il prezzo di mercato converga verso il Target Price.</div>

<div><b>⚖️ PEG Ratio (Price/Earnings-to-Growth):</b><br>
Rapporto tra multiplo P/E e tasso di crescita atteso degli utili (EPS Growth). Valori < 1.0 indicano forte convenienza.
</div>
</div>
            """, button_label="📖 Glossario Metriche")
            
            verdict_counts = df_valued["Verdetto"].value_counts().reset_index()
            verdict_counts.columns = ["Verdetto", "Conteggio"]
            
            color_map = {
                "🟢 Sottovalutata": "#00e676",
                "🟡 Fair Value": "#ff9900",
                "🔴 Sopravvalutata (PEG Alto)": "#f85149",
                "🔴 Sopravvalutata": "#f85149"
            }
            
            st.markdown("**Distribuzione Valutazioni**")
            fig = px.pie(
                verdict_counts, values="Conteggio", names="Verdetto", hole=0.62,
                color="Verdetto", color_discrete_map=color_map
            )
            fig.update_traces(
                textposition='inside',
                textinfo='percent',
                insidetextorientation='horizontal',
                textfont=dict(size=12, color="#ffffff"),
                marker=dict(line=dict(color="#0d1117", width=2)),
                hovertemplate="<b>%{label}</b><br>Quota Valutazioni: <b>%{percent}</b> (%{value} titoli)<extra></extra>"
            )
            fig.update_layout(
                template="plotly_dark", height=320,
                showlegend=True,
                legend=dict(
                    orientation="h",
                    yanchor="top",
                    y=-0.12,
                    xanchor="center",
                    x=0.5,
                    bgcolor="rgba(22, 27, 34, 0.85)",
                    bordercolor="rgba(255, 255, 255, 0.12)",
                    borderwidth=1,
                    font=dict(size=11, color="#ffffff")
                ),
                margin=dict(l=10, r=10, t=10, b=25),
                paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)"
            )
            apply_plotly_theme(fig)
            st.plotly_chart(fig, use_container_width=True, key="val_fair_value_scatter", config={"displayModeBar": "hover", "displaylogo": False})

        # ── GRAFICO POTENZIALE DI RIALZO (UPSIDE / DOWNSIDE) INTEGRATO ──────
        st.divider()
        st.markdown("#### 📈 Potenziale di Rialzo (Upside / Downside Consensus Analisti)")
        st.caption("Distanza percentuale necessaria affinché la quotazione di mercato converga verso il Target Price stimato dal consensus istituzionale.")
        
        df_upside = df_valued.dropna(subset=["Upside %"]).sort_values("Upside %", ascending=True).copy()

        if not df_upside.empty:
            df_upside["Colore"] = np.where(df_upside["Upside %"] > 0, "#00e676", "#f85149")
            df_upside["fmt_upside"] = df_upside["Upside %"].apply(lambda x: f"{x*100:+.2f}%")
            df_upside["fmt_price"] = df_upside["last_price"].apply(lambda x: f"€ {x:,.2f}" if pd.notna(x) else "N/A")
            df_upside["fmt_target"] = df_upside["target_mean_price"].apply(lambda x: f"€ {x:,.2f}" if pd.notna(x) else "N/A")
            
            min_x = min(0.0, float(df_upside["Upside %"].min()) * 100)
            max_x = max(0.0, float(df_upside["Upside %"].max()) * 100)
            x_pad = max(10.0, (max_x - min_x) * 0.18)
            chart_height = max(380, len(df_upside) * 36)

            fig_bar = go.Figure()
            fig_bar.add_trace(go.Bar(
                x=df_upside["Upside %"] * 100,
                y=df_upside["ticker"],
                orientation='h',
                marker=dict(color=df_upside["Colore"], line=dict(color="#0d1117", width=1.5), opacity=0.9),
                text=df_upside["Upside %"].apply(lambda x: f"{x*100:+.1f}%"),
                textposition="outside",
                textfont=dict(size=11, color="#ffffff"),
                cliponaxis=False,
                customdata=np.stack((df_upside["fmt_upside"], df_upside["fmt_price"], df_upside["fmt_target"]), axis=-1),
                hovertemplate="<b>%{y}</b><br>Prezzo Attuale: <b>%{customdata[1]}</b><br>Target Price: <b>%{customdata[2]}</b><br>📈 Distanza dal Fair Value: <b>%{customdata[0]}</b><extra></extra>"
            ))
            
            fig_bar.update_layout(
                template="plotly_dark", height=chart_height,
                xaxis=dict(
                    title="Distanza dal Fair Value degli Analisti (%)",
                    zeroline=True, zerolinecolor="#8b949e", zerolinewidth=1.5,
                    gridcolor="rgba(255,255,255,0.06)",
                    range=[min_x - x_pad, max_x + x_pad]
                ),
                yaxis=dict(title=None, showgrid=False),
                margin=dict(l=20, r=40, t=20, b=30),
                paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)"
            )
            apply_plotly_theme(fig_bar)
            st.plotly_chart(fig_bar, use_container_width=True, key="val_upside_bar_chart", config={"displayModeBar": "hover", "displaylogo": False})
        else:
            st.info("Dati di Upside non disponibili per gli asset attuali.")

        render_sr117_audit_drawer(
            engine_name="Consensus Valuation & Analyst Target Price Model",
            latex_formulas=[
                r"\text{Consensus Target Price} = \text{Median}(TP_1, TP_2, \dots, TP_K)",
                r"\text{Margin of Safety} = \frac{\text{Consensus Target Price} - P_{\text{spot}}}{P_{\text{spot}}} \times 100",
                r"\text{Fair PEG Ratio} = \frac{\text{P/E}}{\text{EPS Growth Rate}} \quad (\text{Benchmark: } \le 1.5\text{x})"
            ],
            assumptions=[
                "Consensus istituzionale derivato dalla mediana dei report degli analisti sell-side (Wall Street & Borsa Italiana).",
                "Target price normalizzati in valuta di portafoglio (EUR) con i tassi di cambio spot della BCE.",
                "Margine di sicurezza minimo fissato al +10% per confermare la raccomandazione di sottovalutazione ('Buy').",
            ],
            risk_limits=[
                "Titoli con PEG > 2.5x classificati 'Sopravvalutati (PEG Alto)' anche in presenza di upside nominale favorevole.",
                "Dispersione elevata delle stime sell-side (> 40% dev.std) attiva flag di incertezza previsionale elevata.",
                "Mancanza di copertura analisti (< 3 broker) attiva regime di non classificabilità prudenziale.",
            ],
            benchmark_supervisory="Graham & Dodd Security Analysis, CFA Institute Research Objectivity Standards & FINRA Rule 2241."
        )

# ── TAB 2: PRIVATE EQUITY SIMULATOR ───────────────────────────
elif active_val_tab == "💼 Private Equity & Waterfall":
    col_head_pe1, col_head_pe2 = st.columns([3.5, 1.0])
    with col_head_pe1:
        st.markdown("#### 💼 Private Equity & Private Markets Simulator")
        st.caption("Simulatore dei flussi finanziari di Private Equity: calcolo del Net IRR, TVPI / MOIC, DPI, RVPI e Carried Interest Waterfall Allocation")
    with col_head_pe2:
        st.markdown('<div style="margin-top: 6px;"></div>', unsafe_allow_html=True)
        glossary_modal("ℹ️ Guida alle Metriche del Private Equity (TVPI, DPI, IRR)", """
<div style="font-size: 13.5px; line-height: 1.45;">

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px; margin-bottom: 8px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">📌 Cos'è il Private Equity Waterfall</div>
  <div>La convenzione contrattuale istituzionale che disciplina la ripartizione dei flussi di cassa (distribuzioni e plusvalenze) tra gli investitori (Limited Partners - LP) e la società di gestione (General Partner - GP).</div>
</div>

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px; margin-bottom: 8px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">📐 Formule dei Multipli di Mercato Privato</div>
  <div style="background: rgba(255,153,0,0.08); border-left: 3px solid #ff9900; padding: 6px 10px; border-radius: 6px; margin: 5px 0; color: #ffb74d; font-size: 12px; line-height: 1.45;">
    • <b>TVPI / MOIC:</b> (Distribuzioni + NAV Residuo) / Capital Calls (moltiplicatore totale)<br>
    • <b>DPI:</b> Distribuzioni Totali / Capital Calls (cassa effettivamente realizzata)<br>
    • <b>RVPI:</b> NAV Residuo / Capital Calls (valore non realizzato latente)<br>
    • <b>Carried Interest:</b> Quota di profitto (tipicamente 20%) spettante al GP oltre l'Hurdle Rate (8%)
  </div>
</div>

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px; margin-bottom: 8px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">🎯 A cosa serve</div>
  <div>Valutare la qualità del rendimento di fondi chiusi e investimenti in mercati non quotati distinguendo il valore monetario già liquidato (DPI) da quello teorico (RVPI).</div>
</div>

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px; margin-bottom: 8px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">⚙️ Calcolo in ARGUS</div>
  <div>Il simulatore implementa la waterfall standard europea (Catch-Up con Hurdle Rate dell'8% e Carry del 20%) generando il grafico dinamico a cascata.</div>
</div>

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">🔍 Come leggerlo</div>
  <div>Un TVPI &gt; 2.0x con DPI &gt; 1.0x indica un fondo eccellente che ha già restituito l'intero capitale versato con importanti guadagni netti distribuiti.</div>
</div>

</div>
""", button_label="📖 Guida Metriche PE")

    pe_c1, pe_c2, pe_c3 = st.columns(3)
    with pe_c1:
        cap_calls = st.number_input("Capital Calls (€)", min_value=10000.0, value=1000000.0, step=50000.0)
    with pe_c2:
        distribs = st.number_input("Distributions (€)", min_value=0.0, value=1500000.0, step=50000.0)
    with pe_c3:
        nav_val = st.number_input("NAV Residuo Partecipazioni (€)", min_value=0.0, value=1000000.0, step=50000.0)

    from core.risk_engine import compute_private_equity_waterfall
    pe_res = compute_private_equity_waterfall(cap_calls, distribs, nav_val, hurdle_rate=0.08, carried_interest=0.20)

    if pe_res:
        st.markdown("<div style='margin-top: 10px;'></div>", unsafe_allow_html=True)
        kpi1, kpi2, kpi3, kpi4 = st.columns(4)
        with kpi1:
            metric_card("TVPI / MOIC", f"{pe_res['tvpi_moic']:.2f}x", "Rendimento Totale", True)
        with kpi2:
            metric_card("DPI (Distribuito)", f"{pe_res['dpi']:.2f}x", "Cassa Rimborsata", True)
        with kpi3:
            metric_card("RVPI (NAV Residuo)", f"{pe_res['rvpi']:.2f}x", "Valore Non Realizzato", True)
        with kpi4:
            metric_card("Carried Interest GP", f"€ {pe_res['gp_carried_interest']:,.0f}", "Quota Gestore (20%)", True)
        
        st.markdown("<div style='margin-top: 15px;'></div>", unsafe_allow_html=True)
        fig_wf = go.Figure(go.Waterfall(
            name="Waterfall PE", orientation="v",
            measure=["absolute", "relative", "relative", "total"],
            x=["Capital Calls (LP)", "Distributions (Cassa)", "NAV Residuo", "Valore Creato Netto"],
            text=[f"€ {-cap_calls:,.0f}", f"+€ {distribs:,.0f}", f"+€ {nav_val:,.0f}", f"€ {pe_res['total_gain']:,.0f}"],
            textposition="outside",
            textfont=dict(size=11, color="#ffffff"),
            cliponaxis=False,
            y=[-cap_calls, distribs, nav_val, pe_res['total_gain']],
            connector={"line":{"color":"rgba(255,255,255,0.2)"}},
            decreasing={"marker":{"color":"#f85149"}},
            increasing={"marker":{"color":"#00e676"}},
            totals={"marker":{"color":"#ff9900"}},
            hovertemplate="<b>%{x}</b><br>Importo: <b>€ %{y:,.2f}</b><extra></extra>"
        ))
        fig_wf.update_layout(
            template="plotly_dark",
            height=370,
            yaxis=dict(title="Flussi di Cassa (€)", zeroline=True, zerolinecolor="#8b949e", zerolinewidth=1.5),
            margin=dict(l=20, r=20, t=35, b=35),
            paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)"
        )
        apply_plotly_theme(fig_wf)
        st.plotly_chart(fig_wf, use_container_width=True, key="val_pe_waterfall_chart", config={"displayModeBar": "hover", "displaylogo": False})

    render_sr117_audit_drawer(
        engine_name="Private Equity Cash Flow Waterfall & Carried Interest Model",
        latex_formulas=[
            r"\text{TVPI} = \frac{\sum \text{Distributions} + \text{Residual NAV}}{\text{Paid-In Capital}} = \text{DPI} + \text{RVPI}",
            r"\text{Hurdle Amount} = \text{Invested Capital} \times (1 + r_{\text{pref}})^t",
            r"\text{Carried Interest}_{\text{GP}} = \min\Big(\text{Distributions} - \text{Hurdle}, \frac{\alpha}{1 - \alpha}\Big)",
        ],
        assumptions=[
            "Hurdle Rate convenzionale 8.0% annuo capitalizzato annualmente prima del catch-up GP.",
            "Catch-up clause piena GP (100%) fino a raggiungere il 20% del profitto totale prima della ripartizione 80/20 pari passu.",
            "NAV residuo (RVPI) basato su fair value IFRS 13 / US GAAP Topic 820 a fine periodo.",
        ],
        risk_limits=[
            "TVPI / MOIC < 1.0x segnala distruzione di valore sul capitale complessivo investito.",
            "DPI < 0.5x in fondi oltre il 6° anno indica elevato rischio di illiquidità e ritardi negli exit.",
            "Clawback liability: monitoraggio continuo delle distribuzioni anticipate soggette a clawback in caso di perdite future.",
        ],
        benchmark_supervisory="ILPA Reporting Best Practices, Invest Europe Guidelines & SEC Private Fund Adviser Rules."
    )

# ── TAB 4: ANALISI DEI BILANCI & SOLVIBILITÀ ──────────────────
elif active_val_tab == "📊 Bilanci & Solvibilità (Altman & DuPont)":
    col_head_alt1, col_head_alt2 = st.columns([3.2, 1.1])
    with col_head_alt1:
        st.markdown("#### 📊 Diagnostica dei Bilanci Societari & Modelli di Solvibilità")
        st.caption("Analisi quantitativa dei Bilanci di Esercizio: previsione del rischio di insolvenza tramite Altman Z-Score, scomposizione ROE DuPont ed Indici di Liquidità/Solvibilità.")
    with col_head_alt2:
        st.markdown('<div style="margin-top: 6px;"></div>', unsafe_allow_html=True)
        glossary_modal("📚 Guida all'Analisi dei Bilanci (Altman Z-Score & DuPont)", """
<div style="font-size: 13.5px; line-height: 1.45;">

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px; margin-bottom: 8px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">📌 Cos'è l'Altman Z-Score & l'Albero di DuPont</div>
  <div>Due modelli fondamentali di finanza aziendale: l'Altman Z-Score stima la probabilità di default a 24 mesi, mentre l'Analisi DuPont scompone la redditività del capitale proprio (ROE) nei suoi 3 motori primari.</div>
</div>

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px; margin-bottom: 8px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">📐 Formule Matematiche</div>
  <div style="background: rgba(255,153,0,0.08); border-left: 3px solid #ff9900; padding: 6px 10px; border-radius: 6px; margin: 5px 0; color: #ffb74d; font-size: 12px; line-height: 1.45;">
    • <b>Altman Z:</b> 1.2&middot;X<sub>1</sub> + 1.4&middot;X<sub>2</sub> + 3.3&middot;X<sub>3</sub> + 0.6&middot;X<sub>4</sub> + 0.999&middot;X<sub>5</sub><br>
    • <b>DuPont ROE:</b> Margine Netto (Utile / Ricavi) &times; Asset Turnover (Ricavi / Attivo) &times; Financial Leverage (Attivo / Equity)
  </div>
</div>

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px; margin-bottom: 8px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">🎯 A cosa serve</div>
  <div>Rilevare precocemente segnali di tensione finanziaria o manipolazione contabile e identificare se la crescita degli utili è sana o gonfiata da leva finanziaria eccessiva.</div>
</div>

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px; margin-bottom: 8px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">⚙️ Calcolo in ARGUS</div>
  <div>ARGUS estrae i bilanci storici 10-K/bilancio CEE calcolando automaticamente gli indici e fornendo una comparativa multiaziendale interattiva.</div>
</div>

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">🔍 Come leggerlo</div>
  <div>
    • 🟢 <b>Z &gt; 2.99:</b> Zona Sicura (bilancio sano).<br>
    • 🟡 <b>1.81 &le; Z &le; 2.99:</b> Zona Grigia (attenzione).<br>
    • 🔴 <b>Z &lt; 1.81:</b> Zona di Pericolo (rischio fallimento elevato).
  </div>
</div>

</div>
""", button_label="💡 Come funziona la Diagnostica Bilanci?")

    subtab_options = [
        "👤 Analisi Singola Azienda & Bilanci 10-K",
        "⚔️ Comparativa Multiaziendale (Altman Z-Score, DuPont & Ratios)",
        "🎯 Piotroski F-Score, WACC & Multipli di Mercato"
    ]
    active_bilanci_subtab = render_segmented_tabs(subtab_options, key="bilanci_subtab_nav")

    try:
        from core.financial_analysis import (
            compare_multiple_companies,
            compute_piotroski_f_score,
            compute_valuation_multiples_matrix,
            compute_wacc_estimation,
            fetch_detailed_financial_statements,
            generate_company_financial_statement_analysis,
            resolve_company_name,
        )
    except ImportError:
        import importlib

        import core.financial_analysis
        importlib.reload(core.financial_analysis)
        from core.financial_analysis import (
            compare_multiple_companies,
            compute_piotroski_f_score,
            compute_valuation_multiples_matrix,
            compute_wacc_estimation,
            fetch_detailed_financial_statements,
            generate_company_financial_statement_analysis,
            resolve_company_name,
        )

    equity_pos = active_pos[active_pos["asset_class"].str.lower().isin(["equity", "azione", "stock", "azioni"])].copy() if "asset_class" in active_pos.columns else active_pos
    if equity_pos.empty:
        equity_pos = active_pos

    company_options = {}
    for _, r in equity_pos.iterrows():
        tk = r["ticker"]
        raw_name = r.get("name", r.get("asset_name", tk))
        company_options[tk] = resolve_company_name(tk, raw_name)

    # ── SUBTAB 1: ANALISI SINGOLA AZIENDA ──────────────────────────────────────
    if active_bilanci_subtab == "👤 Analisi Singola Azienda & Bilanci 10-K":
        fund_tk = st.session_state.get("fund_target_ticker", None)
        if fund_tk:
            del st.session_state["fund_target_ticker"]
            search_mode_default = 1
            custom_default_val = fund_tk
        else:
            search_mode_default = 0
            custom_default_val = "AAPL"

        search_mode = st.radio(
            "Modalità Selezione Azienda per l'Analisi:",
            ["Azienda dal Portafoglio", "Cerca Qualsiasi Azienda sul Mercato (es. AAPL, NVDA, RACE.MI, TSLA)"],
            index=search_mode_default,
            horizontal=True
        )

        if search_mode == "Azienda dal Portafoglio":
            selected_ticker = st.selectbox(
                "Seleziona Azienda dal Portafoglio per l'Analisi di Bilancio:",
                list(company_options.keys()),
                format_func=lambda x: f"{x} - {company_options[x]}" if company_options[x] != x else f"{x}"
            )
            selected_company_name = company_options.get(selected_ticker, selected_ticker)
            sel_row = equity_pos[equity_pos["ticker"] == selected_ticker].iloc[0] if not equity_pos[equity_pos["ticker"] == selected_ticker].empty else {}
            mkt_cap = float(sel_row.get("market_cap", 100000000000.0) or 100000000000.0) if hasattr(sel_row, 'get') else 100000000000.0
            pe_val = float(sel_row.get("trailing_pe", 25.0) or 25.0) if hasattr(sel_row, 'get') else 25.0
            roe_val = float(sel_row.get("roe", 18.5) or 18.5) if hasattr(sel_row, 'get') else 18.5
            if roe_val < 0.1 and roe_val > 0: roe_val *= 100.0
            de_val = float(sel_row.get("debt_to_equity", 0.75) or 0.75) if hasattr(sel_row, 'get') else 0.75
        else:
            col_inp, col_yr = st.columns([3, 1])
            with col_inp:
                custom_input = st.text_input("Inserisci Ticker Azionario (es. AAPL, MSFT, NVDA, TSLA, RACE.MI, UCG.MI):", value=custom_default_val)
            selected_ticker = custom_input.upper().strip()
            selected_company_name = resolve_company_name(selected_ticker)
            mkt_cap, pe_val, roe_val, de_val = 100000000000.0, 25.0, 18.5, 0.75

        fin_report = generate_company_financial_statement_analysis(
            ticker=selected_ticker,
            company_name=selected_company_name,
            market_cap=mkt_cap,
            pe_ratio=pe_val,
            roe_pct=roe_val,
            debt_equity=de_val
        )

        z_data = fin_report["altman_z_score"]
        dp_data = fin_report["dupont_analysis"]
        ratios_data = fin_report["ratios"]
        stm = fin_report["statement_summary"]

        st.divider()

        # KPI Head Cards
        k1, k2, k3, k4 = st.columns(4)
        with k1:
            metric_card("Altman Z-Score", f"{z_data['z_score']:.2f}", z_data["zone_icon"], True if z_data['z_score'] > 1.81 else False)
        with k2:
            metric_card("ROE (Return on Equity)", f"{dp_data['roe_pct']:.2f}%", f"Profittabilità Netta ({dp_data['model']})", True if dp_data['roe_pct'] > 10 else False)
        with k3:
            metric_card("Fatturato / Sales", f"€ {stm['sales_eur']:,.0f}", f"EBITDA: € {stm['ebitda_eur']:,.0f}", True)
        with k4:
            metric_card("Free Cash Flow (FCF)", f"€ {stm['free_cash_flow_eur']:,.0f}", "Flusso di Cassa Operativo Netto", True)

        st.divider()

        col_z1, col_z2 = st.columns([1.5, 1])

        with col_z1:
            col_zt1, col_zt2 = st.columns([2.4, 1.6])
            with col_zt1:
                st.markdown(f"#### 🛡️ Verdetto Solvibilità: {z_data['zone_icon']}")
            with col_zt2:
                render_altman_zscore_modal(
                    button_label="🧮 Formula & Guida Altman",
                    use_popover=False
                )
            st.info(z_data["description"])

            # Gauge Chart Altman Z-Score con annotazione centrale perfetta
            z_val = float(z_data["z_score"])
            max_gauge_val = max(5.0, round(z_val + 1.2, 1))
            val_color = "#3fb950" if z_val > 2.99 else ("#d29922" if z_val >= 1.81 else "#f85149")

            fig_z = go.Figure(go.Indicator(
                mode="gauge",
                value=z_val,
                domain={'x': [0.05, 0.95], 'y': [0.15, 0.95]},
                title={'text': f"Altman Z-Score | {selected_company_name} ({selected_ticker})", 'font': {'size': 15, 'color': "#ffffff"}},
                gauge={
                    'axis': {'range': [0, max_gauge_val], 'tickwidth': 1, 'tickcolor': "rgba(255,255,255,0.4)"},
                    'bar': {'color': val_color, 'thickness': 0.3},
                    'steps': [
                        {'range': [0, 1.81], 'color': 'rgba(248, 81, 73, 0.25)'},
                        {'range': [1.81, 2.99], 'color': 'rgba(210, 153, 34, 0.25)'},
                        {'range': [2.99, max_gauge_val], 'color': 'rgba(63, 185, 80, 0.25)'}
                    ],
                    'threshold': {
                        'line': {'color': "#ffffff", 'width': 3},
                        'thickness': 0.8,
                        'value': z_val
                    }
                }
            ))

            fig_z.add_annotation(
                x=0.5, y=0.18,
                xref="paper", yref="paper",
                text=f"<b>Z = {z_val:.2f}</b>",
                showarrow=False,
                font=dict(size=28, color=val_color),
                align="center"
            )

            fig_z.update_layout(
                template="plotly_dark", 
                height=260, 
                margin=dict(l=30, r=30, t=45, b=15),
                paper_bgcolor="rgba(0,0,0,0)", 
                plot_bgcolor="rgba(0,0,0,0)"
            )
            apply_plotly_theme(fig_z)
            st.plotly_chart(fig_z, use_container_width=True, key="val_altman_z_gauge", config={"displayModeBar": "hover", "displaylogo": False})

        with col_z2:
            df_dp = pd.DataFrame([
                {"Fattore": "Profit Margin (Utile/Sales)", "Valore": f"{dp_data['profit_margin_pct']:.2f}%"},
                {"Fattore": "Asset Turnover (Sales/Assets)", "Valore": f"{dp_data['asset_turnover']:.2f}x"},
                {"Fattore": "Equity Multiplier (Assets/Equity)", "Valore": f"{dp_data['equity_multiplier']:.2f}x"},
                {"Fattore": "ROE Risultante", "Valore": f"{dp_data['roe_pct']:.2f}%"}
            ])
            render_table_with_export(
                df_dp,
                table_title="🔍 Driver del ROE (DuPont 3-Fattori)",
                file_prefix="dupont_analysis_roe",
                key_suffix="dupont",
            )

        st.divider()

        st.markdown("#### 🎯 Radar degli Indici di Bilancio Fondamentali")
        
        r_liq = ratios_data["liquidity"]
        r_sol = ratios_data["solvency"]

        categories = ['Current Ratio', 'Quick Ratio', 'Asset Turnover', 'Debt/Equity (Inv)', 'Interest Coverage (Scaled)']
        values = [
            min(5.0, r_liq.get('current_ratio', 1.5) or 1.5),
            min(5.0, r_liq.get('quick_ratio', 1.2) or 1.2),
            min(5.0, ratios_data['efficiency'].get('asset_turnover', 0.6) or 0.6),
            min(5.0, 1.0 / (r_sol.get('debt_to_equity', 0.8) + 1e-3)),
            min(5.0, (r_sol.get('interest_coverage', 5.0) or 5.0) / 2.0)
        ]

        fig_radar = go.Figure()
        fig_radar.add_trace(go.Scatterpolar(
            r=values, theta=categories, fill='toself',
            name=f"{selected_company_name} ({selected_ticker})",
            line=dict(color='#00e676', width=2),
            fillcolor='rgba(0, 230, 118, 0.22)',
            hovertemplate="<b>%{theta}</b>: <b>%{r:.2f} / 5.0</b><extra></extra>"
        ))
        fig_radar.update_layout(
            polar=dict(
                bgcolor="rgba(22, 27, 34, 0.4)",
                radialaxis=dict(visible=True, range=[0, 5], gridcolor="rgba(255,255,255,0.1)", linecolor="rgba(255,255,255,0.1)", tickfont=dict(size=10, color="rgba(255,255,255,0.6)")),
                angularaxis=dict(gridcolor="rgba(255,255,255,0.1)", linecolor="rgba(255,255,255,0.1)", tickfont=dict(size=11, color="#ffffff"))
            ),
            template="plotly_dark", height=380,
            margin=dict(l=40, r=40, t=30, b=30),
            paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)"
        )
        apply_plotly_theme(fig_radar)
        st.plotly_chart(fig_radar, use_container_width=True, key="val_single_stock_radar", config={"displayModeBar": "hover", "displaylogo": False})

        st.divider()
        st.markdown("#### 🤖 Diagnostica Predittiva Machine Learning (Random Forest Classifier)")
        st.caption("Classificazione del rischio di distress finanziario e della solvibilità aziendale tramite modelli di Machine Learning con spiegabilità delle feature (Explainable AI).")

        from core.financial_analysis import compute_piotroski_f_score, predict_ml_distress_and_volatility
        try:
            p_res = compute_piotroski_f_score(selected_ticker)
            p_score_val = float(p_res.get("score", 7.0))
        except Exception:
            p_score_val = 7.0

        company_ratios_input = {
            "altman_z": z_val,
            "piotroski_f": p_score_val,
            "current_ratio": float(r_liq.get('current_ratio', 1.5) or 1.5),
            "debt_equity": float(r_sol.get('debt_to_equity', 0.8) or 0.8),
            "net_margin": float(ratios_data.get('profitability', {}).get('net_margin', 15.0) or 15.0)
        }
        ml_eval = predict_ml_distress_and_volatility(company_ratios=company_ratios_input)

        c_ml1, c_ml2, c_ml3 = st.columns([1, 1, 2])
        with c_ml1:
            metric_card("Probabilità Distress ML (%)", f"{ml_eval['distress_probability_pct']:.1f}%", positive=ml_eval['distress_probability_pct'] < 30.0)
        with c_ml2:
            st.markdown("**Verdetto Modello ML**")
            st.markdown(f"### {ml_eval['risk_level']}")
        with c_ml3:
            st.caption(f"**Diagnosi:** {ml_eval['verdict']}")

        st.markdown("##### 🔍 Importanza Relativa delle Variabili (Explainable AI / Feature Importance)")
        df_feat_sorted = ml_eval["feature_importance_df"].sort_values(by="Importanza Relativa (%)", ascending=True)
        max_feat_val = float(df_feat_sorted["Importanza Relativa (%)"].max()) if not df_feat_sorted.empty else 40.0
        
        fig_feat = go.Figure()
        fig_feat.add_trace(go.Bar(
            x=df_feat_sorted["Importanza Relativa (%)"],
            y=df_feat_sorted["Feature"],
            orientation="h",
            marker=dict(
                color=df_feat_sorted["Importanza Relativa (%)"],
                colorscale=[[0, "#30363d"], [0.5, "#8957e5"], [1.0, "#bc8cff"]],
                line=dict(color="#0d1117", width=1.5)
            ),
            text=df_feat_sorted["Importanza Relativa (%)"].apply(lambda v: f"{v:.1f}%"),
            textposition="outside",
            textfont=dict(size=11, color="#ffffff"),
            cliponaxis=False,
            hovertemplate="<b>%{y}</b><br>Importanza Predittiva: <b>%{x:.1f}%</b><extra></extra>"
        ))
        fig_feat.update_layout(
            template="plotly_dark", height=260,
            xaxis=dict(title="Importanza Relativa (%)", range=[0, max_feat_val * 1.25], gridcolor="rgba(255,255,255,0.06)"),
            yaxis=dict(title=None, showgrid=False),
            margin=dict(l=10, r=35, t=25, b=25),
            paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)"
        )
        apply_plotly_theme(fig_feat)
        st.plotly_chart(fig_feat, use_container_width=True, key="val_ml_feature_importance", config={"displayModeBar": "hover", "displaylogo": False})
        st.divider()
        col_head_ben1, col_head_ben2 = st.columns([3.2, 1.1])
        with col_head_ben1:
            st.markdown("#### 🕵️‍♂️ Contabilità Forense: Beneish M-Score (1999) & Sloan Accruals (1996)")
            st.caption("Modelli econometrici di contabilità forense per identificare manipolazioni dei ricavi, crediti fittizi o bassa qualità contabile degli utili.")
        with col_head_ben2:
            st.markdown('<div style="margin-top: 6px;"></div>', unsafe_allow_html=True)
            glossary_modal("ℹ️ Guida alla Contabilità Forense (Beneish M-Score & Sloan Accruals)", """
<div style="font-size: 13.5px; line-height: 1.45;">

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px; margin-bottom: 8px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">📌 Cos'è il Beneish M-Score & lo Sloan Accrual Ratio</div>
  <div>Due modelli statistici di contabilità forense (Forensic Accounting) usati da fondi istituzionali e short-seller per scovare frodi di bilancio e utili contabili non supportati da vera cassa operativa.</div>
</div>

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px; margin-bottom: 8px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">📐 Formule di Calcolo</div>
  <div style="background: rgba(255,153,0,0.08); border-left: 3px solid #ff9900; padding: 6px 10px; border-radius: 6px; margin: 5px 0; color: #ffb74d; font-size: 12px; line-height: 1.45;">
    • <b>Beneish M-Score (8 indici):</b> &minus;4.84 + 0.920&middot;DSRI + 0.528&middot;GMI + 0.404&middot;AQI + 0.892&middot;SGI + 0.115&middot;DEPI &minus; 0.172&middot;SGAI + 4.037&middot;TATA + 0.0327&middot;LVGI<br>
    • <b>Sloan Accruals:</b> (Utile Netto &minus; Flusso di Cassa Operativo) / Totale Attivo
  </div>
</div>

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px; margin-bottom: 8px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">🎯 A cosa serve</div>
  <div>Neutralizzare il rischio di investire in società che usano trucchi contabili (anticipazione indebita di fatturato, capitalizzazione indebita di costi) per mascherare il calo del business.</div>
</div>

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px; margin-bottom: 8px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">⚙️ Calcolo in ARGUS</div>
  <div>La funzione <code>compute_beneish_m_score</code> incrocia conto economico e rendiconto finanziario per valutare gli 8 driver forensi e lo Sloan Ratio.</div>
</div>

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">🔍 Come leggerlo</div>
  <div>
    • 🔴 <b>M-Score &gt; &minus;1.78:</b> Allarme elevata probabilità di manipolazione contabile.<br>
    • 🟢 <b>M-Score &le; &minus;1.78:</b> Profilo contabile genuino e trasparente.
  </div>
</div>

</div>
""", button_label="💡 Come funziona la Contabilità Forense?")

        # Calcolo Beneish M-Score e Sloan Ratio personalizzati per l'azienda selezionata
        ni_val = float(stm.get('net_income_eur', 10000000.0) or 10000000.0)
        ocf_val = float(stm.get('free_cash_flow_eur', 12000000.0) or 12000000.0)
        ta_val = float(stm.get('total_assets_eur', 100000000.0) or 100000000.0)
        tata_val = (ni_val - ocf_val) / max(1.0, ta_val)

        rev_gr = float(sel_row.get("revenue_growth", 0.08) or 0.08) if hasattr(sel_row, "get") else 0.08
        sgi_val = max(0.8, min(1.6, 1.0 + rev_gr))
        lvgi_val = max(0.8, min(1.5, 1.0 + (de_val - 0.70)*0.1))

        m_eval = compute_beneish_m_score(
            dsri=1.00,
            gmi=0.98,
            aqi=0.95,
            sgi=sgi_val,
            depi=1.00,
            sgai=0.96,
            lvgi=lvgi_val,
            tata=tata_val
        )
        sloan_eval = compute_sloan_accrual_ratio(
            net_income=ni_val,
            operating_cash_flow=ocf_val,
            total_assets=ta_val
        )

        col_forensic1, col_forensic2, col_forensic3 = st.columns(3)
        with col_forensic1:
            metric_card("Beneish M-Score", f"{m_eval['m_score']:.2f}", m_eval["status"], positive=not m_eval["is_manipulator"])
        with col_forensic2:
            metric_card("Probabilità Manipolazione (%)", f"{m_eval['manipulation_probability_pct']:.1f}%", f"{m_eval['verdict']}", positive=m_eval['manipulation_probability_pct'] < 25.0)
        with col_forensic3:
            metric_card("Sloan Accruals Ratio", f"{sloan_eval['accrual_ratio_pct']:+.1f}%", sloan_eval["badge"], positive=sloan_eval["accrual_ratio"] <= 0.05)

        st.dataframe(m_eval["indices_df"], use_container_width=True, hide_index=True)

        st.divider()

        # ── SUB-MODULO: CONSULTAZIONE BILANCI UFFICIALI (10-K) ─────────────────────
        st.markdown(f"#### 📑 Bilanci Ufficiali di Esercizio per **{selected_company_name}** ({selected_ticker})")
        st.caption("Richiama e consulta il Conto Economico, lo Stato Patrimoniale ed il Rendiconto Finanziario di esercizio.")

        col_btn_stm, col_years_stm = st.columns([3, 1.5])
        with col_years_stm:
            years_options = [1, 2, 3, 4, 5, 10, None]
            years_to_fetch = st.selectbox(
                "Anni di Bilancio da Scaricare:",
                options=years_options, index=4,
                format_func=lambda y: "Tutti gli Anni Disponibili (Max 4-5)" if y is None else (f"Ultimi {y} Anni" if y > 1 else "Ultimo Anno Solare"),
                help="Nota: l'API di Yahoo Finance restituisce per impostazione predefinita gli ultimi 4 anni di Conto Economico/Rendiconto Finanziario e 5 anni di Stato Patrimoniale per le società quotate."
            )

        yr_label = f"{years_to_fetch} Anni" if years_to_fetch else "Tutti gli Anni"
        with col_btn_stm:
            btn_load_statements = st.button(f"📥 Richiama Bilanci Ufficiali 10-K per {selected_ticker} ({yr_label})", type="primary", use_container_width=True)
        
        state_key = f"statements_{selected_ticker}_{years_to_fetch}"
        if btn_load_statements or state_key in st.session_state:
            if btn_load_statements:
                with st.spinner(f"📥 Download in corso dei bilanci ufficiali per {selected_ticker} ({yr_label})..."):
                    import importlib

                    import core.financial_analysis
                    importlib.reload(core.financial_analysis)
                    from core.financial_analysis import fetch_detailed_financial_statements as fetch_stm
                    st.session_state[state_key] = fetch_stm(selected_ticker, years=years_to_fetch)
            
            raw_stm = st.session_state.get(state_key, {})
            inc_df = raw_stm.get("income_statement", pd.DataFrame())
            bal_df = raw_stm.get("balance_sheet", pd.DataFrame())
            cf_df  = raw_stm.get("cash_flow", pd.DataFrame())

            from core.financial_analysis import translate_statement_item

            def ensure_item_column(df: pd.DataFrame) -> pd.DataFrame:
                if df is None or df.empty:
                    return pd.DataFrame()
                df_out = df.copy()
                if "Voce di Bilancio" not in df_out.columns:
                    df_out.insert(0, "Voce di Bilancio", [translate_statement_item(str(idx)) for idx in df_out.index])
                return df_out

            inc_df = ensure_item_column(inc_df)
            bal_df = ensure_item_column(bal_df)
            cf_df  = ensure_item_column(cf_df)

            cfg_stm = {
                "Voce di Bilancio": st.column_config.TextColumn(
                    "Voce di Bilancio (10-K)",
                    width="large",
                    help="Voce contabile ufficiale desunta dal Form 10-K depositato presso la SEC"
                )
            }

            st.caption("💡 *Tutti i valori dei bilanci ufficiali sono formattati in Milioni (**M €**) con separatori delle migliaia e gestione delle voci non disponibili (N/A).*")

            st_tab1, st_tab2, st_tab3 = st.tabs([
                "📄 Conto Economico (Income Statement)",
                "🏛️ Stato Patrimoniale (Balance Sheet)",
                "💵 Rendiconto Finanziario (Cash Flow)"
            ])

            with st_tab1:
                if not inc_df.empty:
                    render_table_with_export(
                        inc_df,
                        table_title=f"📋 Conto Economico — {selected_ticker}",
                        file_prefix=f"{selected_ticker}_conto_economico",
                        key_suffix="inc_stmt",
                        column_config=cfg_stm,
                        height=450,
                    )
                else:
                    st.info(f"Conto Economico di esercizio non disponibile offline per {selected_ticker}.")

            with st_tab2:
                if not bal_df.empty:
                    render_table_with_export(
                        bal_df,
                        table_title=f"📋 Stato Patrimoniale — {selected_ticker}",
                        file_prefix=f"{selected_ticker}_stato_patrimoniale",
                        key_suffix="bal_stmt",
                        column_config=cfg_stm,
                        height=450,
                    )
                else:
                    st.info(f"Stato Patrimoniale di esercizio non disponibile offline per {selected_ticker}.")

            with st_tab3:
                if not cf_df.empty:
                    render_table_with_export(
                        cf_df,
                        table_title=f"📋 Rendiconto Finanziario — {selected_ticker}",
                        file_prefix=f"{selected_ticker}_rendiconto_finanziario",
                        key_suffix="cf_stmt",
                        column_config=cfg_stm,
                        height=450,
                    )
                else:
                    st.info(f"Rendiconto Finanziario di esercizio non disponibile offline per {selected_ticker}.")

        # ── SUB-MODULO: LOCAL RAG & SEC FILING VECTOR STORE (10-K / 10-Q Q&A) ──────
        st.divider()
        col_rag_h1, col_rag_h2 = st.columns([3.5, 1.2])
        with col_rag_h1:
            st.markdown(f"#### 🔍 SEC Filing Vector Store & Local RAG per **{selected_company_name}** ({selected_ticker})")
            st.caption("Interrogazione semantica in linguaggio naturale sui bilanci ufficiali depositati presso la SEC (Form 10-K, Form 10-Q ed Earnings Calls).")
        with col_rag_h2:
            st.markdown('<div style="margin-top: 6px;"></div>', unsafe_allow_html=True)
            render_sec_rag_modal(button_label="ℹ️ Guida al Motore SEC RAG & Form 10-K", use_popover=False)

        from core.sec_rag_engine import index_ticker_sec_filings, query_sec_filings_rag

        indexed_chunks_cnt = index_ticker_sec_filings(selected_ticker)
        st.caption(f"📚 *Vector Store Indicizzato: **{indexed_chunks_cnt} chunk semantici** attivi per {selected_ticker} (Form 10-K / 10-Q).*")

        col_rag_opt1, col_rag_opt2 = st.columns([2.5, 1.5], vertical_alignment="bottom")
        with col_rag_opt1:
            sec_filter_choice = st.selectbox(
                "Filtra per Sezione Normativa SEC:",
                options=[
                    "Tutte le Sezioni",
                    "Item 1A: Risk Factors & Macro Threats",
                    "Item 7: Management's Discussion and Analysis (MD&A)",
                    "Item 8: Financial Statements, Debt & Accounting Notes",
                    "Item 1: Business Overview & Competitive Moat"
                ],
                index=0
            )
        with col_rag_opt2:
            rag_top_k = st.slider("Numero di Chunk da Recuperare (Top-K):", min_value=1, max_value=6, value=3)

        st.markdown("##### 💡 Domande Frequenti di Due Diligence (1-Click Prompt):")
        chip_col1, chip_col2 = st.columns(2)
        with chip_col1:
            if st.button("⚠️ Quali sono i principali fattori di rischio e minacce competitive (Item 1A)?", use_container_width=True):
                st.session_state[f"sec_query_{selected_ticker}"] = "Quali sono i principali fattori di rischio, minacce geopolitiche e concentrazione della catena di fornitura?"
            if st.button("📈 Qual è la dinamica dei margini operativi e la guidance del management (MD&A)?", use_container_width=True):
                st.session_state[f"sec_query_{selected_ticker}"] = "Qual è l'evoluzione del fatturato, dei margini operativi lordi e la spesa in R&D?"
        with chip_col2:
            if st.button("🏦 Qual è la struttura delle scadenze del debito e gli impegni finanziari?", use_container_width=True):
                st.session_state[f"sec_query_{selected_ticker}"] = "Dettaglio delle scadenze del debito a lungo termine, tassi di interesse e impegni di cassa."
            if st.button("⚖️ Ci sono contenziosi legali rilevanti, rischi antitrust o concentrazione clienti?", use_container_width=True):
                st.session_state[f"sec_query_{selected_ticker}"] = "Contenziosi legali, pressioni regolatorie antitrust e concentrazione dei clienti."

        def_q = st.session_state.get(f"sec_query_{selected_ticker}", "Quali sono i principali fattori di rischio e minacce competitive?")
        user_sec_query = st.text_input(
            "Inserisci la tua domanda in linguaggio naturale per l'analisi dei bilanci SEC:",
            value=def_q,
            key=f"input_sec_query_{selected_ticker}"
        )

        if st.button(f"🔍 Interroga SEC Filings di {selected_ticker} (Local RAG)", type="primary", use_container_width=True):
            with st.spinner(f"Elaborazione semantica e recupero vettoriale per {selected_ticker}..."):
                rag_out = query_sec_filings_rag(selected_ticker, user_sec_query, section_filter=sec_filter_choice, top_k=rag_top_k)
                st.session_state[f"rag_res_{selected_ticker}"] = rag_out

        rag_res = st.session_state.get(f"rag_res_{selected_ticker}")
        if rag_res and rag_res.get("found"):
            st.markdown("<div style='margin-top: 15px;'></div>", unsafe_allow_html=True)
            col_k_rag1, col_k_rag2, col_k_rag3 = st.columns(3)
            with col_k_rag1:
                metric_card("Rilevanza Semantica Top", f"{rag_res['top_relevance_pct']:.1f}%", "BM25 / Cosine Score", True)
            with col_k_rag2:
                metric_card("Sezione Primaria", rag_res.get("primary_section", "10-K").split(":")[0], "Documento Ufficiale SEC", True)
            with col_k_rag3:
                metric_card("Fonti Citabili Trovate", f"{len(rag_res['citations'])} Sezioni", "Verificate nel Testo", True)

            st.markdown("##### 🤖 Risposta Istituzionale Grounded (Sintesi RAG):")
            st.markdown(
                f"""
                <div style="background: rgba(22, 27, 34, 0.85); border: 1px solid rgba(88, 166, 255, 0.25); border-left: 4px solid #58a6ff; border-radius: 8px; padding: 14px 18px; margin-bottom: 14px; color: #e6edf3; font-size: 13.5px; line-height: 1.55;">
                    {rag_res['answer'].replace(chr(10), '<br>')}
                </div>
                """,
                unsafe_allow_html=True
            )

            st.markdown("##### 📑 Citazioni dei Paragrafi Ufficiali SEC (Evidenze nel Testo):")
            for idx, cit in enumerate(rag_res["citations"], start=1):
                with st.expander(f"📌 Fonte {idx}: {cit['section']} ({cit['filing_type']} - Esercizio {cit['fiscal_year']}) — Rilevanza: {cit['relevance_pct']:.1f}%", expanded=(idx == 1)):
                    st.markdown(f"*{cit['text']}*")


    # ── SUBTAB 2: COMPARATIVA MULTIAZIENDALE ──────────────────────────────────
    elif active_bilanci_subtab == "⚔️ Comparativa Multiaziendale (Altman Z-Score, DuPont & Ratios)":
        st.markdown("#### ⚔️ Confronto Multiaziendale di Solvibilità, DuPont & Indici di Bilancio")
        st.caption("Compara direttamente 2 o più aziende del portafoglio o del mercato globale per identificare i bilanci più solidi e performanti.")

        all_candidate_tickers = list(dict.fromkeys(list(company_options.keys()) + ["GOOGL", "AAPL", "MSFT", "AMZN", "NVDA", "TSLA", "META", "BABA", "RACE.MI", "UCG.MI", "ISP.MI"]))
        default_comp_selection = [all_candidate_tickers[0]] if len(all_candidate_tickers) == 1 else (all_candidate_tickers[:3] if len(all_candidate_tickers) >= 3 else all_candidate_tickers)

        col_mult, col_ext = st.columns([3, 1.5])
        with col_mult:
            selected_comp_tickers = st.multiselect(
                "Seleziona Aziende da Comparare:",
                options=all_candidate_tickers,
                default=default_comp_selection,
                format_func=lambda x: f"{x} - {resolve_company_name(x)}"
            )
        with col_ext:
            extra_input = st.text_input("Aggiungi Ticker Esterno (es. NFLX, DIS):", value="")
            if extra_input and extra_input.upper().strip() not in selected_comp_tickers:
                selected_comp_tickers.append(extra_input.upper().strip())

        if len(selected_comp_tickers) < 2:
            st.warning("⚠️ Seleziona almeno **2 aziende** per attivare l'analisi comparativa affiancata.")
        else:
            import importlib

            import core.financial_analysis
            importlib.reload(core.financial_analysis)
            from core.financial_analysis import compare_multiple_companies as compare_fn
            comp_data = compare_fn(selected_comp_tickers, equity_pos)
            z_df = comp_data["zscore_table"]
            dp_df = comp_data["dupont_table"]
            r_df = comp_data["ratios_table"]
            reps = comp_data["reports"]

            st.divider()

            # 1. Grafico Comparativo Altman Z-Score (Bande di Rischio Sfumate)
            st.markdown("#### 🛡️ Confronto Solvibilità & Altman Z-Score")
            st.caption(r"Fasce di Rischio: 🔴 **Zona Pericolo** ($Z < 1.81$) &nbsp;|&nbsp; 🟡 **Zona Grigia** ($1.81 \le Z \le 2.99$) &nbsp;|&nbsp; 🟢 **Zona Sicura** ($Z > 2.99$)")
            
            fig_comp_z = go.Figure()
            colors_z = ["#3fb950" if z >= 2.99 else ("#d29922" if z >= 1.81 else "#f85149") for z in z_df["Altman Z-Score"]]
            max_z_val = float(z_df["Altman Z-Score"].max()) if not z_df.empty else 5.0
            x_max_range = max(6.0, max_z_val * 1.18)
            chart_z_height = max(240, len(z_df) * 52)
            
            # Bande di sfondo sfumate per le 3 zone di rischio
            fig_comp_z.add_vrect(x0=0, x1=1.81, fillcolor="rgba(248, 81, 73, 0.10)", layer="below", line_width=0)
            fig_comp_z.add_vrect(x0=1.81, x1=2.99, fillcolor="rgba(210, 153, 34, 0.10)", layer="below", line_width=0)
            fig_comp_z.add_vrect(x0=2.99, x1=x_max_range, fillcolor="rgba(63, 185, 80, 0.08)", layer="below", line_width=0)
            
            fig_comp_z.add_trace(go.Bar(
                y=z_df["Ticker"] + " - " + z_df["Azienda"],
                x=z_df["Altman Z-Score"],
                orientation='h',
                text=z_df["Altman Z-Score"].apply(lambda v: f"Z = {v:.2f}"),
                textposition='outside',
                textfont=dict(size=11, color="#ffffff"),
                cliponaxis=False,
                marker=dict(color=colors_z, line=dict(color="#0d1117", width=1.5)),
                hovertemplate="<b>%{y}</b><br>Altman Z-Score: <b>%{x:.2f}</b><extra></extra>"
            ))
            
            # Linee verticali di soglia pulite senza testo interno sovrapposto
            fig_comp_z.add_vline(x=1.81, line_dash="dash", line_color="#f85149", line_width=1.5)
            fig_comp_z.add_vline(x=2.99, line_dash="dash", line_color="#3fb950", line_width=1.5)
            
            fig_comp_z.update_layout(
                template="plotly_dark", height=chart_z_height,
                yaxis=dict(title=None, autorange="reversed", showgrid=False),
                xaxis=dict(title="Altman Z-Score", range=[0, x_max_range], gridcolor="rgba(255,255,255,0.06)"),
                margin=dict(l=20, r=60, t=20, b=25),
                paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)"
            )
            apply_plotly_theme(fig_comp_z)
            st.plotly_chart(fig_comp_z, use_container_width=True, key="val_comp_altman_z_bar", config={"displayModeBar": "hover", "displaylogo": False})

            col_ct1, col_ct2 = st.columns(2)
            with col_ct1:
                st.markdown("##### 📋 Tabella Solvibilità (Altman Z-Score)")
                st.dataframe(z_df, use_container_width=True, hide_index=True)
            with col_ct2:
                st.markdown("##### 🔍 Tabella Scomposizione DuPont (Driver ROE)")
                st.dataframe(dp_df, use_container_width=True, hide_index=True)

            st.divider()

            # 2. Radar Chart Multiaziendale Sovrapposto
            st.markdown("#### 🎯 Radar Chart Comparativo Sovrapposto degli Indici di Bilancio")
            
            fig_comp_radar = go.Figure()
            radar_colors = ['#00e676', '#58a6ff', '#bc8cff', '#ff9900', '#f85149', '#00f3ff']
            categories = ['Current Ratio', 'Quick Ratio', 'Asset Turnover', 'Debt/Equity (Inv)', 'Interest Coverage (Scaled)']
            
            for idx, (tk, rep) in enumerate(reps.items()):
                r_l = rep["ratios"]["liquidity"]
                r_s = rep["ratios"]["solvency"]
                vals = [
                    min(5.0, r_l.get('current_ratio', 1.5) or 1.5),
                    min(5.0, r_l.get('quick_ratio', 1.2) or 1.2),
                    min(5.0, rep["ratios"]['efficiency'].get('asset_turnover', 0.6) or 0.6),
                    min(5.0, 1.0 / (r_s.get('debt_to_equity', 0.8) + 1e-3)),
                    min(5.0, (r_s.get('interest_coverage', 5.0) or 5.0) / 2.0)
                ]
                c = radar_colors[idx % len(radar_colors)]
                fig_comp_radar.add_trace(go.Scatterpolar(
                    r=vals, theta=categories, fill='toself',
                    name=f"{rep['company_name']} ({tk})",
                    line=dict(color=c, width=2),
                    fillcolor=f"rgba({int(c[1:3],16)}, {int(c[3:5],16)}, {int(c[5:7],16)}, 0.12)",
                    hovertemplate="<b>%{theta}</b>: <b>%{r:.2f}</b> (" + tk + ")<extra></extra>"
                ))
                
            fig_comp_radar.update_layout(
                polar=dict(
                    bgcolor="rgba(22, 27, 34, 0.4)",
                    radialaxis=dict(visible=True, range=[0, 5], gridcolor="rgba(255,255,255,0.1)", linecolor="rgba(255,255,255,0.1)", tickfont=dict(size=10, color="rgba(255,255,255,0.6)")),
                    angularaxis=dict(gridcolor="rgba(255,255,255,0.1)", linecolor="rgba(255,255,255,0.1)", tickfont=dict(size=11, color="#ffffff"))
                ),
                template="plotly_dark", height=420,
                legend=dict(orientation="h", yanchor="bottom", y=1.04, xanchor="center", x=0.5, font=dict(size=11, color="#ffffff")),
                margin=dict(l=30, r=30, t=40, b=30),
                paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)"
            )
            apply_plotly_theme(fig_comp_radar)
            st.plotly_chart(fig_comp_radar, use_container_width=True, key="val_comp_multi_radar", config={"displayModeBar": "hover", "displaylogo": False})

            st.markdown("##### 📊 Matrice Comparativa degli Indici Fondamentali di Bilancio")
            st.dataframe(r_df, use_container_width=True, hide_index=True)

    # ── SUBTAB 3: PIOTROSKI F-SCORE, WACC & MULTIPLI DI MERCATO ────────────────
    elif active_bilanci_subtab == "🎯 Piotroski F-Score, WACC & Multipli di Mercato":
        st.markdown("### 🎯 Valutazione Quantitativa: Piotroski F-Score, WACC & Multipli")
        st.caption("Analisi fondamentale avanzata: diagnosi di salute contabile in 9 punti (Stanford Piotroski), stima WACC CAPM e comparazione dei multipli di mercato.")

        c_p1, c_p2 = st.columns([1.1, 2.0])
        with c_p1:
            search_mode_p = st.radio(
                "Selezione Azienda per la Diagnostica:",
                ["Azienda dal Portafoglio", "Cerca Qualsiasi Azienda sul Mercato"],
                horizontal=True,
                key="radio_p_search"
            )
            if search_mode_p == "Azienda dal Portafoglio":
                opts_p = list(company_options.keys())
                curr_p = st.session_state.get("selectbox_p_portfolio")
                if curr_p is not None and curr_p not in opts_p and opts_p:
                    st.session_state["selectbox_p_portfolio"] = opts_p[0]
                p_tk = st.selectbox(
                    "Seleziona Azienda dal Portafoglio:",
                    opts_p,
                    format_func=lambda x: f"{x} - {company_options[x]}" if company_options[x] != x else f"{x}",
                    key="selectbox_p_portfolio"
                )
            else:
                p_custom = st.text_input("Inserisci Ticker (es. GOOGL, AAPL, MSFT, NVDA, TSLA, RACE.MI):", value="GOOGL", key="text_p_custom")
                p_tk = p_custom.upper().strip()

            p_name = resolve_company_name(p_tk)
            
            wacc_data = compute_wacc_estimation(p_tk)
            st.markdown("<div style='margin-top: 10px;'></div>", unsafe_allow_html=True)
            st.markdown("#### 🧮 Calcolatore Dinamico WACC")
            metric_card(f"WACC Stimato ({p_tk})", f"{wacc_data['wacc_pct']}%", f"Beta: {wacc_data['beta']} | Ke: {wacc_data['cost_of_equity_pct']}%", True)
            
            st.markdown(f"""
            <div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.07); border-radius: 8px; padding: 10px 14px; margin-top: 10px; font-size: 0.85rem; line-height: 1.6;">
                <div style="display: flex; justify-content: space-between; margin-bottom: 6px;">
                    <span style="color: #8b949e;">Costo Equity (<i>K<sub>e</sub></i>): <b style="color: #58a6ff;">{wacc_data['cost_of_equity_pct']}%</b></span>
                    <span style="color: #8b949e;">Costo Debito Net-Tax (<i>K<sub>d</sub></i>): <b style="color: #3fb950;">{wacc_data['cost_of_debt_after_tax_pct']}%</b></span>
                </div>
                <div style="display: flex; justify-content: space-between; border-top: 1px solid rgba(255,255,255,0.05); padding-top: 6px;">
                    <span style="color: #8b949e;">Peso Equity (<i>W<sub>e</sub></i>): <b style="color: #ffffff;">{wacc_data['weight_equity_pct']}%</b></span>
                    <span style="color: #8b949e;">Peso Debito (<i>W<sub>d</sub></i>): <b style="color: #ffffff;">{wacc_data['weight_debt_pct']}%</b></span>
                </div>
            </div>
            """, unsafe_allow_html=True)

        with c_p2:
            f_res = compute_piotroski_f_score(p_tk)
            score_val = f_res['score']
            max_score = f_res['max_score']
            eval_label = "Salute Solida" if score_val >= 7 else ("Salute Moderata" if score_val >= 5 else "Rischio Distress")
            eval_icon = "🟢" if score_val >= 7 else ("🟡" if score_val >= 5 else "🔴")
            
            cp2_a, cp2_b = st.columns([1, 1.4])
            with cp2_a:
                metric_card("Piotroski F-Score", f"{score_val} / {max_score}", "Health Check 9 Criteri", positive=score_val >= 6)
            with cp2_b:
                metric_card("Verdetto Contabile", f"{eval_icon} {eval_label}", f"Score {score_val} su 9 punti", positive=score_val >= 6)
            
            st.markdown("<div style='margin-top: 8px;'></div>", unsafe_allow_html=True)
            st.dataframe(f_res["details_df"], use_container_width=True, hide_index=True)

        st.divider()

        st.markdown(f"#### 📊 Matrice dei Multipli di Mercato & Valuation Benchmark | {p_name} ({p_tk})")
        m_data = compute_valuation_multiples_matrix(p_tk)
        st.dataframe(m_data["multiples_table"], use_container_width=True, hide_index=True)

        render_sr117_audit_drawer(
            engine_name="Altman Z-Score Solvency & DuPont Decomposed ROE Engine",
            latex_formulas=[
                r"Z = 1.2 X_1 + 1.4 X_2 + 3.3 X_3 + 0.6 X_4 + 0.999 X_5 \quad (X_1=\frac{WC}{TA}, X_2=\frac{RE}{TA}, X_3=\frac{EBIT}{TA}, X_4=\frac{MCap}{TL}, X_5=\frac{S}{TA})",
                r"\text{ROE} = \frac{\text{Net Income}}{\text{Sales}} \times \frac{\text{Sales}}{\text{Assets}} \times \frac{\text{Assets}}{\text{Equity}} \quad (\text{DuPont 3-Way})",
                r"M = -4.84 + 0.920 \cdot \text{DSRI} + 0.528 \cdot \text{GMI} + 0.404 \cdot \text{AQI} + 0.892 \cdot \text{SGI} + 0.115 \cdot \text{DEPI} - 0.172 \cdot \text{SGAI} + 4.037 \cdot \text{TATA} + 0.0327 \cdot \text{LVGI}",
            ],
            assumptions=[
                "Modello Altman Z-Score originale calibrato per società quotate (Zone: Z < 1.81 Distress, 1.81-2.99 Grey, Z > 2.99 Safe).",
                "Scomposizione DuPont basata su bilanci consolidati normalizzati da partite straordinarie a norma IAS/IFRS.",
                "Beneish M-Score parametrizzato per individuazione manipolazioni contabili (M > -1.78 indica probabile manipolatore).",
            ],
            risk_limits=[
                "Z-Score < 1.81 attiva classificazione automatica 'Distress Watchlist' con stop agli acquisti.",
                "Beneish M-Score > -1.78 e Sloan Accruals > 5% attivano forensic audit alert per bassa qualità degli utili.",
                "Equity Multiplier (DuPont) > 5.0x segnala leva finanziaria speculativa su bilanci non finanziari.",
            ],
            benchmark_supervisory="Edward Altman (1968), Messod Beneish (1999), Richard Sloan (1996) Accounting Review & Basel III Corporate IRB Default Models."
        )


# ── TAB 5: VALUTAZIONE INTRINSECA DCF MONTE CARLO ─────────────────────
elif active_val_tab == "🧮 Valutazione Intrinseca DCF Monte Carlo":
    col_head_dcf1, col_head_dcf2 = st.columns([3.0, 1.4])
    with col_head_dcf1:
        st.markdown("### 🧮 Modello di Valutazione Intrinseca DCF Monte Carlo")
        st.caption("Stima il Fair Value intrinseco aziendale attualizzando i Flussi di Cassa Liberi (FCF) al WACC ed eseguendo 1.000 simulazioni stocastiche sui parametri chiave.")
    with col_head_dcf2:
        st.markdown('<div style="margin-top: 6px;"></div>', unsafe_allow_html=True)
        glossary_modal("📚 Guida al DCF Monte Carlo", """
<div style="font-size: 13.5px; line-height: 1.45;">

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px; margin-bottom: 8px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">📌 Cos'è il Discounted Cash Flow (DCF) con Simulazione Stocastica</div>
  <div>La metodologia quantitativa fondamentale per determinare il valore economico di un'azienda sommando i flussi di cassa operativi futuri (Free Cash Flows to Firm) scontati al costo medio ponderato del capitale (WACC).</div>
</div>

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px; margin-bottom: 8px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">📐 Formule di Attualizzazione & Terminal Value</div>
  <div style="background: rgba(255,153,0,0.08); border-left: 3px solid #ff9900; padding: 6px 10px; border-radius: 6px; margin: 5px 0; color: #ffb74d; font-size: 12px; line-height: 1.45;">
    • <b>Enterprise Value:</b> &sum; [ FCF<sub>t</sub> / (1 + WACC)<sup>t</sup> ] + Terminal Value / (1 + WACC)<sup>5</sup><br>
    • <b>Terminal Value (Gordon Growth):</b> [ FCF<sub>5</sub> &times; (1 + g) ] / (WACC &minus; g)<br>
    • <b>Equity Value:</b> Enterprise Value + Cassa Disponibile &minus; Debito Finanziario Netto
  </div>
</div>

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px; margin-bottom: 8px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">🎯 A cosa serve</div>
  <div>Superare la staticità del DCF tradizionale introducendo una distribuzione di probabilità a 1.000 iterazioni su crescita ricavi, margini operativi, tasso risk-free e perpetual growth.</div>
</div>

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px; margin-bottom: 8px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">⚙️ Calcolo in ARGUS</div>
  <div>ARGUS calcola il WACC dinamico bottom-up (Beta, Equity Risk Premium, Cost of Debt net-tax) ed esegue la simulazione stocastica generando la distribuzione del Fair Value per azione.</div>
</div>

<div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 10px 14px;">
  <div style="font-weight: 700; color: #58a6ff; margin-bottom: 3px;">🔍 Come leggerlo</div>
  <div>
    • <b>Probabilità Sottovalutazione (%):</b> Percentuale di simulazioni in cui il Fair Value supera il prezzo attuale.<br>
    • <b>Margine di Sicurezza:</b> Distanza percentuale tra il prezzo di mercato e il 10° percentile prudenziale.
  </div>
</div>

</div>
""", button_label="💡 Guida al DCF Monte Carlo")

    try:
        from core.financial_analysis import compute_dcf_monte_carlo_valuation, fetch_dcf_initial_inputs
    except ImportError:
        import importlib

        import core.financial_analysis
        importlib.reload(core.financial_analysis)
        from core.financial_analysis import compute_dcf_monte_carlo_valuation, fetch_dcf_initial_inputs

    # ── RIGA 1: SELEZIONE AZIENDA & PARAMETRI MODELLO ──────────────────────
    st.markdown("#### ⚙️ Input & Parametri del Modello")
    
    col_sel1, col_sel2 = st.columns([1.3, 2.7])
    with col_sel1:
        search_mode_dcf = st.radio(
            "Modalità Selezione:",
            ["Portafoglio", "Cerca sul Mercato"],
            horizontal=True,
            key="radio_dcf_search"
        )
    with col_sel2:
        if search_mode_dcf == "Portafoglio":
            opts_dcf = list(company_options.keys())
            curr_dcf = st.session_state.get("selectbox_dcf_portfolio")
            if curr_dcf is not None and curr_dcf not in opts_dcf and opts_dcf:
                st.session_state["selectbox_dcf_portfolio"] = opts_dcf[0]
            dcf_tk = st.selectbox(
                "Seleziona Azienda dal Portafoglio:",
                opts_dcf,
                format_func=lambda x: f"{x} - {company_options[x]}" if company_options[x] != x else f"{x}",
                key="selectbox_dcf_portfolio"
            )
        else:
            custom_dcf_input = st.text_input(
                "Inserisci Ticker Azionario (es. AAPL, MSFT, NVDA, TSLA, RACE.MI, UCG.MI, DIS, NFLX):",
                value="GOOGL",
                key="text_dcf_custom"
            )
            dcf_tk = custom_dcf_input.upper().strip()

    dcf_name = resolve_company_name(dcf_tk)

    match_pos = active_pos[active_pos["ticker"] == dcf_tk] if "ticker" in active_pos.columns else pd.DataFrame()
    p_price_fallback = float(match_pos.iloc[0]["last_price"]) if not match_pos.empty and pd.notna(match_pos.iloc[0].get("last_price")) else 150.0

    dcf_defaults = fetch_dcf_initial_inputs(dcf_tk, fallback_price=p_price_fallback)
    dcf_currency = str(dcf_defaults.get("currency") or "USD").upper()
    CURR_SYMS = {
        "EUR": "€",
        "USD": "$",
        "GBP": "£",
        "GBp": "p",
        "CHF": "CHF",
        "JPY": "¥",
        "CAD": "C$",
        "AUD": "A$",
        "DKK": "kr",
        "SEK": "kr",
        "NOK": "kr",
        "HKD": "HK$",
    }
    dcf_curr_sym = CURR_SYMS.get(dcf_currency, dcf_currency)

    col_inp1, col_inp2, col_inp3 = st.columns(3)
    with col_inp1:
        input_price = st.number_input(f"Prezzo Spot Attuale ({dcf_curr_sym}):", value=max(0.01, float(dcf_defaults["price"])), min_value=0.01, step=1.0)
    with col_inp2:
        input_fcf = st.number_input(f"FCF Base Iniziale (M {dcf_curr_sym}):", value=max(0.01, float(dcf_defaults["fcf_m"])), min_value=0.01, step=500.0) * 1e6
    with col_inp3:
        input_shares = st.number_input("Azioni Diluite (Milioni):", value=max(0.01, float(dcf_defaults["shares_m"])), min_value=0.01, step=100.0) * 1e6

    with st.expander("🛠️ Parametri Avanzati di Simulazione (WACC, Tassi di Crescita & Volatilità)", expanded=False):
        c_adv1, c_adv2, c_adv3 = st.columns(3)
        with c_adv1:
            wacc_val = st.slider("WACC Medio (%):", 4.0, 16.0, 8.5, 0.25) / 100.0
            cash_val = st.number_input(f"Cassa Netta & Equivalenti (M {dcf_curr_sym}):", value=float(dcf_defaults["cash_m"])) * 1e6
        with c_adv2:
            growth_val = st.slider("Crescita FCF Anni 1-5 (%):", -5.0, 30.0, 8.5, 0.5) / 100.0
            debt_val = st.number_input(f"Debito Totale (M {dcf_curr_sym}):", value=float(dcf_defaults["debt_m"])) * 1e6
        with c_adv3:
            term_g_val = st.slider("Crescita Perpetua Terminale (%):", 0.5, 4.5, 2.5, 0.1) / 100.0
            n_sims = st.select_slider("Numero Iterazioni Monte Carlo:", options=[250, 500, 1000, 2000], value=1000)

    # Calcolo Simulazione Monte Carlo
    dcf_res = compute_dcf_monte_carlo_valuation(
        fcf_base=input_fcf,
        current_price=input_price,
        shares_outstanding=input_shares,
        cash_and_equiv=cash_val,
        total_debt=debt_val,
        growth_rate_mean=growth_val,
        wacc_mean=wacc_val,
        terminal_growth_mean=term_g_val,
        n_simulations=n_sims
    )

    st.divider()

    # ── RIGA 2: VERDETTO & 4 KPI HEAD CARDS A TUTTA LARGHEZZA ─────────────
    st.markdown(f"#### 🎯 Verdetto Valutazione: {dcf_res['recommendation']}")

    dk1, dk2, dk3, dk4 = st.columns(4)
    with dk1:
        metric_card("Fair Value Intrinseco", f"{dcf_curr_sym} {dcf_res['fair_value_median']:.2f}", f"Base Case: {dcf_curr_sym} {dcf_res['fair_value_base']:.2f}", True if dcf_res['upside_downside_pct'] > 0 else False)
    with dk2:
        metric_card("Prezzo Attuale di Mercato", f"{dcf_curr_sym} {dcf_res['current_price']:.2f}", f"Quotazione Spot ({dcf_currency})", True)
    with dk3:
        metric_card("Upside / Downside", f"{dcf_res['upside_downside_pct']:+.1f}%", "Margine di Sicurezza", True if dcf_res['upside_downside_pct'] > 0 else False)
    with dk4:
        metric_card("Probabilità Sottovalutazione", f"{dcf_res['prob_undervalued_pct']:.1f}%", f"{n_sims} Simulazioni", True if dcf_res['prob_undervalued_pct'] > 50 else False)

    st.divider()

    # ── RIGA 3: ISTOGRAMMA DISTRIBUZIONE MONTE CARLO & TABELLA SCENARI ────
    col_chart, col_scen = st.columns([1.65, 1.15])
    
    with col_chart:
        st.markdown(f"##### 📈 Distribuzione Monte Carlo del Fair Value | {dcf_name} ({dcf_tk})")
        
        sim_vals = dcf_res["simulated_fair_values"]
        fv_med = dcf_res["fair_value_median"]
        cur_p = dcf_res["current_price"]
        p10 = dcf_res["p10_bear_case"]
        p90 = dcf_res["p90_bull_case"]
        
        fig_dcf_hist = go.Figure()
        fig_dcf_hist.add_trace(go.Histogram(
            x=sim_vals,
            nbinsx=45,
            name="Distribuzione DCF",
            marker=dict(
                color="rgba(0, 230, 118, 0.55)",
                line=dict(color="#00e676", width=1)
            ),
            hovertemplate=f"Intervallo Fair Value: <b>{dcf_curr_sym} %{{x:,.2f}}</b><br>Conteggio Simulazioni: <b>%{{y}}</b><extra></extra>"
        ))
        
        fig_dcf_hist.add_trace(go.Scatter(x=[None], y=[None], mode="lines", name=f"Mediana ({dcf_curr_sym} {fv_med:.2f})", line=dict(color="#00e676", width=2.5, dash="solid")))
        fig_dcf_hist.add_trace(go.Scatter(x=[None], y=[None], mode="lines", name=f"Prezzo ({dcf_curr_sym} {cur_p:.2f})", line=dict(color="#f85149", width=2, dash="dash")))
        fig_dcf_hist.add_trace(go.Scatter(x=[None], y=[None], mode="lines", name=f"Bear 10% ({dcf_curr_sym} {p10:.2f})", line=dict(color="#d29922", width=1.5, dash="dot")))
        fig_dcf_hist.add_trace(go.Scatter(x=[None], y=[None], mode="lines", name=f"Bull 90% ({dcf_curr_sym} {p90:.2f})", line=dict(color="#58a6ff", width=1.5, dash="dot")))
        
        fig_dcf_hist.add_vline(x=fv_med, line_dash="solid", line_color="#00e676", line_width=2.5)
        fig_dcf_hist.add_vline(x=cur_p, line_dash="dash", line_color="#f85149", line_width=2)
        fig_dcf_hist.add_vline(x=p10, line_dash="dot", line_color="#d29922", line_width=1.5)
        fig_dcf_hist.add_vline(x=p90, line_dash="dot", line_color="#58a6ff", line_width=1.5)
        
        fig_dcf_hist.update_layout(
            xaxis=dict(title=f"Fair Value Stimato ({dcf_curr_sym})", gridcolor="rgba(255,255,255,0.06)"),
            yaxis=dict(title="Frequenza Simulazioni", gridcolor="rgba(255,255,255,0.06)"),
            legend=dict(
                orientation="h",
                yanchor="bottom",
                y=1.02,
                xanchor="center",
                x=0.5,
                font=dict(size=11, color="#ffffff"),
                bgcolor="rgba(22, 27, 34, 0.6)",
                bordercolor="rgba(255,255,255,0.08)",
                borderwidth=1
            ),
            template="plotly_dark",
            height=360,
            margin=dict(l=20, r=20, t=45, b=25),
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)"
        )
        apply_plotly_theme(fig_dcf_hist)
        st.plotly_chart(fig_dcf_hist, use_container_width=True, key="val_dcf_mc_histogram", config={"displayModeBar": "hover", "displaylogo": False})

    with col_scen:
        st.markdown("##### 📋 Matrice di Sensibilità & Scenari")
        df_dcf_scenarios = pd.DataFrame([
            {"Scenario": "🐻 Bear Case (10° Percentile)", "Fair Value": f"{dcf_curr_sym} {dcf_res['p10_bear_case']:.2f}", "Upside/Downside": f"{((dcf_res['p10_bear_case']-dcf_res['current_price'])/dcf_res['current_price'])*100:+.1f}%"},
            {"Scenario": "⚖️ Base Case (Mediana DCF)", "Fair Value": f"{dcf_curr_sym} {dcf_res['fair_value_median']:.2f}", "Upside/Downside": f"{dcf_res['upside_downside_pct']:+.1f}%"},
            {"Scenario": "🐂 Bull Case (90° Percentile)", "Fair Value": f"{dcf_curr_sym} {dcf_res['p90_bull_case']:.2f}", "Upside/Downside": f"{((dcf_res['p90_bull_case']-dcf_res['current_price'])/dcf_res['current_price'])*100:+.1f}%"}
        ])
        st.dataframe(df_dcf_scenarios, use_container_width=True, hide_index=True, height=210)
        
        st.info(f"💡 **Sintesi Strategica**: Con una probabilità di sottovalutazione del **{dcf_res['prob_undervalued_pct']:.1f}%**, il titolo quota a **{abs(dcf_res['upside_downside_pct']):.1f}%** {'a premio' if dcf_res['upside_downside_pct'] < 0 else 'a sconto'} rispetto al Fair Value intrinseco mediano.")

        render_sr117_audit_drawer(
            engine_name="Stochastic Monte Carlo DCF & WACC Intrinsic Valuation Engine",
            latex_formulas=[
                r"\text{Enterprise Value} = \sum_{t=1}^T \frac{\text{FCFF}_t}{(1 + \text{WACC})^t} + \frac{\text{FCFF}_T (1 + g)}{(\text{WACC} - g)(1 + \text{WACC})^T}",
                r"\text{WACC} = \frac{E}{E+D} K_e + \frac{D}{E+D} K_d (1 - \tau_c) \quad \text{con } K_e = R_f + \beta (R_m - R_f)",
                r"\text{Equity Value} = \text{Enterprise Value} + \text{Cash} - \text{Total Debt} - \text{Minorities}",
            ],
            assumptions=[
                "Crescita terminale g compresa tra 1.5% e 2.5% per rispettare la convergenza di lungo termine al PIL globale nominale.",
                "Costo del capitale proprio Ke determinato tramite CAPM con beta rettificato (Vasicek/Blume) e Equity Risk Premium di mercato.",
                "1.000 iterazioni stocastiche Monte Carlo con distribuzioni normali troncate su tassi di crescita, WACC e margini EBITDA.",
            ],
            risk_limits=[
                "WACC deve essere strettamente maggiore di g (WACC - g > 0.5%) per evitare divergenze asintotiche nella formula di Gordon.",
                "Probabilità di sottovalutazione < 30% attiva warning di sopravvalutazione speculativa.",
                "Margine di sicurezza minimo richiesto: +20% per raccomandazione 'Strong Buy' istituzionale.",
            ],
            benchmark_supervisory="Aswath Damodaran Valuation Standards, CFA Institute GIPS & Federal Reserve SR 11-7 Model Risk Management."
        )




