"""
ARGUS — Risk Analytics Platform
Unit Tests for Reinforcement Learning Dynamic Portfolio Optimization
"""

import numpy as np
import pandas as pd
import pytest

from core.reinforcement_learning import PortfolioEnv, RLPolicyAgent, train_and_evaluate_rl_portfolio


def test_rl_environment_step_and_reward():
    np.random.seed(42)
    dates = pd.date_range("2023-01-01", periods=100, freq="B")
    data = {
        "AAPL": np.random.normal(0.0005, 0.015, 100),
        "MSFT": np.random.normal(0.0004, 0.012, 100),
        "BND": np.random.normal(0.0001, 0.003, 100),
    }
    df_rets = pd.DataFrame(data, index=dates)
    
    env = PortfolioEnv(df_rets, window_size=20, reward_type="sortino")
    state = env.reset()
    assert len(state) == 3 * 3 # 3 features * 3 assets = 9
    
    action = np.array([0.5, 0.3, 0.2])
    next_state, reward, done, info = env.step(action)
    
    assert len(next_state) == 9
    assert isinstance(reward, float)
    assert not done
    assert "net_return" in info
    assert "weights" in info


def test_rl_policy_agent_forward_simplex():
    agent = RLPolicyAgent(state_dim=9, action_dim=3)
    dummy_state = np.random.randn(9)
    weights = agent.forward(dummy_state)
    
    assert len(weights) == 3
    assert np.all(weights >= 0)
    assert pytest.approx(float(np.sum(weights)), 1e-5) == 1.0


def test_train_and_evaluate_rl_portfolio():
    np.random.seed(42)
    dates = pd.date_range("2023-01-01", periods=120, freq="B")
    data = {
        "NVDA": np.random.normal(0.001, 0.02, 120),
        "JNJ": np.random.normal(0.0002, 0.008, 120),
        "TLT": np.random.normal(-0.0001, 0.006, 120),
    }
    df_rets = pd.DataFrame(data, index=dates)

    rl_res = train_and_evaluate_rl_portfolio(df_rets, episodes=10, window_size=20, rebalance_days=21)
    assert rl_res["has_data"] is True
    assert not rl_res["learning_curve"].empty
    assert not rl_res["backtest_df"].empty
    assert "rl_equity_curve" in rl_res["backtest_df"].columns
    assert "ew_equity_curve" in rl_res["backtest_df"].columns
    assert "rl_stats" in rl_res
    assert "ew_stats" in rl_res
    assert "final_weights" in rl_res
    assert rl_res["rebalance_days"] == 21

    # Rewards should be reasonable and bounded, not -1500 or -5000
    cum_rewards = rl_res["learning_curve"]["cumulative_reward"]
    assert cum_rewards.min() > -500.0


def test_portfolio_env_periodic_rebalancing_and_drift():
    np.random.seed(42)
    dates = pd.date_range("2023-01-01", periods=50, freq="B")
    data = {
        "A": [0.05] * 50,  # Asset A consistently gains 5%
        "B": [-0.02] * 50, # Asset B loses 2%
    }
    df_rets = pd.DataFrame(data, index=dates)

    env = PortfolioEnv(df_rets, window_size=10, rebalance_days=5, turnover_penalty=0.001)
    env.reset()

    # Step 0: rebalance day ((0) % 5 == 0)
    _, _, _, info0 = env.step(np.array([0.5, 0.5]))
    assert info0["is_rebalance"] is True

    # Step 1: non-rebalance day ((1) % 5 != 0) -> weights drift, turnover=0
    _, _, _, info1 = env.step(np.array([0.8, 0.2]))  # target ignored on non-rebalance day
    assert info1["is_rebalance"] is False
    assert info1["turnover"] == 0.0
    # Because A gained 5% and B lost 2%, active weight of A should have drifted higher than 0.50
    assert info1["weights"][0] > 0.50

