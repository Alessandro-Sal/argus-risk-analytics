# ============================================================
# tests/test_wealth_reporting_hub.py
# Unit tests for Wealth Reporting Hub & Multi-Format Exporters
# ============================================================

import io
import json

import pandas as pd
import pytest

from core.fetcher import get_engine
from core.quarterly_report_generator import generate_white_label_quarterly_pdf_report
from core.voice_advisor_engine import generate_ai_voice_executive_briefing
from core.wealth.wealth_engine import (
    compute_fiscal_analytics,
    generate_advisory_pitchbook_pdf,
    generate_executive_tear_sheet_pdf,
)
from core.wealth.wealth_exporter import export_wealth_master_excel_workbook
from core.wealth.wealth_reporting_hub import render_wealth_reporting_and_exports_hub


def test_white_label_quarterly_pdf_generation():
    engine = get_engine()
    pdf_bytes = generate_white_label_quarterly_pdf_report(
        engine, portfolio_id=1, client_name="Family Office Test", quarter="Q1 2026"
    )
    assert isinstance(pdf_bytes, bytes)
    assert len(pdf_bytes) > 1000
    assert pdf_bytes.startswith(b"%PDF")


def test_advisory_pitchbook_pdf_generation():
    engine = get_engine()
    pdf_bytes = generate_advisory_pitchbook_pdf(engine, portfolio_id=1)
    assert isinstance(pdf_bytes, bytes)
    assert len(pdf_bytes) > 1000
    assert pdf_bytes.startswith(b"%PDF")


def test_executive_tear_sheet_pdf_generation():
    engine = get_engine()
    pdf_bytes = generate_executive_tear_sheet_pdf(engine, portfolio_id=1)
    assert isinstance(pdf_bytes, bytes)
    assert len(pdf_bytes) > 500
    assert pdf_bytes.startswith(b"%PDF")


def test_master_excel_workbook_export():
    engine = get_engine()
    xl_buf = export_wealth_master_excel_workbook(engine, portfolio_id=1)
    assert isinstance(xl_buf, io.BytesIO)
    xl_bytes = xl_buf.getvalue()
    assert len(xl_bytes) > 2000
    # Check valid zip/xlsx signature (PK)
    assert xl_bytes.startswith(b"PK")


def test_parquet_and_csv_export_structures():
    engine = get_engine()
    from core.wealth.wealth_db import get_cashflow_records
    df_tx = get_cashflow_records(engine, portfolio_id=1)
    
    # Parquet
    pq_buf = io.BytesIO()
    df_tx.to_parquet(pq_buf, index=False)
    assert len(pq_buf.getvalue()) > 0

    # CSV
    csv_bytes = df_tx.to_csv(index=False).encode("utf-8")
    assert len(csv_bytes) > 0


def test_voice_script_generation_for_reporting_hub():
    engine = get_engine()
    vb = generate_ai_voice_executive_briefing(engine, portfolio_id=1, client_name="Family Office Test")
    assert "full_text_transcript" in vb
    assert len(vb["full_text_transcript"]) > 100
    assert "dialogue_script" in vb
    assert len(vb["dialogue_script"]) >= 2


def test_wealth_spotlight_palette_and_mnemonics():
    from core.ui_utils import parse_terminal_command, render_wealth_spotlight_palette
    
    cmd_nw = parse_terminal_command("NETWORTH")
    assert cmd_nw is not None
    assert "Patrimonial" in cmd_nw["title"]
    assert "13_" in cmd_nw["page"]

    cmd_cf = parse_terminal_command("CASHFLOW")
    assert cmd_cf is not None
    assert "14_" in cmd_cf["page"]

    cmd_wt = parse_terminal_command("WTIME")
    assert cmd_wt is not None
    assert "13_" in cmd_wt["page"]

    cmd_rep = parse_terminal_command("REPORTS")
    assert cmd_rep is not None
    assert "12_" in cmd_rep["page"]

    assert callable(render_wealth_spotlight_palette)
